"""Instance identity — lets several Green Receipts deployments run side by side on ONE Windows
login without sharing any local state (e.g. an operator's own AL next to their clients' firm deployment, or
the owner's own account next to a friend's).

An instance is named by ``GR_INSTANCE`` (set by config.bat). Unset/empty = the DEFAULT instance,
which keeps every legacy location byte-for-byte (``~/.config/green_receipts``, app port 8756,
bridge port 18482, ``%APPDATA%\\Green Receipts``) so existing installs are untouched.

A NAMED instance gets:
  - its own config dir   ``~/.config/green_receipts/instances/<name>/`` (registry, receipts,
    logs, dedupe seen-files, last_capture.json, bridge_token, Drive token);
  - its own app-data dir ``%APPDATA%\\Green Receipts\\<name>\\`` (app.log);
  - its own ports, which MUST be set explicitly (GR_APP_PORT / GR_BRIDGE_PORT) and must differ
    from the default instance's. Fail-closed: a named instance that would fall back to the default
    ports could reopen the OTHER instance's window or pair with the OTHER instance's extension.

Everything here is read from the environment at call time, so tests can monkeypatch os.environ.
Module name is ``instance`` (repo root) so emit.py, the app and the bridge can all import it.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

DEFAULT_APP_PORT = 8756
DEFAULT_BRIDGE_PORT = 18482
APP_NAME = "Green Receipts"

_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,31}$")


class InstanceConfigError(RuntimeError):
    """The instance settings in config.bat are missing or unsafe (refuse to start)."""


def name() -> str:
    """The instance slug ('' = the default instance). Lower-case letters, digits, dashes."""
    raw = (os.environ.get("GR_INSTANCE") or "").strip().lower()
    if raw in ("", "default"):
        return ""
    if not _NAME_RE.match(raw):
        raise InstanceConfigError(
            f"GR_INSTANCE={raw!r} is not a valid instance name — use 1-32 lower-case letters, "
            "digits or dashes (e.g. 'operator-b', 'firm-clients').")
    return raw


def is_default() -> bool:
    return name() == ""


def label() -> str:
    """Human label shown in the window title + UI header ('' for the default instance)."""
    n = name()
    if not n:
        return ""
    return (os.environ.get("GR_INSTANCE_LABEL") or "").strip() or n.replace("-", " ").title()


def display_name() -> str:
    lb = label()
    return f"{APP_NAME} — {lb}" if lb else APP_NAME


def config_dir() -> Path:
    """Root of this instance's local state. Default instance = the legacy location."""
    base = Path.home() / ".config" / "green_receipts"
    n = name()
    return base / "instances" / n if n else base


def appdata_dir() -> Path:
    """Where app.log lives (%APPDATA%\\Green Receipts[\\<name>])."""
    base = Path(os.environ.get("APPDATA") or str(Path.home())) / APP_NAME
    n = name()
    return base / n if n else base


def _port(var: str, default: int) -> int:
    raw = (os.environ.get(var) or "").strip()
    if not raw:
        if is_default():
            return default
        raise InstanceConfigError(
            f"Instance {name()!r} has no {var} in config.bat. A named instance needs its own "
            f"ports so it can never reach another instance's app or extension.")
    try:
        port = int(raw)
    except ValueError:
        raise InstanceConfigError(f"{var}={raw!r} is not a port number.") from None
    if not 1024 <= port <= 65535:
        raise InstanceConfigError(f"{var}={port} is outside 1024-65535.")
    if not is_default() and port in (DEFAULT_APP_PORT, DEFAULT_BRIDGE_PORT):
        raise InstanceConfigError(
            f"Instance {name()!r} uses {var}={port}, which belongs to the default instance. "
            "Pick a different port.")
    return port


def app_port() -> int:
    return _port("GR_APP_PORT", DEFAULT_APP_PORT)


def bridge_port() -> int:
    return _port("GR_BRIDGE_PORT", DEFAULT_BRIDGE_PORT)


def validate() -> None:
    """Resolve everything once at startup so a bad config.bat fails loudly and early."""
    name()
    a, b = app_port(), bridge_port()
    if a == b:
        raise InstanceConfigError(f"GR_APP_PORT and GR_BRIDGE_PORT are both {a}; they must differ.")


# ---- the person using this install (docs/PLAN_MULTI_TENANCY.md step 3) -------------------------
# Several people of one firm work on the same sheet. Their name travels with what they do (the
# HISTORY and LOG tabs, and the "who is capturing" message), so "who did this?" has an answer.
# It is a label, not a login: it grants nothing and is stored in plain text next to the other
# per-install settings.
OPERATOR_FILE = "operator.json"
_OPERATOR_OK = re.compile(r"^[^\W\d_][\w .'\-]{1,39}$", re.UNICODE)


def clean_operator_name(raw) -> str:
    """A name fit to be written into a sheet cell and into an operator id: starts with a letter,
    then letters, digits, spaces, dot, apostrophe or dash, 2 to 40 characters. No @ # | = and no
    control characters, so it can neither start a formula nor be mistaken for a part of an id.
    Raises ValueError otherwise."""
    name = " ".join(str(raw or "").split())
    if not _OPERATOR_OK.match(name) or "_" in name:
        raise ValueError("Type your name with letters only (2 to 40 characters), for example "
                         "\"Ana\" or \"Ana Silva\".")
    return name


def operator_name() -> str:
    """The name saved for this install, or "" when none is saved or the file cannot be read."""
    try:
        import json
        data = json.loads((config_dir() / OPERATOR_FILE).read_text(encoding="utf-8"))
        return clean_operator_name(data.get("name"))
    except Exception:  # noqa: BLE001 — missing, unreadable or hand-edited badly: no name
        return ""


def set_operator_name(raw) -> str:
    import json
    name = clean_operator_name(raw)
    d = config_dir()
    d.mkdir(parents=True, exist_ok=True)
    (d / OPERATOR_FILE).write_text(json.dumps({"name": name}, ensure_ascii=False), encoding="utf-8")
    return name


def computer_name() -> str:
    import socket
    try:
        return socket.gethostname()[:60] or "computer"
    except Exception:  # noqa: BLE001
        return "computer"


def operator_label() -> str:
    """What is written as the author of a change: "Ana @ PC-ANA", or just the computer's name
    when no name is saved yet."""
    name = operator_name()
    return f"{name} @ {computer_name()}" if name else computer_name()


def describe() -> dict:
    """What /health reports — lets the UI (and a second launch) see WHICH instance is running."""
    return {"instance": name(), "instance_label": label(), "bridge_port": bridge_port()}
