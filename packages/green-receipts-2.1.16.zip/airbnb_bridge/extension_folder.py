"""Which folder did Chrome load the Green Receipts Bridge extension from?

Two Green Receipts installs on one computer (an operator's own and the firm's, or two operators')
each have their own ``airbnb_bridge/extensao`` folder, and each Chrome profile must load the
folder of ITS install. A profile that loads the OTHER install's folder works only while both
folders hold the same extension version. As soon as they differ, the strict version gate
(host_bridge.check_extension_version) refuses every capture, and the extension's self-reload
cannot help because Chrome re-reads the wrong folder.

Detection (no change to the extension, so it also works on the 0.8.0 extension already out):
  * Chrome sends ``Origin: chrome-extension://<id>`` in the WebSocket handshake of the extension's
    service worker. For an UNPACKED extension the id is a pure function of the folder path
    (see ``extension_id_for_path``).
  * This install computes the id of ITS OWN extension folder. A different id means Chrome loaded
    some other folder.
  * To NAME that folder, the ids of the sibling installs (the other folders next to this install,
    e.g. ``...\\Programs\\Green Receipts - Second``) are computed and compared. If none matches, the
    message says "another folder" and points at chrome://extensions -> Details -> "Loaded from".

Safety rules:
  * The strict version gate is never relaxed. A wrong folder with the SAME version is only a
    warning (capture works exactly as today); a wrong folder with a DIFFERENT version is today's
    refusal, with a plain explanation in place of the "Loaded from" hint.
  * Everything fails OPEN to today's behaviour: no Origin header (an older client, a test), an
    unparseable one, or any error while looking -> no verdict.
  * A false alarm cannot persist: the folder shown to the operator is the first spelling this
    module accepts, so following the fix always makes the ids agree.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import time
from pathlib import Path

log = logging.getLogger("airbnb_bridge")

ORIGIN_RE = re.compile(r"^chrome-extension://([a-p]{32})/?$")
STATE_ENV = "GR_EXTENSION_FOLDER_FILE"      # tests / unusual setups: where the last verdict is kept
STATE_NAME = "extension_folder.json"
MAX_SIBLINGS = 60                            # never walk an unreasonably large Programs folder


def extension_id_for_path(path, *, windows: bool | None = None) -> str:
    """The id Chrome gives an UNPACKED extension loaded from ``path``.

    components/crx_file/id_util.cc: SHA-256 of the absolute path (on Windows its UTF-16LE bytes,
    drive letter upper-cased, elsewhere its UTF-8 bytes), the first 16 bytes, each hex digit
    mapped to 'a'..'p'. Checked on 2026-11-24 against two real unpacked entries in a Chrome
    profile's Secure Preferences (exact match on both)."""
    windows = (os.name == "nt") if windows is None else windows
    p = str(path)
    if windows:
        if len(p) >= 2 and p[1] == ":" and p[0].isalpha():
            p = p[0].upper() + p[1:]
        raw = p.encode("utf-16-le")
    else:
        raw = p.encode("utf-8")
    digest = hashlib.sha256(raw).digest()[:16]
    return "".join(chr(ord("a") + (b >> 4)) + chr(ord("a") + (b & 15)) for b in digest)


def extension_id_from_origin(origin) -> str | None:
    """The extension id in an ``Origin: chrome-extension://<id>`` header, or None."""
    m = ORIGIN_RE.match(str(origin or "").strip())
    return m.group(1) if m else None


# ---- this install's own extension folder -------------------------------------------------------
def own_install_root() -> Path:
    """The install folder of THIS code: the code folder, or its parent when the code runs from an
    installed update (<install>/versions/<v>). Mirrors app.updater.install_root_for."""
    code_root = Path(__file__).resolve().parent.parent
    parent = code_root.parent
    if parent.name.lower() == "versions" and (parent.parent / "bootstrap.py").is_file():
        return parent.parent
    return code_root


def own_extension_dir() -> Path:
    """The folder Chrome must load: <install>/airbnb_bridge/extensao, exactly as the Settings
    screen shows it (resolved)."""
    return (own_install_root() / "airbnb_bridge" / "extensao").resolve()


def _spellings(folder) -> list[str]:
    """The path spellings Chrome could have stored for ``folder``: the resolved one first (the one
    the Settings screen tells the operator to paste), then the plain absolute one."""
    p = Path(folder)
    out: list[str] = []
    for cand in (lambda: str(p.resolve()), lambda: str(p.absolute()), lambda: str(p)):
        try:
            s = cand()
        except OSError:
            continue
        if s not in out:
            out.append(s)
    return out


def display_folder(folder) -> str:
    """The folder spelled the way the Settings screen shows it and tells the operator to paste."""
    return _spellings(folder)[0]


def expected_ids(folder) -> set[str]:
    return {extension_id_for_path(s) for s in _spellings(folder)}


def sibling_extension_dirs(ext_dir) -> list[Path]:
    """The extension folders of the OTHER installs next to this one (same parent folder), for
    naming the folder Chrome used. Bounded and quiet: any OS error just means fewer candidates."""
    out: list[Path] = []
    try:
        install = Path(ext_dir).resolve().parent.parent
        own = os.path.normcase(str(install))
        for i, child in enumerate(sorted(install.parent.iterdir())):
            if i >= MAX_SIBLINGS:
                break
            if os.path.normcase(str(child)) == own or not child.is_dir():
                continue
            cand = child / "airbnb_bridge" / "extensao"
            if (cand / "manifest.json").is_file():
                out.append(cand)
    except OSError:
        pass
    return out


def find_folder_for_id(ext_id: str, ext_dir) -> str | None:
    """The sibling install's extension folder whose Chrome id is ``ext_id``, or None."""
    for cand in sibling_extension_dirs(ext_dir):
        for s in _spellings(cand):
            if extension_id_for_path(s) == ext_id:
                return display_folder(cand)
    return None


def _instance_name() -> str:
    try:
        import instance
        return instance.display_name()
    except Exception:  # noqa: BLE001 — a bad config.bat must never hide the extension problem
        return "this Green Receipts"


def check_origin(origin, ext_dir=None, *, port: int | None = None, default_port: int = 18482) -> dict | None:
    """Compare the extension's handshake Origin with the id of THIS install's folder.

    Returns None when there is nothing to say (no/unreadable Origin, or the ids agree, or anything
    went wrong). Otherwise a problem dict: {kind, extension_id, chrome_folder (str|None), this_folder,
    this_name, connection_number (int|None)} — connection_number is set when this install uses a
    port other than the default, because removing the extension from Chrome also clears the number
    typed in its popup."""
    try:
        ext_id = extension_id_from_origin(origin)
        if not ext_id:
            return None
        folder = Path(ext_dir) if ext_dir is not None else own_extension_dir()
        if ext_id in expected_ids(folder):
            return None
        return {
            "kind": "other_folder",
            "extension_id": ext_id,
            "chrome_folder": find_folder_for_id(ext_id, folder),
            "this_folder": display_folder(folder),
            "this_name": _instance_name(),
            "connection_number": port if (port is not None and port != default_port) else None,
        }
    except Exception as e:  # noqa: BLE001 — fail OPEN: no verdict means today's behaviour
        log.debug("extension folder check skipped: %s", e)
        return None


# ---- the words ---------------------------------------------------------------------------------
def fix_steps(problem: dict) -> str:
    """The exact fix, in the order the operator does it."""
    steps = (f"in that same Chrome profile, open chrome://extensions, click Remove on 'Green Receipts "
             f"Bridge', click Load unpacked and choose {problem['this_folder']}")
    num = problem.get("connection_number")
    if num:
        steps += (f", then click the Green Receipts Bridge icon, type {num} in 'Connection number' and "
                  f"click Save (removing the extension clears the number)")
    return steps + "."


def message(problem: dict, *, running: str | None = None, disk: str | None = None) -> str:
    """Plain words for a problem. With ``running``/``disk`` (a version mismatch) this is the
    capture refusal; without them, the warning shown while capture still works."""
    where = (f"from {problem['chrome_folder']}, which is another Green Receipts on this computer"
             if problem.get("chrome_folder") else
             "from a folder that is not this one (chrome://extensions -> Green Receipts Bridge -> "
             "Details -> 'Loaded from' shows which)")
    own = f"This install's own extension folder ({problem.get('this_name') or 'Green Receipts'}) is {problem['this_folder']}."
    if running and disk:
        head = (f"Capture is ABORTED: Chrome is running Green Receipts Bridge v{running} but this Green "
                f"Receipts has v{disk}, and Chrome loaded the extension {where}. Reloading it cannot "
                f"update it, because Chrome re-reads that other folder. {own}")
    else:
        head = (f"Chrome loaded the Green Receipts Bridge extension {where}. {own} Capture works for now "
                "only because both folders hold the same extension version; the next update of either "
                "one will stop captures.")
    return f"{head} Fix: {fix_steps(problem)}"


# ---- the last verdict, kept for the Settings screen and the capture result -----------------------
def state_path() -> Path:
    override = os.environ.get(STATE_ENV)
    if override:
        return Path(override)
    import instance
    return instance.config_dir() / STATE_NAME


def _same(a, b) -> bool:
    return os.path.normcase(os.path.normpath(str(a))) == os.path.normcase(os.path.normpath(str(b)))


def record(problem: dict | None, this_folder) -> None:
    """Remember the latest verdict for ``this_folder`` (None = Chrome loads the right folder).
    Best-effort: a failed write never affects capture. Unchanged verdicts are not rewritten."""
    try:
        p = state_path()
        prev = last_problem(this_folder)
        if (prev is None) == (problem is None) and (
                problem is None or (prev.get("extension_id") == problem.get("extension_id")
                                    and prev.get("message") == problem.get("message"))):
            return
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(p.name + f".{os.getpid()}.tmp")
        tmp.write_text(json.dumps({"at": time.strftime("%Y-%m-%dT%H:%M:%S"), "this_folder": str(this_folder),
                                   "problem": problem}, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, p)
    except Exception as e:  # noqa: BLE001
        log.debug("could not record the extension folder verdict: %s", e)


def last_problem(this_folder=None) -> dict | None:
    """The last recorded problem, or None (none recorded, unreadable, or recorded for another
    folder — e.g. this install was moved)."""
    try:
        data = json.loads(state_path().read_text(encoding="utf-8"))
        prob = data.get("problem")
        if not isinstance(prob, dict):
            return None
        if this_folder is not None and not _same(data.get("this_folder", ""), this_folder):
            return None
        return {**prob, "at": data.get("at")}
    except Exception:  # noqa: BLE001
        return None
