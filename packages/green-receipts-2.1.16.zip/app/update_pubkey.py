"""app/update_pubkey.py — the public keys this app accepts on an update manifest.

With an EMPTY list the updater refuses EVERY manifest (fail closed), so an install that has
GR_UPDATE_URL set but no key simply never updates. The list was empty until the release owner
made the signing key (2026-11-12); it now holds that key.

The release owner fills this with `python tools/release_sign.py keygen` (it writes the public half
here; the private half goes to %USERPROFILE%\\.config\\green_receipts_release\\ and never into the
repo, a bundle or an upload). Each entry is a 64-character hex Ed25519 public key (public, not a
secret). To rotate: add the new key here, ship that release signed with the OLD key, then sign
later releases with the new key and remove the old one in a later release.

Tests never use this list: they pass their own throwaway keys to the updater.
"""

ACCEPTED_KEYS: list[str] = [
    "0c6a4f7c3c9a41edff9682a38abca16adb067a3ef85fc4b947edebb54b2e8f7f",
]
