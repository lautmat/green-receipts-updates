#!/usr/bin/env python3
"""Live capture entry-point — drives the Green Receipts Bridge extension.

This is the self-driving capture path (decision C): it starts the local WS bridge,
waits for the MV3 extension running in YOUR logged-in Chrome to connect, HARD-ABORTS
if the extension is stale, then pages your completed reservations + their VAT
invoices THROUGH THE EXTENSION (which attaches your warm session cookies) and maps
each to a canonical green-receipt row.

  # The owner's path — dry-run against your own account (NOTHING is written):
  python tools/live_capture.py --account my-airbnb --dry-run

  # An operator's path — POST the rows to the serializer:
  python tools/live_capture.py --account client-x \
      --serializer-url <EXEC_URL> --token <TOKEN>

One-time extension install (the only manual step):
  1. chrome://extensions  ->  toggle ON "Developer mode" (top-right)
  2. "Load unpacked"  ->  select  airbnb_bridge/extensao
  3. The toolbar puff should show "Connected" once this script is running.

A login/OTP wall PAUSES the run (exit 2) — log in in your own Chrome tab and
re-run; the OTP never leaves your browser.
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import re
import socket
import sys
import uuid
from datetime import date, timedelta
from pathlib import Path

# Force UTF-8 stdout/stderr: under captura.bat (a real console on a Portuguese-locale machine the
# default code page is cp850/1252) printing a guest name with an emoji/CJK char would raise
# UnicodeEncodeError mid-capture. Mirror emit_receipt.py's guard so display can never crash.
for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, "reconfigure"):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import log_client
from airbnb_bridge import reservations_adapter as A
from airbnb_bridge.host_bridge import BridgeError, host_bridge


def default_operator_id() -> str:
    """Unique PER PROCESS — the serializer treats identical operator ids as the SAME
    holder (claims, leases, locks), so a shared static default would make two
    concurrent runs indistinguishable (review finding B3)."""
    return f"capture@{socket.gethostname()}#{uuid.uuid4().hex[:8]}"


def parse_args(argv=None):
    p = argparse.ArgumentParser(description="Drive the Green Receipts Bridge extension to capture reservations.")
    p.add_argument("--account", required=True, help="Airbnb account identifier (tags airbnb_account_id; NOT a credential).")
    p.add_argument("--since", help="lower edge YYYY-MM-DD (default: 90 days ago).")
    p.add_argument("--until", help="upper edge YYYY-MM-DD, ends_before (default: today).")
    p.add_argument("--dry-run", action="store_true", help="map + reconcile but do NOT POST to the serializer (the owner's dry-run path).")
    p.add_argument("--serializer-url", help="Apps Script /exec endpoint (required unless --dry-run).")
    p.add_argument("--token", help="serializer api_token (required unless --dry-run).")
    p.add_argument("--operator-id", default=None,
                   help="operator_id recorded in HISTORY (default: capture@<hostname>#<uuid8>, "
                        "unique per run — never share one id across concurrent runs).")
    p.add_argument("--listing", action="append", dest="listings", help="restrict to this listing_id_str (repeatable).")
    p.add_argument("--allow-any-listing", action="store_true",
                   help="ADMIN ONLY: turn off the multi-tenant listing firewall (by default only stays on "
                        "this deployment's active Property Settings listings are captured, and a session "
                        "whose newest stays are all foreign is refused as the wrong Airbnb account).")
    p.add_argument("--account-total", type=float, help="independent account payout total for the completeness reconcile.")
    p.add_argument("--connect-timeout", type=float, default=120.0, help="seconds to wait for the extension to connect.")
    p.add_argument("--bridge-token", nargs="?", const="auto", default=None,
                   help="enforce the shared bridge token (multi-user hardening). Bare flag = load/mint "
                        "this instance's bridge_token file (paste it into the extension popup once); "
                        "or pass an explicit value. Omit to disable (single-user default).")
    p.add_argument("--seen-file", help="path to a newline-delimited cache of already-captured HM codes. Read to "
                                       "SKIP their fee lookup (dedupe -> fewer requests); a real (non-dry) run appends "
                                       "the stays it actually stored. Keeps repeat runs nearly silent.")
    p.add_argument("--pace-min", type=float, default=0.5, help="min seconds of jitter before each fee lookup (anti-velocity).")
    p.add_argument("--pace-max", type=float, default=2.0, help="max seconds of jitter before each fee lookup (0 disables).")
    p.add_argument("--max-backfill-months", type=int, default=6,
                   help="HARD floor: never backfill stays whose CHECK-IN is older than this many months "
                        "(default 6; receipts aren't issued for older stays). 0 disables.")
    return p.parse_args(argv)


EXIT_WRONG_ACCOUNT = 5   # the listing firewall refused the session (none of its stays is ours)
EXIT_NO_LISTINGS = 6     # no active listing configured for this instance yet


def _instance_ctx() -> str:
    """One-line technical context for the logs: which instance, which ports/config dir."""
    try:
        import instance
        return (f"instance={instance.name() or 'default'} bridge_port={instance.bridge_port()} "
                f"app_port={instance.app_port()}")
    except Exception as e:  # noqa: BLE001 — diagnostics must never stop a capture
        return f"instance=? ({e})"


def owned_listing_ids() -> set[str]:
    """This deployment's active listings — the local registry synced from Property Settings
    (per instance, instance.py). Empty when nothing is configured yet."""
    from registry import load_registry
    try:
        reg = load_registry()
    except FileNotFoundError:
        return set()
    return {str(p.listing_id_str).strip() for p in reg.properties
            if p.active and str(p.listing_id_str).strip()}


def load_seen(path):
    if not path:
        return set()
    f = Path(path)
    if not f.exists():
        return set()
    return {ln.strip() for ln in f.read_text(encoding="utf-8").splitlines() if ln.strip()}


_HM_RE = re.compile(r"^[A-Za-z0-9]+$")


def append_seen(path, hms):
    if not path or not hms:
        return
    # Only persist well-formed HM codes — an embedded newline (e.g. from a spoofed
    # bridge) would otherwise write spurious 'seen' entries that suppress future fee
    # fetches (silent under-declaration).
    clean = [h for h in hms if _HM_RE.match(str(h))]
    bad = [h for h in hms if not _HM_RE.match(str(h))]
    if bad:
        print(f"WARNING: not persisting {len(bad)} malformed HM code(s) to the seen-file: {bad[:3]}", file=sys.stderr)
    f = Path(path)
    new = [h for h in clean if h not in load_seen(path)]
    if not new:
        return
    try:
        f.parent.mkdir(parents=True, exist_ok=True)
        with f.open("a", encoding="utf-8") as fh:
            for h in new:
                fh.write(h + "\n")
    except OSError as e:
        # Persistence failing must be LOUD — else next run silently re-fetches (safe)
        # but the operator thinks dedupe is working.
        print(f"WARNING: could not write the seen-file {path}: {e} (dedupe not saved)", file=sys.stderr)


def _d(s, default):
    return date.fromisoformat(s) if s else default


def print_report(rep: A.IngestReport):
    print("\n" + "=" * 64)
    print(f"CAPTURE REPORT  account={rep.account}  {rep.since} .. {rep.until}  dry_run={rep.dry_run}")
    print("=" * 64)
    print(f"  pages fetched        : {rep.pages_fetched}")
    print(f"  reservations seen    : {rep.reservations_seen}")
    print(f"  fee lookups          : {rep.fee_lookups}")
    print(f"  skipped already-seen : {rep.rows_skipped_seen}")
    print(f"  skipped > backfill   : {rep.rows_skipped_too_old}")
    print(f"  rows {'mapped' if rep.dry_run else 'ingested':14}: {rep.rows_ingested}")
    print(f"  skipped not-complete : {rep.rows_skipped_not_complete}")
    print(f"  needs review         : {rep.rows_needs_review}")
    if rep.reconcile is not None:
        r = rep.reconcile
        print(f"  reconcile            : {'OK' if r['ok'] else 'SHORTFALL %.2f' % r['shortfall']} "
              f"(captured {r['sum_payouts']:.2f} vs account {r['account_total']:.2f})")
    if rep.challenge:
        print("  >> CHALLENGE: a login/OTP wall PAUSED the run — period NOT complete.")
    if rep.dry_run and rep.rows:
        print("\n  HM           listing_id_str        guest                payout    fee    gross")
        print("  " + "-" * 78)
        for r in rep.rows:
            print("  %-12s %-21s %-20s %8.2f %6.2f %8.2f" % (
                r["hm_code"], r["listing_id_str"], (r["guest"] or "")[:20],
                r["paid_out"] or 0, r["service_fee"] or 0, r["gross_earnings"] or 0))
    if rep.errors:
        print("\n  notes / errors:")
        for e in rep.errors:
            print("   -", e)
    if rep.warnings:
        print("\n  signals (non-blocking — nothing is stopped by these):")
        for w in rep.warnings:
            print("   -", w)
    print()


async def run(args, on_report=None):
    since = _d(args.since, date.today() - timedelta(days=90))
    until = _d(args.until, date.today())
    args.operator_id = args.operator_id or default_operator_id()
    if args.seen_file is None and not args.dry_run:
        # Default ON for real runs (review finding: never enabled -> every month re-fetched
        # ~90 days of already-filed stays and flooded promote with duplicate-row noise).
        # Pass --seen-file "" to disable explicitly. Only durably-RESOLVED stays are ever
        # recorded, so quarantined/needs-review stays remain re-fetchable.
        safe = re.sub(r"[^A-Za-z0-9_-]", "_", args.account)
        import instance
        args.seen_file = str(instance.config_dir() / f"seen_{safe}.txt")
        Path(args.seen_file).parent.mkdir(parents=True, exist_ok=True)
        print(f"Dedupe cache: {args.seen_file}")
    if not args.dry_run and (not args.serializer_url or not args.token):
        print("ERROR: --serializer-url and --token are required unless --dry-run.", file=sys.stderr)
        return 1

    # Two-tier logging: always a local file; online (LOG tab) too when serializer
    # creds are present. Logging is best-effort and never blocks/fails the run.
    log = log_client.setup_logging("capture", operator_id=args.operator_id,
                                   serializer_url=args.serializer_url, api_token=args.token)
    log_client.log_event(log, logging.INFO, f"capture start {since}..{until} dry_run={args.dry_run}",
                         op="capture", entity_id=args.account)

    min_checkin = A.months_before(date.today(), args.max_backfill_months) if args.max_backfill_months > 0 else None
    if min_checkin:
        print(f"Backfill floor: skipping stays with check-in before {min_checkin} "
              f"(> {args.max_backfill_months} months old).")

    # Technical context for EVERY firewall decision below — goes to grv2.log AND the sheet's LOG tab
    # (the operator-facing prints stay plain; the admin debugs from the logs).
    ctx = _instance_ctx()
    owned = None
    if args.allow_any_listing:
        log_client.log_event(log, logging.WARNING, "listing firewall DISABLED (--allow-any-listing)",
                             op="capture", entity_id=args.account, result="firewall_off", detail=ctx)
    else:
        owned = owned_listing_ids()
        if not owned and args.dry_run:
            print("Preview: no rentals are set up in Property Settings yet, so every stay is shown.")
            log_client.log_event(log, logging.INFO, "listing firewall off for dry-run (0 owned listings)",
                                 op="capture", entity_id=args.account, result="firewall_off", detail=ctx)
            owned = None
        elif not owned:
            print("\nNothing was captured — no rentals are set up yet.\nFill in the rentals in Property "
                  "Settings in the Google Sheet, click Sync from Sheet in Settings, then capture again.",
                  file=sys.stderr)
            log_client.log_event(log, logging.ERROR, "capture refused: 0 active listings in the local "
                                 "registry (Property Settings empty or not synced)", op="capture",
                                 entity_id=args.account, result="refused_no_listings", detail=ctx)
            return EXIT_NO_LISTINGS
        else:
            print(f"Only stays for this app's {len(owned)} rental(s) will be captured.")
            log_client.log_event(log, logging.INFO, f"listing firewall ON: {len(owned)} owned listing(s)",
                                 op="capture", entity_id=args.account, result="firewall_on",
                                 detail=f"{ctx} owned={','.join(sorted(owned))}")

    seen = load_seen(args.seen_file)
    if seen:
        print(f"Dedupe: {len(seen)} already-captured stays loaded from {args.seen_file} (their fee won't be re-fetched).")

    print("Starting bridge — waiting for the Green Receipts Bridge extension to connect...")
    print("  (chrome://extensions -> Developer mode -> Load unpacked -> airbnb_bridge/extensao)")
    # Resolve the token ONCE and pass the explicit value (never "auto"), so the token
    # we PRINT is exactly the token enforced — even if the token file can't be persisted.
    bridge_token = args.bridge_token
    if bridge_token == "auto":
        from airbnb_bridge.host_bridge import load_or_mint_bridge_token
        bridge_token = load_or_mint_bridge_token()
        print(f"Bridge token enforcement ON. Paste this into the extension popup once:\n  {bridge_token}")
    elif bridge_token:
        print("Bridge token enforcement ON (using the value you passed; paste the same into the popup).")
    try:
        async with host_bridge(connect_timeout=args.connect_timeout, token=bridge_token) as bridge:
            info = bridge.extension_info or {}
            print(f"Extension connected: v{info.get('extensionVersion')} "
                  f"allowlist={info.get('allowlist')} methods={info.get('methods')}")
            # bridgePort = the connection number the extension itself was set to (0.7.0+): the key fact
            # when two instances share a laptop and the wrong Chrome profile answers.
            log_client.log_event(log, logging.INFO, "extension connected", op="capture",
                                 detail=f"v{info.get('extensionVersion')} "
                                        f"ext_bridge_port={info.get('bridgePort', 'n/a')} {ctx}")
            rep = await A.ingest_extension(
                args.account, since=since, until=until, dry_run=args.dry_run,
                bridge=bridge, serializer_url=args.serializer_url, api_token=args.token,
                operator_id=args.operator_id, listing_ids=args.listings,
                account_payout_total=args.account_total, min_checkin=min_checkin,
                seen_hm=seen, pace_min=args.pace_min, pace_max=args.pace_max,
                owned_listing_ids=owned,
            )
    except A.NoOwnedListingsError as e:
        print("\nNothing was captured — no rentals are set up yet.", file=sys.stderr)
        log_client.log_event(log, logging.ERROR, "capture refused: no owned listings", op="capture",
                             entity_id=args.account, result="refused_no_listings",
                             detail=f"{e} | {ctx}")
        return EXIT_NO_LISTINGS
    except A.AccountMismatchError as e:
        print("\nNothing was captured — Chrome is signed in to a different Airbnb account.\n"
              "Open the Chrome window where you're signed in to this app's Airbnb account, then "
              "capture again.", file=sys.stderr)
        log_client.log_event(log, logging.ERROR, "capture refused: account mismatch (0 owned listings "
                             "on the first reservations page)", op="capture", entity_id=args.account,
                             result="refused_wrong_account",
                             detail=f"{e} | page_listings={','.join(e.seen_listings)} "
                                    f"owned_count={e.owned_count} | {ctx}")
        return EXIT_WRONG_ACCOUNT
    except BridgeError as e:
        print(f"\nBRIDGE ABORT: {e}", file=sys.stderr)
        log_client.log_event(log, logging.ERROR, "bridge abort", op="capture", result="abort", detail=str(e))
        return 1
    print_report(rep)
    if on_report is not None:
        # Additive, backward-compatible: the desktop app reads the structured report
        # (counts/challenge) for its capture screen. The CLI/.bat path passes nothing.
        on_report(rep)
    log_client.log_event(log, logging.INFO,
                         f"capture done: seen={rep.reservations_seen} rows={rep.rows_ingested} "
                         f"needs_review={rep.rows_needs_review} skipped_old={rep.rows_skipped_too_old} "
                         f"challenge={rep.challenge}", op="capture", entity_id=args.account,
                         result="challenge" if rep.challenge else ("ok" if rep.rows_ingested else "empty"))
    for e in rep.errors:
        log_client.log_event(log, logging.WARNING, e, op="capture", result="needs_review")
    # Reconcile / completeness signals (rep.warnings) are the NON-BLOCKING "money paid not matched
    # to a captured stay" notices. They were only printed to stdout — persist them to the sheet LOG
    # tab too so the operator (and the admin) have a durable record of every run's unmatched-income gap.
    for w in rep.warnings:
        log_client.log_event(log, logging.WARNING, w, op="capture", result="signal")
    if rep.rows_skipped_foreign:
        log_client.log_event(log, logging.WARNING,
                             f"listing firewall skipped {rep.rows_skipped_foreign} stay(s) on "
                             f"{len(rep.foreign_counts)} foreign listing(s)", op="capture",
                             entity_id=args.account, result="skipped_foreign",
                             detail=f"per_listing={rep.foreign_counts} {ctx}")
    # Persist the seen-set only after a REAL run that actually stored stays (a dry-run
    # captures nothing, so marking it seen would wrongly skip it on the real run).
    if not args.dry_run and not rep.challenge and rep.captured_hms:
        append_seen(args.seen_file, rep.captured_hms)
        if args.seen_file:
            print(f"Dedupe: recorded {len(rep.captured_hms)} captured stays to {args.seen_file}.")
    if rep.challenge:
        return 2
    # "Zero reservations seen" is the EXACT shape of a silently-skipped month (a
    # cold session that 200s with {"reservations":[]}, an API-shape change, or an
    # over-aggressive window). Never let that read as clean success — make it loud.
    if rep.reservations_seen == 0:
        print("\n*** WARNING: 0 reservations returned. This is either a genuinely empty period OR a\n"
              "    cold/expired session / API change / too-narrow window. VERIFY MANUALLY before\n"
              "    treating this period as complete. ***", file=sys.stderr)
        return 3
    # B1: PROMOTE — the step that makes captured rows claimable by emit. Without it GR
    # stays empty and `emitir` reports "0 pending" forever (nothing else in the operator
    # flow calls the promote op). Runs on every clean REAL capture, which also heals rows
    # a previously-interrupted run left behind in STAGING. Promote fills GR only; nothing
    # is filed — the operator still reviews the sheet before emitting.
    if not args.dry_run:
        try:
            prep = A.post_promote(args.serializer_url, api_token=args.token,
                                  operator_id=args.operator_id)
            counts = prep.get("counts")
            if counts is None:  # serializer JSON refusal (busy / error body)
                raise A.IngestError(f"promote refused: {prep!r}")
            print(f"\nPromoted to the GR tab (ready for review, then emit): "
                  f"{counts.get('promote', 0)} promoted, "
                  f"{counts.get('quarantine', 0)} quarantined (listing not in Property Settings), "
                  f"{counts.get('needs_review', 0)} need review, "
                  f"{counts.get('excluded', 0)} excluded.")
            log_client.log_event(log, logging.INFO, f"promote done: {counts}", op="promote",
                                 entity_id=args.account, result="ok")
        except Exception as e:  # noqa: BLE001 — capture data is safe; only the promote is missing
            print(f"\n*** PROMOTE FAILED: the captured stays ARE saved (STAGING) but are NOT yet\n"
                  f"    claimable by emit. Re-run this capture to retry the promote. ({e}) ***",
                  file=sys.stderr)
            log_client.log_event(log, logging.ERROR, f"promote failed: {e}", op="promote",
                                 entity_id=args.account, result="error")
            return 4
    return 1 if rep.rows_needs_review and not rep.rows_ingested else 0


def _log_hint() -> str:
    try:
        import instance
        return str(instance.config_dir() / "logs" / "grv2.log")
    except Exception:  # noqa: BLE001 — a bad GR_INSTANCE must not mask the friendly stop
        return "grv2.log in your Green Receipts config folder"


def main(argv=None, on_report=None):
    """Operator-safe wrapper: a raw traceback must never be the operator's last screen
    (stage 3). Capture is read-only on Airbnb and idempotent on the sheet, so 'run it
    again' is always the safe instruction. `on_report` (optional) forwards the structured
    report to the desktop app; the CLI/.bat path passes nothing (unchanged)."""
    try:
        return asyncio.new_event_loop().run_until_complete(run(parse_args(argv), on_report=on_report))
    except KeyboardInterrupt:
        print("\nCancelled. Nothing is half-written: captured stays are saved, the rest "
              "will be picked up by the next run.")
        return 130
    except SystemExit:
        raise
    except Exception as e:  # noqa: BLE001 — the friendly stop; details go to the log
        logging.getLogger("grv2").exception("capture crashed")
        print(f"\nThe capture stopped safely: {e}\n"
              f"Nothing is lost — captured stays are saved and a re-run continues where it\n"
              f"stopped. Details: {_log_hint()}\n"
              f"Send the message above to your administrator, then run the capture again.",
              file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
