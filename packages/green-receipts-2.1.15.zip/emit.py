#!/usr/bin/env python3
"""Per-laptop emit entry point (the operator's `emitir` step).

Two modes:
  --dry-run (PREVIEW, read-only, SAFE): for each authorized taxpayer, list the GR
    rows that WOULD emit (no claim, no Portal). Use this first, every time.
  real emit: claim + emit each pending receipt at the Portal das Financas, one
    taxpayer at a time under its per-NIF emit lock, with the triple double-emission
    guard. The emit itself reuses the battle-tested v1 emit_one; the only v2 glue is
    building the AT login from the registry. emit_for_nif's G1-G4 guards (route +
    re-resolve + NIF + payload-identity) ABORT rather than emit on any identity
    mismatch, so a wrong-taxpayer/wrong-CAE receipt cannot be issued — but validate
    your first real run carefully. Real emit requires an explicit --taxpayer or
    --all (it never emits for every taxpayer implicitly).

  python emit.py --exec-url <URL> --token <TOK> --dry-run
  python emit.py --exec-url <URL> --token <TOK>            # real, all taxpayers
  python emit.py --exec-url <URL> --token <TOK> --taxpayer client_a --yes
"""
from __future__ import annotations

import argparse
import logging
import os
import socket
import sys
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import log_client
from emitter import SerializerClient, emit_for_nif, make_real_emit_fn
from registry import load_registry, resolve_credential


def default_operator_id() -> str:
    """Unique PER PROCESS ("{hostname}#{short_uuid}", V2_PLAN section 4.3).

    The serializer's claim + per-NIF emit-lock protocol treats an identical
    operator_id as the SAME holder (benign re-entry), so a shared static default
    would let two concurrent runs — e.g. a double-clicked emitir.bat — wave
    through both layers and double-file real receipts (review finding B3)."""
    return f"{socket.gethostname()}#{uuid.uuid4().hex[:8]}"


def confirm_real_emit(total: int, *, no_confirm: bool = False, input_fn=input) -> bool:
    """The ENFORCED human gate between capture and the irreversible filing.

    Review finding (major): the 'rever' step existed only in documentation — a
    double-clicked captura.bat followed by emitir.bat filed every promoted row at
    the Portal with no human having looked at the sheet. The preview is printed
    right above this prompt; the operator must type EMIT. `--no-confirm` is the
    explicit headless bypass (scheduled runs); a closed/failed stdin ABORTS —
    nothing is ever filed by default."""
    if no_confirm:
        return True
    try:
        answer = input_fn(
            f"\nAbout to file {total} REAL Fatura-Recibo(s) at the Portal das Financas.\n"
            f"This is IRREVERSIBLE. Review the rows above (and the GR tab) first.\n"
            f"Type EMIT to continue, anything else to abort: ")
    except (EOFError, KeyboardInterrupt):
        return False
    return answer.strip().upper() == "EMIT"


def select_taxpayers(reg, only):
    if only:
        if only not in reg.taxpayers:
            raise SystemExit(f"unknown taxpayer '{only}'. Known: {sorted(reg.taxpayers)}")
        return [reg.taxpayers[only]]
    return list(reg.taxpayers.values())


def preview(serializer, taxpayers) -> int:
    """Read-only: show what WOULD emit per taxpayer (no claim, no Portal)."""
    total = 0
    for t in taxpayers:
        rows = serializer.list_claimable([str(t.nif_prestador)])
        total += len(rows)
        print(f"\n  {t.taxpayer_id} (NIF {t.nif_prestador}): {len(rows)} receipt(s) pending")
        for r in rows:
            print("    %-12s %s  ttc=%s base=%s" % (r.get("hm_code"), r.get("service_date"),
                                                    r.get("ttc"), r.get("base")))
    print(f"\n  TOTAL pending across {len(taxpayers)} taxpayer(s): {total}")
    return total


def _login_profile(taxpayer, cred):
    """Build the v1 Profile used only to authenticate (login needs portal_nif +
    portal_password; emission identity comes from the per-property RowProfile)."""
    import profiles
    return profiles.Profile(
        name=taxpayer.taxpayer_id,
        portal_nif=cred.at_login_username, portal_password=cred.password,
        nif_prestador=taxpayer.nif_prestador, nome_prestador=taxpayer.nome_prestador,
        morada_fiscal_prestador=taxpayer.morada_fiscal_prestador,
        morada_fiscal=taxpayer.morada_fiscal,
        estabelecimento_comercial=taxpayer.estabelecimento_comercial,
        atividade_prestador="", atividade_prestador_descr="",
        spreadsheet_id="", sheet_name="",
        sheets_credentials_path=Path(), sheets_token_path=Path(), journal_path=Path(),
    )


def emit_real(serializer, reg, taxpayers, *, operator_id, assume_yes, log, v1_bridge=None,
              on_result=None, on_progress=None, should_stop=None) -> int:
    """`on_result(taxpayer, result_dict)` (optional) is invoked after each taxpayer with
    emit_for_nif's structured result (emitted/errored/in_doubt/skipped/...). Additive +
    backward-compatible: the CLI/.bat path passes nothing and is unaffected; the desktop
    app uses it to surface per-taxpayer outcomes (incl. IN_DOUBT) without a second emit path."""
    import requests
    from emit_receipt import get_latest_doc_number, login_result
    import archival
    import drive_uploader
    emit_fn = make_real_emit_fn()
    # Official-PDF archival: the receipt PDF is ALWAYS saved to a local folder (below); Google
    # Drive is an optional extra when its one-time consent is set up. Either way, emit runs and
    # PDFs can be backfilled later with tools/archive_receipt_pdf.py.
    pdf_root = archival.default_pdf_root()
    try:
        drive_files = drive_uploader.drive_service()
    except Exception as e:
        drive_files = None
        print(f"  (Google-Drive archival off — Drive not set up: {e}; PDFs still saved locally "
              f"to {pdf_root})", file=sys.stderr)
    emitted_total = 0
    summary = []   # (taxpayer_id, outcome) — a partial batch is NEVER silent

    def skip(t, why, result):
        print(f"  {t.taxpayer_id}: {why} — SKIPPED", file=sys.stderr)
        log_client.log_event(log, logging.WARNING, why, op="emit",
                             entity_id=str(t.nif_prestador), result=result)
        summary.append((t.taxpayer_id, "skipped: " + why))
        if on_result is not None:
            # Surface skips (esp. login_failed -> OTP screen) to the app with a normalized dict.
            on_result(t, {"emitted": 0, "errored": 0, "in_doubt": 0,
                          "skipped_reason": why, "result_code": result})

    for t in taxpayers:
        if should_stop is not None and should_stop():
            break   # operator hit Stop between taxpayers — file nothing more
        # A missing/locked credential must SKIP this taxpayer, not abort the whole
        # batch after earlier taxpayers already emitted (review finding).
        try:
            cred = resolve_credential(t, assume_yes=assume_yes)
        except Exception as e:
            skip(t, f"no credential ({e})", "no_cred")
            continue
        # Don't re-attempt a credential known to be BLOCKED / WRONG within its cooldown — each
        # retry extends an AT lockout. Files nothing; flows through skip() -> the honest UI screen.
        # DIVERGENCE HAZARD: this check -> login_result -> login_cache.record ritual is duplicated
        # from app/backend.py Backend._portal_login (which returns a dict); the emit loop keeps its
        # own copy because it must skip()/continue per taxpayer, not return. Keep the two in sync.
        import login_cache
        hit = login_cache.check(t.nif_prestador)
        if hit:
            skip(t, login_cache.guidance(hit), hit["kind"])
            continue
        # Nothing claimable for this taxpayer? Then don't log in at all: on a multi-client
        # "Issue all", each needless Portal login costs seconds AND an attempt against
        # lockout-sensitive credentials. One cheap serializer read decides. Fail-OPEN on a
        # read error (proceed to login) — emit_for_nif re-reads authoritatively either way.
        try:
            if not serializer.list_claimable([str(t.nif_prestador)]):
                summary.append((t.taxpayer_id, "nothing pending"))
                if on_result is not None:
                    on_result(t, {"emitted": 0, "errored": 0, "in_doubt": 0})
                continue
        except Exception:
            pass
        session = requests.Session()
        prof = _login_profile(t, cred)
        # CLASSIFIED login: the result_code carries WHY it failed (bad_credentials /
        # blocked / otp_required / portal_error) so the app shows the right screen
        # instead of collapsing every failure into a misleading "OTP" prompt.
        lr = login_result(session, prof)
        login_cache.record(t.nif_prestador, lr.kind, lr.message)   # success clears; block/bad stores
        if not lr.ok:
            skip(t, lr.message or "login failed", lr.kind)
            continue
        # Seed the per-taxpayer copy-source from the live Portal (v1 semantics — the
        # FIRST receipt copies the latest existing doc, not document 0).
        try:
            source_doc = [get_latest_doc_number(session, prof, assume_yes=assume_yes)]
        except Exception as e:
            skip(t, f"could not read latest doc number ({e})", "no_doc_number")
            continue
        # ALWAYS archive locally; add Drive when it's set up. (Previously archival was skipped
        # entirely when Drive wasn't configured — so no PDF was kept at all.)
        archiver = archival.make_pdf_archiver(portal_session=session, nif_prestador=t.nif_prestador,
                                              registry=reg, drive_files=drive_files,
                                              serializer=serializer, local_root=pdf_root)
        # A transient serializer refusal (busy/500) for THIS taxpayer now fails loud
        # (list_claimable/get_row raise). Contain it per taxpayer so a blip on #2 doesn't skip
        # #3 — already-filed rows are recorded/parked before any raise, so this is safe.
        try:
            res = emit_for_nif(registry=reg, taxpayer=t, serializer=serializer, cred=cred,
                               emit_fn=emit_fn, session=session, operator_id=operator_id,
                               source_doc=source_doc, archiver=archiver, v1_bridge=v1_bridge,
                               should_stop=should_stop,
                               on_progress=((lambda info, _t=t: on_progress({**info, "taxpayer": _t.nome_prestador}))
                                            if on_progress else None))
        except Exception as e:  # noqa: BLE001 — one taxpayer's blip must not abort the batch
            skip(t, f"serializer/emit error ({e}) — retry this taxpayer next run", "emit_error")
            continue
        emitted_total += res.get("emitted", 0)
        print(f"  {t.taxpayer_id} (NIF {t.nif_prestador}): {res}")
        if res.get("skipped"):
            # Per-run operator ids (B3) mean a crashed run's lock is NOT silently re-entered;
            # it expires server-side. Tell the operator what to do instead of a bare skip.
            print("    (another emit run is active for this taxpayer — or a previous run "
                  "crashed and its lock has not expired yet, ~20 min. Wait and re-run.)",
                  file=sys.stderr)
        # WARNING (not INFO) when rows errored or in-doubt so a LOG-tab filter for warnings actually
        # surfaces it — an all-errored run must not hide behind an INFO 'result:none' (2026-07-09: 4
        # rows errored on the 12-month dup-window bug and the run looked clean at INFO).
        _errored, _indoubt = res.get("errored", 0), res.get("in_doubt", 0)
        _level = logging.WARNING if (_errored or _indoubt) else logging.INFO
        _result = "error" if _errored else ("in_doubt" if _indoubt else ("ok" if res.get("emitted") else "none"))
        log_client.log_event(log, _level,
                             f"emit done {res.get('emitted',0)} ok / {_errored} err / "
                             f"{_indoubt} in_doubt / {res.get('archived',0)} pdf", op="emit",
                             entity_id=str(t.nif_prestador), result=_result)
        line = (f"{res.get('emitted',0)} emitted, {res.get('errored',0)} err, "
                f"{res.get('in_doubt',0)} in_doubt, {res.get('archived',0)} pdf-archived")
        if v1_bridge is not None:   # v1||v2 firewall tallies only when the firewall is on
            line += (f", {res.get('skipped_v1',0)} v1-skipped, "
                     f"{res.get('v1_write_failed',0)} v1-writeerr")
        summary.append((t.taxpayer_id, line))
        if on_result is not None:
            on_result(t, res)

    print("\n  --- resumo por contribuinte ---")
    for tid, st in summary:
        print(f"  {tid}: {st}")
    return emitted_total


def _main(argv=None):
    p = argparse.ArgumentParser(description="Emit pending Fatura-Recibo receipts (per-laptop).")
    p.add_argument("--exec-url", default=os.environ.get("GRV2_EXEC"), help="serializer /exec URL (or GRV2_EXEC).")
    p.add_argument("--token", default=os.environ.get("GRV2_TOKEN"), help="serializer api_token (or GRV2_TOKEN).")
    p.add_argument("--taxpayer", help="emit for ONE taxpayer slug.")
    p.add_argument("--all", action="store_true", help="emit for ALL taxpayers in the registry (explicit; required for real emit if --taxpayer is omitted).")
    p.add_argument("--operator-id", default=None,
                   help="operator id for claims/locks/HISTORY (default: <hostname>#<uuid8>, "
                        "unique per run — never share one id across concurrent runs).")
    p.add_argument("--dry-run", action="store_true", help="PREVIEW only — list what would emit (no Portal).")
    p.add_argument("--yes", action="store_true", help="non-interactive credentials (stored creds "
                   "only; never prompt). Does NOT skip the type-EMIT confirmation.")
    p.add_argument("--no-confirm", action="store_true",
                   help="skip the type-EMIT confirmation (headless/scheduled runs only).")
    p.add_argument("--v1-bridge", action="store_true",
                   help="v1||v2 firewall: reserve/writeback the matching legacy v1 GR-AB&B row so a "
                        "booking is filed by exactly one system (the v1 sheet must be reachable).")
    p.add_argument("--v1-sheet-id", default=os.environ.get("GRV2_V1_SHEET_ID"),
                   help="v1 GR-AB&B spreadsheet id for --v1-bridge (or GRV2_V1_SHEET_ID).")
    args = p.parse_args(argv)
    if not args.exec_url or not args.token:
        print("ERROR: --exec-url and --token (or GRV2_EXEC / GRV2_TOKEN) required.", file=sys.stderr)
        return 2

    operator_id = args.operator_id or default_operator_id()
    reg = load_registry()
    serializer = SerializerClient(args.exec_url, args.token)
    taxpayers = select_taxpayers(reg, args.taxpayer)
    log = log_client.setup_logging("emit", operator_id=operator_id,
                                   serializer_url=args.exec_url, api_token=args.token)

    if args.dry_run:
        print("PREVIEW (read-only — no receipts issued):")
        preview(serializer, taxpayers)
        return 0

    # Real emit: never issue receipts for every taxpayer implicitly (review finding).
    if not args.taxpayer and not args.all:
        print("ERROR: real emit needs --taxpayer <slug> OR --all. Refusing to emit for "
              "every taxpayer implicitly. (Use --dry-run to preview.)", file=sys.stderr)
        return 2

    # v1||v2 firewall (opt-in). Build it BEFORE emitting; if the operator asked for the firewall
    # but the v1 sheet is unreachable, REFUSE to emit rather than silently drop the protection.
    bridge = None
    if args.v1_bridge:
        try:
            import v1_bridge as v1b
            bridge = v1b.make_v1_bridge(spreadsheet_id=args.v1_sheet_id)
            print("  v1||v2 firewall: ON (reserving/writing back the matching v1 GR-AB&B rows).")
        except Exception as e:
            print(f"ERROR: --v1-bridge was requested but the v1||v2 firewall could not be enabled "
                  f"({e}). Refusing to emit without the firewall you asked for. The firewall is for "
                  f"the v1||v2 parallel period only — a v2-only deployment should simply omit "
                  f"--v1-bridge.", file=sys.stderr)
            return 2

    # The enforced review gate: show exactly what would file, then require typed consent.
    print("Pending receipts (preview):")
    total = preview(serializer, taxpayers)
    if total == 0:
        print("Nothing to emit.")
        return 0
    if not confirm_real_emit(total, no_confirm=args.no_confirm):
        print("Aborted — nothing was filed.")
        return 2

    print(f"EMITTING for real at the Portal das Financas … (run id: {operator_id})")
    n = emit_real(serializer, reg, taxpayers, operator_id=operator_id,
                  assume_yes=args.yes, log=log, v1_bridge=bridge)
    print(f"\nDONE — {n} receipt(s) emitted.")
    return 0


def _log_crash(msg: str) -> None:
    """Record a crash traceback in grv2.log WITHOUT ever leaking it to the operator's console.

    A crash BEFORE log_client.setup_logging() has run — the fresh-machine case: load_registry()
    raises "no taxpayers.toml — run setup.bat" three lines before logging is configured — leaves
    the 'grv2' logger with NO handler. logging.exception() then finds zero handlers anywhere and
    falls through to logging.lastResort -> stderr, so the operator gets exactly the raw traceback
    this wrapper exists to prevent, AND the details never reach the grv2.log the friendly message
    points them at. NOTE: propagate=False alone does NOT fix it — callHandlers() fires lastResort
    whenever it finds zero handlers, however the walk ended. A handler must exist: the real file
    sink (same path/format setup_logging uses), with a NullHandler as the floor. Best-effort
    throughout: logging must never mask the friendly stop. A crash AFTER setup_logging ran already
    has handlers, so this is a no-op there and that path is unchanged.
    """
    lg = logging.getLogger("grv2")
    if not lg.handlers:
        try:
            lg.propagate = False
            import instance
            d = instance.config_dir() / "logs"
            d.mkdir(parents=True, exist_ok=True)
            h = logging.FileHandler(d / "grv2.log", encoding="utf-8")
            h.setFormatter(logging.Formatter("%(asctime)s %(levelname)-7s [%(name)s] %(message)s"))
            lg.addHandler(h)
            lg.setLevel(logging.DEBUG)
        except Exception:  # noqa: BLE001 — can't open the log; still never leak to stderr
            lg.addHandler(logging.NullHandler())
    try:
        lg.exception(msg)
    except Exception:  # noqa: BLE001
        pass


def _crash_log_hint() -> str:
    try:
        import instance
        return str(instance.config_dir() / "logs" / "grv2.log")
    except Exception:  # noqa: BLE001 — a bad GR_INSTANCE must not mask the friendly stop
        return "grv2.log in your Green Receipts config folder"


def main(argv=None):
    """Operator-safe wrapper: a raw traceback must never be the operator's last screen
    (stage 3). Every receipt outcome is printed per taxpayer as the batch runs; each
    row's state is safe by design (filed rows are recorded or parked IN_DOUBT)."""
    try:
        return _main(argv)
    except KeyboardInterrupt:
        print("\nCancelled. Anything already filed is shown above; nothing else was touched.")
        return 130
    except Exception as e:  # noqa: BLE001 — the friendly stop; details go to the log
        _log_crash("emit crashed")
        print(f"\nThe run stopped safely: {e}\n"
              f"Anything already filed is shown in the summary above — no receipt is ever\n"
              f"lost or doubled by this stop. Details: {_crash_log_hint()}\n"
              f"Send the message above to your administrator, then run emitir again.",
              file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
