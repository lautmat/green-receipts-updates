"""Local-PDF path router — builds the on-disk path for an emitted Fatura-Recibo.

PURE: this module writes NO files and touches no network. It only assembles a
path STRING. Layout (one folder per client, one sub-folder per filing month):

    <root>/<safe(client_name)>/<YYYY-MM>/FR-<safe(num_doc)>.pdf

The only load-bearing rule is contamination-safety: a receipt is a real tax
document, so it must NEVER land outside ``<root>/<client>``. ``_safe`` scrubs
every path separator, reserved char, control char, and ``..`` traversal out of
each component; ``receipt_local_path`` then re-asserts the result stays under
``root`` before returning it.
"""
from __future__ import annotations

import os
import re

# Windows-reserved filename chars (also covers POSIX '/'): every one becomes '-'.
# A '/' inside a num_doc (e.g. "FR ATSIRE01FR/117") is the case the spec calls out.
_FORBIDDEN = set('<>:"/\\|?*')
_CONTROL = re.compile(r"[\x00-\x1f\x7f]")   # control chars -> space (then collapsed)
_WS = re.compile(r"\s+")                     # any whitespace run -> single '_'


def _safe(component) -> str:
    """Make one path component filesystem-safe on Windows — never a separator, a
    ``..``, or empty (any of which would let the receipt escape its folder).

    control chars -> space; reserved punctuation (incl. '/' and '\\') -> '-';
    whitespace runs collapse to '_'; boundary '_'/'.'/space are trimmed (which
    also kills a bare '..' and Windows' illegal trailing dot). Empty -> '_' so
    the folder level can never collapse away.
    """
    s = "" if component is None else str(component)
    s = _CONTROL.sub(" ", s)
    s = "".join("-" if c in _FORBIDDEN else c for c in s)
    s = _WS.sub("_", s)
    s = s.strip("_. ")
    return s or "_"


def _year_month(filed_date) -> str:
    """The ``YYYY-MM`` sub-folder from a date/datetime or an ISO ``YYYY-MM-DD`` str."""
    if hasattr(filed_date, "strftime"):          # date / datetime
        return filed_date.strftime("%Y-%m")
    m = re.match(r"\s*(\d{4})-(\d{2})", str(filed_date))
    if not m:
        raise ValueError(f"filed_date not YYYY-MM[-DD]: {filed_date!r}")
    return f"{m.group(1)}-{m.group(2)}"


def receipt_local_path(root, client_name, filed_date, num_doc) -> str:
    """Absolute, normalized path for a client's receipt PDF (builds a string only).

    ``<root>/<safe(client_name)>/<YYYY-MM>/FR-<safe(num_doc)>.pdf``. ``filed_date``
    (date or ISO string) selects the month sub-folder. Raises ``ValueError`` if the
    assembled path would escape ``root`` — the contamination guard, which cannot
    trip given ``_safe`` but is asserted anyway (defence in depth for a tax doc).
    """
    root_abs = os.path.abspath(os.fspath(root))
    month = _year_month(filed_date)
    filename = "FR-" + _safe(num_doc) + ".pdf"
    full = os.path.normpath(os.path.join(root_abs, _safe(client_name), month, filename))
    if os.path.commonpath((root_abs, full)) != root_abs:
        raise ValueError(f"path escaped root: {full!r} not under {root_abs!r}")
    return full
