"""Per-profile config + secret loader for green_receipts.

Each profile (e.g. "laurent", "operator-b") has:
  - secrets (portal NIF + password) in Windows Credential Manager via `keyring`,
    under service "green_receipts/<profile>"
  - non-secret identity + default spreadsheet in
    ~/.config/green_receipts/<profile>.toml
  - Sheets-API OAuth files in ~/.config/green_receipts/, with the same
    laurent-unprefixed-legacy convention used by apps_script_sync.py

Module name is `profiles` (plural) to avoid shadowing stdlib `profile`.
"""
from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass
from pathlib import Path

import keyring

CONFIG_DIR = Path(os.path.expanduser("~/.config/green_receipts"))
SERVICE_PREFIX = "green_receipts"
KEY_PORTAL_NIF = "portal_nif"
KEY_PORTAL_PASSWORD = "portal_password"


def keyring_service(profile_name: str) -> str:
    """Credential Manager service name for a profile's secrets."""
    return f"{SERVICE_PREFIX}/{profile_name}"


def config_path(profile_name: str) -> Path:
    return CONFIG_DIR / f"{profile_name}.toml"


def sheets_paths_for(profile_name: str) -> dict[str, Path]:
    """Sheets-side file paths. Mirrors apps_script_sync.paths_for_user's
    laurent-legacy-unprefixed convention so the two scripts stay aligned
    without importing each other.
    """
    if profile_name == "laurent":
        return {
            "credentials": CONFIG_DIR / "credentials.json",
            "token": CONFIG_DIR / "token.json",
            "journal": CONFIG_DIR / "journal_laurent.json",
        }
    return {
        "credentials": CONFIG_DIR / f"{profile_name}_credentials.json",
        "token": CONFIG_DIR / f"token_{profile_name}_sheets.json",
        "journal": CONFIG_DIR / f"journal_{profile_name}.json",
    }


@dataclass
class Profile:
    name: str
    # Secrets (resolved at load time from keyring)
    portal_nif: str
    portal_password: str
    # Identity (from toml [portal])
    nif_prestador: int
    nome_prestador: str
    morada_fiscal_prestador: str
    morada_fiscal: str
    estabelecimento_comercial: str
    atividade_prestador: str
    atividade_prestador_descr: str
    # Sheet (from toml [sheet], CLI-overridable)
    spreadsheet_id: str
    sheet_name: str
    # Computed file paths
    sheets_credentials_path: Path
    sheets_token_path: Path
    journal_path: Path


def _get_secret(profile_name: str, key: str) -> str:
    service = keyring_service(profile_name)
    value = keyring.get_password(service, key)
    if value is None:
        raise RuntimeError(
            f"Missing keyring entry: service={service!r}, username={key!r}.\n"
            f"  Add it by running:\n"
            f"    python setup_profile.py add {profile_name}\n"
            f"  Or for the initial laurent migration:\n"
            f"    python setup_profile.py migrate"
        )
    return value


def load_profile(name: str, *, sheet_overrides: dict | None = None) -> Profile:
    """Read the profile's toml + keyring entries.

    sheet_overrides may contain 'spreadsheet_id' and/or 'sheet_name' to
    override the toml defaults (typically wired from CLI args).
    """
    cfg_path = config_path(name)
    if not cfg_path.exists():
        raise RuntimeError(
            f"Profile config not found: {cfg_path}\n"
            f"  Run: python setup_profile.py add {name}\n"
            f"  (or for laurent: python setup_profile.py migrate)"
        )
    with cfg_path.open("rb") as f:
        cfg = tomllib.load(f)

    portal = cfg.get("portal", {})
    sheet = cfg.get("sheet", {})
    overrides = sheet_overrides or {}
    paths = sheets_paths_for(name)

    try:
        return Profile(
            name=name,
            portal_nif=_get_secret(name, KEY_PORTAL_NIF),
            portal_password=_get_secret(name, KEY_PORTAL_PASSWORD),
            nif_prestador=int(portal["nif_prestador"]),
            nome_prestador=str(portal["nome_prestador"]),
            morada_fiscal_prestador=str(portal["morada_fiscal_prestador"]),
            morada_fiscal=str(portal["morada_fiscal"]),
            estabelecimento_comercial=str(portal["estabelecimento_comercial"]),
            atividade_prestador=str(portal["atividade_prestador"]),
            atividade_prestador_descr=str(portal["atividade_prestador_descr"]),
            spreadsheet_id=str(overrides.get("spreadsheet_id") or sheet["spreadsheet_id"]),
            sheet_name=str(overrides.get("sheet_name") or sheet["sheet_name"]),
            sheets_credentials_path=paths["credentials"],
            sheets_token_path=paths["token"],
            journal_path=paths["journal"],
        )
    except KeyError as e:
        raise RuntimeError(
            f"Profile {name!r} is missing required field {e.args[0]!r} in {cfg_path}."
        ) from None
