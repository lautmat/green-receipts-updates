"""drive_uploader.py — Phase 6b/8b binary archival to Google Drive (SCAFFOLD).

Uploads a VAT invoice (or receipt PDF) into the client/property folder tree
(archival.drive_folder_path) and returns the Drive URL to record via the serializer
recordInvoice / recordReceiptPdf op (the metadata + cross-check live in archival.py,
which is pure + tested).

GATED on a one-time Drive consent (YOUR action): the green_receipts OAuth token is
Sheets-scoped; add the `drive.file` scope and re-consent once. Until then this module
is unused — the INVOICES tab + cross-check work without it; only the binary copy of
each PDF in Drive is deferred. (The invoice CONTENT itself still needs the deferred
render-then-extract, since a GET returns only the SPA shell — see docs/V2_PLAN.md.)

The load-bearing logic here is ensure_folder_path (dedupe-or-create each segment so a
document is always filed under the same client/property, never duplicated), which is
unit-tested against a fake Drive service. The actual upload is a thin wrapper.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any

DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.file"
FOLDER_MIME = "application/vnd.google-apps.folder"
# Per instance (instance.py): a named instance never uploads with another instance's Drive token.
import instance as _instance  # noqa: E402

_TOKEN_DRIVE = _instance.config_dir() / "token_drive.json"


def drive_service(token_path: Path | None = None):
    """Build a live Drive v3 ``files()`` resource from the token_drive.json written
    by setup_drive_scope.py. Raises a clear error if the Drive consent isn't done."""
    p = token_path or _TOKEN_DRIVE
    if not p.exists():
        raise RuntimeError(f"Drive token not found at {p} — run `python setup_drive_scope.py` once.")
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    creds = Credentials.from_authorized_user_file(str(p), [DRIVE_SCOPE])
    if not creds.valid:
        creds.refresh(Request())
    return build("drive", "v3", credentials=creds).files()


def _q_escape(name: str) -> str:
    return str(name).replace("\\", "\\\\").replace("'", "\\'")


def ensure_folder_path(files_api: Any, path: str, *, root: str = "root") -> str:
    """Ensure every segment of `path` ('GreenReceipts/Client/Apt') exists under
    `root`; create the missing ones; return the LEAF folder id. Idempotent — an
    existing folder is reused, never duplicated. `files_api` is a Drive v3
    ``service.files()`` resource (so it can be faked in tests)."""
    parent = root
    for seg in [s for s in path.split("/") if s]:
        q = ("name = '%s' and mimeType = '%s' and '%s' in parents and trashed = false"
             % (_q_escape(seg), FOLDER_MIME, parent))
        res = files_api.list(q=q, spaces="drive", fields="files(id,name)").execute()
        existing = res.get("files", [])
        if existing:
            parent = existing[0]["id"]
        else:
            meta = {"name": seg, "mimeType": FOLDER_MIME, "parents": [parent]}
            parent = files_api.create(body=meta, fields="id").execute()["id"]
    return parent


def upload_into(files_api: Any, folder_id: str, name: str, media: Any) -> str:
    """Upload one file (a prepared MediaUpload) into `folder_id`; return its
    webViewLink (the Drive URL to record on the GR/INVOICES row)."""
    meta = {"name": name, "parents": [folder_id]}
    f = files_api.create(body=meta, media_body=media, fields="id,webViewLink").execute()
    return f.get("webViewLink") or ("https://drive.google.com/file/d/%s/view" % f.get("id"))


def archive_document(files_api: Any, *, client: str, property_label: str, name: str, media: Any) -> str:
    """High-level: ensure GreenReceipts/<client>/<property> exists, upload `name`,
    return the Drive URL. Routing mirrors emission so a doc can't be misfiled."""
    from archival import drive_folder_path
    folder_id = ensure_folder_path(files_api, drive_folder_path(client, property_label))
    return upload_into(files_api, folder_id, name, media)
