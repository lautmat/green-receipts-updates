"""
Green Receipts (Recibos Verdes) automation for Portal das Financas.

Automates the issuance of Fatura-Recibo for Alojamento Local
via the portal's internal JSON API.

Multi-profile: pass --profile laurent|<another profile>. Per-profile secrets live in
Windows Credential Manager; identity + default spreadsheet live in
~/.config/green_receipts/<profile>.toml. See setup_profile.py.
"""

import argparse
import html as html_lib
import io
import json
import logging
import re
import sys
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path

import requests

from profiles import Profile, load_profile

# Named logger for the shipped "grv2" pipeline. In CLI runs this has no handlers
# attached and silently drops records (Python's default) — that is fine and
# intended here; the existing print()s remain the CLI's trail via app.log. When
# the app (backend.py) has configured "grv2" with online sinks, these calls flow
# there too, which is the whole point: setup-flow diagnostics reaching the LOG.
_grvlog = logging.getLogger("grv2")

# Force UTF-8 stdout/stderr on Windows. The default cp1252 codec can't encode
# some characters that appear in Airbnb guest names (e.g. "İ", "ł", various
# CJK glyphs), which would crash print_pending_table mid-output. We reconfigure
# to UTF-8 with errors='replace' so any still-unencodable char becomes '?' but
# the program never crashes on display.
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# Constants
BASE_URL = "https://irs.portaldasfinancas.gov.pt"
LOGIN_FORM_URL = "https://www.acesso.gov.pt/v2/loginForm"
LOGIN_POST_URL = "https://www.acesso.gov.pt/v2/login"
VAT_RATE = 0.06
VAT_RATE_ID = 3

SHEETS_SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]

# GR-AB&B column indices (0-based, matching sheet A..P)
COL_MONTH = 0      # A — month (derived from start date)
COL_START = 2      # C — used as service_date (FILTER-sourced)
COL_END = 3        # D — end date (FILTER-sourced, used for description)
COL_NAME = 4       # E — guest name (FILTER-sourced)
COL_COUNTRY = 5    # F — (read but not used yet; emit_receipt.py hardcodes UK)
COL_NIF = 6        # G — buyer NIF (default 999999990)
COL_DESC = 7       # H — description (derived from C+D)
COL_TTC = 8        # I — total TTC (FILTER-sourced)
COL_VAT = 9        # J — VAT (derived from I)
COL_BASE = 10      # K — base price (derived from I)
COL_DOCNUM = 13    # N — writeback: Num Doc
COL_EMITTED = 14   # O — writeback: Emitted At
COL_ERROR = 15     # P — writeback: Error

# Expected header row — used by validate_column_headers() to detect sheet changes.
# Only checks columns the script actually reads/writes (skips B, L, M which are unused).
EXPECTED_HEADERS = {
    COL_START: "Start date",    # C
    COL_END: "End date",        # D
    COL_NAME: "Name",           # E
    COL_DESC: "Description",    # H
    COL_TTC: "TTC",             # I
    COL_BASE: "Base Value",     # K
    COL_DOCNUM: "Num Doc",      # N
    COL_EMITTED: "Emitted At",  # O
    COL_ERROR: "Error",         # P
}

COMMON_HEADERS = {
    "Accept": "application/json",
    "Content-Type": "application/json",
    "Origin": "https://irs.portaldasfinancas.gov.pt",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/146.0.0.0 Safari/537.36"
    ),
}

CONSULTAR_REFERER = f"https://irs.portaldasfinancas.gov.pt/recibos/portal/consultar"


def emit_page_referer(doc_number: int, service_date: str) -> str:
    return (
        f"https://irs.portaldasfinancas.gov.pt/recibos/portal/emitir/emitirfaturaV2"
        f"?idDocumento={doc_number}&dataCopia={service_date}&validated=true"
    )


# ---------------------------------------------------------------------------
# Back-dated receipts: cadastro/IVA-history handshake
# ---------------------------------------------------------------------------
# The Portal's emitirV2 REJECTS a receipt whose service date is more than ~10 days old
# with a misleading "Por motivos de ordem técnica..." error — UNLESS the client first
# fetches the cadastro + IVA history for that date. The web UI does exactly this on
# date-selection (emitirfaturaV2 bundle: onSelectDataPrestacao -> historicoCadastroCall
# when dataPrestacao < today-10). We replicate it. Confirmed end-to-end with validate-only
# probes: 06-28 fails without the handshake, succeeds with it; recent dates never need it.
HISTORICO_HANDSHAKE_DAYS = 10


def needs_historico_handshake(service_date: str, today: date | None = None) -> bool:
    """True when service_date is old enough that emitirV2 needs the cadastro handshake first."""
    today = today or date.today()
    try:
        sd = date.fromisoformat(service_date)
    except (ValueError, TypeError):
        return False
    return sd < (today - timedelta(days=HISTORICO_HANDSHAKE_DAYS))


def historico_cadastro_handshake(
    session: requests.Session, nif_prestador: int, service_date: str, debug: bool = False
) -> list:
    """Replicate the web UI's back-dated handshake: GET obterHistoricoCadastro (+ the companion
    obterHistoricoConsultaIva) for (service_date, nif). Returns the activities registered on that
    date. Raises RuntimeError if the Portal reports NO registered activity on that date — such a
    stay predates início de atividade (or falls in a cadastro gap) and must be issued as an
    'ato isolado' at the Portal, not by this tool (fail-safe: the caller parks it)."""
    params = {"dataPrestacao": service_date, "nifPrestadorServicos": nif_prestador}
    headers = {**COMMON_HEADERS, "Referer": CONSULTAR_REFERER}
    r = session.get(f"{BASE_URL}/recibos/api/obterHistoricoCadastro",
                    params=params, headers=headers, timeout=120)
    r.raise_for_status()
    data = r.json()
    if debug:
        print(f"  [DEBUG] obterHistoricoCadastro({service_date}): {json.dumps(data, ensure_ascii=False)[:300]}")
    activities = data.get("listaActividadesHistoricoCadastro") or []
    if data.get("success") is False or not activities:
        msg = data.get("errorMessage") or "no registered activity"
        raise RuntimeError(
            f"Portal reports no registered activity on {service_date} "
            f"(before início de atividade or a cadastro gap): {msg}. "
            f"This stay must be issued as an 'ato isolado' at the Portal, not by this tool."
        )
    # Companion IVA-history call the UI also fires; non-fatal if it errors.
    try:
        session.get(f"{BASE_URL}/recibos/api/obterHistoricoConsultaIva",
                    params=params, headers=headers, timeout=120)
    except Exception:
        pass
    return activities


# ---------------------------------------------------------------------------
# Prestador cadastro (auto-derive identity from AT instead of hand-typing)
# ---------------------------------------------------------------------------
@dataclass
class Cadastro:
    """The prestador's registration as AT holds it, read from the emit page's server-rendered
    `info-prestador` blob. Source of truth for identity — nothing here is hand-typed or mocked."""
    nif: int | None
    nome: str
    morada_fiscal_prestador: str        # domicílio fiscal (AT moradaFiscal) -> receipt moradaFiscalPrestador
    estabelecimento_comercial: str      # establishment
    morada_fiscal: str                  # what the receipt prints as moradaFiscal (establishment if present)
    data_inicio_atividade: str          # ISO "YYYY-MM-DD" or ""
    iva_cod_enq: str
    iva_desc_enq: str
    iva_cod_tipo_operacoes: str
    iva_tipo_sujeito_passivo: str
    actividades: list = field(default_factory=list)   # [{"code": "055201", "descr": "..."}]


_EN_MONTHS = {m: i for i, m in enumerate(
    ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], start=1)}


def _parse_data_inicio_act(raw) -> str:
    """AT returns e.g. 'Jun 20, 2022 12:00:00 AM' (server English locale). Return ISO date or ''.
    Parsed with an explicit English-month map, NOT strptime %b/%p, so it works regardless of the
    operator machine's locale (e.g. a Portuguese Windows would otherwise fail on Out/Dez)."""
    if not raw or not isinstance(raw, str):
        return ""
    s = raw.strip()
    m = re.match(r"([A-Za-z]{3})\s+(\d{1,2}),\s*(\d{4})", s)   # "Mon DD, YYYY ..." (ignore the time)
    if m:
        mon = _EN_MONTHS.get(m.group(1).title())
        if mon:
            try:
                return date(int(m.group(3)), mon, int(m.group(2))).isoformat()
            except ValueError:
                pass
    try:  # already ISO "YYYY-MM-DD..."
        return date.fromisoformat(s[:10]).isoformat()
    except ValueError:
        return ""


def parse_info_prestador(html_text: str):
    """PURE: extract + normalise the server-rendered `info-prestador` attribute into a Cadastro.
    Returns None if the blob isn't present; raises ValueError on malformed JSON."""
    # Quote-agnostic: tolerate the Portal re-rendering the attribute single- OR double-quoted.
    m = re.search(r"info-prestador=(['\"])(\{.*?\})\1", html_text, re.DOTALL)
    if not m:
        return None
    info = json.loads(html_lib.unescape(m.group(2)))
    estab = (info.get("estabelecimentoComercial") or "").strip()
    dom = (info.get("moradaFiscal") or "").strip()
    iva = info.get("consultaIva") or {}
    tsp = iva.get("tipoSujeitoPassivo")
    acts = [{"code": str(a.get("value")), "descr": (a.get("text") or "").strip()}
            for a in (info.get("actividades") or []) if a.get("value")]
    return Cadastro(
        nif=info.get("nif"),
        nome=(info.get("nome") or "").strip(),
        morada_fiscal_prestador=dom,
        estabelecimento_comercial=estab,
        morada_fiscal=(estab or dom),
        data_inicio_atividade=_parse_data_inicio_act(info.get("dataInicioAct")),
        iva_cod_enq=(iva.get("codEnqIva") or "").strip(),
        iva_desc_enq=(iva.get("descEnqIVA") or "").strip(),
        iva_cod_tipo_operacoes=(iva.get("codTipoOperacoes") or "").strip(),
        iva_tipo_sujeito_passivo=("" if tsp is None else str(tsp).strip()),
        actividades=acts,
    )


def fetch_cadastro(session: requests.Session, debug: bool = False) -> "Cadastro":
    """Fetch + parse the prestador's AT cadastro from the emit-form page (authenticated session
    required). Raises RuntimeError if the page can't be read or the blob can't be located."""
    r = session.get(f"{BASE_URL}/recibos/portal/emitir/emitirfaturaV2",
                    headers={**COMMON_HEADERS, "Accept": "text/html", "Referer": CONSULTAR_REFERER},
                    timeout=120)
    r.raise_for_status()
    try:
        cad = parse_info_prestador(r.text)
    except ValueError as e:
        raise RuntimeError(f"could not parse info-prestador blob: {e}")
    if cad is None:
        raise RuntimeError(
            "info-prestador blob not found on the emit page (not logged in, or Portal layout changed)"
        )
    return cad


def cadastro_to_registry_fields(cad: "Cadastro") -> dict:
    """Map a Cadastro (read from AT) to the registry taxpayer fields it populates — the single
    definition used by registration AND by 'refresh from AT', so the two can never drift apart."""
    return {
        "nome_prestador": cad.nome,
        "morada_fiscal_prestador": cad.morada_fiscal_prestador,
        "morada_fiscal": cad.morada_fiscal,
        "estabelecimento_comercial": cad.estabelecimento_comercial,
        "data_inicio_atividade": cad.data_inicio_atividade,
        "iva_cod_enq": cad.iva_cod_enq,
        "iva_desc_enq": cad.iva_desc_enq,
        "iva_cod_tipo_operacoes": cad.iva_cod_tipo_operacoes,
        "iva_tipo_sujeito_passivo": cad.iva_tipo_sujeito_passivo,
    }


def login_and_fetch_cadastro(at_login_username: str, nif_prestador: int, password: str,
                             debug: bool = False):
    """Authenticate with a bare login profile and read the prestador cadastro from AT.
    Returns (LoginResult, Cadastro|None): Cadastro is None when login fails (inspect the
    LoginResult.kind). Used at registration to auto-derive identity — nothing is hand-typed."""
    prof = Profile(
        name=str(nif_prestador),
        portal_nif=at_login_username, portal_password=password,
        nif_prestador=int(nif_prestador), nome_prestador="",
        morada_fiscal_prestador="", morada_fiscal="", estabelecimento_comercial="",
        atividade_prestador="", atividade_prestador_descr="",
        spreadsheet_id="", sheet_name="",
        sheets_credentials_path=Path(), sheets_token_path=Path(), journal_path=Path(),
    )
    session = requests.Session()
    lr = login_result(session, prof)
    if not lr.ok:
        return lr, None
    return lr, fetch_cadastro(session, debug=debug)


# ---------------------------------------------------------------------------
# Authentication
# ---------------------------------------------------------------------------
from collections import namedtuple

# A CLASSIFIED login outcome (never a bare bool): lets the app tell apart a wrong
# password, a temporary credential lockout, a genuine 2FA/Chave Movel challenge, and
# the Portal being unreachable/changed — instead of collapsing all of them into one
# misleading "the Portal asked for a code" screen.
#   kind ∈ {"ok", "bad_credentials", "blocked", "otp_required", "portal_error"}
LoginResult = namedtuple("LoginResult", ["ok", "kind", "message"])

CONCLUIR_URL = "https://www.acesso.gov.pt/v2/concluir"


def _login_error_message(text: str) -> str:
    """Extract the Portal's OWN error words from the acesso.gov.pt SPA response."""
    import re
    for pat in (r"globalError:\s*`([^`]*)`",
                r"errorMsg['\"]?\s*:\s*['\"]([^'\"]{2,200})['\"]",
                r"(N[uú]mero de tentativas[^'\"<]{0,120})",
                r"(Credencial[^'\"<]{0,120})"):
        m = re.search(pat, text)
        if m and m.group(1).strip():
            return m.group(1).strip()
    return ""


def login_result(session: requests.Session, profile: Profile) -> "LoginResult":
    """Authenticate against acesso.gov.pt and return a CLASSIFIED LoginResult.
    Files nothing — auth only.

    Flow (reverse-engineered 2026-07 — the Portal migrated login to a React SPA;
    see memory/portal-login-spa-migration.md):
      1. GET  /v2/loginForm            -> CSRF token + data-attributes {partID, path}
      2. POST /v2/login (form-encoded) -> real signal `loginSuccess: parseBoolean('true')`
      3. GET  /v2/concluir?partID&path -> auto-submit SSO-assertion form (this MOVED here
                                          from the login response in older Portal versions)
      4. POST that form to irs         -> establishes the receipts (sireinter) session
      5. GET  obtemDocumentosV2        -> 200 == authenticated (authoritative check)
    """
    import re

    print("Logging in to Portal das Financas...")
    try:
        # Step 1 — sign-in form (CSRF + service context)
        resp = session.get(
            LOGIN_FORM_URL,
            params={"partID": "SIRE", "path": "/recibos/portal/consultar"},
            headers={"User-Agent": COMMON_HEADERS["User-Agent"]},
        )
        resp.raise_for_status()

        csrf_match = re.search(r"token:\s*`([^`]+)`", resp.text) or \
            re.search(r'"token"\s*:\s*"([^"]+)"', resp.text)
        if not csrf_match:
            print("ERROR: Could not read the sign-in form (Portal down or page changed).")
            _grvlog.warning("login failed: portal_error — could not read the sign-in form",
                            extra={"op": "portal_login", "entity_id": "", "result": "portal_error", "detail": ""})
            return LoginResult(False, "portal_error",
                               "could not read the Portal sign-in form — it may be down or its login page changed")
        csrf_token = csrf_match.group(1)

        attr_match = re.search(r'id="data-attributes"[^>]*>(.*?)</script>', resp.text, re.DOTALL)
        attributes = json.loads(attr_match.group(1)) if attr_match else {}
        part_id = attributes.get("partID", "SIRE")
        path = attributes.get("path", "/recibos/portal/consultar")

        # Step 2 — POST credentials (form-encoded, NOT JSON)
        login_data = {
            "_csrf": csrf_token,
            "selectedAuthMethod": "N",
            "authVersion": "2",
            "username": profile.portal_nif,
            "password": profile.portal_password,
        }
        login_data.update(attributes)
        resp = session.post(
            LOGIN_POST_URL,
            data=login_data,
            headers={
                "User-Agent": COMMON_HEADERS["User-Agent"],
                "Content-Type": "application/x-www-form-urlencoded",
                "Referer": resp.url,
                "Origin": "https://www.acesso.gov.pt",
            },
            allow_redirects=True,
        )

        # The SPA sets its real state via `loginSuccess: parseBoolean('true')`. The var
        # NAMES appear in the JS bundle even on FAILURE, so a plain substring test is a
        # false positive (the old bug) — require the parseBoolean('true') form.
        def flag(name: str) -> bool:
            return bool(re.search(name + r":\s*parseBoolean\('true'\)", resp.text))

        err = _login_error_message(resp.text)

        if flag("is2FA"):
            print("The Portal is asking for a one-time code (2FA / Chave Movel Digital).")
            _grvlog.warning(f"login failed: otp_required — {err}",
                            extra={"op": "portal_login", "entity_id": "", "result": "otp_required", "detail": err})
            return LoginResult(False, "otp_required",
                               err or "the Portal is asking for a one-time code (SMS / Chave Movel Digital)")

        if not flag("loginSuccess"):
            # "Credencial temporariamente suspensa/bloqueada" / "tentativas EXCEDIDO" = locked out.
            # NOT "Tem mais N tentativas" — that is a wrong-password COUNTDOWN (attempts remaining),
            # so we must NOT key on the bare word "tentativas" (it appears in both messages).
            if any(k in err.lower() for k in ("bloquead", "suspens", "excedid")):
                print(f"ERROR: Credential temporarily blocked: {err}")
                _grvlog.warning(f"login failed: blocked — {err}",
                                extra={"op": "portal_login", "entity_id": "", "result": "blocked", "detail": err})
                return LoginResult(False, "blocked",
                                   err or "too many login attempts — the credential is temporarily blocked; wait ~15-30 min")
            if not err:
                # No success marker AND no recognisable Portal error text. A genuine wrong
                # password returns a message ("Tem mais N tentativas", etc.); its ABSENCE almost
                # always means the Portal login page changed (it went React-SPA once already and
                # broke exactly this check). Classify as an ESCALATABLE portal_error so the
                # operator is told to send the log — NOT to re-enter a password that is likely
                # correct (which would loop forever and read as user error).
                print("ERROR: Could not confirm sign-in (no success marker, no Portal error message).")
                _grvlog.warning("login failed: portal_error — no success marker, no Portal error message",
                                extra={"op": "portal_login", "entity_id": "", "result": "portal_error", "detail": ""})
                return LoginResult(False, "portal_error",
                                   "couldn't confirm the sign-in and the Portal returned no error — "
                                   "it may have changed. If the password is definitely correct, "
                                   "send Laurent the app log (this is not a wrong-password error).")
            print(f"ERROR: Login failed: {err}")
            _grvlog.warning(f"login failed: bad_credentials — {err}",
                            extra={"op": "portal_login", "entity_id": "", "result": "bad_credentials", "detail": err})
            return LoginResult(False, "bad_credentials", err)

        # Step 3 — complete the SSO hand-off. The signed-assertion auto-submit form now
        # lives in the /v2/concluir response (older Portal versions returned it from
        # /v2/login, which is why the old code's 'Could not find SSO redirect form' fired).
        concluir = session.get(
            f"{CONCLUIR_URL}?partID={part_id}&path={path}",
            headers={"User-Agent": COMMON_HEADERS["User-Agent"], "Referer": resp.url},
            allow_redirects=True,
        )
        form_action = re.search(r'<form[^>]*action=["\']([^"\']+)["\']', concluir.text)
        sso_data: dict = {}
        for m in re.finditer(r'<input\b[^>]*\bname=["\']([^"\']+)["\'][^>]*\bvalue=["\']([^"\']*)["\']', concluir.text):
            sso_data.setdefault(m.group(1), m.group(2))
        for m in re.finditer(r'<input\b[^>]*\bvalue=["\']([^"\']*)["\'][^>]*\bname=["\']([^"\']+)["\']', concluir.text):
            sso_data.setdefault(m.group(2), m.group(1))
        if not form_action or not sso_data:
            print("ERROR: Signed in, but could not complete the hand-off to the receipts service.")
            _grvlog.warning("login failed: portal_error — signed in, but the hand-off step form was missing",
                            extra={"op": "portal_login", "entity_id": "", "result": "portal_error", "detail": ""})
            return LoginResult(False, "portal_error",
                               "signed in, but the Portal's hand-off step could not be completed (a Portal-side change)")

        print(f"  Completing sign-in -> {form_action.group(1)}")
        sso = session.post(
            form_action.group(1),
            data=sso_data,
            headers={
                "User-Agent": COMMON_HEADERS["User-Agent"],
                "Content-Type": "application/x-www-form-urlencoded",
                "Referer": concluir.url,
            },
            allow_redirects=True,
        )

        # Diagnostic summary of the step-4 SSO hand-off — this response used to be
        # discarded outright, which is why a remote failure of THIS step (the
        # "401 on the receipts API" symptom) was invisible in both the CLI trail
        # and the online LOG. Cookie NAMES only, never values; a marker sniff of
        # the response body for known interstitial/error pages (no full body).
        irs_cookies = sorted({c.name for c in getattr(session, "cookies", [])
                              if "portaldasfinancas" in (c.domain or "")})
        sso_markers = [m for m in ("erro", "autoriz", "ades", "consentimento",
                                   "senha", "password", "captcha")
                       if m in sso.text.lower()]
        # The final URL can carry a LIVE session id in the path (";sireinter_JSessionID=...")
        # — mask it before it reaches any log (log_client.scrub also catches it, second layer).
        final_url = re.sub(r"(jsessionid=)[^\s;?&\"]+", r"\1***", sso.url or "", flags=re.I)
        sso_summary = (f"SSO hand-off: status={sso.status_code} final={final_url} "
                       f"hops={len(getattr(sso, 'history', []))} irs_cookies={irs_cookies} markers={sso_markers}")
        print(f"  {sso_summary}")
        _grvlog.info(sso_summary, extra={"op": "portal_login", "entity_id": "",
                                         "result": "sso_handoff", "detail": ""})

        # Step 5 — authoritative: can we actually call the receipts API?
        test = session.get(
            f"{BASE_URL}/recibos/api/obtemDocumentosV2",
            params={
                "dataEmissaoInicio": date.today().replace(day=1).isoformat(),
                "dataEmissaoFim": date.today().isoformat(),
                "nifPrestadorServicos": profile.nif_prestador,
                "modoConsulta": "Prestador",
                "tipoPesquisa": "1",
                "tableSize": "1",
                "offset": "0",
                "isAutoSearchOn": "on",
            },
            headers=COMMON_HEADERS,
        )
        if test.status_code == 200:
            print("Login successful!")
            _grvlog.info("login ok", extra={"op": "portal_login", "entity_id": "",
                                            "result": "ok", "detail": ""})
            return LoginResult(True, "ok", "")
        print(f"ERROR: Sign-in completed but the receipts API returned {test.status_code}.")
        _grvlog.warning(f"login failed: portal_error — receipts probe status={test.status_code}; "
                        f"{sso_summary}",
                        extra={"op": "portal_login", "entity_id": "",
                              "result": "portal_error", "detail": sso_summary})
        return LoginResult(False, "portal_error",
                           f"sign-in completed but the receipts service returned {test.status_code}")
    except requests.RequestException as e:
        print(f"ERROR: Could not reach the Portal: {e}")
        _grvlog.warning(f"could not reach the Portal ({e})",
                        extra={"op": "portal_login", "entity_id": "",
                              "result": "portal_error", "detail": str(e)})
        return LoginResult(False, "portal_error", f"could not reach the Portal ({e})")


def login(session: requests.Session, profile: Profile) -> bool:
    """Back-compatible boolean wrapper over login_result() — the CLI / .bat path
    only needs pass/fail; the desktop app uses login_result() for the real reason."""
    return login_result(session, profile).ok


def login_with_cookie(session: requests.Session, profile: Profile, *, assume_yes: bool = False) -> bool:
    """Fallback: prompt user to paste session cookies from browser.

    Disabled (returns False immediately) when assume_yes is True — a scheduled
    task can never satisfy a paste-cookies prompt, so failing fast is correct.
    """
    if assume_yes:
        print("ERROR: Automatic login failed and --yes mode disables the cookie-paste fallback.")
        return False

    print("\nAutomatic login failed or was skipped.")
    print("To continue, log in manually in your browser and paste your cookies.")
    print("In Chrome DevTools (F12) > Application > Cookies, copy all cookies")
    print("for irs.portaldasfinancas.gov.pt as a single string (name=val; name2=val2).")
    print()
    cookie_str = input("Paste cookies (or 'q' to quit): ").strip()
    if cookie_str.lower() == "q":
        return False

    for pair in cookie_str.split(";"):
        pair = pair.strip()
        if "=" in pair:
            name, value = pair.split("=", 1)
            session.cookies.set(name.strip(), value.strip(), domain="irs.portaldasfinancas.gov.pt")

    test = session.get(
        f"{BASE_URL}/recibos/api/obtemDocumentosV2",
        params={
            "dataEmissaoInicio": date.today().replace(day=1).isoformat(),
            "dataEmissaoFim": date.today().isoformat(),
            "nifPrestadorServicos": profile.nif_prestador,
            "modoConsulta": "Prestador",
            "tipoPesquisa": "1",
            "tableSize": "1",
            "offset": "0",
            "isAutoSearchOn": "on",
        },
        headers=COMMON_HEADERS,
    )
    if test.status_code == 200:
        print("Cookie authentication successful!")
        return True

    print("ERROR: Cookie authentication failed.")
    return False


# ---------------------------------------------------------------------------
# API calls
# ---------------------------------------------------------------------------
def get_latest_doc_number(session: requests.Session, profile: Profile, *, assume_yes: bool = False) -> int:
    """Return the most recently issued document number.

    The portal's emit flow takes the latest existing receipt as the
    pre-fill ("copy") source and the server assigns the new receipt
    number automatically. So we return the latest *existing* number,
    not latest+1.

    Under --yes, the input() fallback for manual entry is disabled: we
    raise instead, since a scheduled task cannot answer the prompt.
    """
    today = date.today()
    month = today.month - 11
    year = today.year
    if month <= 0:
        month += 12
        year -= 1
    start = date(year, month, 1)

    resp = session.get(
        f"{BASE_URL}/recibos/api/obtemDocumentosV2",
        params={
            "dataEmissaoInicio": start.isoformat(),
            "dataEmissaoFim": today.isoformat(),
            "nifPrestadorServicos": profile.nif_prestador,
            "modoConsulta": "Prestador",
            "tipoPesquisa": "1",
            "tableSize": "1",
            "offset": "0",
            "isAutoSearchOn": "on",
        },
        headers={**COMMON_HEADERS, "Referer": CONSULTAR_REFERER},
    )
    resp.raise_for_status()
    data = resp.json()

    if isinstance(data, dict) and data.get("success"):
        docs = data.get("listaDocumentos") or []
        if docs and isinstance(docs[0], dict):
            latest_num = docs[0].get("numDocumento")
            if latest_num:
                return int(latest_num)

    print(f"  DEBUG: obtemDocumentosV2 response: {json.dumps(data, indent=2, ensure_ascii=False)[:800]}")
    if assume_yes:
        raise RuntimeError(
            "Could not auto-detect latest document number, and --yes mode "
            "disables the interactive fallback. Aborting."
        )
    num = input("Could not auto-detect doc number. Enter latest existing document number: ").strip()
    return int(num)


def validate_new_receipt(session: requests.Session, profile: Profile,
                         doc_number: int, service_date: str, debug: bool = False) -> bool:
    """Step 1: Validate receipt metadata."""
    payload = {
        "nifPrestadorServicos": profile.nif_prestador,
        "numDocumento": doc_number,
        "dataPrestacaoServico": service_date,
    }
    resp = session.post(
        f"{BASE_URL}/recibos/api/emitirNovoValidationV2",
        json=payload,
        headers={**COMMON_HEADERS, "Referer": CONSULTAR_REFERER},
    )
    resp.raise_for_status()
    data = resp.json()
    if debug:
        print(f"  [DEBUG] emitirNovoValidationV2 response: {json.dumps(data, indent=2, ensure_ascii=False)}")
    # This endpoint returns "Recibo inexistente" for new receipts, which is expected.
    # Only check for the "erros" field which signals actual validation errors.
    if data and isinstance(data, dict) and data.get("erros"):
        print(f"  Validation errors: {data['erros']}")
        return False
    return True


def validate_line_item(
    session: requests.Session,
    description: str,
    base_price: float,
    total_with_vat: float,
    vat_amount: float,
    service_date: str,
    doc_number: int,
    debug: bool = False,
) -> bool:
    """Step 2: Validate the line item."""
    payload = {
        "index": 0,
        "tipoProduto": "S",
        "tipoRef": "OUT",
        "referencia": "Alojamento Local",
        "cpv": None,
        "compromissoGeral": None,
        "compromisso": None,
        "descricao": description,
        "quantidade": 1,
        "unidade": "1  ",
        "unidadeAbbr": "Unidade",
        "precoUnit": str(base_price),
        "precoUnitCDescontoLinha": str(base_price),
        "idTaxaIVA": VAT_RATE_ID,
        "taxaIVA": VAT_RATE,
        "motivoIsencaoLinha": None,
        "precoUnitCIVA": fmt_price(total_with_vat),
        "valorDescontoComercialLinha": 0,
        "taxaDescontoFinanceiroGeral": None,
        "valorDescontoFinanceiro": 0,
        "valorDescontoLinha": "0",
        "total": str(base_price),
        "valorIVA": str(vat_amount),
        "totalCIVA": fmt_price(total_with_vat),
        "taxaPercImpSeloLinha": None,
        "valorFixoImpSeloLinha": None,
        "valorMinimoImpSeloLinha": None,
        "valorImpSeloLinha": None,
        "numLinha": 1,
        "antigaReferencia": "Alojamento Local",
        "isCalculoByPrUnitCIVA": False,
        "isAdqConsumidorFinal": False,
        "isAdqEstrangeiro": True,
        "isNacional": False,
        "isAtoIsolado": False,
        "isEntidadeFEAP": False,
        "dataTransacao": service_date,
        "isToEnviarFEAP": None,
        "tipoRecibo": "FR",
        "listaMotivosIsencaoOuTaxaComConhecimentoEnqIva": [],
    }
    resp = session.post(
        f"{BASE_URL}/recibos/api/linhaValidation",
        json=payload,
        headers={**COMMON_HEADERS, "Referer": emit_page_referer(doc_number, service_date)},
    )
    resp.raise_for_status()
    data = resp.json()
    if debug:
        print(f"  [DEBUG] linhaValidation response: {json.dumps(data, indent=2, ensure_ascii=False)}")
    if data and isinstance(data, dict):
        if data.get("erros"):
            print(f"  Line validation errors: {data['erros']}")
            return False
        if data.get("success") is False:
            print(f"  Line validation failed: {data.get('errorMessage', 'unknown')}")
            if data.get("fieldErrors"):
                print(f"  Field errors: {data['fieldErrors']}")
            return False
    return True


def build_receipt_payload(
    profile: Profile,
    description: str,
    base_price: float,
    total_with_vat: float,
    vat_amount: float,
    vat_unrounded: float,
    service_date: str,
    validate: bool,
    guest_name: str | None = None,
) -> dict:
    """Build the full receipt payload for emitirV2."""
    # IVA regime is per-taxpayer (auto-derived from AT). Treat the block ATOMICALLY: if the
    # profile carries ANY derived IVA field, ship all four exactly as derived — a blank stays
    # blank so the Portal rejects/parks rather than silently splicing another taxpayer's value
    # into a filed receipt. Only when ALL four are absent (legacy / v1 Profile) fall back to the
    # historical hard-coded regime. (Never mix derived + fallback within one receipt.)
    _iva = {
        "codEnqIva": getattr(profile, "iva_cod_enq", "") or "",
        "descEnqIVA": getattr(profile, "iva_desc_enq", "") or "",
        "codTipoOperacoes": getattr(profile, "iva_cod_tipo_operacoes", "") or "",
        "tipoSujeitoPassivo": getattr(profile, "iva_tipo_sujeito_passivo", "") or "",
    }
    if not any(_iva.values()):
        _iva = {"codEnqIva": "I", "descEnqIVA": "Normal Trimestral por Opção",
                "codTipoOperacoes": "B", "tipoSujeitoPassivo": "1"}
    consultas_iva = {**_iva, "date": date.today().isoformat()}
    return {
        "tipoRecibo": "FR",
        "tipoDocumentoLabel": "Fatura-Recibo",
        "moradaFiscalPrestador": profile.morada_fiscal_prestador,
        "atividadePrestador": profile.atividade_prestador,
        "atividadePrestadorDescr": profile.atividade_prestador_descr,
        "estabelecimentoComercial": profile.estabelecimento_comercial,
        "nifEstrangeiro": "999999990",
        "isEstrangeiro": False,
        "nomeAdquirente": (guest_name.strip() if guest_name and guest_name.strip() else None),
        "pais": "826",
        "mostraSSaude": False,
        "dataTransmissao": date.today().isoformat(),
        "linhasDocumento": [
            {
                "tipoProduto": "S",
                "tipoRef": "OUT",
                "referencia": "Alojamento Local",
                "cpv": None,
                "compromisso": None,
                "descricao": description,
                "quantidade": 1,
                "unidade": "1  ",
                "unidadeAbbr": "Unidade - Unidade",
                "precoUnit": str(base_price),
                "precoUnitCDescontoLinha": str(base_price),
                "idTaxaIVA": VAT_RATE_ID,
                "taxaIVA": VAT_RATE,
                "precoUnitCIVA": fmt_price(total_with_vat),
                "motivoIsencaoLinha": None,
                "valorDescontoComercialLinha": 0,
                "valorDescontoFinanceiro": 0,
                "valorDescontoLinha": "0",
                "total": str(base_price),
                "valorIVA": str(vat_unrounded),
                "totalCIVA": fmt_price(total_with_vat),
                "taxaPercImpSeloLinha": None,
                "valorFixoImpSeloLinha": None,
                "valorImpSeloLinha": None,
                "valorMinimoImpSeloLinha": None,
                "numLinha": 1,
                "antigaReferencia": "Alojamento Local",
                "hasAlteracao": True,
                "isCalculoByPrUnitCIVA": False,
                "listaMotivosIsencaoOuTaxaComConhecimentoEnqIva": [],
            }
        ],
        "titulo": "1",
        "regimeIncidenciaIrs": "07",
        "isRpac": False,
        "isTransmitenteContabilidadeOrganizada": False,
        "isRespeitaPropIntelectual": False,
        "isAplicaEpacPropIntelectual": False,
        "isAdquirenteContabilidade": False,
        "listaPagamento": [],
        "hasNifAdquirenteAndNotFinal": False,
        "nifPrestadorServicos": profile.nif_prestador,
        "nomePrestadorServicos": profile.nome_prestador,
        "taxasIva": [
            {
                "valorBase": str(base_price),
                "valorIva": f"{vat_amount:.2f}",
                "valorRemanescente": 0,
                "valorTotalCIVA": fmt_price(total_with_vat),
                "valorImposto": f"{vat_amount:.2f}",
                "idTaxa": VAT_RATE_ID,
                "taxa": VAT_RATE,
            }
        ],
        "impostosSelo": [],
        "valorBase": str(base_price),
        "valorBaseTributavel": str(base_price),
        "valorIVA": f"{vat_amount:.2f}",
        "valorImpostoSelo": 0,
        "valorDescontoComercial": 0,
        "valorDescontoFinanceiro": 0,
        "valorBaseTributavelDisponivel": str(base_price),
        "valorIRS": 0,
        "valorTotalImpostos": f"{vat_amount:.2f}",
        "importanciaRecebida": fmt_price(total_with_vat),
        "valorTotalCImpostos": fmt_price(total_with_vat),
        "valorTotalRetFonte": "0",
        "dataPrestacao": service_date,
        "isToEnviarFEAP": None,
        "compromisso": None,
        "acordoQuadro": None,
        "moradaAdquirente": None,
        "nifAdquirente": None,
        "regimeRetencaoIrs": None,
        "idCliente": None,
        "paisAdqCliente": "826",
        "valorBaseCalculoProdutos": None,
        "valorBaseConsiderarProdutos": None,
        "valorBaseCalculoServicos": None,
        "valorBaseConsiderarServicos": None,
        "valorBaseConsiderarTotal": None,
        "valorContribuicaoFundo": None,
        "valorContribuicaoPrevidencial": None,
        "valorContribuicaoSetor": None,
        "valorTotalContribuicoes": None,
        "isRespeitaProducao": None,
        "isRpacPres": None,
        "impSeloRetFonte": None,
        "taxaProdutos": 0.2,
        "taxaServicos": 0.7,
        "taxaSetor": 0.051,
        "taxaPrevidencial": 0.214,
        "taxaFundo": 0,
        "valorIvaDedutivel": 0,
        "consultasIva": consultas_iva,  # atomic: all-derived, or all-fallback (see top of fn)
        "moradaFiscal": profile.morada_fiscal,
        "numBeneficiario": None,
        "subsistemaSaude": None,
        "subsistemaSaudeOutro": None,
        "moradaAdqClienteL": None,
        "codPostalAdqCliente": None,
        "localidadeAdqCliente": None,
        "idMoradaEntrega": None,
        "moradaAdqEntregaL": None,
        "codPostalAdqEntrega": None,
        "localidadeAdqEntrega": None,
        "paisAdqEntrega": None,
        "dataEntrega": None,
        "horaEntrega": None,
        "isToValidate": validate,
    }


def submit_receipt(
    session: requests.Session,
    profile: Profile,
    description: str,
    base_price: float,
    total_with_vat: float,
    vat_amount: float,
    vat_unrounded: float,
    service_date: str,
    doc_number: int,
    validate_only: bool = False,
    debug: bool = False,
    guest_name: str | None = None,
) -> dict:
    """Submit receipt via emitirV2."""
    payload = build_receipt_payload(
        profile, description, base_price, total_with_vat, vat_amount, vat_unrounded,
        service_date, validate=validate_only, guest_name=guest_name,
    )
    resp = session.post(
        f"{BASE_URL}/recibos/api/emitirV2",
        json=payload,
        headers={**COMMON_HEADERS, "Referer": emit_page_referer(doc_number, service_date)},
    )
    resp.raise_for_status()
    data = resp.json()
    if debug:
        label = "emitirV2 (validate)" if validate_only else "emitirV2 (submit)"
        print(f"  [DEBUG] {label} response: {json.dumps(data, indent=2, ensure_ascii=False)}")
    return data


# ---------------------------------------------------------------------------
# Interactive flow
# ---------------------------------------------------------------------------
def prompt_receipt_details() -> tuple[float, str, str, str | None]:
    """Prompt user for the variable fields. Returns (base_price, date, description, guest_name)."""
    print("\n--- New Receipt ---\n")

    while True:
        price_str = input("Base price (without VAT, e.g. 357.55): ").strip()
        try:
            base_price = float(price_str)
            if base_price <= 0:
                raise ValueError
            break
        except ValueError:
            print("  Invalid price. Enter a positive number.")

    while True:
        date_str = input("Service date (YYYY-MM-DD, e.g. 2026-03-09): ").strip()
        try:
            datetime.strptime(date_str, "%Y-%m-%d")
            break
        except ValueError:
            print("  Invalid date format. Use YYYY-MM-DD.")

    description = input("Description (e.g. Alojamento Local - 2026-03-05 a 2026-03-09): ").strip()
    if not description:
        description = f"Alojamento Local - {date_str}"

    guest_name = input("Client name (leave empty for none): ").strip() or None

    return base_price, date_str, description, guest_name


def fmt_price(value: float) -> str:
    """Format a price value as a string, using integer format for whole numbers."""
    if value == int(value):
        return str(int(value))
    return str(value)


def calculate_vat(base_price: float) -> tuple[float, float, float]:
    """Calculate VAT amount and total with VAT.

    Matches the portal's rounding: total is rounded to nearest integer,
    then VAT = total - base.
    """
    raw_total = base_price * (1 + VAT_RATE)
    total_with_vat = round(raw_total, 2)
    vat_amount = round(total_with_vat - base_price, 2)
    # Unrounded VAT for line item: must be exactly base * rate at 4 dp
    # (the portal validates this against precoUnit * taxaIVA on the server side
    # — sending 3 dp triggers a "technical error" rejection).
    vat_unrounded = round(base_price * VAT_RATE, 4)
    return vat_amount, vat_unrounded, total_with_vat


# ---------------------------------------------------------------------------
# --from-sheet mode: read pending rows from GR-AB&B, emit in batch, writeback
# ---------------------------------------------------------------------------
def _lazy_google_imports():
    """Import Google libs only when --from-sheet is used."""
    global _Credentials, _InstalledAppFlow, _GoogleRequest, _build
    try:
        from google.oauth2.credentials import Credentials as _Credentials
        from google_auth_oauthlib.flow import InstalledAppFlow as _InstalledAppFlow
        from google.auth.transport.requests import Request as _GoogleRequest
        from googleapiclient.discovery import build as _build
    except ImportError as e:
        print("ERROR: Google API libraries are not installed.")
        print("  Install them with: pip install -r requirements.txt")
        print(f"  Underlying error: {e}")
        sys.exit(1)


def get_sheets_service(profile: Profile, *, assume_yes: bool = False):
    """Authenticate with Google and return a Sheets API client.

    Under --yes, if the cached token is missing/expired and a browser-based
    OAuth flow would be required, we fail fast rather than block the
    scheduled task forever waiting on a browser.
    """
    _lazy_google_imports()
    creds = None
    token_path = profile.sheets_token_path
    creds_path = profile.sheets_credentials_path
    if token_path.exists():
        creds = _Credentials.from_authorized_user_file(str(token_path), SHEETS_SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(_GoogleRequest())
        else:
            if assume_yes:
                raise RuntimeError(
                    f"Google OAuth token missing or unrefreshable at {token_path}.\n"
                    f"  --yes mode disables the browser-based OAuth flow.\n"
                    f"  Re-run interactively (without --yes) once to refresh the token, "
                    f"then the scheduled task will work again."
                )
            if not creds_path.exists():
                print(f"ERROR: Google OAuth client secrets not found at {creds_path}")
                print("  Create a Desktop OAuth client in Google Cloud Console, download the")
                print("  credentials JSON, and save it to that path. See README for details.")
                sys.exit(1)
            flow = _InstalledAppFlow.from_client_secrets_file(str(creds_path), SHEETS_SCOPES)
            creds = flow.run_local_server(port=0)
        token_path.parent.mkdir(parents=True, exist_ok=True)
        token_path.write_text(creds.to_json())
    return _build("sheets", "v4", credentials=creds)


def parse_sheet_date(value: str) -> str | None:
    """Accept the common formats found in GR-AB&B, return ISO yyyy-mm-dd."""
    if not value:
        return None
    value = str(value).strip()
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%d/%m/%Y"):
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            continue
    return None


def ensure_writeback_headers(sheets, profile: Profile) -> None:
    """Write N1:P1 headers on first run if they're missing."""
    r = sheets.spreadsheets().values().get(
        spreadsheetId=profile.spreadsheet_id,
        range=f"'{profile.sheet_name}'!N1:P1",
    ).execute()
    current = (r.get("values") or [[]])
    current_row = current[0] if current else []
    expected = ["Num Doc", "Emitted At", "Error"]
    if current_row[:3] != expected:
        sheets.spreadsheets().values().update(
            spreadsheetId=profile.spreadsheet_id,
            range=f"'{profile.sheet_name}'!N1:P1",
            valueInputOption="USER_ENTERED",
            body={"values": [expected]},
        ).execute()
        print("  Added writeback headers to N1:P1.")


def _autofill_row(row: list, sheet_row: int) -> dict[str, tuple[str, str]]:
    """Compute missing derived cells from FILTER-sourced data.

    Returns {col_letter: (value, reason)} for cells that need writing back.
    Only fills cells that are empty AND computable from available data.
    """
    fills: dict[str, tuple[str, str]] = {}

    start_raw = (row[COL_START] or "").strip()
    end_raw = (row[COL_END] or "").strip()
    ttc_raw = (row[COL_TTC] or "").strip()
    start_date = parse_sheet_date(start_raw)
    end_date = parse_sheet_date(end_raw)

    # A — month: derive from start date
    if not (row[COL_MONTH] or "").strip() and start_date:
        y, m, _ = start_date.split("-")
        fills["A"] = (f"{y}-{m}", "month from start date")

    # G — NIF: default 999999990 (generic consumer) if empty
    if not (row[COL_NIF] or "").strip():
        fills["G"] = ("999999990", "default consumer NIF")

    # H — description: derive from start + end dates
    if not (row[COL_DESC] or "").strip() and start_date and end_date:
        desc = f"Alojamento Local - {start_date} a {end_date}"
        fills["H"] = (desc, "from start/end dates")

    # J — VAT and K — base: derive from TTC (column I)
    if ttc_raw and not (row[COL_BASE] or "").strip():
        try:
            ttc = float(str(ttc_raw).replace(",", "."))
            base = round(ttc / (1 + VAT_RATE), 2)
            vat = round(ttc - base, 2)
            fills["J"] = (str(vat), "VAT from TTC")
            fills["K"] = (str(base), "base from TTC")
        except (ValueError, TypeError):
            pass

    return fills


def autofill_pending(sheets, profile: Profile, pending_rows: list[dict], dry_run: bool) -> None:
    """Write auto-computed cells back to the sheet for rows that need them."""
    if not any(p.get("_fills") for p in pending_rows):
        return

    count = 0
    for p in pending_rows:
        fills = p.get("_fills", {})
        if not fills:
            continue
        sr = p["sheet_row"]
        cols = ", ".join(f"{c}={v}" for c, (v, _) in sorted(fills.items()))
        print(f"  Row {sr}: auto-fill {cols}")

        if not dry_run:
            for col_letter, (value, _reason) in fills.items():
                cell = f"'{profile.sheet_name}'!{col_letter}{sr}"
                sheets.spreadsheets().values().update(
                    spreadsheetId=profile.spreadsheet_id,
                    range=cell,
                    valueInputOption="USER_ENTERED",
                    body={"values": [[value]]},
                ).execute()
        count += 1

    mode = "[DRY RUN] Would auto-fill" if dry_run else "Auto-filled"
    print(f"  {mode} {count} row(s).")


def read_pending_rows(sheets, profile: Profile) -> list[dict]:
    """Return unissued rows from GR-AB&B as a list of dicts."""
    r = sheets.spreadsheets().values().get(
        spreadsheetId=profile.spreadsheet_id,
        range=f"'{profile.sheet_name}'!A2:P",
    ).execute()
    rows = r.get("values", [])
    pending, skipped = [], []
    for i, raw in enumerate(rows):
        row = list(raw) + [""] * (16 - len(raw))
        sheet_row = i + 2  # 1-indexed, accounting for header row

        doc_num = (row[COL_DOCNUM] or "").strip()
        if doc_num:
            continue  # already emitted — skip silently

        # Compute any missing derived fields from FILTER-sourced data
        fills = _autofill_row(row, sheet_row)
        col_index = {"A": COL_MONTH, "G": COL_NIF, "H": COL_DESC,
                     "J": COL_VAT, "K": COL_BASE}
        for col_letter, (value, _) in fills.items():
            idx = col_index.get(col_letter)
            if idx is not None:
                row[idx] = value

        base_raw = (row[COL_BASE] or "").strip()
        if not base_raw:
            ttc_raw = (row[COL_TTC] or "").strip()
            if not ttc_raw:
                continue  # empty/template row — skip silently
            skipped.append((sheet_row, f"no base price and TTC={ttc_raw!r} failed to compute"))
            continue
        try:
            base = float(str(base_raw).replace(",", "."))
        except (ValueError, TypeError):
            skipped.append((sheet_row, f"invalid base price: {base_raw!r}"))
            continue

        service_date = parse_sheet_date(row[COL_START])
        if not service_date:
            skipped.append((sheet_row, f"invalid start date: {row[COL_START]!r}"))
            continue

        description = (row[COL_DESC] or "").strip()
        if not description:
            skipped.append((sheet_row, "missing description (no start/end dates to compute)"))
            continue

        pending.append({
            "sheet_row": sheet_row,
            "base": round(base, 2),
            "service_date": service_date,
            "description": description,
            "guest": (row[COL_NAME] or "").strip(),
            "country": (row[COL_COUNTRY] or "").strip(),
            "prior_error": (row[COL_ERROR] or "").strip(),
            "_fills": fills,
        })

    if skipped:
        print(f"  Skipped {len(skipped)} incomplete row(s):")
        for sr, reason in skipped[:10]:
            print(f"    row {sr}: {reason}")
    return pending


def print_pending_table(pending: list[dict]) -> None:
    if not pending:
        print("\nNo pending rows.\n")
        return
    total_base = sum(p["base"] for p in pending)
    total_vat = round(sum(round(p["base"] * VAT_RATE, 2) for p in pending), 2)
    total_ttc = round(total_base + total_vat, 2)

    print(f"\nPending receipts ({len(pending)}):\n")
    header = (f"  {'#':<3} {'Row':<5} {'Date':<11} {'Guest':<22} "
              f"{'Base':>9} {'VAT':>7} {'Total':>9}  Description")
    print(header)
    print(f"  {'-'*3} {'-'*5} {'-'*11} {'-'*22} {'-'*9} {'-'*7} {'-'*9}  {'-'*50}")
    for i, p in enumerate(pending, 1):
        vat = round(p["base"] * VAT_RATE, 2)
        ttc = round(p["base"] + vat, 2)
        guest = (p["guest"] or "")[:22]
        desc = (p["description"] or "")[:60]
        print(f"  {i:<3} {p['sheet_row']:<5} {p['service_date']:<11} {guest:<22} "
              f"{p['base']:>9.2f} {vat:>7.2f} {ttc:>9.2f}  {desc}")
        if p["prior_error"]:
            print(f"      ! prior error: {p['prior_error'][:90]}")
    print(f"\n  Totals: base {total_base:.2f}  VAT {total_vat:.2f}  TTC {total_ttc:.2f} EUR\n")


def parse_selection(text: str, n: int) -> list[int]:
    out = set()
    for part in text.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            out.update(range(int(a), int(b) + 1))
        else:
            out.add(int(part))
    return sorted(i for i in out if 1 <= i <= n)


def select_rows(pending: list[dict], *, assume_yes: bool = False) -> list[dict]:
    """Interactive row selection. Under --yes, returns all pending unchanged."""
    if assume_yes:
        print(f"  --yes: auto-selecting all {len(pending)} pending row(s).")
        return pending
    while True:
        ans = input(f"Emit all {len(pending)}? [y/N/s=select/q=quit]: ").strip().lower()
        if ans in ("", "n", "no", "q", "quit"):
            return []
        if ans in ("y", "yes"):
            return pending
        if ans == "s":
            try:
                idxs = parse_selection(
                    input("  Row numbers (e.g. 1,3,5-7): "), len(pending)
                )
                if idxs:
                    return [pending[i - 1] for i in idxs]
                print("  Empty selection.")
            except ValueError:
                print("  Invalid selection.")
                continue


def validate_column_headers(sheets, profile: Profile) -> None:
    """Abort with a clear error if GR-AB&B column headers don't match expectations.

    Prevents silent data corruption if the sheet is reorganized (columns
    inserted, reordered, or renamed). Reads row 1 once and compares against
    EXPECTED_HEADERS.
    """
    r = sheets.spreadsheets().values().get(
        spreadsheetId=profile.spreadsheet_id,
        range=f"'{profile.sheet_name}'!A1:P1",
    ).execute()
    headers = (r.get("values") or [[]])[0]
    mismatches = []
    for idx, expected in EXPECTED_HEADERS.items():
        actual = headers[idx].strip() if idx < len(headers) else "(missing)"
        if actual.lower() != expected.lower():
            col_letter = chr(ord("A") + idx)
            mismatches.append(f"  {col_letter} (col {idx}): expected {expected!r}, got {actual!r}")
    if mismatches:
        print("ERROR: GR-AB&B column headers have changed!")
        print("  The script's hardcoded column indices no longer match the sheet.\n")
        for m in mismatches:
            print(m)
        print("\n  Update the COL_* constants and EXPECTED_HEADERS in emit_receipt.py,")
        print("  or restore the sheet layout. Aborting to prevent wrong data.")
        sys.exit(1)
    print("  Column headers validated OK.")


# ---------------------------------------------------------------------------
# Crash journal — survives process crashes between emission and writeback
# ---------------------------------------------------------------------------
def _journal_load(profile: Profile) -> list[dict]:
    if profile.journal_path.exists():
        try:
            return json.loads(profile.journal_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return []
    return []


def _journal_save(profile: Profile, entries: list[dict]) -> None:
    profile.journal_path.parent.mkdir(parents=True, exist_ok=True)
    profile.journal_path.write_text(
        json.dumps(entries, indent=2, ensure_ascii=False), encoding="utf-8"
    )


def journal_record_pending(profile: Profile, sheet_row: int, service_date: str,
                           base: float, desc: str) -> None:
    """Record that we're about to emit for this row."""
    entries = _journal_load(profile)
    entries.append({
        "sheet_row": sheet_row,
        "service_date": service_date,
        "base": base,
        "description": desc,
        "status": "pending",
        "ts": datetime.now().isoformat(),
    })
    _journal_save(profile, entries)


def journal_record_emitted(profile: Profile, sheet_row: int, doc_number: int) -> None:
    """Record that emission succeeded (but writeback hasn't happened yet)."""
    entries = _journal_load(profile)
    for e in entries:
        if e["sheet_row"] == sheet_row and e["status"] == "pending":
            e["status"] = "emitted"
            e["doc_number"] = doc_number
            break
    _journal_save(profile, entries)


def journal_record_done(profile: Profile, sheet_row: int) -> None:
    """Remove the entry — emission and writeback both succeeded."""
    entries = _journal_load(profile)
    entries = [e for e in entries if not (e["sheet_row"] == sheet_row and e["status"] == "emitted")]
    _journal_save(profile, entries)


def journal_recover(sheets, profile: Profile) -> int:
    """Recover any entries stuck at 'emitted' — writeback failed last run.

    Returns number of recovered rows.
    """
    entries = _journal_load(profile)
    stuck = [e for e in entries if e["status"] == "emitted"]
    if not stuck:
        return 0

    print(f"\n  Recovering {len(stuck)} row(s) from crash journal (emitted but writeback failed):")
    recovered = 0
    for e in stuck:
        sr = e["sheet_row"]
        doc = e["doc_number"]
        print(f"    Row {sr}: doc {doc} — writing back...")
        try:
            writeback_row(sheets, profile, sr, doc_number=doc)
            journal_record_done(profile, sr)
            recovered += 1
            print(f"    Row {sr}: recovered OK.")
        except Exception as err:
            print(f"    Row {sr}: STILL FAILED: {err}")
    # Clean up pending entries that never got emitted (stale from aborted runs)
    entries = _journal_load(profile)
    entries = [e for e in entries if e["status"] not in ("pending",)]
    _journal_save(profile, entries)
    return recovered


# ---------------------------------------------------------------------------
# Portal duplicate guard — prevents re-emission if writeback was lost
# Portal duplicate-query lookback. HARD CONSTRAINT: obtemDocumentosV2 REJECTS any dataEmissao range
# wider than 12 CALENDAR months ({"success":false, fieldError "...no máximo 12 meses"}) — a 35-month
# window made EVERY dup-check fail success:false -> "unknown" -> park every row, forever (the 2026-07-09
# "0 filed" incident). 11 months stays comfortably under the cap (a first-of-month start can be up to
# ~1 month longer than the nominal span, and the cap is calendar-months incl. leap years — verified
# live). The dup-check is a BACKSTOP for a RECENT lost-writeback; the sheet lifecycle + Num Doc column
# + journal are the primary guards and cover older duplicates. _fetch_issued_docs offset-pages past the
# tableSize=500 cap using the response's totalDocs, so the OLDEST receipts are no longer blind-spotted.
PORTAL_DUP_LOOKBACK_MONTHS = 11


def portal_dup_window_start(today=None):
    """First-of-month date PORTAL_DUP_LOOKBACK_MONTHS before `today` (multi-year safe)."""
    today = today or date.today()
    tm = today.year * 12 + (today.month - 1) - PORTAL_DUP_LOOKBACK_MONTHS
    return date(tm // 12, tm % 12 + 1, 1)


# ---------------------------------------------------------------------------
def _iso_date_or_none(value):
    """Normalize a date-ish value ('2026-06-23', '2026/06/23', '2026-06-23 10:11') to ISO
    'YYYY-MM-DD', or None if it doesn't look like a date. String compare on the result is
    chronological. (Canonical copy; emitter.portal_receipt_status delegates here.)"""
    s = str(value or "").strip().replace("/", "-")[:10]
    if len(s) == 10 and s[4] == "-" and s[7] == "-" \
            and s[:4].isdigit() and s[5:7].isdigit() and s[8:10].isdigit():
        return s
    return None


def fetch_issued_docs(session, profile, start, today, *, page: int = 500, max_pages: int = 40):
    """Fetch EVERY issued Fatura-Recibo in [start, today] from obtemDocumentosV2, OFFSET-PAGED.

    [start, today] MUST be <= 12 calendar months (the Portal rejects wider ranges with
    success:false) — callers derive `start` from portal_dup_window_start (11 months).

    Returns the full listaDocumentos list, or None (-> caller PARKS the row) on ANY failure:
    a network/HTTP/JSON error, an unsuccessful body, or a page set we can't prove complete.
    The response carries `totalDocs`; we page by offset until we've collected them all, so a
    prestador with >tableSize receipts is no longer blind-spotted (the old offset=0 fail-OPEN).
    A missing/garbage totalDocs falls back to 'a short page means the end' — and if every page
    comes back full without a usable total we return None rather than risk a truncated 'absent'.
    """
    docs: list = []
    for i in range(max_pages):
        try:
            resp = session.get(
                f"{BASE_URL}/recibos/api/obtemDocumentosV2",
                params={
                    "dataEmissaoInicio": start.isoformat(),
                    "dataEmissaoFim": today.isoformat(),
                    "nifPrestadorServicos": profile.nif_prestador,
                    "modoConsulta": "Prestador",
                    "tipoPesquisa": "1",
                    "tableSize": str(page),
                    "offset": str(i * page),
                    "isAutoSearchOn": "on",
                },
                headers={**COMMON_HEADERS, "Referer": CONSULTAR_REFERER},
                timeout=120,   # a hung connection must not wedge the batch (up to max_pages gets)
            )
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            print(f"  WARNING: Portal duplicate check failed ({e}); parking the row this run.")
            return None
        if not isinstance(data, dict) or not data.get("success"):
            fe = (data or {}).get("fieldErrors") if isinstance(data, dict) else None
            print(f"  WARNING: Portal duplicate check returned an unsuccessful body ({fe or 'no detail'}); parking.")
            return None
        page_docs = data.get("listaDocumentos") or []
        docs.extend(page_docs)
        # totalDocs is the GRAND total across all offset pages, NOT per-page — verified live
        # (a tableSize=5 request reported totalDocs=80, numPaginas=16), so this fast-path can't
        # early-return a truncated list. If it were ever missing/garbage we fall through to the
        # short-page / max_pages logic below (never a truncated 'absent').
        total = data.get("totalDocs")
        try:
            if total is not None and len(docs) >= int(total):
                return docs
        except (TypeError, ValueError):
            total = None
        if len(page_docs) < page:      # a short (or empty) page is the last one
            return docs
        # a FULL page with no usable total -> can't tell if more remain; keep paging, bounded by max_pages
    return None   # never proved complete within max_pages -> fail-safe park (never a truncated 'absent')


# A booking code as a receipt line prints it: "Alojamento Local 123456/AL - HMEXAMPLE1 - 2026-10-15 a ...".
_HM_CODE_RE = re.compile(r"\bHM[A-Z0-9]{8}\b")


def receipt_pdf_hm_codes(pdf_bytes) -> set:
    """The HM booking code(s) printed on an official Fatura-Recibo PDF. An empty set means the
    PDF is unreadable or names no booking, so the caller must not read it as 'a different stay'."""
    if not pdf_bytes or pdf_bytes[:4] != b"%PDF":
        return set()
    try:
        from pypdf import PdfReader
        text = " ".join((page.extract_text() or "") for page in PdfReader(io.BytesIO(pdf_bytes)).pages)
    except Exception:
        return set()
    return set(_HM_CODE_RE.findall(text))


def _portal_doc_hm_codes(session, profile, doc) -> set:
    """Read the HM code(s) off a Portal receipt's official PDF (the same PDF archival.py fetches).
    An empty set means we could not tell (no record, no PDF, a Portal error)."""
    try:
        from archival import fetch_receipt_pdf    # lazy: archival imports the bridge package
        pdf = fetch_receipt_pdf(
            session, nif=doc.get("nifPrestadorServicos") or profile.nif_prestador,
            user_id=doc.get("userId", 0), numero_unico=doc["numeroUnico"],
            num_doc=doc.get("numDocumento"))
    except Exception:
        return set()
    return receipt_pdf_hm_codes(pdf)


def _found_doc_number(doc) -> int | None:
    try:
        return int(doc["numDocumento"])
    except (KeyError, TypeError, ValueError):
        return None   # matched, but the doc number is malformed -> still a dup, park safely


def check_portal_duplicate(
    session: requests.Session, profile: Profile,
    service_date: str, base_price: float, description: str,
    guest: str | None = None, docs=None, hm_code: str | None = None,
) -> tuple[str, int | None]:
    """Check if a receipt already exists on the Portal for this row — the CANONICAL cross-system
    duplicate guard (emitter.portal_receipt_status delegates here, so v1 CLI + v2 app share ONE
    implementation and can't drift).

    Returns a TRISTATE so a query failure is never mistaken for "no receipt":
    ("found", doc) / ("absent", None) / ("unknown", None).

    Matching: the obtemDocumentosV2 LIST response carries dataEmissao / importanciaRecebida /
    valorBase / nomeAdquirente but NO dataPrestacao, so we match on valorBase + importanciaRecebida
    (+ nomeAdquirente when a guest is given, which also discriminates two same-rate listings), PLUS a
    dataEmissao FLOOR: a receipt EMITTED before this stay's service_date is a PREVIOUS stay's receipt
    (this workflow files after the stay), so a repeat guest's older same-price receipt no longer parks
    the new stay. A doc with a missing/unparseable dataEmissao still counts as a match (fail-safe:
    prefer a false 'found' — a human verifies — over filing a real duplicate).

    Fail-SAFE: on any query/HTTP/JSON error, an unsuccessful body, or an unverifiably-complete page
    set, fetch_issued_docs returns None and this returns ("unknown", None); the caller PARKS the row
    (never a fail-open emit that could re-file). The journal + the sheet's Num Doc column remain the
    primary guards; the parked row retries next run.
    """
    # `docs`: an optional pre-fetched issued-docs SNAPSHOT (a per-taxpayer list the caller fetched
    # ONCE and appends filed docs to) — lets the per-row pre-emit guard skip re-listing the Portal
    # for every row. None => fetch the 11-month list live NOW (the standalone v1 CLI, the on-exception
    # check, and the post-emit re-confirm all pass None so those stay a fresh authoritative read). An
    # EMPTY list is a VALID snapshot (taxpayer has no receipts), distinct from None (fetch failed).
    if docs is None:
        _today = date.today()
        docs = fetch_issued_docs(session, profile, portal_dup_window_start(_today), _today)
        if docs is None:
            return ("unknown", None)

    expected_total = round(float(base_price) * (1 + VAT_RATE), 2)
    expected_base = round(float(base_price), 2)
    g = (guest or "").strip().lower()
    svc = _iso_date_or_none(service_date)
    for doc in docs:
        if not isinstance(doc, dict):
            continue
        doc_total = doc.get("importanciaRecebida")
        if doc_total is None or abs(float(doc_total) - expected_total) >= 0.02:
            continue
        vb = doc.get("valorBase")
        if vb is not None and abs(float(vb) - expected_base) >= 0.02:
            continue
        if g and str(doc.get("nomeAdquirente") or "").strip().lower() != g:
            continue
        snap_hm = doc.get("_hm_code")   # set on receipts THIS run filed (emitter._emit)
        if snap_hm and hm_code:
            # Same guest, same amount, filed in this run: a duplicate only for the SAME booking.
            if snap_hm != hm_code:
                continue
            return ("found", _found_doc_number(doc))
        if hm_code:
            # A Portal receipt: its PDF names the booking. Another booking's receipt is never this
            # row's duplicate; this booking's receipt is. No readable code -> the date rules below.
            codes = _portal_doc_hm_codes(session, profile, doc)
            if codes and hm_code not in codes:
                continue
            if hm_code in codes:
                return ("found", _found_doc_number(doc))
        # In-batch receipts without a booking code carry the date they were filed under: a receipt
        # filed for another stay's date is not this row's duplicate.
        filed_for = _iso_date_or_none(doc.get("_txn_date"))
        if filed_for and svc and filed_for != svc:
            continue
        # dataEmissao floor: a receipt issued BEFORE the stay is a prior stay's, not this one's.
        emitted_on = _iso_date_or_none(doc.get("dataEmissao"))
        if svc and emitted_on and emitted_on < svc:
            continue
        return ("found", _found_doc_number(doc))
    return ("absent", None)


# ---------------------------------------------------------------------------
# Session health check — re-login if portal session expired mid-batch
# ---------------------------------------------------------------------------
def ensure_session_alive(session: requests.Session, profile: Profile) -> bool:
    """Quick probe of the portal API; re-login if session expired.

    Returns True if the session is (now) alive, False if re-login also failed.
    """
    try:
        resp = session.get(
            f"{BASE_URL}/recibos/api/obtemDocumentosV2",
            params={
                "dataEmissaoInicio": date.today().isoformat(),
                "dataEmissaoFim": date.today().isoformat(),
                "nifPrestadorServicos": profile.nif_prestador,
                "modoConsulta": "Prestador",
                "tipoPesquisa": "1",
                "tableSize": "1",
                "offset": "0",
                "isAutoSearchOn": "on",
            },
            headers={**COMMON_HEADERS, "Referer": CONSULTAR_REFERER},
        )
        data = resp.json()
        if isinstance(data, dict) and data.get("success"):
            return True
    except Exception:
        pass
    print("  Session expired, re-authenticating...")
    return login(session, profile)


def writeback_row(sheets, profile: Profile, sheet_row: int, *,
                  doc_number: int | None = None, error: str | None = None) -> None:
    """Write either (doc_number + timestamp) or error back to the sheet row."""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if doc_number is not None:
        values = [[str(doc_number), now, ""]]
    else:
        values = [["", "", (error or "unknown")[:500]]]
    sheets.spreadsheets().values().update(
        spreadsheetId=profile.spreadsheet_id,
        range=f"'{profile.sheet_name}'!N{sheet_row}:P{sheet_row}",
        valueInputOption="USER_ENTERED",
        body={"values": values},
    ).execute()


def emit_one(
    session: requests.Session,
    profile: Profile,
    base_price: float,
    service_date: str,
    description: str,
    source_doc_number: int,
    debug: bool = False,
    guest_name: str | None = None,
) -> int:
    """Run the full 4-step emission flow for one receipt.

    Returns the new numDocumento on success. Raises RuntimeError on any failure.
    """
    vat_amount, vat_unrounded, total_with_vat = calculate_vat(base_price)

    # Guard: a stay whose service date predates início de atividade cannot be a normal
    # Fatura-Recibo (it would need an "ato isolado"). Cheap local pre-check using the
    # auto-derived date; skipped when the profile has no início date recorded. ISO dates
    # compare lexicographically = chronologically.
    # Normalize to ISO first: the lexicographic compare below and the handshake's date maths
    # are only correct for YYYY-MM-DD, and upstream plumbing tolerates slash forms.
    _sd_iso = _iso_date_or_none(service_date) or service_date
    inicio_ativ = getattr(profile, "data_inicio_atividade", "") or ""
    if inicio_ativ and _sd_iso < inicio_ativ:
        raise RuntimeError(
            f"service date {service_date} is before início de atividade {inicio_ativ} — "
            f"this stay must be issued as an 'ato isolado' at the Portal, not by this tool."
        )

    # A v2 taxpayer MUST carry an IVA regime derived from AT. A blank one means the setup-time
    # cadastro fetch failed — refuse to file with a guessed default that could be the WRONG
    # regime; park with a fixable reason instead. (A legacy v1 Profile has no iva_* attribute at
    # all, so hasattr() is False and the historical hard-coded regime still applies to it.)
    if hasattr(profile, "iva_cod_enq") and not any(
            getattr(profile, f, "") for f in ("iva_cod_enq", "iva_desc_enq",
                                              "iva_cod_tipo_operacoes", "iva_tipo_sujeito_passivo")):
        raise RuntimeError(
            "this client's IVA regime is not set — it couldn't be read from AT when they were "
            "added. Open Settings and use 'Refresh from Finanças' for this client, then issue "
            "again; refusing to file with a default regime that may be wrong."
        )

    # Same fail-closed rule for the fiscal address: the Portal ACCEPTS a blank
    # moradaFiscalPrestador (a blank-address receipt was really filed once — the dup-NIF
    # incident), so nothing downstream would stop a legally-sloppy document. Park with the
    # fix path instead. v2 profiles only (same discriminator as the IVA guard above).
    if hasattr(profile, "iva_cod_enq") and not (getattr(profile, "morada_fiscal_prestador", "") or "").strip():
        raise RuntimeError(
            "the taxpayer's fiscal address is blank — it couldn't be read from AT at setup. "
            "Open Settings and use 'Refresh from Finanças' for this client, then issue again; "
            "refusing to file a receipt with a blank address."
        )

    # Back-dated receipts (service date > ~10 days old) require the Portal's cadastro/IVA
    # handshake first, exactly as the web UI does on date-selection; without it emitirV2
    # rejects with a misleading "ordem técnica" error. Raises (-> row parked) if the Portal
    # reports no registered activity on that date (needs an ato isolado).
    if needs_historico_handshake(_sd_iso):
        historico_cadastro_handshake(session, profile.nif_prestador, _sd_iso, debug=debug)

    # Step 1/4: metadata validation
    if not validate_new_receipt(session, profile, source_doc_number, service_date, debug=debug):
        raise RuntimeError("metadata validation failed")

    # Navigate to emit page (matches browser flow — needed as Referer for next calls)
    session.get(emit_page_referer(source_doc_number, service_date))

    # Step 2/4: line item validation
    if not validate_line_item(
        session, description, base_price, total_with_vat,
        vat_unrounded, service_date, source_doc_number, debug=debug,
    ):
        raise RuntimeError("line item validation failed")

    # Step 3/4: server-side dry-run
    dry = submit_receipt(
        session, profile, description, base_price, total_with_vat,
        vat_amount, vat_unrounded, service_date, source_doc_number,
        validate_only=True, debug=debug, guest_name=guest_name,
    )
    if isinstance(dry, dict):
        if dry.get("erros"):
            raise RuntimeError(f"server validation: {dry['erros']}")
        if dry.get("success") is False:
            msg = dry.get("errorMessage", "unknown")
            if dry.get("fieldErrors"):
                msg += f" | fieldErrors: {dry['fieldErrors']}"
            raise RuntimeError(f"server validation failed: {msg}")

    # Step 4/4: real submission
    result = submit_receipt(
        session, profile, description, base_price, total_with_vat,
        vat_amount, vat_unrounded, service_date, source_doc_number,
        validate_only=False, debug=debug, guest_name=guest_name,
    )
    if not isinstance(result, dict):
        raise RuntimeError(f"unexpected response: {result}")
    if result.get("success") is False:
        msg = result.get("errorMessage", "unknown")
        if result.get("fieldErrors"):
            msg += f" | fieldErrors: {result['fieldErrors']}"
        raise RuntimeError(f"submit failed: {msg}")

    num = result.get("numDocumento")
    if not num:
        raise RuntimeError(f"no numDocumento in response: {result}")
    return int(num)


def emit_from_sheet(
    session: requests.Session, profile: Profile,
    dry_run: bool = False, debug: bool = False, assume_yes: bool = False,
) -> None:
    """Main --from-sheet flow: read pending rows, preview, confirm, emit, writeback.

    In dry_run mode, authenticates with both Google and the Portal, prints the
    preview of pending rows + totals, and exits without touching either service's
    write surface. Useful for verifying the pipeline before committing to a batch.

    Resilience features:
    - Column header validation prevents silent data corruption on sheet changes
    - Crash journal survives between emission and writeback
    - Portal duplicate guard prevents re-emission if writeback was lost
    - Session health check + auto-reconnect prevents mid-batch expiry
    - Writeback failures escalated with non-zero exit code
    """
    print(f"\nAuthenticating with Google Sheets (profile: {profile.name})...")
    sheets = get_sheets_service(profile, assume_yes=assume_yes)

    # --- Validate column headers (fail-fast if sheet structure changed) ---
    validate_column_headers(sheets, profile)

    if dry_run:
        r = sheets.spreadsheets().values().get(
            spreadsheetId=profile.spreadsheet_id,
            range=f"'{profile.sheet_name}'!N1:P1",
        ).execute()
        current_row = (r.get("values") or [[]])[0]
        expected = ["Num Doc", "Emitted At", "Error"]
        if current_row[:3] != expected:
            print("  WARNING: Writeback headers missing or wrong at N1:P1.")
            print(f"    Expected: {expected}")
            print(f"    Found:    {current_row[:3]}")
            print("    (Dry-run won't add them; run without --dry-run to auto-create.)")
        else:
            print("  Writeback headers OK (N1:P1).")
    else:
        ensure_writeback_headers(sheets, profile)

    # --- Recover any rows stuck from a previous crashed run ---
    recovered = journal_recover(sheets, profile)
    if recovered:
        print(f"  Recovered {recovered} row(s) from previous run.")

    print(f"Reading pending rows from '{profile.sheet_name}'...")
    pending = read_pending_rows(sheets, profile)

    if any(p.get("_fills") for p in pending):
        print("\nAuto-filling missing derived cells:")
        autofill_pending(sheets, profile, pending, dry_run=dry_run)

    print_pending_table(pending)
    if not pending:
        return

    if dry_run:
        print("[DRY RUN] Skipping emission loop — no receipts issued, no sheet writeback.\n")
        print("To emit for real, re-run without --dry-run.\n")
        return

    to_emit = select_rows(pending, assume_yes=assume_yes)
    if not to_emit:
        print("Nothing selected.")
        return

    print("\nFetching latest document number...")
    source_doc_number = get_latest_doc_number(session, profile, assume_yes=assume_yes)
    print(f"  Latest existing: {source_doc_number}")
    session.get(f"{BASE_URL}/recibos/portal/consultar")

    emitted, errored, skipped = 0, 0, 0
    writeback_failures: list[dict] = []

    for i, row in enumerate(to_emit, 1):
        sr = row["sheet_row"]
        print(
            f"\n[{i}/{len(to_emit)}] row {sr}: "
            f"{row['guest']} / {row['service_date']} / {row['base']:.2f} EUR"
        )

        dup_status, existing = check_portal_duplicate(
            session, profile, row["service_date"], row["base"], row["description"],
            guest=row.get("guest"),
        )
        if dup_status == "found":
            print(f"  DUPLICATE DETECTED: doc {existing} already exists on Portal.")
            print(f"  Writing back existing doc number (writeback was lost last run).")
            try:
                writeback_row(sheets, profile, sr, doc_number=existing)
            except Exception as wb_err:
                print(f"  WARNING: could not write back recovered doc: {wb_err}")
                writeback_failures.append({"row": sr, "doc": existing, "error": str(wb_err)})
            emitted += 1
            continue
        if dup_status == "unknown":
            # FAIL-SAFE: could not check the Portal -> PARK this row (do NOT emit). Num Doc stays
            # blank so it retries next run; the note lands in col P for the operator.
            print("  SKIPPED: Portal duplicate-check unreachable; parking row (retries next run).")
            try:
                writeback_row(sheets, profile, sr,
                              error="RETRY: Portal duplicate-check unreachable; not emitted this run")
            except Exception as wb_err:
                print(f"  WARNING: could not park row: {wb_err}")
                writeback_failures.append({"row": sr, "doc": None, "error": str(wb_err)})
            skipped += 1
            continue

        if not ensure_session_alive(session, profile):
            print("  FATAL: Could not re-authenticate with Portal. Stopping batch.")
            break

        journal_record_pending(profile, sr, row["service_date"], row["base"], row["description"])

        try:
            num = emit_one(
                session,
                profile,
                row["base"],
                row["service_date"],
                row["description"],
                source_doc_number,
                debug=debug,
                guest_name=row.get("guest"),
            )
            print(f"  OK -> doc {num}")

            journal_record_emitted(profile, sr, num)

            writeback_row(sheets, profile, sr, doc_number=num)

            journal_record_done(profile, sr)

            source_doc_number = num
            emitted += 1
        except Exception as e:
            print(f"  FAILED: {e}")
            try:
                writeback_row(sheets, profile, sr, error=str(e))
            except Exception as wb_err:
                print(f"  WARNING: also failed to write error back to sheet: {wb_err}")
                writeback_failures.append({"row": sr, "doc": None, "error": str(wb_err)})
            errored += 1

    print(f"\n=== Batch complete: {emitted} emitted, {errored} errored, {skipped} parked ===")

    if writeback_failures:
        fail_path = profile.journal_path.parent / "last_batch_failures.json"
        fail_path.write_text(json.dumps(writeback_failures, indent=2), encoding="utf-8")
        print(f"\n  CRITICAL: {len(writeback_failures)} writeback failure(s)!")
        print(f"  These rows were emitted on Portal but NOT recorded in the sheet:")
        for f in writeback_failures:
            print(f"    Row {f['row']}: doc={f['doc']} — {f['error']}")
        print(f"\n  Recovery file: {fail_path}")
        print("  Re-run --from-sheet to auto-recover via crash journal, or fix manually.")
        sys.exit(1)


# ---------------------------------------------------------------------------
# Argument parsing + entry point
# ---------------------------------------------------------------------------
def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Issue Portuguese Fatura-Recibo via Portal das Financas."
    )
    p.add_argument("--profile", default="laurent",
                   help="profile name (e.g. laurent, operator-b). Default: laurent.")
    p.add_argument("--from-sheet", action="store_true",
                   help="batch mode: read pending rows from GR-AB&B")
    p.add_argument("--dry-run", action="store_true",
                   help="preview without hitting the Portal write surface")
    p.add_argument("--debug", action="store_true",
                   help="print Portal API responses")
    p.add_argument("--yes", action="store_true",
                   help="non-interactive: auto-confirm prompts and disable input fallbacks. "
                        "Required for Windows Task Scheduler.")
    p.add_argument("--spreadsheet-id", default=None,
                   help="override the profile's default spreadsheet id")
    p.add_argument("--sheet-name", default=None,
                   help="override the profile's default sheet tab name")
    return p.parse_args(argv)


def main():
    args = parse_args()

    sheet_overrides: dict = {}
    if args.spreadsheet_id:
        sheet_overrides["spreadsheet_id"] = args.spreadsheet_id
    if args.sheet_name:
        sheet_overrides["sheet_name"] = args.sheet_name

    try:
        profile = load_profile(args.profile, sheet_overrides=sheet_overrides)
    except RuntimeError as e:
        print(f"ERROR loading profile {args.profile!r}:\n{e}", file=sys.stderr)
        sys.exit(1)

    session = requests.Session()

    if not login(session, profile):
        if not login_with_cookie(session, profile, assume_yes=args.yes):
            sys.exit(1)

    if args.from_sheet:
        emit_from_sheet(session, profile,
                        dry_run=args.dry_run, debug=args.debug, assume_yes=args.yes)
        return

    # Interactive single-receipt path. --yes here means: skip the final
    # "Submit this receipt?" confirmation. The price/date/description
    # prompts themselves can't be auto-answered, so --yes implies an
    # interactive caller for this path.
    if args.yes:
        print("Note: --yes only auto-confirms; the price/date/description prompts still need input.")

    print("\nFetching latest document number...")
    source_doc_number = get_latest_doc_number(session, profile, assume_yes=args.yes)
    print(f"  Latest existing: {source_doc_number}  (new receipt will likely be {source_doc_number + 1})")

    base_price, service_date, description, guest_name = prompt_receipt_details()
    vat_amount, vat_unrounded, total_with_vat = calculate_vat(base_price)

    print("\n" + "=" * 50)
    print("RECEIPT SUMMARY")
    print("=" * 50)
    print(f"  Profile:      {profile.name}")
    print(f"  Type:         Fatura-Recibo (FR)")
    print(f"  Copy source:  {source_doc_number}  (new number assigned by server)")
    print(f"  Description:  {description}")
    print(f"  Service date: {service_date}")
    print(f"  Base price:   {base_price:.2f} EUR")
    print(f"  VAT (6%):     {vat_amount:.2f} EUR")
    print(f"  Total:        {total_with_vat:.0f} EUR")
    print(f"  Client name:  {guest_name or '(none)'}")
    print(f"  Buyer:        Foreign (NIF 999999990, country UK)")
    print("=" * 50)

    if args.dry_run:
        print("\n[DRY RUN] Skipping submission.")
        print("Payload that would be sent:")
        payload = build_receipt_payload(
            profile, description, base_price, total_with_vat, vat_amount, vat_unrounded,
            service_date, validate=False, guest_name=guest_name,
        )
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return

    if args.yes:
        print("\n[--yes] Auto-confirming receipt submission.")
    else:
        confirm = input("\nSubmit this receipt? (yes/no): ").strip().lower()
        if confirm not in ("yes", "y"):
            print("Cancelled.")
            return

    session.get(f"{BASE_URL}/recibos/portal/consultar")

    try:
        doc_number = emit_one(
            session, profile, base_price, service_date, description,
            source_doc_number, debug=args.debug, guest_name=guest_name,
        )
    except RuntimeError as e:
        print(f"\n  FAILED: {e}")
        sys.exit(1)

    print(f"\n  Receipt submitted successfully!")
    print(f"  Document number: {doc_number}")


if __name__ == "__main__":
    main()
