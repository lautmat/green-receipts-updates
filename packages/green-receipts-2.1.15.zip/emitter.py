#!/usr/bin/env python3
"""green-receipts v2 — per-laptop emitter (Phase 5).

Orchestrates: per-NIF EMIT_LOCK -> listClaimable -> claim -> guards G1-G4 ->
recordEmitting -> emit_one (v1, reused verbatim) -> recordEmitted, parking the row
IN_DOUBT on a failure at/after the irreversible Portal submit. The serializer client
and the emit function are INJECTABLE so the orchestration is unit-tested without the
real Portal (issuing real tax documents in a test is forbidden).

Identity is STRICT (owner decision 2026-06-22, no. 1): an AT sub-user only ever issues
under its own NIF, so for every row `nifPrestadorServicos == taxpayer_nif ==
int(at_login_username.split('/')[0])` and `atividadePrestador == "0"+cae_code`. A
divergence is an identity-loading bug -> abort the whole batch, emit nothing more.
"""
from __future__ import annotations

import json
import random
import re
import sys
import time
from dataclasses import dataclass
from datetime import date

VAT_RATE = 0.06  # matches emit_receipt.VAT_RATE (=> effective 5.6605% of TTC)


class EmitInDoubt(Exception):
    """The irreversible emitirV2 submit MAY have happened (e.g. network timeout). The
    row is parked IN_DOUBT for human Portal verification — NEVER auto re-emitted."""


class EmitBatchAbort(Exception):
    """A guard violation that must stop the entire batch (identity-loading bug)."""


def base_from_ttc(ttc) -> float:
    return round(float(ttc) / (1 + VAT_RATE), 2)


@dataclass
class RowProfile:
    """Per-row prestador identity. Duck-types the fields emit_receipt.build_receipt_payload
    + emit_one read, so v1 emit_one is reused unchanged."""
    nif_prestador: int
    nome_prestador: str
    morada_fiscal_prestador: str
    morada_fiscal: str
    estabelecimento_comercial: str
    atividade_prestador: str            # "0" + cae_code, e.g. "055201"
    atividade_prestador_descr: str
    portal_nif: str                     # at_login_username "NIF/seq"
    portal_password: str
    # Auto-derived cadastro (from AT). Defaults keep older callers/tests working; emit_one
    # uses data_inicio_atividade as an activity-start guard and build_receipt_payload uses
    # the iva_* fields (falling back to the historical hard-coded regime when blank).
    data_inicio_atividade: str = ""
    iva_cod_enq: str = ""
    iva_desc_enq: str = ""
    iva_cod_tipo_operacoes: str = ""
    iva_tipo_sujeito_passivo: str = ""


def build_row_profile(taxpayer, prop, cred) -> RowProfile:
    return RowProfile(
        nif_prestador=int(taxpayer.nif_prestador),
        nome_prestador=taxpayer.nome_prestador,
        morada_fiscal_prestador=taxpayer.morada_fiscal_prestador,
        morada_fiscal=taxpayer.morada_fiscal,
        estabelecimento_comercial=taxpayer.estabelecimento_comercial,
        atividade_prestador="0" + str(prop.cae_code),
        atividade_prestador_descr=prop.cae_descr,
        portal_nif=taxpayer.at_login_username,
        portal_password=cred.password,
        data_inicio_atividade=getattr(taxpayer, "data_inicio_atividade", ""),
        iva_cod_enq=getattr(taxpayer, "iva_cod_enq", ""),
        iva_desc_enq=getattr(taxpayer, "iva_desc_enq", ""),
        iva_cod_tipo_operacoes=getattr(taxpayer, "iva_cod_tipo_operacoes", ""),
        iva_tipo_sujeito_passivo=getattr(taxpayer, "iva_tipo_sujeito_passivo", ""),
    )


def cadastro_drift(session, taxpayer) -> str:
    """Return a plain description if the taxpayer's LIVE AT registration no longer matches what
    the registry stored at setup (IVA regime or an address changed at Finanças), else "". This is
    how the tool handles a taxpayer's data changing over time: it re-reads AT each run and refuses
    to file under stale details. Best-effort — ANY read error returns "" (a network hiccup must not
    block filing; the stored values were correct at setup). Only NON-BLANK stored fields are
    compared, so a not-yet-derived (blank) field never reads as drift (emit_one guards blank IVA)."""
    if session is None or not hasattr(taxpayer, "iva_cod_enq"):
        return ""
    try:
        from emit_receipt import fetch_cadastro
        cad = fetch_cadastro(session)
    except Exception:
        return ""
    checks = [
        ("IVA regime", getattr(taxpayer, "iva_cod_enq", ""), cad.iva_cod_enq),
        ("IVA operations code", getattr(taxpayer, "iva_cod_tipo_operacoes", ""), cad.iva_cod_tipo_operacoes),
        ("fiscal address", getattr(taxpayer, "morada_fiscal_prestador", ""), cad.morada_fiscal_prestador),
        ("establishment", getattr(taxpayer, "estabelecimento_comercial", ""), cad.estabelecimento_comercial),
    ]

    # Compare case/whitespace-insensitively: hand-typed addresses (the setup fallback when the
    # AT read failed) legitimately differ from AT's rendering in case and spacing — that is not
    # drift, and parking every run over it would train the operator to ignore the guard.
    def _norm(s):
        return " ".join(str(s or "").split()).casefold()
    diffs = [f"{label} '{stored}' -> '{live}'" for label, stored, live in checks
             if _norm(stored) and _norm(stored) != _norm(live)]
    return "; ".join(diffs)


def emit_for_nif(*, registry, taxpayer, serializer, cred, emit_fn,
                 operator_id="emitter", session=None, source_doc=None, archiver=None,
                 v1_bridge=None, on_progress=None, should_stop=None) -> dict:
    """Emit all claimable rows for one taxpayer, under its per-NIF emit lock.

    ``archiver`` (optional) is called ``archiver(num_doc=, row=, session=)`` after each
    successful emit to archive the official Fatura-Recibo PDF (best-effort; a failure is
    counted, never fatal — the receipt is filed + recorded and the PDF can be backfilled).

    ``v1_bridge`` (optional) is the v1∥v2 firewall (see v1_bridge.py): before each emit it
    RESERVES the matching legacy v1 GR-AB&B row (or detects v1 already filed -> skip), and
    after the outcome it writes the doc number back / releases the reservation — so a booking
    is filed by exactly one system. Best-effort: a v1-sheet failure never blocks a v2 emit."""
    nif = int(taxpayer.nif_prestador)
    lock = serializer.emit_lock_acquire(nif, operator_id)
    if not lock.get("ok"):
        return {"nif": nif, "skipped": "emit-lock held by " + str(lock.get("held_by")),
                "emitted": 0, "errored": 0, "in_doubt": 0}

    source_doc = source_doc if source_doc is not None else [0]
    emitted = errored = indoubt = skipped_v1 = stolen = 0
    archived = archive_failed = v1_write_failed = 0

    def _bridge_call(method, reservation, **kw):
        """Best-effort v1-sheet write (commit/release); a failure never blocks a v2 emit."""
        nonlocal v1_write_failed
        if v1_bridge is None or reservation is None:
            return
        try:
            getattr(v1_bridge, method)(reservation, **kw)
        except Exception:
            v1_write_failed += 1

    # Defined OUTSIDE the try: the finally's archival pass must see it even when the claim
    # loop raises before/while filling it (a mid-batch serializer 500 would otherwise skip
    # archival for every receipt already filed this run — silently, with archived=0).
    to_archive = []   # (num, row) pairs — PDF archival is deferred to after the filing loop
    try:
        # DRIFT GUARD (once per taxpayer, before claiming any row): if the prestador's AT
        # registration changed since setup (new IVA regime, moved establishment, etc.), do NOT
        # file receipts under the stale details — park the whole taxpayer with a clear reason so
        # the operator refreshes it in Settings. Best-effort; a read failure proceeds (see docstring).
        drift = cadastro_drift(session, taxpayer)
        if drift:
            return {"nif": nif, "emitted": 0, "errored": 0, "in_doubt": 0,
                    "skipped": f"tax details changed at Finanças ({drift}) — open Settings, refresh "
                               f"this client from AT, then issue again"}
        # Duplicate-check baseline: fetch THIS taxpayer's issued-docs list ONCE (under the emit lock,
        # on its own authenticated session -> its own docs only), then reuse it for every row's
        # pre-emit dup guard instead of re-listing the Portal per row. _emit appends each filed doc so
        # a same-batch duplicate is still caught. None (fetch failed) -> rows fall back to a live
        # per-row fetch (unchanged fail-safe); session None (tests) -> None (per-row live).
        # ACCEPTED TRADE-OFF: a receipt filed OUTSIDE this process while the batch runs (manual
        # Portal issuance / a parallel v1 run) is invisible to the snapshot. The post-submit
        # re-confirm still runs LIVE, so such a collision surfaces as IN_DOUBT for a human —
        # fail-safe, not fail-open. Don't hand-file while a batch is running (also in the docs).
        dup_snapshot = None
        if session is not None:
            from emit_receipt import fetch_issued_docs, portal_dup_window_start
            _t = date.today()
            dup_snapshot = fetch_issued_docs(session, taxpayer, portal_dup_window_start(_t), _t)
        for cand in serializer.list_claimable([str(nif)]):
            # STOP: honored only BETWEEN rows (before we claim/file the next), never mid-submit — so a
            # stop can never orphan a half-filed receipt. Rows already filed stay filed; nothing new starts.
            if should_stop is not None and should_stop():
                break
            lease = serializer.claim(cand["row_id"], operator_id)
            if not lease.get("ok"):
                continue
            rid, version = cand["row_id"], lease["row_version"]
            row = serializer.get_row(rid)["row"]

            # G1 — route_status must be RESOLVED.
            if row.get("route_status") != "RESOLVED":
                serializer.record_error(rid, operator_id, version, "G1: not RESOLVED")
                errored += 1
                continue
            # G2 — re-resolve the listing and confirm it still maps to this row's stamp.
            prop = registry.resolve_listing(row.get("listing_id_str", ""))
            prop_tx = registry.taxpayers.get(prop.taxpayer_id) if prop else None
            if (not prop or not prop_tx or int(prop_tx.nif_prestador) != int(row["taxpayer_nif"])
                    or str(prop.cae_code) != str(row["cae_code"])):
                serializer.record_error(rid, operator_id, version, "G2: settings drift / re-resolve mismatch")
                errored += 1
                continue
            # G3 — only emit rows whose taxpayer_nif is the NIF we are authorized for.
            if str(row["taxpayer_nif"]) != str(nif):
                serializer.record_error(rid, operator_id, version, "G3: nif not authorized")
                errored += 1
                continue

            profile = build_row_profile(taxpayer, prop, cred)
            # G4 — payload identity MUST equal the row stamp; a mismatch aborts the whole batch.
            if (int(profile.nif_prestador) != int(row["taxpayer_nif"])
                    or profile.atividade_prestador != "0" + str(row["cae_code"])):
                raise EmitBatchAbort(f"G4 identity mismatch on {rid}: emit nothing")

            # v1∥v2 firewall — claim the matching v1 GR-AB&B row BEFORE any Portal write, so v1
            # never re-files this booking (and we detect a stay v1 already filed). Best-effort:
            # if the v1 sheet is unreachable we proceed (v2's Portal pre-check is the backstop).
            reservation = None
            if v1_bridge is not None:
                try:
                    reservation = v1_bridge.reserve(row)
                except Exception:
                    reservation = None
                    v1_write_failed += 1
                if reservation is not None and reservation.action == "skip_filed":
                    serializer.record_in_doubt(rid, operator_id, reservation.detail)
                    skipped_v1 += 1
                    continue
                if reservation is not None and reservation.action == "skip_blocked":
                    serializer.record_error(rid, operator_id, version, "v1_bridge: " + reservation.detail)
                    errored += 1
                    continue

            base = (float(row["base"]) if str(row.get("base", "")) not in ("", "None")
                    else base_from_ttc(row["ttc"]))
            # The server's LAST STOP before the irreversible submit: recordEmitting refuses
            # when the claim no longer belongs to us (409 "stolen"/version conflict — e.g.
            # our lease expired while the laptop slept and another emitter took the row).
            # Filing anyway could produce a DUPLICATE real receipt, so: no emit_fn, and for
            # a genuinely-stolen row NO further state writes (it is not ours). A busy/
            # internal/transport refusal is different: the row is still OURS and merely
            # unconfirmed — release our claim (best-effort) so it does not stall for the
            # full lease, and count it errored, not stolen (review finding).
            try:
                rec_emitting = serializer.record_emitting(rid, operator_id, version)
            except Exception as e:  # noqa: BLE001 — transport blip must not abort the batch
                rec_emitting = {"ok": False, "error": repr(e)}
            if not (isinstance(rec_emitting, dict) and rec_emitting.get("ok")):
                _bridge_call("release", reservation, in_doubt=False,
                             note=f"record_emitting refused: {rec_emitting!r}")
                reason = str(rec_emitting.get("reason", "") if isinstance(rec_emitting, dict) else "")
                if reason in ("stolen", "version_conflict"):
                    stolen += 1          # another holder owns it now — touch nothing
                else:
                    try:                 # still ours: free the claim instead of stalling it
                        serializer.release(rid, operator_id, version)
                    except Exception:    # noqa: BLE001 — best-effort; lease expiry backstops
                        pass
                    errored += 1
                continue
            # Progress (display-only): fire ONLY now — the row passed every guard + the firewall and is
            # about to file at the Portal — so the count reflects RECEIPTS BEING FILED, not the (larger)
            # pool of claimable stays the firewall skips as already-filed-in-v1.
            if on_progress is not None:
                on_progress({"guest": row.get("guest") or "", "hm": row.get("hm_code") or ""})
            try:
                # Transaction date on the receipt (dataPrestacao) = the Airbnb PAYOUT date when the
                # sheet carries it (payment-date pipeline), else fall back to the stay's service_date
                # (check-in) so existing rows are UNCHANGED. The receipt DESCRIPTION and the Portal
                # duplicate-match keep the stay dates (dup-match keys on dataEmissao, not this date).
                txn_date = row.get("payment_date") or row["service_date"]
                num = emit_fn(session=session, profile=profile, base=base,
                              service_date=txn_date, description=row["description"],
                              source_doc=source_doc[0], guest=row.get("guest"),
                              docs_snapshot=dup_snapshot)
                source_doc[0] = num
            except EmitInDoubt as e:
                # receipt MAY exist -> keep the v1 row BLOCKED (never restore to re-fileable).
                _bridge_call("release", reservation, in_doubt=True, note=str(e))
                serializer.record_in_doubt(rid, operator_id, str(e))
                indoubt += 1
                continue
            except Exception as e:  # pre-submit / safe failure -> re-claimable ERROR
                # positively NOT filed -> release the v1 reservation so v1 can handle it.
                _bridge_call("release", reservation, in_doubt=False, note=str(e))
                serializer.record_error(rid, operator_id, version, str(e))
                errored += 1
                continue

            # --- PAST THIS LINE THE RECEIPT IS FILED (doc `num`, irreversible Portal submit). ---
            # Persisting the EMITTED state can still fail: the serializer HTTP call can raise
            # (Apps Script 5xx / HTML error page / 302 / timeout -> requests raises or r.json()
            # raises), or it can return a non-dict / not-ok body (version conflict, lease loss).
            # A FILED receipt must NEVER fall back to a re-claimable ERROR -- the next run would
            # RE-FILE it -> duplicate real tax document. ANY failure here parks IN_DOUBT instead
            # (the receipt exists; a human reconciles) and is never counted emitted.
            try:
                rec = serializer.record_emitted(rid, operator_id, version, num)
                committed = isinstance(rec, dict) and (rec.get("ok") is True or rec.get("idempotent"))
            except Exception as e:
                rec, committed = repr(e), False
            if not committed:
                # The receipt IS filed as doc `num` (only v2's own state-write failed). Write the
                # REAL doc to v1 so it never re-files; v2's row stays IN_DOUBT for a human to fix.
                _bridge_call("commit", reservation, num_doc=num)
                serializer.record_in_doubt(rid, operator_id,
                                           f"FILED as doc {num} but record_emitted not committed: {rec}")
                indoubt += 1
                continue

            emitted += 1
            _bridge_call("commit", reservation, num_doc=num)
            if archiver is not None:
                to_archive.append((num, row))   # DEFERRED — archived in one pass after the loop
    finally:
        # Official-PDF archival, batched AFTER the filing loop (still under the session + lock),
        # so the per-receipt 503 "PDF not generated yet" retries (up to ~12s each) never stall the
        # filing loop the operator is watching. In the FINALLY so a mid-loop exception (serializer
        # refusal etc.) still archives every receipt that DID file. Best-effort: the receipts are
        # already filed AND recorded; any archival failure is recoverable offline
        # (tools/archive_receipt_pdf.py) and must NEVER fail the emit (nor mask the loop's error).
        for _num, _row in to_archive:
            try:
                archiver(num_doc=_num, row=_row, session=session)
                archived += 1
            except Exception:
                archive_failed += 1
        try:
            # POST-SUBMIT cleanup only: every receipt is already filed + recorded by now. The
            # release is idempotent and the lock self-expires on its lease, so a transient 404
            # here must NEVER mask a successful batch (it did: the finally raised, the operator
            # saw an error though all receipts filed). Retry a blip, and swallow a final failure.
            serializer.emit_lock_release(nif, operator_id)
        except Exception:  # noqa: BLE001 — lease expiry backstops; never fail a filed batch
            pass

    return {"nif": nif, "emitted": emitted, "errored": errored, "in_doubt": indoubt,
            "stolen": stolen, "skipped_v1": skipped_v1, "archived": archived,
            "archive_failed": archive_failed, "v1_write_failed": v1_write_failed}


# --------------------------------------------------------------------------
# Production wiring (reuses v1 emit_receipt; lazily imported so tests need neither)
# --------------------------------------------------------------------------
class SerializerClient:
    """HTTP client to the Apps Script serializer web-app."""

    def __init__(self, exec_url: str, token: str, requests_mod=None):
        self.url, self.token = exec_url, token
        if requests_mod is None:
            import requests as requests_mod
        self._r = requests_mod

    def _post(self, op, operator_id="emitter", _tries=1, **kw):
        # A transient Apps Script hiccup (cold start, concurrent-execution limit, a 302 to an HTML
        # error page, an empty body) makes a bare r.json() raise a cryptic "Expecting value: line 1
        # column 1 (char 0)" that failed the WHOLE taxpayer. Retry _tries times for the IDEMPOTENT ops
        # (emit-lock + reads pass _tries>1 — they run BEFORE any Portal write), then raise a CLEAR error
        # the operator can act on. Write ops keep _tries=1: no auto-retry (no double-write risk) — a
        # non-JSON reply raises here and the caller's in-doubt/refusal handling makes it safe + clear.
        body = {"op": op, "operator_id": operator_id, "api_token": self.token, **kw}
        last = "no response"
        for attempt in range(max(1, _tries)):
            try:
                r = self._r.post(self.url, data=json.dumps(body),
                                 headers={"Content-Type": "application/json"}, timeout=120)
                return r.json()
            except ValueError:  # non-JSON body (Apps Script HTML/empty/redirect) — r.json() failed
                last = (f"serializer returned a non-JSON response (HTTP {getattr(r, 'status_code', '?')}) "
                        f"— likely a transient Apps Script error")
            except Exception as e:  # noqa: BLE001 — connection reset / read timeout
                last = f"serializer request failed ({e})"
            if attempt + 1 < max(1, _tries):
                # Equal-jitter backoff (base grows 1s,2s,3s...): sleep half the base plus a
                # random half. Decorrelates concurrent laptops (an operator's firm runs ~3 against one
                # document-locked serializer) so they don't retry in lockstep and re-collide on the
                # LockService (thundering herd). Single-client 404s are unaffected (still ~1-2s).
                _base = 1.0 * (attempt + 1)
                time.sleep(_base / 2 + random.uniform(0, _base / 2))
        raise RuntimeError(last + " — retry")

    def list_claimable(self, nifs):
        # A serializer refusal (503 busy / error body) has NO 'rows' key. Treating it as
        # an empty list read as "0 receipts pending" — the operator would conclude the
        # month was done (review: _post ignores the _status-in-body protocol). Fail LOUD.
        reply = self._post("listClaimable", nifs=nifs, _tries=3)
        if not isinstance(reply, dict) or "rows" not in reply:
            raise RuntimeError(f"serializer refused listClaimable (NOT '0 pending' — retry "
                               f"in a minute): {reply!r}")
        return reply["rows"]

    def claim(self, row_id, op):
        # PRE-SUBMIT + server-idempotent: claimDecision allows a same-owner re-claim while the
        # row is CLAIMED (Logic.gs), so retrying a lost-response claim just returns the current
        # authoritative row_version. At Apps Script's real ~1-in-4 non-JSON/404 rate a no-retry
        # claim aborted the whole batch on the first blip; _tries=3 (matching getRow + the emit
        # lock) rides through it. No double-file risk: this runs BEFORE any Portal write.
        return self._post("claim", operator_id=op, row_id=row_id, _tries=3)

    def get_row(self, row_id):
        reply = self._post("getRow", row_id=row_id, _tries=3)
        if not isinstance(reply, dict):
            raise RuntimeError(f"serializer refused getRow({row_id}): {reply!r}")
        # A clean 404 "not found" is a VALID answer (the caller handles a missing row and shows
        # a friendly message). Only a real refusal (busy 503 / 500 / no _status) fails loud, so
        # a refusal is never silently read as "not found" — while a genuine not-found never
        # throws a raw traceback at the operator (override.py / corrigir.bat).
        if "row" not in reply and reply.get("_status") != 404:
            raise RuntimeError(f"serializer refused getRow({row_id}): {reply!r}")
        return reply

    def list_settings(self, nifs):
        # Sheet->app property sync: read-only dump of the authoritative "Property Settings"
        # tab. Fail-LOUD contract — a serializer refusal must never read as "no properties"
        # (a sync that silently emptied the local mapping would park every stay at emit).
        reply = self._post("listSettings", nifs=nifs, _tries=3)
        if not isinstance(reply, dict) or "rows" not in reply:
            raise RuntimeError(f"serializer refused listSettings (retry in a minute): {reply!r}")
        return reply["rows"]

    def list_in_doubt(self, nifs):
        # #2: the reconcile worklist. Same fail-LOUD contract as list_claimable — a refusal must
        # NEVER read as "nothing to reconcile" (that would hide a possibly-duplicate receipt).
        reply = self._post("listInDoubt", nifs=nifs, _tries=3)
        if not isinstance(reply, dict) or "rows" not in reply:
            raise RuntimeError(f"serializer refused listInDoubt (retry in a minute): {reply!r}")
        return reply["rows"]

    def resolve_in_doubt(self, row_id, row_version, op="human", actor=None, note=None):
        # #2: operator "mark verified" IN_DOUBT -> VERIFIED (CAS on row_version, server-guarded).
        return self._post("resolveInDoubt", operator_id=op, row_id=row_id, row_version=row_version,
                          actor=actor, note=note)

    def list_needs_review(self, nifs):
        # Stage D: the pre-emit REVIEW LANE (STAGING needs_review + QUARANTINE). Fail-LOUD like
        # list_claimable/list_in_doubt — a refusal must NEVER read as "nothing to review" (that would
        # hide a resolution/flagged stay the operator must handle before a receipt can issue).
        reply = self._post("listNeedsReview", nifs=nifs, _tries=3)
        if not isinstance(reply, dict) or "rows" not in reply:
            raise RuntimeError(f"serializer refused listNeedsReview (retry in a minute): {reply!r}")
        return reply["rows"]

    def mark_parked_filed_by_hand(self, row_id, op="human", actor=None):
        # A PARKED stay (Review -> Needs review) the operator issued by hand at the Portal ->
        # STAGING 'filed_by_hand' (terminal; a later capture never issues it). Server-idempotent
        # (an already-marked row answers ok+idempotent), so a lost-response retry is safe — and it
        # never touches the Portal. An older serializer answers {"error": "unknown op"}.
        return self._post("markParkedFiledByHand", operator_id=op, row_id=row_id, actor=actor, _tries=3)

    def override(self, row_id, field, old_value, new_value, row_version, op="human", actor=None):
        return self._post("override", operator_id=op, actor=actor, row_id=row_id, field=field,
                          old_value=old_value, new_value=new_value, row_version=row_version)

    def reroute(self, row_id, row_version, op="human"):
        """Re-stamp an un-emitted row from the CURRENT Property Settings (the G2
        settings-drift remedy) and return it to PENDING. CAS on row_version."""
        return self._post("reroute", operator_id=op, row_id=row_id, row_version=row_version)

    def record_invoice(self, *, hm, invoice_id, invoice_number, role, service_fee, vat,
                       reverse_charge, issue_date, drive_url, op="archivist"):
        return self._post("recordInvoice", operator_id=op, hm=hm, invoice_id=invoice_id,
                          invoice_number=invoice_number, role=role, service_fee=service_fee,
                          vat=vat, reverse_charge=reverse_charge, issue_date=issue_date, drive_url=drive_url)

    def record_receipt_pdf(self, *, row_id, num_doc, drive_url, op="archivist"):
        return self._post("recordReceiptPdf", operator_id=op, row_id=row_id, num_doc=num_doc, drive_url=drive_url)

    def record_emitting(self, row_id, op, v):
        # PRE-SUBMIT + server-idempotent: handleRecordEmitting does NOT bump row_version and only
        # flips CLAIMED->EMITTING (Code.gs), so retrying a lost-response call is safe and returns
        # ok again. This is the LAST serializer write before the irreversible Portal submit; at
        # the measured ~1-in-4 non-JSON/404 rate, a no-retry call here aborted the batch. _tries=3
        # rides through a transient blip. (record_emitted, POST-submit, keeps its own IN_DOUBT path.)
        return self._post("recordEmitting", operator_id=op, row_id=row_id, row_version=v, _tries=3)

    def record_emitted(self, row_id, op, v, num):
        return self._post("recordEmitted", operator_id=op, row_id=row_id, row_version=v, num_doc=num)

    def record_error(self, row_id, op, v, err):
        return self._post("recordError", operator_id=op, row_id=row_id, row_version=v, error=err)

    def record_in_doubt(self, row_id, op, note):
        # This is the state write that parks a possibly-FILED receipt. If it is lost, the
        # row stays EMITTING and returns to the re-claimable pool -> a duplicate real tax
        # document on the next run. Retry hard, and if the serializer still won't take it,
        # SCREAM with everything a human needs to fix the sheet by hand (review finding:
        # record_in_doubt was a fire-and-forget single HTTP call).
        import time
        last = None
        for attempt in range(4):
            try:
                reply = self._post("recordInDoubt", operator_id=op, row_id=row_id, note=note)
                if isinstance(reply, dict) and (reply.get("ok") or reply.get("idempotent")):
                    return reply
                last = repr(reply)
            except Exception as e:  # noqa: BLE001 — transport blip: retry
                last = repr(e)
            if attempt < 3:
                time.sleep(0.5 * (2 ** attempt))
        print(f"\n*** CRITICAL: could not park row {row_id} IN_DOUBT ({note}). Last error: {last}\n"
              f"*** The receipt MAY be filed at the Portal. BEFORE the next emit run, open the GR\n"
              f"*** sheet and set this row's lifecycle to IN_DOUBT yourself, then verify at the\n"
              f"*** Portal (Faturas e Recibos Verdes > Consultar).", file=sys.stderr)
        return {"ok": False, "error": last}

    def release(self, row_id, op, v):
        return self._post("release", operator_id=op, row_id=row_id, row_version=v)

    def emit_lock_acquire(self, nif, op):
        return self._post("emitLockAcquire", operator_id=op, nif=str(nif), _tries=3)

    def emit_lock_release(self, nif, op):
        # POST-SUBMIT + idempotent: releasing an already-released/expired lock is a no-op, so
        # retrying a lost-response release is safe. _tries=3 so the final cleanup call rides
        # through a transient 404 instead of surfacing as an error on an otherwise-clean batch.
        return self._post("emitLockRelease", operator_id=op, nif=str(nif), _tries=3)


_HM_CODE_RE = re.compile(r"\bHM[A-Z0-9]{8}\b")   # same pattern as emit_receipt._HM_CODE_RE


def hm_code_from_description(description) -> str | None:
    """The Airbnb booking code (HM...) a receipt line is for ('... 123456/AL - HMEXAMPLE1 - ...'), or None."""
    m = _HM_CODE_RE.search(str(description or ""))
    return m.group(0) if m else None


def portal_receipt_status(session, profile, service_date, base, guest=None, docs=None, hm_code=None):
    """Ask the Portal whether a Fatura-Recibo matching this filing already exists — a TRISTATE
    ('found', num) / ('absent', None) / ('unknown', None). This is the out-of-band source of
    truth that arbitrates every emit outcome: the pre-emit duplicate guard; on an emit exception
    'found'/'unknown' -> IN_DOUBT vs 'absent' -> re-claimable ERROR; and the post-emit doc-number
    re-confirm.

    Delegates to emit_receipt.check_portal_duplicate so the v1 CLI (check_portal_duplicate) and the
    v2 app (this) share ONE implementation — the 11-month offset-paged window (the Portal caps
    obtemDocumentosV2 at 12 months), the base+total+guest match, and the dataEmissao floor — and can
    never drift. See check_portal_duplicate for the full matching + fail-safe contract."""
    from emit_receipt import check_portal_duplicate
    return check_portal_duplicate(session, profile, service_date, base, "", guest=guest, docs=docs,
                                  hm_code=hm_code)


def make_real_emit_fn(*, confirm=True):
    """An emit_fn wrapping v1 emit_one, with the Portal as the arbiter of every outcome.

    The original wrapper only mapped socket errors to IN_DOUBT, so a receipt that reached
    the Portal but whose response was a 5xx / redirect / non-JSON raised HTTPError /
    JSONDecodeError and was recorded as a RE-CLAIMABLE error -> the next run would RE-FILE
    -> duplicate real tax document. This version asks the Portal what actually happened:

      * pre-emit: if a receipt for (date,total) already exists -> refuse (IN_DOUBT), never
        file a second copy (also catches a v1 receipt for the same stay).
      * on ANY exception: query the Portal. 'found' or 'unknown' -> IN_DOUBT (the receipt
        may exist; a human verifies, it is NEVER auto re-emitted). Only a positively
        'absent' receipt is re-raised as the original error (safe, re-claimable).
      * on success: re-confirm; a doc-number mismatch parks IN_DOUBT.

    `confirm=False` restores the old behavior (tests / offline)."""
    from emit_receipt import emit_one  # lazy: keeps tests free of requests/keyring

    def _emit(*, session, profile, base, service_date, description, source_doc, guest, docs_snapshot=None):
        # docs_snapshot: the per-taxpayer issued-docs list, fetched ONCE by emit_for_nif and appended
        # to after each filing. Used ONLY for the pre-emit duplicate guard (a pre-existing v1/manual/
        # prior-run receipt, or an earlier same-batch one via the append below). The on-exception and
        # post-success re-confirm checks below deliberately pass docs=None -> a FRESH live read, because
        # they must reflect what THIS emit just did at the Portal, which a run-start snapshot cannot.
        # hm: the booking this row is for, read from its receipt line. It tells the guard which stay a
        # Portal receipt is for, so a second stay of the same guest at the same price is not a duplicate.
        total = round(float(base) * (1 + VAT_RATE), 2)
        hm = hm_code_from_description(description)
        if confirm:
            status, n = portal_receipt_status(session, profile, service_date, base, guest=guest,
                                              docs=docs_snapshot, hm_code=hm)
            if status == "found":
                raise EmitInDoubt(
                    f"a receipt for {service_date} total {total:.2f} ALREADY exists as doc {n} "
                    f"- refusing to file a duplicate (verify, then mark the row done)")
            if status == "unknown":
                # Fail CLOSED, but self-healing: nothing has been filed yet, so this must
                # NOT park IN_DOUBT (which is terminal) — a plain raise here (BEFORE the
                # emit_one try) lands in the caller's safe-error path: re-claimable ERROR,
                # retried next run. (Was: 'unknown' proceeded to file blind — the one
                # fail-OPEN edge of the duplicate protection; review finding.)
                raise RuntimeError(
                    f"Portal duplicate pre-check unavailable for {service_date}/{total:.2f} "
                    f"- refusing to file blind; the row stays re-claimable, retry next run")
        try:
            num = emit_one(session, profile, base, service_date, description, source_doc, guest_name=guest)
        except EmitInDoubt:
            raise
        except Exception as e:
            # Pre-submit failures are safe (re-claimable); a failure AT/AFTER the irreversible
            # submit may have filed the receipt. Let the Portal decide which it was.
            if not confirm:
                raise EmitInDoubt(f"emit failed and confirmation is off: {e!r}")
            status, n = portal_receipt_status(session, profile, service_date, base, guest=guest, hm_code=hm)
            if status == "found":
                raise EmitInDoubt(f"emit raised {e!r} but the Portal shows the receipt as doc {n} "
                                  f"({service_date}/{total:.2f}) -> FILED; verify, do not re-emit")
            if status == "unknown":
                raise EmitInDoubt(f"emit raised {e!r} AND the Portal state is unconfirmable "
                                  f"({service_date}/{total:.2f}) -> park IN_DOUBT, verify manually")
            raise  # 'absent': positively not filed -> safe re-claimable ERROR
        if confirm:
            status, n = portal_receipt_status(session, profile, service_date, base, guest=guest, hm_code=hm)
            if status == "found" and n != num:
                raise EmitInDoubt(f"emit returned doc {num} but the Portal shows doc {n} for "
                                  f"{service_date}/{total:.2f}; verify before trusting either")
        # Reflect the just-filed doc in the per-taxpayer snapshot so a SECOND identical-amount(+guest)
        # row later in the SAME batch is caught by the pre-emit guard (exactly as the old per-row live
        # re-fetch did). Fields mirror the obtemDocumentosV2 list shape that check_portal_duplicate reads.
        # _txn_date: the date this doc was filed under, so the guard only catches a later row on the SAME
        # date (a repeat of the same stay), not a different stay of the same guest at the same price.
        if docs_snapshot is not None:
            docs_snapshot.append({
                "numDocumento": num,
                "importanciaRecebida": f"{total:.2f}",
                "valorBase": f"{round(float(base), 2):.2f}",
                "nomeAdquirente": guest or "",
                "dataEmissao": date.today().isoformat(),
                "_txn_date": service_date,
                "_hm_code": hm,
            })
        return num

    return _emit
