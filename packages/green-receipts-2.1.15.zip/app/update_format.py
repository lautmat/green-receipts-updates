"""app/update_format.py — the ONE definition of what an update is (docs/PLAN_AUTO_UPDATE.md Part 1).

Shared by the app's updater (app/updater.py), the release tools (tools/make_update.py,
tools/release_sign.py, tools/publish_update.py) and the tests, so the builder can never produce a
package the app would refuse, and the app can never accept a shape the builder would not make.

Standard library only, except Ed25519 signature checks, which use the `cryptography` package
already in the bundle. If `cryptography` cannot be imported, every signature check FAILS (closed).

Trust model in one line: a manifest is believed only after its exact bytes verify against one of
the accepted public keys (app/update_pubkey.py); a package is believed only after its size and
SHA-256 match that verified manifest; a package is unpacked only after every entry passes
check_member() below. Nothing here touches the network.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import zipfile
from pathlib import Path, PurePosixPath

MANIFEST_SCHEMA = 1

# Size caps (bytes / counts). Generous for code (the app's own files are ~1.5 MB), tight enough
# that a corrupt or hostile file cannot fill the disk or exhaust memory.
MAX_MANIFEST_BYTES = 64 * 1024
MAX_SIGNATURE_BYTES = 1024
MAX_PACKAGE_BYTES = 40 * 1024 * 1024          # the downloaded zip
MAX_UNCOMPRESSED_BYTES = 120 * 1024 * 1024    # everything inside it, added up
MAX_ENTRIES = 5000
MAX_INSTALLER_BYTES = 400 * 1024 * 1024       # Part 4: the full installer (embedded Python inside)
MAX_NOTES_CHARS = 400

VERSION_RE = re.compile(r"^\d{1,4}(\.\d{1,4}){1,3}$")
CHANNEL_RE = re.compile(r"^[a-z][a-z0-9-]{0,19}$")
HEX64_RE = re.compile(r"^[0-9a-f]{64}$")
INSTANCE_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,31}$")    # same rule as instance.py

# The top-level names an update package may contain: the app's own code, i.e. what
# tools/graduate.py allowlists (GRADUATE_FILES + GRADUATE_DIRS) minus the launchers (*.bat — they
# are written per install by build_portable.py and an update must never change how the app is
# started) and minus dev-only folders. tests/test_update_package.py asserts this matches
# graduate.py, so the two lists cannot drift apart silently.
PACKAGE_TOP_LEVEL = frozenset({
    "emitter.py", "emit.py", "emit_receipt.py", "profiles.py", "registry.py", "instance.py",
    "setup_taxpayer.py", "log_client.py", "archival.py", "drive_uploader.py", "override.py",
    "business_days.py", "login_cache.py", "pdf_store.py", "build_portable.py",
    "verify_settings.py", "verify_integrity.py", "requirements.txt", "README.md",
    "tools", "app", "airbnb_bridge", "apps_script_webapp", "config_templates", "schema", "guia",
    "tests",
})

# Never inside a package, at any depth (checked on every path component, case-insensitively):
# the operator's config and secrets, the embedded Python, the bootstrap (the one file an update
# cannot replace), the updater's own state folder, and per-operator build output.
FORBIDDEN_NAMES = frozenset({
    "config.bat", "python", "bootstrap.py", "bundle_version", "versions", "registry_seed",
    "build", ".git", ".env", "__pycache__",
})
# Windows reserved device names (a file called "nul" or "con.txt" misbehaves on Windows).
_WIN_RESERVED = re.compile(r"^(con|prn|aux|nul|com[0-9]|lpt[0-9])(\..*)?$", re.IGNORECASE)
_SYNC_DUPLICATE = re.compile(r" \(\d+\)")      # "app (1).js" — stale cloud-sync copies


class UpdateFormatError(ValueError):
    """A manifest, signature or package that must be refused (fail closed)."""


class SignatureUnavailable(UpdateFormatError):
    """The `cryptography` package is missing or broken: NOTHING can be verified, so every update
    is refused (fail closed). Distinct so the app can say exactly that in its log."""


# ---------------------------------------------------------------- versions / small parsers
def parse_version(v) -> tuple:
    s = str(v or "").strip()
    if not VERSION_RE.match(s):
        raise UpdateFormatError(f"not a version number: {s!r}")
    return tuple(int(p) for p in s.split("."))


def is_version(v) -> bool:
    try:
        parse_version(v)
        return True
    except UpdateFormatError:
        return False


def version_gt(a, b) -> bool:
    """a > b, padding with zeros (2.1 == 2.1.0)."""
    ta, tb = parse_version(a), parse_version(b)
    n = max(len(ta), len(tb))
    return ta + (0,) * (n - len(ta)) > tb + (0,) * (n - len(tb))


def sha256_file(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def is_sync_duplicate(name: str) -> bool:
    """True for ' (1)'-style cloud-sync duplicates (stale copies; never shipped)."""
    return bool(_SYNC_DUPLICATE.search(name))


# ---------------------------------------------------------------- signatures (Ed25519)
def _ed25519():
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        from cryptography.exceptions import InvalidSignature
    except Exception as e:  # noqa: BLE001 — no crypto = no trust
        raise SignatureUnavailable(
            f"the 'cryptography' package could not be loaded ({type(e).__name__}: {e}); "
            "no update can be verified, so all updates are refused") from None
    return Ed25519PublicKey, InvalidSignature


def parse_signature(sig_bytes: bytes) -> bytes:
    """A .sig file is the 64-byte Ed25519 signature written as 128 lower-case hex characters."""
    if not isinstance(sig_bytes, (bytes, bytearray)) or len(sig_bytes) > MAX_SIGNATURE_BYTES:
        raise UpdateFormatError("signature file is missing or too large")
    try:
        text = bytes(sig_bytes).decode("ascii").strip().lower()
    except UnicodeDecodeError:
        raise UpdateFormatError("signature file is not text") from None
    if not re.match(r"^[0-9a-f]{128}$", text):
        raise UpdateFormatError("signature file is not a 128-character hex signature")
    return bytes.fromhex(text)


def verify_signature(data: bytes, sig_bytes: bytes, accepted_keys) -> str:
    """Verify `data` (the EXACT manifest bytes) against the accepted public keys (hex, 32 bytes).
    Returns the hex key that verified it. Raises UpdateFormatError on ANY doubt: no accepted key,
    a malformed key, a malformed signature, or no key verifying."""
    keys = [str(k).strip().lower() for k in (accepted_keys or []) if str(k).strip()]
    if not keys:
        raise UpdateFormatError("no accepted update key is configured (updates are refused)")
    sig = parse_signature(sig_bytes)
    Ed25519PublicKey, InvalidSignature = _ed25519()
    for k in keys:
        if not HEX64_RE.match(k):
            continue   # a malformed entry can never verify anything
        try:
            Ed25519PublicKey.from_public_bytes(bytes.fromhex(k)).verify(sig, bytes(data))
            return k
        except InvalidSignature:
            continue
        except Exception:  # noqa: BLE001
            continue
    raise UpdateFormatError("bad signature (no accepted key verifies this manifest)")


# ---------------------------------------------------------------- manifest
def _req(m, key, typ):
    v = m.get(key)
    if not isinstance(v, typ) or isinstance(v, bool):
        raise UpdateFormatError(f"manifest field {key!r} is missing or has the wrong type")
    return v


def _check_artifact(entry: dict, prefix: str, max_bytes: int) -> dict:
    url = _req(entry, prefix + "url", str).strip()
    sha = _req(entry, prefix + "sha256", str).strip().lower()
    size = _req(entry, prefix + "size", int)
    if not url or len(url) > 500 or any(c in url for c in "\\\r\n\t "):
        raise UpdateFormatError(f"manifest {prefix}url is not a plain URL")
    if not HEX64_RE.match(sha):
        raise UpdateFormatError(f"manifest {prefix}sha256 is not a SHA-256")
    if not 0 < size <= max_bytes:
        raise UpdateFormatError(f"manifest {prefix}size is outside the allowed range")
    return {"url": url, "sha256": sha, "size": size}


def parse_manifest(data: bytes) -> dict:
    """Parse + validate a manifest's bytes (call ONLY after verify_signature). Returns a normalized
    dict; raises UpdateFormatError on anything unexpected (unknown schema, bad version, ...)."""
    if len(data) > MAX_MANIFEST_BYTES:
        raise UpdateFormatError("manifest is too large")
    try:
        m = json.loads(bytes(data).decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        raise UpdateFormatError("manifest is not valid JSON") from None
    if not isinstance(m, dict):
        raise UpdateFormatError("manifest is not a JSON object")
    if m.get("schema") != MANIFEST_SCHEMA or isinstance(m.get("schema"), bool):
        raise UpdateFormatError(f"unknown manifest schema {m.get('schema')!r}")
    channel = _req(m, "channel", str)
    if not CHANNEL_RE.match(channel):
        raise UpdateFormatError("manifest channel is not a valid channel name")
    version = _req(m, "version", str)
    parse_version(version)
    pkg = _check_artifact(m, "package_", MAX_PACKAGE_BYTES)
    requires_bundle = _req(m, "requires_bundle", int)
    if not 0 <= requires_bundle <= 10_000:
        raise UpdateFormatError("manifest requires_bundle is outside the allowed range")
    blocked = m.get("blocked_versions", [])
    if not isinstance(blocked, list) or not all(isinstance(b, str) and is_version(b) for b in blocked):
        raise UpdateFormatError("manifest blocked_versions must be a list of version numbers")
    if version in blocked:
        raise UpdateFormatError("manifest blocks its own version")
    ext = m.get("extension_version")
    if ext is not None and not (isinstance(ext, str) and is_version(ext)):
        raise UpdateFormatError("manifest extension_version is not a version number")
    contract = m.get("min_serializer_contract")
    if contract is not None and (not isinstance(contract, int) or isinstance(contract, bool) or contract < 0):
        raise UpdateFormatError("manifest min_serializer_contract must be a whole number")
    notes = m.get("notes", "")
    if not isinstance(notes, str) or len(notes) > MAX_NOTES_CHARS:
        raise UpdateFormatError("manifest notes must be a short text")
    released = m.get("released", "")
    if not isinstance(released, str) or (released and not re.match(r"^\d{4}-\d{2}-\d{2}$", released)):
        raise UpdateFormatError("manifest released must be a YYYY-MM-DD date")
    out = {"schema": MANIFEST_SCHEMA, "channel": channel, "version": version, "released": released,
           "package": pkg, "requires_bundle": requires_bundle, "blocked_versions": list(blocked),
           "extension_version": ext, "min_serializer_contract": contract, "notes": notes.strip(),
           "installers": {}}
    # Part 4 — releases that change Python or dependencies ship a full installer. The default
    # instance's is at the top level; a NAMED instance (its own installer identity) has its own
    # entry under "installers". An install only ever uses the entry for its own instance.
    if "installer_url" in m:
        out["installers"]["default"] = _check_artifact(m, "installer_", MAX_INSTALLER_BYTES)
    extra = m.get("installers", {})
    if not isinstance(extra, dict):
        raise UpdateFormatError("manifest installers must be an object")
    for name, entry in extra.items():
        if not (isinstance(name, str) and (name == "default" or INSTANCE_RE.match(name))) \
                or not isinstance(entry, dict):
            raise UpdateFormatError("manifest installers has a bad entry")
        out["installers"][name] = _check_artifact(entry, "installer_", MAX_INSTALLER_BYTES)
    return out


# ---------------------------------------------------------------- package entries
def check_member_name(name: str) -> PurePosixPath:
    """Return the safe relative path for a zip entry name, or raise UpdateFormatError.

    Refused: empty names, absolute paths, drive letters / colons (also NTFS alternate streams),
    backslashes, '.' or '..' components, empty components, names ending in a dot or space
    (Windows silently strips those), Windows device names, control characters, sync duplicates
    ('x (1).py'), anything outside PACKAGE_TOP_LEVEL, and FORBIDDEN_NAMES at any depth."""
    if not isinstance(name, str) or not name or len(name) > 240:
        raise UpdateFormatError(f"package entry has an unusable name: {name!r}")
    if "\\" in name or ":" in name or "\x00" in name or any(ord(c) < 32 for c in name):
        raise UpdateFormatError(f"package entry name has a forbidden character: {name!r}")
    if name.startswith("/"):
        raise UpdateFormatError(f"package entry is an absolute path: {name!r}")
    trimmed = name[:-1] if name.endswith("/") else name
    parts = trimmed.split("/")
    for p in parts:
        if p in ("", ".", ".."):
            raise UpdateFormatError(f"package entry has a '.', '..' or empty part: {name!r}")
        if p != p.strip() or p.endswith("."):
            raise UpdateFormatError(f"package entry part ends with a space or dot: {name!r}")
        if _WIN_RESERVED.match(p):
            raise UpdateFormatError(f"package entry uses a Windows device name: {name!r}")
        if p.lower() in FORBIDDEN_NAMES:
            raise UpdateFormatError(f"package entry touches a protected name ({p}): {name!r}")
        if is_sync_duplicate(p):
            raise UpdateFormatError(f"package entry is a ' (1)' sync duplicate: {name!r}")
    if parts[0] not in PACKAGE_TOP_LEVEL:
        raise UpdateFormatError(f"package entry is outside the allowed folders: {name!r}")
    return PurePosixPath(*parts)


def _is_symlink(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16) & 0xFFFF
    return stat.S_ISLNK(mode) if mode else False


def check_package(zip_path) -> list:
    """Validate EVERY entry of a package before anything is written. Returns the list of
    (ZipInfo, safe_path) to extract (files only). Raises UpdateFormatError."""
    try:
        zf = zipfile.ZipFile(zip_path)
    except (zipfile.BadZipFile, OSError) as e:
        raise UpdateFormatError(f"package is not a readable zip ({type(e).__name__})") from None
    with zf:
        infos = zf.infolist()
        if not infos:
            raise UpdateFormatError("package is empty")
        if len(infos) > MAX_ENTRIES:
            raise UpdateFormatError("package has too many entries")
        total, seen, out = 0, set(), []
        for info in infos:
            safe = check_member_name(info.filename)
            if _is_symlink(info):
                raise UpdateFormatError(f"package entry is a symbolic link: {info.filename!r}")
            if info.flag_bits & 0x1:
                raise UpdateFormatError(f"package entry is encrypted: {info.filename!r}")
            key = str(safe).lower()                      # Windows: case-insensitive file system
            if key in seen:
                raise UpdateFormatError(f"package has a duplicate entry: {info.filename!r}")
            seen.add(key)
            if info.is_dir():
                continue
            if info.file_size < 0 or info.file_size > MAX_UNCOMPRESSED_BYTES:
                raise UpdateFormatError(f"package entry is too large: {info.filename!r}")
            total += info.file_size
            if total > MAX_UNCOMPRESSED_BYTES:
                raise UpdateFormatError("package is too large once unpacked")
            out.append((info, safe))
        # A file and a folder with the same name ("app" file + "app/x.py") cannot both exist.
        dirs = {str(PurePosixPath(*p.parts[:i])).lower() for _, p in out for i in range(1, len(p.parts))}
        if any(str(p).lower() in dirs for _, p in out):
            raise UpdateFormatError("package has a file where a folder is expected")
        if not any(str(p) == "app/version.py" for _, p in out):
            raise UpdateFormatError("package has no app/version.py")
        return out


def safe_extract(zip_path, dest) -> int:
    """Unpack a package into the EMPTY folder `dest` after check_package() accepted every entry.
    Writes files one by one (never ZipFile.extractall), re-checks each final path is inside
    `dest`, and counts bytes as they are written (a lying header cannot exceed the cap).
    Returns the number of files written."""
    members = check_package(zip_path)
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=False)
    root = dest.resolve()
    written_total = 0
    with zipfile.ZipFile(zip_path) as zf:
        for info, safe in members:
            target = (root / Path(*safe.parts)).resolve()
            if root not in target.parents:
                raise UpdateFormatError(f"package entry escapes the folder: {info.filename!r}")
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, open(target, "xb") as out:
                left = info.file_size
                while True:
                    chunk = src.read(1024 * 1024)
                    if not chunk:
                        break
                    left -= len(chunk)
                    written_total += len(chunk)
                    if left < 0 or written_total > MAX_UNCOMPRESSED_BYTES:
                        raise UpdateFormatError(f"package entry is bigger than it says: {info.filename!r}")
                    out.write(chunk)
            os.chmod(target, 0o644)
    return len(members)


def read_tree_version(root) -> str | None:
    """The __version__ declared by <root>/app/version.py (text parse, nothing imported)."""
    try:
        text = (Path(root) / "app" / "version.py").read_text(encoding="utf-8")
    except OSError:
        return None
    m = re.search(r'^__version__\s*=\s*["\']([^"\']+)["\']', text, re.MULTILINE)
    return m.group(1) if m and is_version(m.group(1)) else None


def read_extension_version(ext_dir) -> str | None:
    try:
        v = json.loads((Path(ext_dir) / "manifest.json").read_text(encoding="utf-8")).get("version")
    except (OSError, ValueError, AttributeError):
        return None
    return str(v) if v else None
