"""Single source of the app's version string.

Bump it here. /health serves it (the UI rail shows it), and build_portable.py prints the
exact `iscc /DAppVersion=<this>` command at the end of every build — use that command
verbatim so the window, /health, and the installer filename never drift apart.
"""

__version__ = "2.1.15"
