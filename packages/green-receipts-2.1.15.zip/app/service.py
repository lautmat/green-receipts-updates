"""app/service.py — a thin local HTTP API the desktop UI talks to. It ONLY forwards to
app/backend.py (the safety choke point) and returns structured JSON, so the UI can never
reach the filing path except through the enforced gate. Binds to 127.0.0.1 only — nothing
leaves the operator's machine (same privacy story as the .bat flow).

Run: uvicorn app.service:app  (or via app/main.py, which also opens the window).
The safety-critical logic + its tests live in app/backend.py; this file stays boring."""
from __future__ import annotations

import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from fastapi import FastAPI, HTTPException  # noqa: E402
from fastapi.responses import JSONResponse  # noqa: E402
from fastapi.staticfiles import StaticFiles  # noqa: E402
from pydantic import BaseModel  # noqa: E402

from app.backend import Backend  # noqa: E402

app = FastAPI(title="Green Receipts")
_backend: Backend | None = None

_LOOPBACK = {"127.0.0.1", "::1", "localhost"}


@app.middleware("http")
async def _loopback_only(request, call_next):
    """Enforce local-only access IN THE APP, not just by the 127.0.0.1 bind in main.py — so a
    stray `uvicorn --host 0.0.0.0` can never expose the real-filing endpoint on the LAN
    (review hardening). This is a single-operator desktop tool; nothing off-box should reach it."""
    host = request.client.host if request.client else ""
    if host not in _LOOPBACK:
        return JSONResponse({"error": "forbidden", "detail": "local access only"}, status_code=403)
    return await call_next(request)


def set_backend(b: Backend) -> None:
    """Inject a Backend (tests / a custom build). Otherwise built lazily from env."""
    global _backend
    _backend = b


class _NotConfigured(Exception):
    """Config (GRV2_EXEC/GRV2_TOKEN) missing — surfaced to the UI as a structured 503."""


def _bk() -> Backend:
    global _backend
    if _backend is None:
        try:
            _backend = Backend.from_env()
        except RuntimeError as e:
            # Missing config (GRV2_EXEC/GRV2_TOKEN not set) — a misconfigured/blank launch. Raise
            # a marker the endpoint wrappers turn into a structured JSON 503 (NOT HTTPException with
            # a dict detail — FastAPI str()-ifies a dict detail into an unparseable blob). Don't
            # cache the failure (a fixed config + relaunch works). In the real bundle config.bat
            # sets these first.
            raise _NotConfigured(str(e))
    return _backend


def _not_configured_response(e: "_NotConfigured") -> JSONResponse:
    return JSONResponse({"error": "not_configured", "detail": str(e)}, status_code=503)


class EmitBody(BaseModel):
    taxpayer: str
    confirmed: bool = False


class CaptureBody(BaseModel):
    account: str
    dry_run: bool = False


class TaxpayerBody(BaseModel):
    # The operator enters ONLY NIF + login + password. Name / slug / addresses / IVA regime
    # are auto-derived from AT server-side (the tax authority is the source of truth for the
    # identity that goes on receipts) — deliberately NOT acceptable as input here: a
    # hand-typed IVA regime pre-empting the AT read is the mistype risk this design removed.
    nif: int
    at_login_username: str
    password: str
    taxpayer_id: str = ""      # optional explicit slug (tests); normally derived from the AT name


class PasswordBody(BaseModel):
    nif: int
    password: str


class OnePasswordBody(BaseModel):
    password: str


class ListingBody(BaseModel):
    listing_id: str
    taxpayer_id: str | None = None     # slug, or…
    taxpayer_nif: str | None = None    # …the NIF (what the operator knows; resolved server-side)
    cae_code: str
    cae_descr: str = ""
    al_number: str = ""
    listing_name: str = ""


class OverrideBody(BaseModel):
    row_id: str
    field: str
    new_value: str
    actor: str | None = None


class RowBody(BaseModel):
    row_id: str


class ResolveBody(BaseModel):
    row_id: str
    actor: str | None = None
    note: str | None = None


class ResolveAllBody(BaseModel):
    actor: str | None = None


class CsvBody(BaseModel):
    csv_text: str
    actor: str | None = None


def _guard(fn):
    """Run an adapter call; a ValueError (bad input / unknown taxpayer / dup listing) becomes a
    400, a missing-config (_NotConfigured) a structured 503, and ANY other exception a structured
    JSON 500 carrying str(e) — the data layer writes deliberate, actionable fail-LOUD messages
    ('serializer refused … retry in a minute') and a bare 500 text page was flattening them into
    a generic 'internal error' in the UI."""
    try:
        return fn()
    except _NotConfigured as e:
        return _not_configured_response(e)
    except ValueError as e:
        return JSONResponse({"error": "bad_request", "detail": str(e)}, status_code=400)
    except Exception as e:  # noqa: BLE001 — surfaced, never swallowed: message + 500 status
        import logging
        logging.getLogger("grv2").exception("unhandled in %s", getattr(fn, "__name__", "endpoint"))
        return JSONResponse({"error": "internal", "detail": str(e) or type(e).__name__},
                            status_code=500)


@app.get("/health")
def health():
    """Liveness AND readiness. `ok` stays True whenever the server is up (the launcher's
    single-instance guard + startup wait depend on a 200), and `configured` reports whether the
    serializer creds are present so the UI can show a clear 'not connected' screen at OPEN time
    rather than 503-ing mid-emit."""
    import os
    from app.version import __version__
    return {"ok": True, "version": __version__,
            "configured": bool(os.environ.get("GRV2_EXEC") and os.environ.get("GRV2_TOKEN")),
            # optional extras the UI uses when present: the workbook link ("Open in Google Sheet")
            # and whether the v1||v2 firewall is on (Review explains v1-filed stays get skipped).
            "sheet_url": os.environ.get("GRV2_SHEET_URL") or None,
            "v1_firewall": bool(os.environ.get("GRV2_V1_SHEET_ID")),
            # which instance this is (instance.py): the launcher's single-instance guard refuses to
            # reopen a DIFFERENT instance's window, and the UI header shows the label.
            **_instance_info()}


def _instance_info() -> dict:
    try:
        import instance
        return instance.describe()
    except Exception as e:  # noqa: BLE001 — health must stay 200; the launcher already validated
        return {"instance": None, "instance_error": str(e)}


@app.get("/taxpayers")
def taxpayers():
    return _guard(lambda: {"taxpayers": _bk().list_taxpayers()})


@app.get("/pending")
def pending_all():
    """Pending stays across ALL clients, each row tagged with its client (multi-tenant Review)."""
    return _guard(lambda: _bk().list_pending_all())


@app.get("/pending/{taxpayer}")
def pending(taxpayer: str):
    return _guard(lambda: _bk().list_pending(taxpayer))


@app.get("/emit/preview/{taxpayer}")
def emit_preview(taxpayer: str):
    """READ-ONLY: what an Issue would actually file (firewall pre-check). Files nothing."""
    return _guard(lambda: _bk().preview_emit(taxpayer))


@app.post("/emit")
def emit(body: EmitBody):
    """The UI's confirm modal maps here: body.confirmed=True is the ONLY thing that lets the
    process gate pass. A missing/false confirmed fails closed (files nothing)."""
    return _guard(lambda: _bk().run_emit(body.taxpayer, confirmed=body.confirmed))


# ---- capture (screen 2) ----
@app.get("/bridge/check")
def bridge_check():
    """Pre-flight: is the Chrome bridge extension loaded + connectable? Starts+stops the local bridge
    briefly and reports — so the operator knows BEFORE clicking Capture. Reads nothing from Airbnb."""
    return _guard(lambda: _bk().check_extension())


@app.get("/selfcheck")
def selfcheck(extension: bool = True):
    """Pre-flight self-test of the whole setup (clients, passwords, sheet/token, extension) — safe +
    idempotent, no Portal login, no filing. Lets the admin confirm a fresh deployment before handing it over."""
    return _guard(lambda: _bk().self_check(include_extension=extension))


@app.post("/capture")
def capture(body: CaptureBody):
    return _guard(lambda: _bk().capture(body.account, dry_run=body.dry_run))


@app.get("/capture/auto/status")
def capture_auto_status():
    """8c: would an automatic capture start now (last capture > 24 h old, switched on, nothing running)?"""
    return _guard(lambda: _bk().auto_capture_status())


@app.post("/capture/auto")
def capture_auto(body: CaptureBody):
    """8c: the ONE automatic capture on app start — the same capture as the button (never a preview,
    never an issue), and only when due and the extension answered the pre-flight check. body.dry_run
    is ignored on purpose."""
    return _guard(lambda: _bk().auto_capture(body.account))


@app.get("/needs-review/urgent")
def needs_review_urgent():
    """8c: not-issued stays with fewer than 2 working days left before their issue-by date."""
    return _guard(lambda: _bk().urgent_parked())


@app.get("/emit/progress")
def emit_progress():
    """Live emit progress (done/total/current), polled by the UI while /emit runs. Display-only."""
    return _guard(lambda: _bk().emit_progress())


@app.get("/capture/progress")
def capture_progress():
    """Live capture progress (running + elapsed seconds), polled while /capture blocks. Display-only."""
    return _guard(lambda: _bk().capture_progress())


@app.post("/emit/cancel")
def emit_cancel():
    """STOP: ask the running emit to stop after the current receipt (never mid-submit)."""
    return _guard(lambda: _bk().cancel_emit())


# ---- setup (screen 1) — password stored DIRECTLY, never getpass ----
def _after_setup_mutation(result):
    """The Backend loads the registry ONCE at construction, so a setup mutation (new taxpayer /
    listing) would be invisible to /pending and /emit until relaunch (a documented lifecycle gap —
    now closed). Drop the cached Backend after a SUCCESSFUL mutation; the next call rebuilds it
    from env and re-reads the registry."""
    global _backend
    if isinstance(result, dict) and result.get("ok"):
        _backend = None
    return result


@app.get("/setup/status")
def setup_status():
    return _guard(lambda: _bk().setup_status())


@app.get("/setup/paths")
def setup_paths():
    return _guard(lambda: _bk().setup_paths())


@app.post("/setup/open/{which}")
def setup_open(which: str):
    """Open one of the app's OWN folders (receipts / extension / install) in the file manager.
    `which` is a NAME checked against Backend.OPENABLE — never a caller-supplied path."""
    return _guard(lambda: _bk().open_folder(which))


@app.get("/setup/registry")
def setup_registry():
    """What's already configured (read-only): taxpayers + properties, for the Settings screen."""
    return _guard(lambda: _bk().list_registry())


@app.get("/setup/test-login/{taxpayer}")
def setup_test_login(taxpayer: str):
    """READ-ONLY: attempt the Portal sign-in for one taxpayer and return the classified
    result (ok / bad_credentials / blocked / otp_required / portal_error). Files nothing."""
    return _guard(lambda: _bk().test_login(taxpayer))


@app.post("/setup/taxpayer")
def setup_taxpayer(body: TaxpayerBody):
    return _guard(lambda: _after_setup_mutation(_bk().add_taxpayer(
        taxpayer_id=body.taxpayer_id, nif=body.nif, at_login_username=body.at_login_username,
        password=body.password)))


@app.post("/setup/refresh-cadastro/{taxpayer}")
def setup_refresh_cadastro(taxpayer: str):
    # READ from AT + update the local registry; files nothing. Handles a client's tax details
    # changing over time. Re-reads the registry afterwards so the change takes effect immediately.
    return _guard(lambda: _after_setup_mutation(_bk().refresh_cadastro(taxpayer)))


@app.post("/setup/password")
def setup_password(body: PasswordBody):
    return _guard(lambda: _after_setup_mutation(_bk().set_password(nif=body.nif, password=body.password)))


@app.post("/setup/password/{taxpayer}")
def setup_password_for(taxpayer: str, body: OnePasswordBody):
    # Change an EXISTING taxpayer's Portal password by slug (the UI never holds the real NIF).
    return _guard(lambda: _after_setup_mutation(_bk().set_password_for(taxpayer, body.password)))


@app.post("/setup/sync-properties")
def setup_sync_properties():
    # One-way Sheet -> app listing sync (the Sheet is the only place listings are edited).
    # Read-only at the serializer; upserts the local routing; never deletes local rows.
    return _guard(lambda: _after_setup_mutation(_bk().sync_properties_from_sheet()))


@app.get("/capture/last")
def capture_last():
    return _guard(lambda: _bk().last_capture())


@app.post("/setup/listing")
def setup_listing(body: ListingBody):
    return _guard(lambda: _after_setup_mutation(_bk().map_listing(
        listing_id=body.listing_id, taxpayer_id=body.taxpayer_id, taxpayer_nif=body.taxpayer_nif,
        cae_code=body.cae_code, cae_descr=body.cae_descr, al_number=body.al_number,
        listing_name=body.listing_name)))


# ---- fix (screen 4) — audited CAS ops, never a raw sheet edit ----
@app.get("/fix/{row_id}")
def fix_show(row_id: str):
    return _guard(lambda: _bk().fix_show(row_id))


class BoundaryBody(BaseModel):
    row_ids: list[str]
    actor: str | None = None


@app.post("/boundary/filed-manually")
def boundary_filed_manually(body: BoundaryBody):
    # Switch-over decision: these stays were filed by hand -> terminal VERIFIED (audited).
    return _guard(lambda: _bk().mark_filed_manually(body.row_ids, actor=body.actor))


@app.post("/fix/override")
def fix_override(body: OverrideBody):
    return _guard(lambda: _bk().fix_override(
        row_id=body.row_id, field=body.field, new_value=body.new_value, actor=body.actor))


@app.post("/fix/reroute")
def fix_reroute(body: RowBody):
    return _guard(lambda: _bk().fix_reroute(body.row_id))


# ---- Stage D: pre-emit review lane (STAGING needs_review + QUARANTINE), non-blocking ----
@app.get("/needs-review")
def needs_review():
    return _guard(lambda: _bk().list_needs_review())


@app.post("/review/filed-by-hand")
def review_filed_by_hand(body: BoundaryBody):
    # A PARKED stay the operator issued by hand at the Portal -> STAGING 'filed_by_hand' (terminal,
    # audited): the app never issues it, even when a later capture reads its fee.
    return _guard(lambda: _bk().mark_parked_filed_by_hand(body.row_ids, actor=body.actor))


# ---- Stage F: CSV drop -> correct exact payout dates + signal unmatched income (non-blocking) ----
@app.post("/apply-csv")
def apply_csv(body: CsvBody):
    return _guard(lambda: _bk().apply_csv(body.csv_text, actor=body.actor))


# ---- reconcile (#2) — the IN_DOUBT worklist ----
@app.get("/indoubt")
def indoubt():
    return _guard(lambda: _bk().list_in_doubt())


@app.post("/indoubt/resolve")
def indoubt_resolve(body: ResolveBody):
    return _guard(lambda: _bk().resolve_in_doubt(row_id=body.row_id, actor=body.actor, note=body.note))


@app.post("/indoubt/resolve-v1")
def indoubt_resolve_v1(body: ResolveAllBody):
    # Bulk-verify ONLY the v1-firewall matches (already-filed-in-v1); genuine ambiguity is left per-row.
    return _guard(lambda: _bk().resolve_v1_matches(actor=body.actor))


# ---- self-update (docs/PLAN_AUTO_UPDATE.md) — inert unless GR_UPDATE_URL is set ----
class InstallBody(BaseModel):
    confirmed: bool = False


@app.get("/update/status")
def update_status():
    """The quiet update lines for the UI (updated / ready / withdrawn version / install needed).
    {"enabled": false, "lines": []} when the updater is off. Display-only; never fails the UI."""
    try:
        from app import updater
        st = updater.status()
        busy = _backend._busy() if _backend is not None else ""
        return {**st, "busy": busy}
    except Exception as e:  # noqa: BLE001
        return {"enabled": False, "lines": [], "error": type(e).__name__}


@app.post("/update/install")
def update_install(body: InstallBody):
    """Part 4: the operator clicked Install for an update that needs the installer. Runs only with
    confirmed=True and only when no capture or issue is running; the app then closes and the
    installer reopens it."""
    def _run():
        from app import updater
        if _backend is not None:
            return _backend.install_update(confirmed=body.confirmed)
        # No backend yet = no capture or issue can be running in this app.
        return updater.get().install_now(confirmed=body.confirmed, acquire_idle=lambda: (lambda: None))
    return _guard(_run)


# Serve the UI (static assets) if present; the 7 screens are recreated here from the design.
_UI = Path(__file__).resolve().parent / "ui"
if _UI.is_dir():
    app.mount("/", StaticFiles(directory=str(_UI), html=True), name="ui")
