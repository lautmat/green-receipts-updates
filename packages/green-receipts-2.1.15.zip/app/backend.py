"""app/backend.py — the SAFE adapter between the desktop UI and the existing green-receipts
backend. This is the safety choke point: it REUSES the shipped Python (emit.py / emitter /
live_capture / registry), never reimplementing the filing loop, and enforces the three
non-negotiable conditions a GUI must uphold to be no more error-prone than the .bat flow:

  1. The human gate stays in the PROCESS, not the UI. Every emit routes through
     emit.confirm_real_emit (the real gate) via its input_fn seam — we feed "EMIT" ONLY when
     the caller passed confirmed=True. We NEVER pass no_confirm=True and NEVER call
     emit_for_nif()/emit_real() around the gate. A service bug that forgets `confirmed`
     fails CLOSED (input_fn returns "" -> gate False -> abort).
  2. A FRESH operator_id per emit invocation (emit.default_operator_id), plus an in-process
     lock so two clicks / two windows can't race the per-NIF emit-lock and double-file.
  3. Every figure is read from the serializer (Sheet = source of truth) at call time — never
     a UI-cached or client-computed number.

The whole app/ package only IMPORTS the backend; it changes nothing in the .bat flow, so
rollback is simply "stop shipping app/". (The one backend touch — emit_real's optional
on_result hook — is additive and dormant without this app.)
"""
from __future__ import annotations

import os
import subprocess
import sys
import threading
import tomllib
from pathlib import Path

# app/ is a subdir; put the repo root (the backend) on the path.
_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from emit import (  # noqa: E402  the shipped backend — reused, never reimplemented
    confirm_real_emit, default_operator_id, emit_real, select_taxpayers,
)


def _mask_nif(nif) -> str:
    s = str(nif)
    return ("•" * max(0, len(s) - 3)) + s[-3:] if s else ""


def _f(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _issue_by(payment_date) -> str:
    """The 'issue within 5 business days' deadline (weekdays only) for a row that carries a
    payout/payment date; "" for rows that don't (existing rows, or a stay not yet paid)."""
    pd = str(payment_date or "").strip()
    if not pd:
        return ""
    try:
        import business_days
        return business_days.issue_by(pd, 5)
    except Exception:  # noqa: BLE001 — a deadline is advisory; never block a row on it
        return ""


def _urgency(issue_by) -> tuple:
    """(days_left, urgency) for a row's 5-business-day deadline, computed SERVER-SIDE (one clock — no
    client-timezone drift at day boundaries). urgency: 'overdue' (deadline passed), 'due_soon' (<=2
    business days left), else 'ok'; ('', '') when there's no deadline. ADVISORY only — an overdue receipt
    must still be issuable (more urgently, in fact); the UI must never gate a row on this."""
    ib = str(issue_by or "").strip()
    if not ib:
        return (None, "")
    try:
        import datetime
        import business_days
        left = business_days.business_days_left(ib, datetime.date.today())
        return (left, "overdue" if left < 0 else ("due_soon" if left <= 2 else "ok"))
    except Exception:  # noqa: BLE001 — advisory; never break the row on it
        return (None, "")


def _is_iso_date(v) -> bool:
    """Strict ISO YYYY-MM-DD calendar-date check — mirrors the serializer's isIsoDate_ so the app
    rejects a bad override date (banana / 2026-13-45 / US 07/06/2026) BEFORE it reaches the sheet."""
    import datetime
    import re
    s = str(v or "").strip()
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", s):
        return False
    try:
        datetime.date.fromisoformat(s)
        return True
    except ValueError:
        return False


# ---- 8c: capture without being asked (docs/PLAN_FEE_LOOKUP_400.md step 8c) ----------------------
# On app start the UI asks the backend to capture when the last capture is older than this and the
# extension answered the pre-flight check. CAPTURE ONLY: the same capture() the "Capture now" button
# runs (dry_run=False), never an issue. Turn it off per deployment with GR_AUTO_CAPTURE=0 in config.bat.
AUTO_CAPTURE_ENV = "GR_AUTO_CAPTURE"
AUTO_CAPTURE_MAX_AGE_HOURS = 24
AUTO_CAPTURE_EXT_CHECK_MAX_AGE_SEC = 120   # the extension check the auto-capture relies on must be this fresh
# A not-issued stay with FEWER than this many working days left before its issue-by date is shown
# as a red banner on the first screen.
URGENT_DAYS_LEFT = 2


def auto_capture_enabled() -> bool:
    """GR_AUTO_CAPTURE from the deployment's config (config.bat). Default ON; 0/false/off/no = off."""
    return str(os.environ.get(AUTO_CAPTURE_ENV, "1")).strip().lower() not in {"0", "false", "off", "no"}


def _update_blocked() -> str | None:
    """The withdrawn-version banner text (docs/PLAN_AUTO_UPDATE.md 1.2 blocked_versions), else None.
    Always None when the updater is off (GR_UPDATE_URL unset) — then nothing here changes."""
    try:
        try:
            from app import updater as _u
        except ImportError:   # app/ itself on sys.path (the backend tests)
            import updater as _u  # type: ignore[no-redef]
        return _u.blocked_message()
    except Exception:  # noqa: BLE001 — a broken updater must never block or crash capture/issue
        return None


def _install_root() -> Path:
    """The install folder of THIS instance — the code folder, or its parent when the code runs
    from an installed update (<install>/versions/<v>). Chrome loads the extension from here."""
    try:
        try:
            from app.updater import install_root_for
        except ImportError:
            from updater import install_root_for  # type: ignore[no-redef]
        return install_root_for(_ROOT)
    except Exception:  # noqa: BLE001
        return _ROOT


def _flagged_for_ui(flagged) -> list:
    """The capture report's per-stay 'not issued' list, shaped for the capture screen: guest, dates,
    the plain reason, and the issue-by deadline (5 business days from the payout-date estimate)."""
    out = []
    for f in flagged:
        if not isinstance(f, dict):
            continue
        issue_by = _issue_by(f.get("payment_date"))
        days_left, urgency = _urgency(issue_by)
        out.append({"hm_code": str(f.get("hm_code") or ""), "guest": str(f.get("guest") or ""),
                    "check_in": str(f.get("check_in") or ""), "check_out": str(f.get("check_out") or ""),
                    "reason": str(f.get("reason") or ""), "kind": str(f.get("kind") or ""),
                    "saved": bool(f.get("saved")), "issue_by": issue_by,
                    "days_left": days_left, "urgency": urgency})
    return out


def _display_row(r: dict) -> dict:
    """Normalize a claimable row for the UI, showing the EXACT figures the engine files so the
    operator approves what is actually issued. The sheet stores the Airbnb gross (ttc); the engine
    derives base = round(ttc/1.06, 2), then RE-derives the filed total = round(base*1.06, 2) and
    vat = round(total - base, 2) (emit_receipt.calculate_vat) — the filed total can differ from the
    raw ttc by 1 cent, so we display the DERIVED total, not ttc. service_fee is the Airbnb
    commission -> host payout = ttc - fee (reconciliation only, never the filed amount)."""
    ttc, fee = _f(r.get("ttc")), _f(r.get("service_fee"))
    base = _f(r.get("base"))
    if base is None and ttc is not None:
        base = round(ttc / 1.06, 2)
    total = round(base * 1.06, 2) if base is not None else None   # importanciaRecebida (FILED)
    vat = round(total - base, 2) if (total is not None and base is not None) else None
    issue_by = _issue_by(r.get("payment_date"))
    days_left, urgency = _urgency(issue_by)
    return {
        "row_id": r.get("row_id"), "hm_code": r.get("hm_code"),
        "taxpayer_nif": str(r.get("taxpayer_nif") or ""),   # which CLIENT this stay files under (multi-tenant)
        # payment_date = Airbnb payout date (the receipt's dataPrestacao when present); issue_by =
        # its 5-business-day deadline. Both "" for rows without a payout date (backward-compatible).
        "payment_date": str(r.get("payment_date") or ""),
        "issue_by": issue_by, "days_left": days_left, "urgency": urgency,
        "service_date": r.get("service_date"), "end_date": r.get("end_date"),
        "guest": r.get("guest"), "ttc": r.get("ttc"),   # raw gross, kept only for host-payout calc
        "listing_id": str(r.get("listing_id_str") or ""),   # which PROPERTY (decorated with its name by the caller)
        # checked in before this client's switch-over but inside the review window — the
        # operator decides in Review: "filed by hand" (-> verified) or let the app file it.
        "boundary": bool(r.get("boundary")),
        "base": (f"{base:.2f}" if base is not None else ""),
        "vat": (f"{vat:.2f}" if vat is not None else ""),
        "total": (f"{total:.2f}" if total is not None else ""),   # what the receipt reports
        "fee": (f"{fee:.2f}" if fee is not None else ""),
        "payout": (f"{ttc - fee:.2f}" if (ttc is not None and fee is not None) else ""),
    }


class Backend:
    """Injectable so the safety wiring is unit-testable without a live serializer/Portal.
    Production: Backend.from_env(). Tests: pass fakes for serializer/reg/emit_real_fn."""

    def __init__(self, *, serializer, reg, emit_real_fn=emit_real, log=None,
                 registry_dir=None, capture_main=None, v1_bridge=None, default_account=None,
                 update_guard=None):
        self.serializer = serializer
        # Kill switch: a version the admin withdrew (signed manifest blocked_versions) refuses to
        # capture or issue. Injectable for tests; default = the app's updater (None when it is off).
        self._update_guard = update_guard or _update_blocked
        self.reg = reg                      # used by pending/emit; may be None in setup-only mode
        self.emit_real_fn = emit_real_fn
        self.log = log
        self.v1_bridge = v1_bridge          # v1||v2 firewall (parallel period only); None = off
        self.default_account = default_account   # GR_ACCOUNT — the .bat flow's capture label
        self._emit_lock = threading.Lock()
        self._capture_lock = threading.Lock()
        if registry_dir is None:
            from registry import REGISTRY_DIR
            registry_dir = REGISTRY_DIR
        self.registry_dir = registry_dir
        self._capture_main = capture_main   # injectable; else lazy tools.live_capture.main
        # Live emit progress: run_emit writes it via a per-row callback; /emit/progress reads it from a
        # sibling threadpool thread while the blocking /emit runs (uvicorn runs sync endpoints in a
        # threadpool). Dict updates are GIL-atomic and this is display-only, so no lock is needed.
        self._emit_progress = {"running": False, "done": 0, "total": 0, "current": "", "taxpayer": ""}
        # Live capture progress: capture() blocks (paced Airbnb reads), so /capture/progress is polled
        # from a sibling threadpool thread to show the operator it's WORKING (elapsed seconds), not hung.
        # Display-only; the capture INTERNALS + Airbnb pacing are untouched (no counts streamed).
        self._capture_progress = {"running": False, "started": 0.0}
        # STOP button: run_emit passes should_stop=self._emit_cancel.is_set; the emit loop checks it
        # BETWEEN receipts, so a stop never interrupts a receipt mid-submit. /emit/cancel sets it.
        self._emit_cancel = threading.Event()
        # 8c: the last extension pre-flight result ({at, connected}) and whether this app run already
        # started its one automatic capture.
        self._last_ext_check: dict | None = None
        self._auto_capture_started = False

    # ---- construction ------------------------------------------------------
    @classmethod
    def from_env(cls):
        """Build the real backend from the same env the .bat flow uses (GRV2_EXEC/GRV2_TOKEN)."""
        import os
        import log_client
        from emitter import SerializerClient
        from registry import Registry, load_registry
        exec_url, token = os.environ.get("GRV2_EXEC"), os.environ.get("GRV2_TOKEN")
        if not exec_url or not token:
            raise RuntimeError("GRV2_EXEC / GRV2_TOKEN not set (config not loaded).")
        try:
            reg = load_registry()
        except FileNotFoundError:
            # A FRESH machine: creds are baked but no taxpayer exists yet (an operator, day one,
            # before Setup). The app must still start so the SETUP screen can create the first
            # taxpayer — an empty registry is safe: pending/emit refuse with a clear ValueError
            # ("no taxpayer") until one is added, and the service re-reads the registry after
            # every setup mutation.
            reg = Registry()
        except tomllib.TOMLDecodeError as e:
            # A PRESENT-but-DAMAGED settings file (half-written block, bad manual edit). Do NOT
            # silently start empty (that hides the damage and risks re-adding an existing taxpayer
            # as a duplicate) — stop with a clear, recoverable instruction. setup_taxpayer keeps a
            # ".bak" of the last good file next to it (atomic writes).
            from registry import REGISTRY_DIR
            raise RuntimeError(
                "Your settings file looks damaged and couldn't be read. In the folder "
                f"{REGISTRY_DIR}, rename 'taxpayers.toml.bak' to 'taxpayers.toml' to restore the "
                f"last good version, or re-run Setup. (Details: {e})"
            )
        serializer = SerializerClient(exec_url, token)
        # PRIMARY telemetry = the Google Sheet LOG tab, always on: passing serializer_url+token
        # wires log_client's serializer 'log' poster (handleLog -> LOG tab). Label the rows with
        # the operator's account (GR_ACCOUNT, set by config.bat) so a multi-operator LOG tab is
        # legible — the .bat flow already tags rows emit@host / capture@host; the app was the one
        # generic "app". The `host` column still carries the hostname.
        # OPTIONAL central HTTP collector (GRV2_TELEMETRY_URL) stays OFF unless explicitly baked
        # — we're using the Sheet log, so this is normally unset. Best-effort, never blocks.
        log = log_client.setup_logging(
            "app", operator_id=os.environ.get("GR_ACCOUNT") or "app",
            serializer_url=exec_url, api_token=token,
            telemetry_url=os.environ.get("GRV2_TELEMETRY_URL"),
            telemetry_secret=os.environ.get("GRV2_TELEMETRY_SECRET"))
        # Which instance produced the following LOG rows (several instances can share a laptop, and
        # a misrouted extension is diagnosed from exactly these values). Best-effort.
        try:
            import logging

            import instance
            from app.version import __version__
            log_client.log_event(
                log, logging.INFO, "app started", op="app", result="start",
                detail=(f"v{__version__} instance={instance.name() or 'default'} "
                        f"app_port={instance.app_port()} bridge_port={instance.bridge_port()} "
                        f"taxpayers={len(getattr(reg, 'taxpayers', {}) or {})} "
                        f"listings={len([p for p in getattr(reg, 'properties', []) if p.active])}"))
        except Exception:  # noqa: BLE001 — diagnostics must never stop the app
            pass
        # v1||v2 firewall (the parallel period on the owner's own account): GRV2_V1_SHEET_ID set ->
        # the firewall is ON, exactly like emit.py --v1-bridge, and FAIL-CLOSED — if the bridge
        # can't be built the app refuses to start rather than silently emitting without the
        # firewall the admin configured. A v2-only deployment (another operator) simply leaves it unset.
        v1_bridge = None
        v1_sheet = os.environ.get("GRV2_V1_SHEET_ID")
        if v1_sheet:
            # The import stays INSIDE the try: v1_bridge.py ships only in a --with-v1-bridge build
            # (graduate excludes it from v2-only operator bundles), so on a v2-only build this is an
            # ImportError — which must ALSO fail closed with the clear message, not a raw 500.
            try:
                import v1_bridge as v1b
                v1_bridge = v1b.make_v1_bridge(spreadsheet_id=v1_sheet)
            except Exception as e:
                raise RuntimeError(
                    f"GRV2_V1_SHEET_ID is set but the v1||v2 firewall could not be enabled ({e}). "
                    "Refusing to run without the firewall you configured — unset GRV2_V1_SHEET_ID "
                    "for a v2-only deployment, or rebuild with --with-v1-bridge.") from e
        return cls(serializer=serializer, reg=reg, log=log, v1_bridge=v1_bridge,
                   default_account=os.environ.get("GR_ACCOUNT"))

    # ---- read side (safe; no Portal, no claim) -----------------------------
    def list_taxpayers(self) -> list[dict]:
        return [{"taxpayer_id": t.taxpayer_id, "name": t.nome_prestador,
                 "nif_masked": _mask_nif(t.nif_prestador)}
                for t in self.reg.taxpayers.values()]

    def list_pending(self, taxpayer_slug: str) -> dict:
        """Structured pending rows for the selected taxpayer, straight from the serializer
        (Sheet figures). A serializer refusal surfaces as a structured error — NEVER an empty
        list read as '0 pending'."""
        t = self._require_taxpayer(taxpayer_slug)
        try:
            rows = self.serializer.list_claimable([str(t.nif_prestador)])
        except Exception as e:  # noqa: BLE001 — SerializerClient raises loud on a refusal
            return {"error": "serializer_unavailable", "detail": str(e), "retry": True}
        pnames = self._property_names()
        out = []
        for r in rows:
            d = _display_row(r)
            d["property"] = pnames.get(d.get("listing_id") or "", "")
            out.append(d)
        return {"taxpayer_id": t.taxpayer_id, "count": len(out), "rows": out}

    def _clients_by_nif(self) -> dict:
        """nif(str) -> {taxpayer_id, name, nif_masked} — for tagging rows and the client picker."""
        return {str(t.nif_prestador): {"taxpayer_id": t.taxpayer_id, "name": t.nome_prestador,
                                       "nif_masked": _mask_nif(t.nif_prestador)}
                for t in self.reg.taxpayers.values()}

    def _property_names(self) -> dict:
        """listing_id(str) -> friendly property name, from the local (Sheet-synced) settings."""
        return {str(p.listing_id_str): (p.listing_name or p.property_id or str(p.listing_id_str))
                for p in self.reg.properties}

    def list_pending_all(self) -> dict:
        """Pending rows across ALL taxpayers in ONE serializer call, each row tagged with its
        client (name + masked NIF). Powers the multi-tenant Review — the operator sees every
        client's stays together, no per-taxpayer switching."""
        clients = self._clients_by_nif()
        nifs = list(clients.keys())
        if not nifs:
            return {"count": 0, "rows": [], "clients": []}
        try:
            rows = self.serializer.list_claimable(nifs)
        except Exception as e:  # noqa: BLE001
            return {"error": "serializer_unavailable", "detail": str(e), "retry": True}
        pnames = self._property_names()
        out = []
        for r in rows:
            d = _display_row(r)
            c = clients.get(d.get("taxpayer_nif")) or {}
            d["client_name"] = c.get("name") or "Unassigned"
            d["client_nif_masked"] = c.get("nif_masked") or "—"
            d["taxpayer_id"] = c.get("taxpayer_id") or ""
            d["property"] = pnames.get(d.get("listing_id") or "", "")
            out.append(d)
        return {"count": len(out), "rows": out,
                "clients": [{"taxpayer_id": v["taxpayer_id"], "name": v["name"],
                             "nif_masked": v["nif_masked"]} for v in clients.values()]}

    def list_registry(self) -> dict:
        """What's already configured (read-only) for the Settings screen: taxpayers (name / NIF /
        Portal login) and properties (listing -> client + CAE + AL number)."""
        names = {t.taxpayer_id: t.nome_prestador for t in self.reg.taxpayers.values()}
        # cadastro_ok=False -> the add-time AT read failed (usually a wrong password): addresses /
        # IVA regime are blank and emit refuses the taxpayer. Surfaced as a badge in Settings so
        # the operator sees the broken state there instead of discovering it at filing time.
        taxpayers = [{"taxpayer_id": t.taxpayer_id, "name": t.nome_prestador,
                      "nif_masked": _mask_nif(t.nif_prestador), "at_login": t.at_login_username,
                      "cadastro_ok": bool(getattr(t, "morada_fiscal_prestador", "")
                                          and getattr(t, "iva_cod_enq", ""))}
                     for t in self.reg.taxpayers.values()]
        properties = [{"listing_id": p.listing_id_str, "listing_name": p.listing_name,
                       "taxpayer_id": p.taxpayer_id,
                       "taxpayer_name": names.get(p.taxpayer_id, p.taxpayer_id),
                       "cae_code": p.cae_code, "al_number": p.al_number}
                      for p in self.reg.properties]
        return {"taxpayers": taxpayers, "properties": properties}

    def preview_emit(self, taxpayer_slug: str) -> dict:
        """READ-ONLY preview of what an Issue will actually file. When the v1||v2 firewall is on,
        it runs the bridge's locate() (a pure search of the v1 sheet — reserve() is what writes)
        for each claimable row and splits them: rows whose v1 twin ALREADY has a Num Doc are
        'skipped_v1' (the firewall will refuse them), the rest are 'will_file'. This is why the
        confirm modal can honestly say '4 will file / 21 already filed' instead of a scary '25'.
        Without a firewall (an operator), every claimable row will file — no pre-filter.

        taxpayer_slug == "all" previews across EVERY client; will_file rows are tagged with the
        client so the confirm modal reads 'Angela (client X) · Bruno (client Y) …'."""
        clients = self._clients_by_nif()
        if taxpayer_slug == "all":
            nifs = list(clients.keys())
            if not nifs:
                return {"taxpayer_id": "all", "total": 0, "firewall": self.v1_bridge is not None,
                        "will_file_count": 0, "skipped_v1_count": 0, "will_file": [], "skipped_v1": []}
        else:
            nifs = [str(self._require_taxpayer(taxpayer_slug).nif_prestador)]
        try:
            rows = self.serializer.list_claimable(nifs)
        except Exception as e:  # noqa: BLE001
            return {"error": "serializer_unavailable", "detail": str(e), "retry": True}
        will_file, skipped = [], []
        if self.v1_bridge is not None:
            for r in rows:
                try:
                    kind, _sheet_row, v1_doc = self.v1_bridge.locate(r)
                except Exception:  # noqa: BLE001 — a locate hiccup must not hide a row; treat as will-file
                    kind, v1_doc = "error", ""
                if kind == "match" and str(v1_doc or "").strip():
                    skipped.append({"guest": r.get("guest"), "hm_code": r.get("hm_code"),
                                    "v1_doc": str(v1_doc).strip()})
                else:
                    will_file.append(r)
        else:
            will_file = list(rows)

        pnames = self._property_names()

        def _tag(r):
            d = _display_row(r)
            c = clients.get(d.get("taxpayer_nif")) or {}
            d["client_name"] = c.get("name") or "Unassigned"
            d["client_nif_masked"] = c.get("nif_masked") or "—"
            d["property"] = pnames.get(d.get("listing_id") or "", "")
            return d
        return {"taxpayer_id": taxpayer_slug, "total": len(rows),
                "firewall": self.v1_bridge is not None,
                "will_file_count": len(will_file), "skipped_v1_count": len(skipped),
                "will_file": [_tag(r) for r in will_file], "skipped_v1": skipped}

    # ---- the irreversible action (the choke point) -------------------------
    def run_emit(self, taxpayer_slug: str, *, confirmed: bool) -> dict:
        """File the pending Fatura-Recibo for ONE explicitly-selected taxpayer.

        confirmed=True means the UI showed its confirm modal and the operator clicked
        Issue. That is the ONLY thing that lets the process gate pass; everything else
        aborts and files nothing."""
        # taxpayer_slug == "all" -> file for EVERY configured client in one batch (emit_real
        # already loops taxpayers, per-NIF locks + guards intact); else the single selected one.
        blocked = self._update_guard()
        if blocked:   # withdrawn version: file NOTHING (checked before any serializer call)
            return {"error": "blocked_version", "detail": blocked, "filed": 0}
        if taxpayer_slug == "all":
            taxpayers = list(self.reg.taxpayers.values())
            if not taxpayers:
                raise ValueError("no taxpayers configured — add one in Settings first")
        else:
            taxpayers = [self._require_taxpayer(taxpayer_slug)]
        nifs = [str(t.nif_prestador) for t in taxpayers]

        # (3) Sheet-authoritative total — recomputed here, never a UI cache. Note: this count
        # is INDICATIVE (shown in the confirm modal); emit_for_nif re-lists at file time and
        # the returned `filed` is the authoritative number of receipts actually issued. Each
        # row still passes G1-G4 + the Portal duplicate pre-check at file time, so a row that
        # changed between here and filing can never be mis-filed — only the pre-count differs.
        try:
            total = len(self.serializer.list_claimable(nifs))
        except Exception as e:  # noqa: BLE001
            return {"error": "serializer_unavailable", "detail": str(e), "retry": True}
        if total == 0:
            return {"filed": 0, "nothing_pending": True}

        # (2) one emit at a time in this app (belt-and-suspenders over the serializer lock).
        if not self._emit_lock.acquire(blocking=False):
            return {"error": "busy", "detail": "An emit is already running in this app."}
        try:
            operator_id = default_operator_id()  # (2) FRESH per invocation

            # (1) THE process gate. confirm_real_emit is the real function; we feed "EMIT"
            # only when the UI confirmed. no_confirm stays False -> a forgotten `confirmed`
            # or any wiring slip fails CLOSED (nothing filed).
            gate_ok = confirm_real_emit(
                total, no_confirm=False,
                input_fn=lambda _prompt: "EMIT" if confirmed else "")
            if not gate_ok:
                return {"filed": 0, "aborted": True, "reason": "not confirmed"}

            # Live progress for the UI (polled via /emit/progress while this call blocks). `done` counts
            # RECEIPTS ACTUALLY FILING (on_progress now fires only at the Portal submit), so it matches the
            # "will file" count the operator confirmed — not the larger claimable pool. Display-only, no lock.
            self._emit_cancel.clear()   # fresh run: forget any earlier Stop
            self._emit_progress.update({"running": True, "total": total, "done": 0, "current": "", "taxpayer": ""})

            def _prog(info):
                p = self._emit_progress
                p["done"] = p.get("done", 0) + 1
                p["current"], p["taxpayer"] = info.get("guest") or "", info.get("taxpayer") or ""

            results: list[dict] = []
            filed = self.emit_real_fn(
                self.serializer, self.reg, taxpayers,
                operator_id=operator_id, assume_yes=True, log=self.log,
                v1_bridge=self.v1_bridge,   # v1||v2 firewall when configured (GRV2_V1_SHEET_ID)
                on_progress=_prog, should_stop=self._emit_cancel.is_set,
                on_result=lambda tx, res: results.append(
                    {"taxpayer_id": tx.taxpayer_id, "name": tx.nome_prestador,
                     "nif_masked": _mask_nif(tx.nif_prestador),
                     "emitted": res.get("emitted", 0), "errored": res.get("errored", 0),
                     "in_doubt": res.get("in_doubt", 0), "archived": res.get("archived", 0),
                     # The PDF copy is best-effort and NEVER fails a filing — but now that the app
                     # tells the operator where their PDFs are, a missing one must be said out loud
                     # rather than leaving a silently short folder.
                     "archive_failed": res.get("archive_failed", 0),
                     "skipped_reason": res.get("skipped_reason"),
                     # emit_for_nif returns {"skipped": "emit-lock held by ..."} when the per-NIF
                     # SERIALIZER lease (~20 min) is held by another/crashed run. That is NOT a
                     # skipped_reason (those are no_cred/login_failed/...); if we drop it the run
                     # returns filed:0 and the UI shows a FALSE "0 receipts filed" (audit finding).
                     "lock_held": res.get("skipped"),
                     # v1||v2 firewall tallies: stays skipped because the v1 sheet already holds
                     # their receipt (expected + correct during the parallel period — surfaced so
                     # "25 pending -> 4 filed" reads as the firewall working, not a failure).
                     "skipped_v1": res.get("skipped_v1", 0),
                     "v1_write_failed": res.get("v1_write_failed", 0),
                     "result_code": res.get("result_code")}))
        finally:
            self._emit_progress["running"] = False
            self._emit_lock.release()

        in_doubt = sum(r.get("in_doubt", 0) for r in results)
        # Per-ROW errors (re-claimable ERROR: a pre-submit failure like the Portal duplicate pre-check
        # being unavailable). DISTINCT from in_doubt and from a taxpayer-level skip. This MUST surface:
        # a run that errored every row (e.g. the 12-month dup-window bug) otherwise rendered as a clean
        # "0 filed / 0 in doubt" success — the operator got no warning (2026-07-09 incident).
        errored_total = sum(r.get("errored", 0) for r in results)
        # Skipped = filed NOTHING for that taxpayer (no_cred / login_failed / no_doc_number /
        # emit_error). This is DISTINCT from in_doubt (a possibly-filed row a human must
        # reconcile) — the UI must not conflate the two (review finding).
        skipped = [{"taxpayer_id": r["taxpayer_id"], "reason": r.get("skipped_reason"),
                    "code": r.get("result_code")} for r in results if r.get("skipped_reason")]
        # A login problem now carries its PRECISE kind. Only a genuine 2FA challenge
        # (otp_required) maps to the OTP screen; bad_credentials / blocked / portal_error
        # each get their own honest screen (never mislabel a bad password as "OTP").
        _login_kinds = {"otp_required", "bad_credentials", "blocked", "portal_error", "login_failed"}
        login_problem = next((s for s in skipped if s.get("code") in _login_kinds), None)
        # A held serializer lease is 'try again in ~20 min', NOT a failure and NOT '0 pending' —
        # the UI shows a wait panel instead of the Done screen.
        lock_held = [r for r in results if r.get("lock_held")]
        return {
            "filed": filed, "operator_id": operator_id, "per_taxpayer": results,
            "in_doubt_total": in_doubt, "skipped": skipped,
            "skipped_v1_total": sum(r.get("skipped_v1", 0) for r in results),
            "login_challenge": (login_problem or {}).get("code") == "otp_required",  # -> OTP screen ONLY for real 2FA
            # Precise login diagnosis for the UI's honest screens (blocked / wrong password /
            # Portal unreachable). None when login was fine. detail = the Portal's own words.
            "login_problem": ({"kind": login_problem["code"], "detail": login_problem.get("reason")}
                              if login_problem else None),
            "busy": bool(lock_held),           # -> the UI's "please wait ~20 min" screen
            "busy_detail": (lock_held[0].get("lock_held") if lock_held else None),
            "errored_total": errored_total,    # -> Done screen "N couldn't be filed — will retry" banner
            "needs_attention": in_doubt > 0 or bool(skipped) or errored_total > 0,
        }

    # ---- setup (screen 1) — wraps setup_taxpayer; NEVER getpass -------------
    def setup_status(self) -> dict:
        from setup_taxpayer import existing_taxpayer_ids, taxpayers_missing_password
        txs = sorted(existing_taxpayer_ids(self.registry_dir))
        needs_pw = [{"taxpayer_id": tid, "nif_masked": _mask_nif(nif)}
                    for tid, nif in taxpayers_missing_password(self.registry_dir)]
        return {"taxpayers": txs, "needs_password": needs_pw, "configured": bool(txs)}

    def add_taxpayer(self, *, nif, at_login_username, password, taxpayer_id="",
                     nome_prestador="", morada_fiscal_prestador="", morada_fiscal="",
                     estabelecimento_comercial="", data_inicio_atividade="", iva_cod_enq="",
                     iva_desc_enq="", iva_cod_tipo_operacoes="", iva_tipo_sujeito_passivo="") -> dict:
        """Identity (registry TOML) + Portal password (Windows keyring) in one call. The
        password is stored DIRECTLY via store_password — the app never calls getpass (which
        assumes a TTY and would hang the service thread).

        The operator enters ONLY NIF + Portal login + password: the legal name, addresses,
        IVA regime and início de atividade are AUTO-DERIVED from AT (fill-if-blank) — the
        tax authority is the source of truth for the identity that goes on receipts, so
        there is nothing to mistype. A failed AT fetch is non-fatal: the taxpayer is still
        created (with a loud warning + a placeholder name) and "Refresh from Finanças"
        fills everything once the sign-in works."""
        from setup_taxpayer import append_taxpayer, store_password
        # Reject a SECOND taxpayer for a NIF already in the registry (the dup-NIF mess:
        # multiple entries for one NIF, one filing a blank-address receipt). append_taxpayer
        # re-checks this, but doing it FIRST avoids a pointless live AT login below. Fresh
        # read of the TOML so a mutation earlier this session is seen even with a cached reg.
        import tomllib
        _tf = self.registry_dir / "taxpayers.toml"
        _existing = tomllib.loads(_tf.read_text(encoding="utf-8")).get("taxpayer", []) if _tf.exists() else []
        if any(str(x.get("nif_prestador")) == str(int(nif)) for x in _existing):
            raise ValueError(f"a taxpayer with NIF {int(nif)} already exists — edit it in the "
                             f"Google Sheet instead of adding a duplicate")
        # Copy-paste guard BEFORE any network call: the username's NIF base must match the
        # taxpayer NIF (append_taxpayer re-checks, but by then we'd have burned a real AT
        # login attempt against someone ELSE's account with a mismatched pair).
        _base = str(at_login_username).split("/")[0].strip()
        if _base != str(int(nif)):
            raise ValueError(f"the Portal username's NIF part ({_base or '?'}) doesn't match the "
                             f"client's NIF — check for a copy-paste mix-up")
        fields = {
            "taxpayer_id": taxpayer_id, "nif_prestador": int(nif), "cred_mode": "stored",
            "at_login_username": at_login_username, "nome_prestador": nome_prestador,
            "morada_fiscal_prestador": morada_fiscal_prestador, "morada_fiscal": morada_fiscal,
            "estabelecimento_comercial": estabelecimento_comercial,
            "data_inicio_atividade": data_inicio_atividade, "iva_cod_enq": iva_cod_enq,
            "iva_desc_enq": iva_desc_enq, "iva_cod_tipo_operacoes": iva_cod_tipo_operacoes,
            "iva_tipo_sujeito_passivo": iva_tipo_sujeito_passivo,
        }
        warning = None
        if not all(fields.get(k) for k in ("nome_prestador", "morada_fiscal_prestador",
                                           "morada_fiscal", "estabelecimento_comercial",
                                           "iva_cod_enq")):
            import login_cache
            hit = login_cache.check(int(nif))
            if hit:   # known block / wrong password in cooldown — do NOT burn another AT attempt
                warning = ("couldn't read the registration from AT: "
                           + login_cache.guidance(hit)
                           + " The client was saved; fix the password, then use "
                             "'Refresh from Finanças'.")
            else:
                try:
                    from emit_receipt import cadastro_to_registry_fields, login_and_fetch_cadastro
                    lr, cad = login_and_fetch_cadastro(at_login_username, int(nif), password)
                    login_cache.record(int(nif), lr.kind, lr.message)
                    if cad is None:
                        warning = (f"couldn't read your registration from AT (sign-in: {lr.kind}); "
                                   f"addresses left blank — you can fill them in the Google Sheet.")
                        # Best-effort: telemetry must never break setup. See ~line 908 for the pattern.
                        try:
                            import logging as _logging
                            import log_client as _lc
                            _lc.log_event(getattr(self, "log", None) or _logging.getLogger("grv2"),
                                          _logging.WARNING, "cadastro read failed at add_taxpayer",
                                          op="add_client", entity_id=_mask_nif(nif),
                                          result=lr.kind, detail=lr.message)
                        except Exception:  # noqa: BLE001
                            pass
                    else:
                        # THE single Cadastro->registry mapping (shared with refresh) — never
                        # a hand-copied field list that can drift from it.
                        for k, v in cadastro_to_registry_fields(cad).items():
                            if v and not fields.get(k):
                                fields[k] = v
                        try:
                            import logging as _logging
                            import log_client as _lc
                            _lc.log_event(getattr(self, "log", None) or _logging.getLogger("grv2"),
                                          _logging.INFO, "cadastro read ok",
                                          op="add_client", entity_id=_mask_nif(nif), result="ok", detail="")
                        except Exception:  # noqa: BLE001
                            pass
                except Exception as e:
                    warning = (f"couldn't read your registration from AT ({type(e).__name__}); "
                               f"addresses left blank — you can fill them in the Google Sheet.")
                    try:
                        import logging as _logging
                        import log_client as _lc
                        _lc.log_event(getattr(self, "log", None) or _logging.getLogger("grv2"),
                                      _logging.WARNING, "cadastro read raised at add_taxpayer",
                                      op="add_client", entity_id=_mask_nif(nif),
                                      result="exception", detail=type(e).__name__)
                    except Exception:  # noqa: BLE001
                        pass
        # No name field in the UI any more: derive the slug from the AT-fetched legal name
        # (or a NIF-based placeholder when the fetch failed — refresh_cadastro fills the
        # real name later; the slug itself is a permanent internal key, never shown).
        if not fields["taxpayer_id"]:
            import re as _re
            base = _re.sub(r"[^a-z0-9]+", "_", (fields["nome_prestador"] or "").lower()).strip("_") \
                   or f"client_{int(nif)}"
            from setup_taxpayer import existing_taxpayer_ids
            taken = existing_taxpayer_ids(self.registry_dir)
            slug, n = base, 2
            while slug in taken:
                slug, n = f"{base}_{n}", n + 1
            fields["taxpayer_id"] = taxpayer_id = slug
        if not fields["nome_prestador"]:
            # placeholder so tables/logs stay readable; NEVER filed (emit blocks on blank cadastro)
            fields["nome_prestador"] = f"Client {int(nif)}"
        append_taxpayer(self.registry_dir, fields)   # validates NIF/slug/at-login/cred_mode
        store_password(int(nif), password)
        out = {"ok": True, "taxpayer_id": taxpayer_id, "cadastro": {
            "nome_prestador": fields["nome_prestador"],
            "morada_fiscal_prestador": fields["morada_fiscal_prestador"],
            "morada_fiscal": fields["morada_fiscal"],
            "estabelecimento_comercial": fields["estabelecimento_comercial"],
            "data_inicio_atividade": fields["data_inicio_atividade"],
            "iva_regime": fields["iva_desc_enq"] or fields["iva_cod_enq"],
        }}
        if warning:
            out["warning"] = warning
        return out

    def set_password(self, *, nif, password) -> dict:
        from setup_taxpayer import store_password
        store_password(int(nif), password)
        import login_cache
        login_cache.clear(int(nif))   # new password -> forget the cached block/wrong-password
        try:
            import logging as _logging
            import log_client as _lc
            _lc.log_event(getattr(self, "log", None) or _logging.getLogger("grv2"),
                          _logging.INFO, "password re-stored; login cache cleared",
                          op="set_password", entity_id=_mask_nif(nif), result="ok", detail="")
        except Exception:  # noqa: BLE001
            pass
        return {"ok": True}

    def set_password_for(self, taxpayer_slug: str, password: str) -> dict:
        """Change an EXISTING taxpayer's Portal password from the app (by slug — the UI shows a
        masked NIF, never the real one). Looks the NIF up in the registry and re-stores the
        password in Windows' encrypted store. Files nothing."""
        t = self.reg.taxpayers.get(taxpayer_slug)
        if t is None:
            raise ValueError(f"unknown taxpayer {taxpayer_slug!r}")
        from setup_taxpayer import store_password
        store_password(int(t.nif_prestador), password)
        import login_cache
        login_cache.clear(int(t.nif_prestador))   # new password -> forget the cached block/wrong-password
        try:
            import logging as _logging
            import log_client as _lc
            _lc.log_event(getattr(self, "log", None) or _logging.getLogger("grv2"),
                          _logging.INFO, "password re-stored; login cache cleared",
                          op="set_password", entity_id=_mask_nif(t.nif_prestador), result="ok", detail="")
        except Exception:  # noqa: BLE001
            pass
        return {"ok": True, "taxpayer_id": taxpayer_slug}

    def _portal_login(self, t, cred):
        """Shared Portal sign-in ritual for the READ-ONLY setup flows (test_login / refresh_cadastro):
        honor the login cooldown, else attempt the sign-in and record the outcome — files NOTHING.
        A cached block / wrong-password still in cooldown SUPPRESSES the attempt (retrying is exactly
        what extends an AT lockout). Returns ({ok, kind, message, cached, nif_masked}, session):
        `session` is the live requests.Session from a real attempt — reuse it for a follow-up AT read
        (e.g. fetch_cadastro) — or None when the cooldown suppressed the attempt.

        DIVERGENCE HAZARD: emit.py's emit_real loop runs this SAME check -> login_result -> record
        ritual inline (it flows through skip() rather than returning a dict, so it can't call this
        helper). Keep the cooldown / record semantics here in sync with that copy."""
        import requests
        import login_cache
        from emit_receipt import login_result
        from emit import _login_profile
        nif_masked = _mask_nif(t.nif_prestador)
        hit = login_cache.check(t.nif_prestador)
        if hit:   # a known block / wrong-password in cooldown -> do NOT re-attempt (retrying extends a lock)
            try:
                import logging as _logging
                import log_client as _lc
                _lc.log_event(getattr(self, "log", None) or _logging.getLogger("grv2"),
                              _logging.WARNING, f"portal login {hit['kind']} (cached/cooldown)",
                              op="setup_login", entity_id=nif_masked, result=hit["kind"],
                              detail=login_cache.guidance(hit))
            except Exception:  # noqa: BLE001
                pass
            return ({"ok": False, "kind": hit["kind"], "message": login_cache.guidance(hit),
                     "cached": True, "nif_masked": nif_masked}, None)
        session = requests.Session()
        lr = login_result(session, _login_profile(t, cred))
        login_cache.record(t.nif_prestador, lr.kind, lr.message)   # success clears; block/bad stores
        try:
            import logging as _logging
            import log_client as _lc
            _lc.log_event(getattr(self, "log", None) or _logging.getLogger("grv2"),
                          _logging.INFO if lr.ok else _logging.WARNING, f"portal login {lr.kind}",
                          op="setup_login", entity_id=nif_masked, result=lr.kind, detail=lr.message)
        except Exception:  # noqa: BLE001
            pass
        return ({"ok": lr.ok, "kind": lr.kind, "message": lr.message,
                 "cached": False, "nif_masked": nif_masked}, session)

    def test_login(self, taxpayer_slug: str) -> dict:
        """READ-ONLY: verify a taxpayer's stored Portal credential by attempting the sign-in
        (login only — files NOTHING). Returns the CLASSIFIED result so Setup can show the real
        reason (ok / wrong password / temporarily blocked / 2FA / Portal unreachable) instead of
        the operator discovering it only at emit time. One attempt — do not call it in a loop."""
        from registry import resolve_credential
        t = self.reg.taxpayers.get(taxpayer_slug)
        if t is None:
            raise ValueError(f"unknown taxpayer {taxpayer_slug!r}")
        try:
            cred = resolve_credential(t, assume_yes=True)
        except Exception as e:
            nif_masked = _mask_nif(t.nif_prestador)
            try:
                import logging as _logging
                import log_client as _lc
                _lc.log_event(getattr(self, "log", None) or _logging.getLogger("grv2"),
                              _logging.WARNING, "test_login no_cred",
                              op="test_login", entity_id=nif_masked, result="no_cred", detail=str(e))
            except Exception:  # noqa: BLE001
                pass
            return {"ok": False, "kind": "no_cred", "message": str(e),
                    "nif_masked": nif_masked}
        res, _ = self._portal_login(t, cred)
        return res

    def refresh_cadastro(self, taxpayer_slug: str) -> dict:
        """Re-read a taxpayer's registration from AT and update the registry in place (addresses /
        IVA regime / início de atividade). This is how a taxpayer's details changing over time is
        handled: READ from AT + a local registry write — files NOTHING at the Portal. Returns the
        fields that changed so the UI can show them."""
        from registry import resolve_credential
        from emit_receipt import fetch_cadastro, cadastro_to_registry_fields
        from setup_taxpayer import update_taxpayer
        t = self.reg.taxpayers.get(taxpayer_slug)
        if t is None:
            raise ValueError(f"unknown taxpayer {taxpayer_slug!r}")
        cred = resolve_credential(t, assume_yes=True)
        res, session = self._portal_login(t, cred)
        nif_masked = _mask_nif(t.nif_prestador)
        if not res["ok"]:   # cooldown-suppressed OR the sign-in failed -> nothing to read from AT
            try:
                import logging as _logging
                import log_client as _lc
                _lc.log_event(getattr(self, "log", None) or _logging.getLogger("grv2"),
                              _logging.WARNING, f"refresh_cadastro {res['kind']}",
                              op="refresh_cadastro", entity_id=nif_masked,
                              result=res["kind"], detail=res.get("message") or "")
            except Exception:  # noqa: BLE001
                pass
            return res
        new_fields = cadastro_to_registry_fields(fetch_cadastro(session))
        changed = {k: {"from": getattr(t, k, ""), "to": v}
                   for k, v in new_fields.items() if str(getattr(t, k, "")) != str(v)}
        if changed:
            update_taxpayer(self.registry_dir, taxpayer_slug, new_fields)
        try:
            import logging as _logging
            import log_client as _lc
            _lc.log_event(getattr(self, "log", None) or _logging.getLogger("grv2"),
                          _logging.INFO, "refresh_cadastro ok",
                          op="refresh_cadastro", entity_id=nif_masked, result="ok", detail="")
        except Exception:  # noqa: BLE001
            pass
        return {"ok": True, "changed": changed, "nif_masked": nif_masked}

    def sync_properties_from_sheet(self) -> dict:
        """One-way Sheet -> app sync of the listing->taxpayer routing. The Google Sheet's
        "Property Settings" tab (the admin's space) is the ONLY place listings are added
        or edited; the operator just presses Sync. Read-only at the serializer; upserts the
        local properties.toml; never deletes (sheet-vanished rows come back as local_only)."""
        from setup_taxpayer import sync_properties_from_sheet
        nif_to_slug = {str(t.nif_prestador): t.taxpayer_id for t in self.reg.taxpayers.values()}
        if not nif_to_slug:
            raise ValueError("add a client first — listings are matched to clients by NIF")
        rows = self.serializer.list_settings(sorted(nif_to_slug))
        return {"ok": True, **sync_properties_from_sheet(self.registry_dir, rows, nif_to_slug)}

    def map_listing(self, *, listing_id, taxpayer_id=None, taxpayer_nif=None, cae_code,
                    cae_descr="", al_number="", listing_name="") -> dict:
        """Accepts the taxpayer by NIF (what the operator actually knows — rehearsal feedback)
        or by slug; a NIF is resolved against the registry and must match exactly one taxpayer."""
        import tomllib
        from setup_taxpayer import append_property
        if not taxpayer_id and taxpayer_nif:
            nif = str(taxpayer_nif).strip().replace(" ", "")
            txs = tomllib.loads((self.registry_dir / "taxpayers.toml").read_text(encoding="utf-8")) \
                .get("taxpayer", []) if (self.registry_dir / "taxpayers.toml").exists() else []
            hits = [t["taxpayer_id"] for t in txs if str(t.get("nif_prestador")) == nif]
            if len(hits) != 1:
                raise ValueError(f"no taxpayer with NIF {nif} — add it in step 3 first"
                                 if not hits else f"NIF {nif} matches several taxpayers")
            taxpayer_id = hits[0]
        if not taxpayer_id:
            raise ValueError("taxpayer (NIF) is required")
        append_property(self.registry_dir, {   # validates listing uniqueness + CAE + known taxpayer
            "listing_id_str": listing_id, "listing_name": listing_name, "taxpayer_id": taxpayer_id,
            "cae_code": cae_code, "cae_descr": cae_descr, "al_number": al_number})
        return {"ok": True, "listing_id": str(listing_id), "taxpayer_id": taxpayer_id}

    def setup_paths(self) -> dict:
        """Real filesystem paths the operator needs — the unpacked Chrome extension dir (so the UI
        can show/copy the exact path instead of describing it) and the receipts folder every issued
        Fatura-Recibo PDF is saved to, which an operator otherwise has no way to discover.

        ``drive_on`` reports whether the OPTIONAL Google-Drive copy is set up (the one-time
        `setup_drive_scope.py` consent). It exists so the UI can state where the PDFs actually
        went — local only, or local + Drive — instead of claiming Drive unconditionally."""
        import archival
        root = _install_root()
        ext = (root / "airbnb_bridge" / "extensao").resolve()   # the folder Chrome loaded
        receipts = Path(archival.default_pdf_root())
        try:
            import drive_uploader
            drive_on = drive_uploader._TOKEN_DRIVE.exists()
        except Exception:  # noqa: BLE001 — a missing module/token path must never break Settings
            drive_on = False
        return {"extension_dir": str(ext), "extension_exists": ext.is_dir(),
                "install_dir": str(root),
                "receipts_dir": str(receipts), "receipts_exists": receipts.is_dir(),
                "drive_on": drive_on}

    # Folders the UI is allowed to open — a NAME, never a caller-supplied path, so the endpoint
    # can't be turned into "open anything on this machine".
    OPENABLE = ("receipts_dir", "extension_dir", "install_dir")

    def open_folder(self, which: str) -> dict:
        """Open one of OPENABLE in the OS file manager. Read-only for the operator's data — it
        launches the file manager and nothing else."""
        if which not in self.OPENABLE:
            return {"ok": False, "error": "unknown folder"}
        path = Path(self.setup_paths()[which])
        if not path.is_dir():
            # The receipts folder only exists once something has been filed — say so plainly
            # rather than failing with an OS error the operator can't act on.
            return {"ok": False, "error": "not_yet", "path": str(path),
                    "detail": "This folder doesn't exist yet — it's created when the first receipt is filed."}
        try:
            if sys.platform == "win32":
                os.startfile(str(path))  # noqa: S606 — fixed, allow-listed path
            else:
                subprocess.Popen(["open" if sys.platform == "darwin" else "xdg-open", str(path)])
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": "could_not_open", "path": str(path), "detail": str(e)}
        return {"ok": True, "path": str(path)}

    # ---- fix (screen 4) — wraps override.py's audited CAS ops ---------------
    # payment_date is overridable so an operator (or a later EXACT payout date from a CSV drop) can
    # correct the extension lane's check-in+1 ESTIMATE before the receipt is claimed/emitted. It is a
    # date, not money -> non-money override path. MUST mirror Logic.gs OVERRIDABLE_FIELDS exactly.
    OVERRIDABLE = ["service_date", "end_date", "guest", "buyer_nif", "buyer_country",
                   "description", "ttc", "vat", "base", "payment_date"]
    # Date fields among OVERRIDABLE — a non-blank override must be a valid ISO date. Mirrors the
    # serializer's OVERRIDE_DATE_FIELDS so a bad date is rejected client-side with a clean error too.
    OVERRIDE_DATE_FIELDS = {"service_date", "end_date", "payment_date"}

    def _get_row(self, row_id):
        """get_row, but a serializer REFUSAL (busy/500) becomes a structured error dict
        (like list_pending) instead of a raised RuntimeError that would 500 the UI. A clean
        404 returns {'row': None}. Returns (row, version, error_dict-or-None)."""
        try:
            g = self.serializer.get_row(row_id)
        except Exception as e:  # noqa: BLE001
            return None, None, {"error": "serializer_unavailable", "detail": str(e), "retry": True}
        return g.get("row"), g.get("row_version"), None

    def fix_show(self, row_id: str) -> dict:
        row, version, err = self._get_row(row_id)
        if err:
            return err
        if not row:
            return {"error": "not_found", "detail": f"row {row_id} not found"}
        return {"row_id": row_id, "lifecycle": row.get("lifecycle"), "row_version": version,
                "fields": {f: row.get(f) for f in self.OVERRIDABLE}}

    def mark_filed_manually(self, row_ids, actor=None) -> dict:
        """Operator decision for SWITCH-OVER boundary stays: "I already filed this one by
        hand." Uses the same audited two-step as the cutover reconciler (park IN_DOUBT with
        the reason, then resolve -> terminal VERIFIED) so the stay is on the books and can
        never be filed by the app — and never silently: every row is in HISTORY twice."""
        done, failed = [], []
        for rid in row_ids:
            try:
                # record_in_doubt RETURNS {"ok": False, ...} on a serializer refusal (it does not
                # raise — it is the park write and is designed to fail loud-but-soft). Ignoring it
                # turned a clean refusal into a misleading "row not found after parking"; surface the
                # real reason instead so the operator sees why the mark did not take.
                parked = self.serializer.record_in_doubt(
                    rid, "switchover", "operator confirmed: filed by hand before switch-over")
                if not (isinstance(parked, dict) and (parked.get("ok") or parked.get("idempotent"))):
                    raise RuntimeError("serializer refused to park the row: "
                                       + str((parked or {}).get("error") or parked))
                v = next((d for d in self.serializer.list_in_doubt(
                    [str(t.nif_prestador) for t in self.reg.taxpayers.values()])
                    if d["row_id"] == rid), None)
                if v is None:
                    raise RuntimeError("row not found in the unconfirmed list after parking")
                resolved = self.serializer.resolve_in_doubt(rid, v["row_version"], op="switchover",
                                                            actor=actor or "operator",
                                                            note="filed by hand before switch-over")
                if not (isinstance(resolved, dict) and resolved.get("ok")):
                    raise RuntimeError("serializer refused to finalize the row: "
                                       + str((resolved or {}).get("error") or resolved))
                done.append(rid)
            except Exception as e:  # noqa: BLE001 — keep going; report per row
                failed.append({"row_id": rid, "detail": str(e)})
        return {"ok": not failed, "marked": done, "failed": failed}

    def mark_parked_filed_by_hand(self, row_ids, actor=None) -> dict:
        """Operator decision for a PARKED stay (Review -> Needs review, e.g. "Airbnb did not give us
        this stay's fee"): "I issued this receipt by hand at the Portal." The serializer moves the
        STAGING row to the terminal 'filed_by_hand' state — never promoted, no longer listed for
        review, and every later capture of the stay is a no-op — so the app can never issue it a
        second time. Audited in HISTORY. Per-row result, like mark_filed_manually; a refusal carries
        the serializer's plain reason. An older serializer does not know the op: say so plainly."""
        done, failed = [], []
        for rid in row_ids or []:
            try:
                res = self.serializer.mark_parked_filed_by_hand(rid, actor=actor or "operator")
            except Exception as e:  # noqa: BLE001 — transport: report per row, keep going
                failed.append({"row_id": rid, "detail": f"couldn't reach the Google Sheet ({e})"})
                continue
            if isinstance(res, dict) and res.get("ok"):
                done.append(rid)
            elif isinstance(res, dict) and res.get("error") == "unknown op":
                failed.append({"row_id": rid, "detail": "Your firm's Google Sheet needs an update before "
                               "a stay can be marked here. Nothing was changed — tell Laurent."})
            else:
                failed.append({"row_id": rid, "detail": str((res or {}).get("reason")
                                                            or (res or {}).get("error") or res)})
        return {"ok": not failed, "marked": done, "failed": failed}

    def fix_override(self, *, row_id, field, new_value, actor=None) -> dict:
        """Correct ONE field via the serializer's version-checked override op — never a raw
        sheet edit. Only PENDING/ERROR rows are correctable (the serializer enforces it)."""
        if field not in self.OVERRIDABLE:
            return {"error": "bad_field", "detail": f"{field} is not overridable"}
        if field in self.OVERRIDE_DATE_FIELDS and str(new_value or "").strip() != "" and not _is_iso_date(new_value):
            return {"error": "bad_value", "detail": f"{field} must be a valid date (YYYY-MM-DD)"}
        row, version, err = self._get_row(row_id)
        if err:
            return err
        if not row:
            return {"error": "not_found", "detail": f"row {row_id} not found"}
        res = self.serializer.override(row_id, field, row.get(field), new_value, version, actor=actor)
        if res.get("ok"):
            return {"ok": True, "field": field, "old": res.get("old_value"), "new": res.get("new_value")}
        return {"error": res.get("result", "rejected"), "detail": res.get("reason")}

    def fix_reroute(self, row_id: str) -> dict:
        """Re-stamp an un-emitted row from the CURRENT Property Settings (the G2 settings-drift
        remedy). CAS on row_version; the serializer refuses EMITTED/EMITTING/IN_DOUBT/CLAIMED."""
        row, version, err = self._get_row(row_id)
        if err:
            return err
        if not row:
            return {"error": "not_found", "detail": f"row {row_id} not found"}
        res = self.serializer.reroute(row_id, version)
        if res.get("ok"):
            s = res.get("stamp") or {}
            return {"ok": True, "taxpayer_nif": s.get("taxpayer_nif"), "cae_code": s.get("cae_code")}
        return {"error": "rejected", "detail": res.get("error")}

    # ---- reconcile (#2) — the IN_DOUBT worklist -----------------------------
    def list_in_doubt(self, taxpayer_slug: str | None = None) -> dict:
        """IN_DOUBT rows to reconcile (a possibly-filed receipt a human must verify at the Portal),
        across all the operator's taxpayers or one if given. A refusal is a STRUCTURED error — never
        an empty list read as 'nothing to reconcile' (which would hide a possible duplicate)."""
        if taxpayer_slug:
            nifs = [str(self._require_taxpayer(taxpayer_slug).nif_prestador)]
        else:
            nifs = [str(t.nif_prestador) for t in self.reg.taxpayers.values()]
        try:
            rows = self.serializer.list_in_doubt(nifs)
        except Exception as e:  # noqa: BLE001
            return {"error": "serializer_unavailable", "detail": str(e), "retry": True}
        return {"count": len(rows), "rows": [
            {"row_id": r.get("row_id"), "hm_code": r.get("hm_code"),
             "nif_masked": _mask_nif(r.get("taxpayer_nif")),
             "service_date": r.get("service_date"), "end_date": r.get("end_date"),
             "ttc": r.get("ttc"), "base": r.get("base"), "guest": r.get("guest"),
             "description": r.get("description"), "num_doc": r.get("num_doc"),
             "note": r.get("note"), "row_version": r.get("row_version")} for r in rows]}

    def list_needs_review(self, taxpayer_slug: str | None = None) -> dict:
        """The pre-emit REVIEW LANE: STAGING needs_review + QUARANTINE rows a human must decide before a
        receipt can issue (a Resolution/Adjustment to classify, a suspect amount, a listing that didn't
        resolve). Each row is tagged with its client (or 'Unassigned' when the listing didn't resolve to
        a taxpayer). A refusal is a STRUCTURED error, never an empty list read as 'nothing to review'.
        NON-BLOCKING: a separate worklist — issuing clean rows never depends on it."""
        clients = self._clients_by_nif()
        if taxpayer_slug:
            nifs = [str(self._require_taxpayer(taxpayer_slug).nif_prestador)]
        else:
            nifs = list(clients.keys())
        try:
            rows = self.serializer.list_needs_review(nifs)
        except Exception as e:  # noqa: BLE001
            return {"error": "serializer_unavailable", "detail": str(e), "retry": True}
        out = []
        for r in rows:
            c = clients.get(str(r.get("taxpayer_nif") or "")) or {}
            issue_by = _issue_by(r.get("payment_date"))
            days_left, urgency = _urgency(issue_by)
            out.append({
                "row_id": r.get("row_id"), "lane": r.get("lane"), "hm_code": r.get("hm_code"),
                "listing_id_str": r.get("listing_id_str"), "route_status": r.get("route_status"),
                "guest": r.get("guest"), "type": r.get("type"),
                "check_in": r.get("check_in"), "check_out": r.get("check_out"),
                "payment_date": r.get("payment_date"), "issue_by": issue_by,
                "days_left": days_left, "urgency": urgency,
                "paid_out": r.get("paid_out"), "gross_earnings": r.get("gross_earnings"),
                "currency": r.get("currency"),
                "review_reason": r.get("review_reason") or "", "details": r.get("details") or "",
                "property_label": r.get("property_label") or "",
                "client_name": c.get("name") or "Unassigned",
                "client_nif_masked": c.get("nif_masked") or "—",
                "taxpayer_id": c.get("taxpayer_id") or ""})
        return {"count": len(out), "rows": out}

    def apply_csv(self, csv_text: str, *, actor=None) -> dict:
        """Stage F — ingest a Transaction-History CSV DROP. It NEVER files and NEVER deletes: it CORRECTS
        each pending stay's dataPrestacao to the EXACT payout date from the CSV (the extension lane's
        check-in+1 is only ~52% accurate) via the ISO-validated override, and returns the unmatched-income
        gap + the count of resolution/adjustment 'extras' as a NON-BLOCKING signal for the operator to
        classify. Only PENDING rows are corrected (the serializer enforces it); a bad CSV is a structured
        error, never a crash."""
        import csv as _csv
        import io
        # Airbnb's Transaction-History export is Excel-targeted and ships a UTF-8 BOM; f.text() in the
        # browser decodes UTF-8 but keeps the BOM, so DictReader would name the first column "﻿Date"
        # and the locale guard would (wrongly) report the leading column missing. Strip it — the plan
        # documents this reader as csv.DictReader(utf-8-sig).
        csv_text = csv_text.lstrip("﻿")
        try:
            rows = list(_csv.DictReader(io.StringIO(csv_text)))
        except Exception as e:  # noqa: BLE001
            return {"error": "bad_csv", "detail": str(e)}
        if not rows:
            return {"error": "bad_csv", "detail": "no rows found in the CSV"}
        from airbnb_bridge.transactions import parse_csv_signals
        sig = parse_csv_signals(rows)
        if sig.get("error"):   # non-English / DD-MM CSV -> clear message, correct NOTHING (never mis-date)
            return {"error": sig["error"], "detail": sig.get("detail") or "unsupported CSV"}
        pending = self.list_pending_all()
        if pending.get("error"):
            return pending
        corrected, unchanged, failed = [], 0, []
        for row in pending.get("rows", []):
            exact = sig["exact_dates"].get(row.get("hm_code"))
            if not exact:
                continue
            if exact == (row.get("payment_date") or ""):
                unchanged += 1
                continue
            res = self.fix_override(row_id=row["row_id"], field="payment_date", new_value=exact, actor=actor)
            if res.get("ok"):
                corrected.append({"hm_code": row.get("hm_code"), "old": row.get("payment_date") or "", "new": exact})
            else:
                failed.append({"hm_code": row.get("hm_code"), "detail": res.get("detail") or res.get("error")})
        gap = sig["gap"]
        signal = ""
        if abs(gap) > 0.01:
            if gap > 0:   # more was paid out than the reservations total -> extra income to account for
                signal = (f"€{abs(gap):.2f} of income not matched to a reservation — {len(sig['extras'])} "
                          f"item(s) (resolution / adjustment / long stay) to review; check the Airbnb transactions.")
            else:         # less was paid out than the reservations total -> a refund/deduction/chargeback
                signal = (f"€{abs(gap):.2f} paid out is LESS than the reservation total (a refund / deduction / "
                          f"chargeback) — {len(sig['extras'])} item(s) to review; check the Airbnb transactions.")
        # Durable record on the sheet LOG tab: each date correction already lands in HISTORY (via the
        # override), but the RUN SUMMARY + the unmatched-income gap signal were only returned to the
        # UI. Log them so the operator/the admin can see, after the fact, that a CSV was dropped and what
        # it changed/flagged. Best-effort: telemetry must never break the correction flow.
        try:
            import logging as _logging
            import log_client as _lc
            summary = (f"CSV drop: {len(corrected)} date(s) corrected, {unchanged} already exact, "
                       f"{len(failed)} failed; gap €{gap:.2f}, {len(sig['extras'])} extra(s) to review")
            _lc.log_event(getattr(self, "log", None) or _logging.getLogger("app"),
                          _logging.WARNING if (signal or failed) else _logging.INFO,
                          summary, op="apply_csv",
                          result="signal" if signal else ("error" if failed else "ok"),
                          detail=signal)
        except Exception:  # noqa: BLE001
            pass
        return {"dates_corrected": len(corrected), "dates_unchanged": unchanged, "corrections": corrected,
                "correct_failed": failed, "extras": len(sig["extras"]), "gap": gap,
                "payout_total": sig["payout_total"], "reservation_total": sig["reservation_total"],
                "signal": signal}

    def resolve_in_doubt(self, *, row_id, actor=None, note=None) -> dict:
        """Operator 'mark verified' after reconciling at the Portal: IN_DOUBT -> VERIFIED. Reads the
        current row_version first (CAS via serializer.resolve_in_doubt), so it can't race a change.
        The serializer refuses anything but IN_DOUBT -> a wrong click can never make a row claimable
        again. Structured error, never a 500."""
        row, version, err = self._get_row(row_id)
        if err:
            return err
        if not row:
            return {"error": "not_found", "detail": f"row {row_id} not found"}
        res = self.serializer.resolve_in_doubt(row_id, version, actor=actor, note=note)
        if res.get("ok"):
            return {"ok": True, "row_id": row_id, "verified": True, "idempotent": res.get("idempotent", False)}
        return {"error": res.get("reason", "rejected"), "detail": res.get("reason"), "current": res.get("current")}

    def resolve_v1_matches(self, *, actor=None) -> dict:
        """Bulk 'mark verified' for ONLY the v1∥v2-firewall in-doubt rows (note carries 'already filed by
        v1 as doc N'). Those are KNOWN-filed in the operator's previous tool, so confirming each by hand is
        busywork (a parallel-period artifact — the owner's account, not an operator's). GENUINELY-ambiguous
        in-doubt rows (an emit the app couldn't confirm) are NEVER touched — they still require a per-row
        Portal check. Each resolve goes through the same CAS/lifecycle guard, so a concurrent change can't
        be clobbered; a row that isn't a clear v1 match is left alone (fail-safe)."""
        listing = self.list_in_doubt()
        if listing.get("error"):
            return listing
        rows = listing.get("rows", [])
        v1_rows = [r for r in rows if "already filed by v1" in (r.get("note") or "").lower()]
        resolved, failed = [], []
        for r in v1_rows:
            res = self.resolve_in_doubt(row_id=r["row_id"], actor=actor,
                                        note="bulk-verified: already filed in v1 (operator confirmed)")
            (resolved if res.get("ok") else failed).append(
                r["row_id"] if res.get("ok") else {"row_id": r["row_id"], "detail": res.get("detail") or res.get("error")})
        return {"resolved": len(resolved), "failed": failed,
                "v1_total": len(v1_rows), "other_in_doubt": len(rows) - len(v1_rows)}

    # ---- capture (screen 2) — drives live_capture off-thread ---------------
    def capture(self, account: str, *, dry_run: bool = False) -> dict:
        """Run one capture (reads finished stays in the operator's Chrome + auto-promotes).
        Runs to completion off the UI thread; returns a STRUCTURED status + the report counts.
        One capture at a time (a second call while one runs -> busy)."""
        blocked = self._update_guard()
        if blocked:   # withdrawn version: read and write nothing
            return {"error": "blocked_version", "detail": blocked, "status": "blocked"}
        if not self._capture_lock.acquire(blocking=False):
            return {"error": "busy", "detail": "A capture is already running."}
        # GR_ACCOUNT (config.bat) is the authoritative Airbnb-account label: it keys the dedupe
        # seen-file (~/.config/green_receipts/seen_<account>.txt) + airbnb_account_id tagging.
        # The UI sends the taxpayer slug as a fallback; if the label diverged from the .bat flow's,
        # captures would stop deduping against each other (review finding).
        account = self.default_account or account
        import time as _time
        self._capture_progress = {"running": True, "started": _time.time()}
        try:
            main = self._capture_main
            if main is None:
                from tools.live_capture import main as main  # lazy: needs websockets/extension
            argv = ["--account", account,
                    "--serializer-url", getattr(self.serializer, "url", ""),
                    "--token", getattr(self.serializer, "token", "")]
            if dry_run:
                argv.append("--dry-run")
            captured: dict = {}
            code = main(argv, on_report=lambda rep: captured.update({
                "reservations_seen": rep.reservations_seen, "rows_ingested": rep.rows_ingested,
                "needs_review": rep.rows_needs_review, "skipped_seen": rep.rows_skipped_seen,
                "skipped_too_old": rep.rows_skipped_too_old, "challenge": rep.challenge,
                "skipped_foreign": getattr(rep, "rows_skipped_foreign", 0),
                # NON-BLOCKING completeness signals — surfaced as a separate field, NEVER via error/status,
                # so the UI shows them as an amber note and never as a failed capture (audit finding).
                "warnings": list(rep.warnings), "reconcile": rep.reconcile,
                # The stays NOT sent on to be issued this run, each with its plain reason + its
                # 5-business-day deadline, so the capture screen can name them (never just a count).
                "flagged": _flagged_for_ui(getattr(rep, "flagged", None) or []),
                "filed_by_hand": getattr(rep, "rows_filed_by_hand", 0),
                # 8b: stays whose fee came from Airbnb's VAT invoice because the details lookup failed.
                "fees_from_vat_invoice": getattr(rep, "fees_from_vat_invoice", 0)}))
        finally:
            self._capture_progress["running"] = False
            self._capture_lock.release()
        status = {0: "ok", 1: "failed", 2: "challenge", 3: "empty",
                  4: "promote_failed", 5: "wrong_account", 6: "no_listings",
                  130: "cancelled"}.get(code, "failed")
        result = {"status": status, "exit_code": code,
                  # 'challenge' -> the OTP screen; 'empty' -> confirm-manually warning;
                  # 'promote_failed' -> captured but re-run to make them claimable.
                  "login_challenge": status == "challenge", **captured}
        if status == "ok" and not dry_run:
            self._write_last_capture(result)   # "last capture: <when>, N stays" on the Capture screen
        return result

    def _last_capture_path(self):
        return Path(self.registry_dir).parent / "last_capture.json"

    def _write_last_capture(self, result: dict) -> None:
        # Best-effort operator memory — a failed write must never fail the capture itself.
        import json as _json
        import time as _time
        try:
            self._last_capture_path().write_text(_json.dumps({
                "ts": _time.strftime("%Y-%m-%dT%H:%M:%S"),
                "reservations_seen": result.get("reservations_seen", 0),
                "rows_ingested": result.get("rows_ingested", 0)}), encoding="utf-8")
        except OSError:
            pass

    def last_capture(self) -> dict:
        """When the last successful (non-preview) capture ran + what it found — so the Capture
        screen can say "last run: X days ago" instead of leaving the operator guessing whether
        anything is outstanding. {ts, days_ago, reservations_seen, rows_ingested} or {ts: None}."""
        import json as _json
        import time as _time
        p = self._last_capture_path()
        try:
            d = _json.loads(p.read_text(encoding="utf-8"))
            age = _time.time() - _time.mktime(_time.strptime(d["ts"], "%Y-%m-%dT%H:%M:%S"))
            d["days_ago"] = max(0, int(age // 86400))
            return d
        except (OSError, ValueError, KeyError):
            return {"ts": None}

    def check_extension(self, *, timeout: float = 12.0) -> dict:
        """Pre-flight: is the Chrome bridge extension loaded + connectable? Briefly starts the local
        bridge WS server and waits ONE extension reconnect cycle for it to connect, then stops it. It
        reads NOTHING from Airbnb — only the handshake — so the operator learns BEFORE clicking Capture
        whether the extension is ready. Returns quickly when the extension is present (wait_for_extension
        resolves the instant it connects); only a genuinely-absent extension waits the full timeout. The
        port is fully released before this returns, so a following Capture never collides with the probe."""
        import asyncio
        if not self._capture_lock.acquire(blocking=False):
            return {"connected": None, "detail": "a capture is running — the extension is in use"}
        try:
            try:
                from airbnb_bridge.host_bridge import HostBridge
            except Exception as e:  # noqa: BLE001 — websockets missing (shouldn't happen in the bundle)
                return {"connected": False, "detail": f"bridge unavailable ({e})"}

            async def _probe():
                bridge = HostBridge(connect_timeout=timeout)
                try:
                    await bridge.start()
                    await bridge.wait_for_extension()  # BridgeError if it never connects (absent)
                    # Match the CAPTURE gate exactly: a connected-but-out-of-date extension is REFUSED by
                    # capture (ensure_fresh_extension raises), so the pre-flight must report it not-ready
                    # too — else we'd say "connected" for an extension the next Capture would abort.
                    # Same as capture: a stale extension that can reload itself is asked to first (8d).
                    _reload = getattr(bridge, "reload_if_stale", None)
                    if _reload is not None:
                        await _reload()
                    try:
                        bridge.ensure_fresh_extension()
                    except Exception as e:  # noqa: BLE001 — stale/version mismatch
                        return {"connected": False, "reason": "stale",
                                "detail": "your Green Receipts extension is out of date — reload it in "
                                          "chrome://extensions, then re-check (" + (str(e) or "version mismatch") + ")"}
                    return {"connected": True, "detail": ""}
                except Exception as e:  # noqa: BLE001 — never connected / bind error
                    return {"connected": False, "reason": "absent", "detail": str(e) or "no extension connected"}
                finally:
                    try:
                        await bridge.stop()
                    except Exception:  # noqa: BLE001
                        pass
            import time as _time
            try:
                res = asyncio.run(_probe())
            except RuntimeError as e:  # e.g. asyncio.run in an already-running loop (defensive)
                res = {"connected": False, "detail": str(e)}
            self._last_ext_check = {"at": _time.time(), "connected": res.get("connected") is True}
            return res
        finally:
            self._capture_lock.release()

    # ---- 8c: capture without being asked ----------------------------------
    def _last_capture_age_hours(self, now: float | None = None):
        """Hours since the last successful real capture on this computer, or None if none ran."""
        import time as _time
        ts = self.last_capture().get("ts")
        if not ts:
            return None
        try:
            then = _time.mktime(_time.strptime(str(ts), "%Y-%m-%dT%H:%M:%S"))
        except (ValueError, OverflowError):
            return None
        return max(0.0, ((now if now is not None else _time.time()) - then) / 3600.0)

    def _busy(self) -> str:
        """'capture' / 'issue' while one is running in this app, else ''."""
        if self._capture_lock.locked() or self._capture_progress.get("running"):
            return "capture"
        if self._emit_lock.locked() or self._emit_progress.get("running"):
            return "issue"
        return ""

    def auto_capture_status(self, *, now: float | None = None) -> dict:
        """Would an automatic capture start now? {enabled, due, reason, hours_since}. reason is one
        of: off, already_ran, never, recent, busy_capture, busy_issue, due. A computer where no capture
        ever ran is NOT auto-captured (the first capture is the operator's own, deliberate step)."""
        hours = self._last_capture_age_hours(now)
        out = {"enabled": auto_capture_enabled(), "due": False,
               "hours_since": (round(hours, 1) if hours is not None else None),
               "max_age_hours": AUTO_CAPTURE_MAX_AGE_HOURS}
        if not out["enabled"]:
            return {**out, "reason": "off"}
        if self._auto_capture_started:
            return {**out, "reason": "already_ran"}
        if self._update_guard():
            return {**out, "reason": "blocked_version"}
        if hours is None:
            return {**out, "reason": "never"}
        if hours <= AUTO_CAPTURE_MAX_AGE_HOURS:
            return {**out, "reason": "recent"}
        busy = self._busy()
        if busy:
            return {**out, "reason": "busy_" + busy}
        return {**out, "due": True, "reason": "due"}

    def auto_capture(self, account: str, *, now: float | None = None) -> dict:
        """Run ONE automatic capture on app start when it is due (auto_capture_status) AND the
        extension answered a pre-flight check in the last AUTO_CAPTURE_EXT_CHECK_MAX_AGE_SEC. It is
        the very same capture() as the button (real, not a preview), with the same locks and gates; it
        NEVER issues anything (no emit call exists on this path). At most once per app run."""
        import time as _time
        st = self.auto_capture_status(now=now)
        if not st["due"]:
            return {"auto": True, "started": False, "reason": st["reason"]}
        t = now if now is not None else _time.time()
        ext = self._last_ext_check
        if not ext or not ext.get("connected") or (t - ext.get("at", 0)) > AUTO_CAPTURE_EXT_CHECK_MAX_AGE_SEC:
            return {"auto": True, "started": False, "reason": "extension"}
        self._auto_capture_started = True
        res = self.capture(account, dry_run=False)
        return {**res, "auto": True, "started": res.get("error") != "busy"}

    def urgent_parked(self, *, today=None) -> dict:
        """Not-issued stays in the review lane with FEWER than URGENT_DAYS_LEFT working days left
        before their issue-by date (overdue included) — the red banner on the first screen. Uses
        business_days (weekdays only) like every other deadline in the app. A refusal is a structured
        error, never an empty list read as 'nothing urgent'."""
        import datetime
        import business_days
        nr = self.list_needs_review()
        if nr.get("error"):
            return nr
        day = today or datetime.date.today()
        rows = []
        for r in nr.get("rows", []):
            ib = r.get("issue_by") or ""
            if not ib:
                continue
            try:
                left = business_days.business_days_left(ib, day)
            except (ValueError, TypeError):
                continue
            if left < URGENT_DAYS_LEFT:
                rows.append({"row_id": r.get("row_id"), "hm_code": r.get("hm_code"), "guest": r.get("guest"),
                             "check_in": r.get("check_in"), "check_out": r.get("check_out"),
                             "issue_by": ib, "days_left": left, "review_reason": r.get("review_reason") or "",
                             "client_name": r.get("client_name") or ""})
        rows.sort(key=lambda x: x["days_left"])
        return {"count": len(rows), "rows": rows, "threshold": URGENT_DAYS_LEFT}

    def self_check(self, *, include_extension: bool = True) -> dict:
        """PRE-FLIGHT — verify the operator's setup is ready BEFORE the first real emit, so a fresh
        deployment (an operator) has no surprises. Every check is SAFE + idempotent: it does NOT log in to
        the Portal and does NOT file anything. Returns a per-item {label, ok, detail} list + `ready`."""
        checks = []
        st = self.setup_status()
        checks.append({"label": "Clients set up", "ok": bool(st.get("configured")),
                       "detail": (f"{len(st.get('taxpayers', []))} client(s) configured" if st.get("configured")
                                  else "No clients yet — add one on the Settings screen")})
        missing = st.get("needs_password", [])
        checks.append({"label": "Portal passwords saved",
                       "ok": bool(st.get("configured")) and not missing,
                       "detail": ("all clients have a saved Portal password" if not missing
                                  else f"{len(missing)} client(s) still need a Portal password (Settings → add password)")})
        # serializer URL + token + Google Sheet all reachable — a real claimable query (the same path
        # emit uses) validates auth + sheet. ALWAYS call it, even with zero clients (the fresh-deploy case
        # this whole check exists for): list_claimable([]) still round-trips the URL/token/sheet and raises
        # on failure, so a wrong token can never show a green "Connected" before any client is added.
        try:
            self.serializer.list_claimable([str(t.nif_prestador) for t in self.reg.taxpayers.values()])
            checks.append({"label": "Connected to the Google Sheet", "ok": True,
                           "detail": "serializer URL + token + sheet all reachable"})
        except Exception as e:  # noqa: BLE001
            checks.append({"label": "Connected to the Google Sheet", "ok": False,
                           "detail": f"couldn't reach it — check the URL/token in config.bat ({str(e)[:70]})"})
        if include_extension:
            try:
                ext = self.check_extension()
                conn = ext.get("connected")
                checks.append({"label": "Chrome extension connected", "ok": conn is True,
                               "detail": ext.get("detail") or ("connected" if conn else
                                         "not detected — load it in Chrome (chrome://extensions), then re-check")})
            except Exception as e:  # noqa: BLE001
                checks.append({"label": "Chrome extension connected", "ok": False, "detail": str(e)[:80]})
        # Portal login is deliberately NOT auto-tested — repeated logins can trip the tax-portal lockout;
        # it is validated on the first real Issue, which now surfaces the precise reason (bad password /
        # blocked / OTP) via the honest login screens.
        return {"ready": all(c["ok"] for c in checks), "checks": checks,
                "note": "Portal login isn't tested here (to avoid the tax-portal lockout) — it's checked on your first real Issue."}

    def install_update(self, *, confirmed: bool) -> dict:
        """Part 4 of docs/PLAN_AUTO_UPDATE.md: the operator clicked Install for an update that needs
        the installer. Never unattended (confirmed must be True) and never while a capture or an
        issue runs: both locks are taken first and kept, so neither can start before the app closes."""
        try:
            from app import updater as _u
        except ImportError:
            import updater as _u  # type: ignore[no-redef]

        def acquire_idle():
            if not self._capture_lock.acquire(blocking=False):
                return None
            if not self._emit_lock.acquire(blocking=False):
                self._capture_lock.release()
                return None
            if self._capture_progress.get("running") or self._emit_progress.get("running"):
                self._emit_lock.release()
                self._capture_lock.release()
                return None

            def release():
                self._emit_lock.release()
                self._capture_lock.release()
            return release
        return _u.get().install_now(confirmed=confirmed, acquire_idle=acquire_idle)

    def emit_progress(self) -> dict:
        """A snapshot of the live emit progress (polled by the UI while /emit runs). Display-only."""
        return dict(self._emit_progress)

    def capture_progress(self) -> dict:
        """Live capture progress (polled while /capture blocks): running + elapsed seconds, so the
        UI can show it's working rather than a frozen screen. Display-only; no Airbnb interaction."""
        import time as _time
        p = self._capture_progress
        elapsed = int(_time.time() - p.get("started", 0.0)) if p.get("running") else 0
        return {"running": bool(p.get("running")), "elapsed": max(0, elapsed)}

    def cancel_emit(self) -> dict:
        """STOP: request the running emit to stop AFTER the current receipt (checked between rows, never
        mid-submit). No-op if nothing is running. Cleared at the start of the next run_emit."""
        self._emit_cancel.set()
        return {"stopping": True, "running": bool(self._emit_progress.get("running"))}

    # ---- helpers -----------------------------------------------------------
    def _require_taxpayer(self, slug: str):
        # NEVER an implicit "all": the UI must select exactly one taxpayer to file for
        # (wrong-scope --all is a documented misfile risk).
        if not slug:
            raise ValueError("no taxpayer selected — the app never files for 'all' implicitly")
        try:
            (t,) = select_taxpayers(self.reg, slug)
        except SystemExit as e:
            raise ValueError(str(e))
        return t
