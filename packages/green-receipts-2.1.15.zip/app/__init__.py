"""Green Receipts desktop app — a front-end that ONLY imports the existing backend.
Rollback = stop shipping this package; the .bat/installer flow is untouched."""
