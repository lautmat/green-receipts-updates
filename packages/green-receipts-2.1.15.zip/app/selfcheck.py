"""app/selfcheck.py — offline self-test of a code tree before it may become the active version
(docs/PLAN_AUTO_UPDATE.md 2.3). Run by the updater in a SUBPROCESS with the bundle's Python:

    python app/selfcheck.py --root <candidate tree> --expect-version 2.1.15 [--install-root <install>]

It never touches the network, the operator's data, Credential Manager or the Portal. Checks:
  1. <root>/app/version.py declares exactly the expected version;
  2. every module the app runs imports (app/, airbnb_bridge/, and the backend modules the app and
     the capture/issue paths load), and every other .py file in the tree compiles — a syntax
     error or a missing dependency fails here, not on the operator's next capture. (Stand-alone
     command-line scripts are compiled, not imported: some read the operator's files at import.)
  3. every imported first-party module came from <root> — none silently fell back to the install
     folder's older copy (the install root is also on sys.path in the bundle);
  4. the parts the app needs are present: the local service with its /health route, the UI files,
     the Chrome extension's manifest with a version;
  5. the issue gate still fails closed: emit.confirm_real_emit refuses without the typed EMIT;
  6. the instance settings in the environment are valid (instance.validate()).
Prints one line per failure and "SELFCHECK OK" on success; exit 0 = pass, 1 = fail.

Standard library only at the top (this file may be run against a tree it does not belong to).
"""
from __future__ import annotations

import argparse
import importlib
import json
import os
import re
import sys
import traceback
from pathlib import Path

SKIP_DIRS = {"tests", "__pycache__", "apps_script_webapp", "config_templates", "guia", "fonts", "ui",
             "extensao"}
# Imported (executed): what the running app, capture and issue load. Everything else: compiled.
IMPORT_PACKAGES = ("app", "airbnb_bridge")
IMPORT_MODULES = ("emit", "emitter", "registry", "archival", "log_client", "override", "emit_receipt",
                  "profiles", "schema", "verify_settings", "business_days", "pdf_store", "login_cache",
                  "instance", "setup_taxpayer", "drive_uploader", "tools.live_capture")


def _under(path, root: Path) -> bool:
    try:
        Path(path).resolve().relative_to(root)
        return True
    except (ValueError, OSError, TypeError):
        return False


def module_names(root: Path) -> list[str]:
    """Dotted names of every .py module under root (packages included), tests excluded."""
    out = []
    for p in sorted(root.rglob("*.py")):
        rel = p.relative_to(root)
        if any(part in SKIP_DIRS for part in rel.parts[:-1]) or rel.name.startswith("."):
            continue
        if rel.parts and rel.parts[0] in ("tests",):
            continue
        parts = list(rel.with_suffix("").parts)
        if parts[-1] == "__init__":
            parts = parts[:-1]
        if not parts or not all(re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", x) for x in parts):
            continue
        if parts == ["app", "selfcheck"] or parts[-1] == "__main__":
            continue
        out.append(".".join(parts))
    return out


def to_import(names: list[str]) -> list[str]:
    return [n for n in names if n.split(".")[0] in IMPORT_PACKAGES or n in IMPORT_MODULES]


def run(root: Path, expect_version: str, install_root: Path | None) -> list[str]:
    failures: list[str] = []
    root = root.resolve()
    # Only the candidate tree may provide first-party code: drop this script's own folder (a plain
    # `python app/selfcheck.py` puts it first) and put the candidate first.
    here = str(Path(__file__).resolve().parent)
    sys.path[:] = [p for p in sys.path if os.path.normcase(os.path.abspath(p or ".")) != os.path.normcase(here)]
    sys.path.insert(0, str(root))
    sys.dont_write_bytecode = True    # the check leaves no __pycache__ behind in the candidate

    # 1. version
    try:
        text = (root / "app" / "version.py").read_text(encoding="utf-8")
        m = re.search(r'^__version__\s*=\s*["\']([^"\']+)["\']', text, re.MULTILINE)
        found = m.group(1) if m else None
    except OSError:
        found = None
    if found != expect_version:
        failures.append(f"version: app/version.py says {found!r}, expected {expect_version!r}")

    # 2. import what the app runs; compile everything else
    names = module_names(root)
    for name in to_import(names):
        try:
            importlib.import_module(name)
        except BaseException as e:  # noqa: BLE001 — SystemExit at import is a failure too
            last = traceback.format_exception_only(type(e), e)[-1].strip()
            failures.append(f"import {name}: {last[:300]}")
    for p in sorted(root.rglob("*.py")):
        rel = p.relative_to(root)
        if any(part in SKIP_DIRS for part in rel.parts[:-1]):
            continue
        try:
            compile(p.read_bytes(), str(p), "exec", dont_inherit=True)
        except (SyntaxError, ValueError) as e:
            failures.append(f"compile {rel.as_posix()}: {type(e).__name__}: {e}"[:300])

    # 3. no first-party module from outside the candidate
    tops = {n.split(".")[0] for n in names}
    inst = install_root.resolve() if install_root else None
    py_dir = (inst / "python") if inst else None
    for mname, mod in list(sys.modules.items()):
        f = getattr(mod, "__file__", None)
        if not f or mname == "__main__":     # __main__ = this (trusted) self-check script itself
            continue
        if mname.split(".")[0] in tops and not _under(f, root):
            failures.append(f"module {mname} was loaded from outside the update ({f})")
        elif inst and _under(f, inst) and not _under(f, root) and not (py_dir and _under(f, py_dir)):
            failures.append(f"module {mname} would come from the install folder, not the update ({f})")

    # 4. the parts the app needs
    if (root / "app" / "service.py").is_file():
        try:
            svc = importlib.import_module("app.service")
            paths = {getattr(r, "path", None) for r in getattr(svc.app, "routes", [])}
            if "/health" not in paths:
                failures.append("app.service has no /health route")
        except BaseException as e:  # noqa: BLE001
            failures.append(f"app.service: {type(e).__name__}: {e}"[:300])
        for ui in ("index.html", "app.js"):
            if not (root / "app" / "ui" / ui).is_file():
                failures.append(f"app/ui/{ui} is missing")
    if not (root / "app" / "main.py").is_file():
        failures.append("app/main.py is missing")
    ext = root / "airbnb_bridge" / "extensao"
    if (root / "airbnb_bridge").is_dir():
        try:
            if not json.loads((ext / "manifest.json").read_text(encoding="utf-8")).get("version"):
                failures.append("the Chrome extension manifest has no version")
        except (OSError, ValueError, AttributeError):
            failures.append("the Chrome extension manifest is missing or unreadable")

    # 5. the issue gate fails closed
    if (root / "emit.py").is_file():
        try:
            emit = importlib.import_module("emit")
            if emit.confirm_real_emit(1, no_confirm=False, input_fn=lambda _p: "") is not False:
                failures.append("emit.confirm_real_emit no longer refuses without EMIT")
        except BaseException as e:  # noqa: BLE001
            failures.append(f"emit gate: {type(e).__name__}: {e}"[:300])

    # 6. instance settings
    if (root / "instance.py").is_file():
        try:
            importlib.import_module("instance").validate()
        except BaseException as e:  # noqa: BLE001
            failures.append(f"instance settings: {e}"[:300])
    return failures


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Offline self-test of a code tree.")
    p.add_argument("--root", required=True, type=Path)
    p.add_argument("--expect-version", required=True)
    p.add_argument("--install-root", type=Path, default=None)
    args = p.parse_args(argv)
    try:
        failures = run(args.root, args.expect_version, args.install_root)
    except BaseException as e:  # noqa: BLE001
        failures = [f"self-check crashed: {type(e).__name__}: {e}"]
    for f in failures:
        print("SELFCHECK FAIL:", f, flush=True)
    if failures:
        return 1
    print("SELFCHECK OK", flush=True)
    return 0


if __name__ == "__main__":
    os._exit(main())   # os._exit: a module that left a thread running cannot hang the check
