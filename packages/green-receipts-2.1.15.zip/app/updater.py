"""app/updater.py — the app's self-update (docs/PLAN_AUTO_UPDATE.md Parts 2-4).

INERT unless GR_UPDATE_URL is set (config.bat): no thread, no network, no file written, and the
app behaves exactly as before. GR_UPDATE_CHANNEL picks the channel (default "stable").

Trust chain, in order (any failure stops there, changes nothing, and the app keeps running):
  1. fetch <url>/<channel>/manifest.json and .sig (10 s timeout, size caps);
  2. the EXACT manifest bytes must verify against an accepted Ed25519 key (app/update_pubkey.py;
     an empty list refuses everything). A bad signature is also reported to the LOG tab;
  3. the manifest must parse (known schema, this install's channel, sane fields);
  4. its version must be higher than the running one, not already failed here, and its
     requires_bundle must not exceed this install's BUNDLE_VERSION (else: installer path, Part 4);
  5. the package URL must be under the update URL; the download must have exactly the signed
     size and SHA-256;
  6. every zip entry must pass app/update_format.check_member_name (allowlisted top-level names,
     no '..', absolute paths, drive letters, backslashes, symlinks, config.bat, python/, ...),
     within size and count caps; it is unpacked into versions/<v>.staging;
  7. the unpacked tree must declare the same version and pass app/selfcheck.py in a subprocess
     (the RUNNING version's self-check, plus the candidate's own if it has one);
  8. only then: rename to versions/<v> and set "pending". bootstrap.py makes it active at the
     NEXT start (never while the app is running), and rolls back if it fails to start.

All paths are relative to the install root of the RUNNING instance (each named instance has its
own install folder). The operator's config, registry, Credential Manager and seen-files live
outside the install folder and are never touched; config.bat, python/ and bootstrap.py are
refused by the unpacker.
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse
import urllib.request
from pathlib import Path

try:  # works both as app.updater and when app/ itself is on sys.path (the backend tests)
    from app import update_format as UF
except ImportError:  # pragma: no cover
    import update_format as UF  # type: ignore[no-redef]

UPDATE_URL_ENV = "GR_UPDATE_URL"
CHANNEL_ENV = "GR_UPDATE_CHANNEL"
DEFAULT_CHANNEL = "stable"
CHECK_INTERVAL_SEC = 6 * 3600
FETCH_TIMEOUT_SEC = 10.0
SELFCHECK_TIMEOUT_SEC = 180.0
READY_NOTICE_AFTER_SEC = 24 * 3600
BACKGROUND_DELAY_SEC = 20.0          # let the app's logging (LOG tab) come up first
EXIT_DELAY_SEC = 1.5

_LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1"}


class FetchError(RuntimeError):
    """Offline, timeout, HTTP error — transient; logged and ignored."""


class TooLargeError(FetchError):
    """The file is bigger than allowed (for a signed artifact: bigger than its signed size)."""


# ---------------------------------------------------------------- paths
def default_code_root() -> Path:
    return Path(__file__).resolve().parent.parent


def install_root_for(code_root: Path) -> Path:
    """<install>\\versions\\<v> -> <install>; anything else is itself the install root."""
    code_root = Path(code_root).resolve()
    parent = code_root.parent
    if parent.name.lower() == "versions" and (parent.parent / "bootstrap.py").is_file():
        return parent.parent
    return code_root


def read_bundle_version(install_root: Path) -> int:
    """<install>\\BUNDLE_VERSION as an int; missing or unreadable = 0 (the strictest answer)."""
    try:
        txt = (Path(install_root) / "BUNDLE_VERSION").read_text(encoding="ascii").strip()
        return int(txt) if txt.isdigit() else 0
    except (OSError, ValueError, UnicodeDecodeError):
        return 0


def validate_base_url(url: str) -> str:
    """https://host/path/ (or http on 127.0.0.1/localhost for local tests). Returns the URL with
    a trailing slash, or raises ValueError. No credentials, query or fragment."""
    u = urllib.parse.urlsplit(str(url or "").strip())
    if u.scheme not in ("https", "http") or not u.hostname:
        raise ValueError("GR_UPDATE_URL must be an https:// address")
    if u.scheme == "http" and u.hostname not in _LOOPBACK_HOSTS:
        raise ValueError("GR_UPDATE_URL must use https:// (plain http only on this computer)")
    if u.username or u.password or u.query or u.fragment:
        raise ValueError("GR_UPDATE_URL must not carry a login, query or fragment")
    path = u.path if u.path.endswith("/") else u.path + "/"
    return urllib.parse.urlunsplit((u.scheme, u.netloc, path, "", ""))


def _host_of(url: str) -> str:
    try:
        return urllib.parse.urlsplit(url).hostname or "?"
    except ValueError:
        return "?"


# ---------------------------------------------------------------- small file helpers
def _read_json(path: Path, max_bytes: int = 256 * 1024):
    try:
        p = Path(path)
        if p.stat().st_size > max_bytes:
            return None
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError, UnicodeDecodeError):
        return None


def _write_json_atomic(path: Path, obj) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(obj, indent=1, sort_keys=True), encoding="utf-8")
    for attempt in range(5):         # Windows: a reader holding the file can block a replace
        try:
            os.replace(tmp, path)
            return
        except PermissionError:
            if attempt == 4:
                raise
            time.sleep(0.1)


def _rmtree(path: Path) -> None:
    shutil.rmtree(path, ignore_errors=True)
    try:
        if Path(path).is_file():
            Path(path).unlink()
    except OSError:
        pass


def normalize_state(raw) -> dict:
    """current.json, cleaned: only valid version strings survive."""
    s = raw if isinstance(raw, dict) else {}

    def v(x):
        return x if isinstance(x, str) and UF.is_version(x) else None
    failed = s.get("failed") if isinstance(s.get("failed"), list) else []
    att = s.get("attempts") if isinstance(s.get("attempts"), dict) else {}
    return {"schema": 1, "active": v(s.get("active")), "previous": v(s.get("previous")),
            "pending": v(s.get("pending")),
            "failed": sorted({f for f in failed if isinstance(f, str) and UF.is_version(f)},
                             key=UF.parse_version),
            # failed starts per version, counted by bootstrap.py (2 = given up); cleared on a clean start
            "attempts": {k: n for k, n in att.items() if UF.is_version(k) and isinstance(n, int)
                         and not isinstance(n, bool) and 0 <= n <= 99}}


# ---------------------------------------------------------------- network (stdlib only)
def url_allowed(url: str) -> bool:
    """https anywhere; plain http only to this computer (127.0.0.1 / localhost — the tests)."""
    try:
        u = urllib.parse.urlsplit(url)
    except ValueError:
        return False
    return u.scheme == "https" or (u.scheme == "http" and (u.hostname or "") in _LOOPBACK_HOSTS)


class _SafeRedirects(urllib.request.HTTPRedirectHandler):
    """Follow a redirect only to https (or http on this computer) and at most a few hops, so a
    redirect can never downgrade to plain http or reach file:// / ftp://. Everything fetched is
    still signature/hash-checked afterwards; this only keeps the transport honest."""
    max_redirections = 5

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not url_allowed(newurl):
            raise FetchError(f"refused a redirect to a non-https address ({_host_of(newurl)})")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


_OPENER = urllib.request.build_opener(_SafeRedirects)


def http_fetch(url: str, max_bytes: int, *, dest: Path | None = None,
               timeout: float = FETCH_TIMEOUT_SEC):
    """GET url. Returns bytes, or writes to `dest` and returns None. Enforces max_bytes while
    reading (a lying Content-Length cannot exceed it). Raises FetchError."""
    if not url_allowed(url):
        raise FetchError("not an https address")
    req = urllib.request.Request(url, headers={"User-Agent": "GreenReceipts-Updater/1",
                                               "Cache-Control": "no-cache"})
    try:
        with _OPENER.open(req, timeout=timeout) as r:  # noqa: S310 — scheme checked, redirects guarded
            if getattr(r, "status", 200) != 200:
                raise FetchError(f"HTTP {r.status}")
            cl = r.headers.get("Content-Length")
            if cl and cl.isdigit() and int(cl) > max_bytes:
                raise TooLargeError("file is larger than allowed")
            out = open(dest, "wb") if dest else None
            buf, total = [], 0
            try:
                while True:
                    chunk = r.read(256 * 1024)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > max_bytes:
                        raise TooLargeError("file is larger than allowed")
                    if out:
                        out.write(chunk)
                    else:
                        buf.append(chunk)
            finally:
                if out:
                    out.close()
            return None if dest else b"".join(buf)
    except FetchError:
        raise
    except Exception as e:  # noqa: BLE001 — offline / DNS / timeout / HTTP 404 / TLS
        raise FetchError(f"{type(e).__name__}: {str(e)[:120]}") from None


# ---------------------------------------------------------------- Part 4: the installer
def launch_installer(installer: Path, install_root: Path, app_pid: int) -> None:
    """Run the downloaded, verified installer AFTER this app has exited, then reopen the app.

    The ONLY place the app starts an installer. Tests replace it with a fake. It writes a small
    helper script to a temp folder and starts it detached: the helper waits for this app's process
    to end (the installer must replace python\\ files this app has open), runs the installer
    per-user and silently into THIS instance's install folder, then starts GreenReceiptsApp.bat."""
    installer, install_root = Path(installer), Path(install_root)
    helper_dir = Path(tempfile.mkdtemp(prefix="gr_update_"))
    helper = helper_dir / "run_update.cmd"
    log = helper_dir / "installer.log"
    lines = [
        "@echo off",
        ":wait",
        f'tasklist /FI "PID eq {int(app_pid)}" 2>NUL | find "{int(app_pid)}" >NUL',
        "if not errorlevel 1 (timeout /t 1 /nobreak >NUL & goto wait)",
        f'"{installer}" /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /CURRENTUSER '
        f'"/DIR={install_root}" "/LOG={log}"',
        f'cd /D "{install_root}"',
        'start "" "GreenReceiptsApp.bat"',
    ]
    helper.write_text("\r\n".join(lines) + "\r\n", encoding="ascii")
    flags = 0
    if sys.platform == "win32":
        flags = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS | subprocess.CREATE_NO_WINDOW
    subprocess.Popen(["cmd.exe", "/c", str(helper)], cwd=str(helper_dir), creationflags=flags,
                     close_fds=True)


def _default_exit() -> None:
    try:
        sys.stdout.flush()
        sys.stderr.flush()
    except Exception:  # noqa: BLE001
        pass
    os._exit(0)


# ---------------------------------------------------------------- Part 3: the extension folder
def _copy_tree_files(src: Path, dest: Path) -> None:
    """Per-file fallback: every file replaced atomically, manifest.json LAST, so Chrome can never
    read a new manifest next to old files (or a half-written manifest)."""
    files = sorted((p for p in src.rglob("*") if p.is_file() and "__pycache__" not in p.parts),
                   key=lambda p: (p.name == "manifest.json" and p.parent == src, str(p)))
    for p in files:
        target = dest / p.relative_to(src)
        target.parent.mkdir(parents=True, exist_ok=True)
        tmp = target.with_name(f".{target.name}.{os.getpid()}.tmp")
        shutil.copyfile(p, tmp)
        os.replace(tmp, target)


def sync_extension(src: Path, dest: Path) -> str:
    """Make `dest` (the folder Chrome loaded) hold the extension in `src` when their manifest
    versions differ. Copy to a temporary sibling, check it, then swap folders; if Windows refuses
    the swap, replace file by file with the manifest last. Returns 'same' / 'copied' / 'no_source'
    / 'failed'."""
    src, dest = Path(src), Path(dest)
    sv = UF.read_extension_version(src)
    if not sv:
        return "no_source"
    if sv == UF.read_extension_version(dest):
        return "same"
    tag = f"{os.getpid()}-{int(time.time() * 1000)}"
    tmp = dest.parent / f".{dest.name}.new-{tag}"
    old = dest.parent / f".{dest.name}.old-{tag}"
    try:
        shutil.copytree(src, tmp, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        if UF.read_extension_version(tmp) != sv:
            raise OSError("copied extension does not read back")
        try:
            if dest.exists():
                os.replace(dest, old)
            os.replace(tmp, dest)
        except OSError:
            if not dest.exists() and old.exists():
                os.replace(old, dest)          # put the original back first
            _copy_tree_files(tmp, dest)
    except OSError:
        pass
    finally:
        _rmtree(tmp)
        _rmtree(old)
    return "copied" if UF.read_extension_version(dest) == sv else "failed"


# ---------------------------------------------------------------- the updater
class Updater:
    def __init__(self, *, install_root=None, code_root=None, running_version=None,
                 base_url=None, channel=None, accepted_keys=None, fetch=None, python_exe=None,
                 now=time.time, log=None, serializer_contract=None, instance_name=None,
                 installer_launcher=None, exit_fn=None, check_interval=CHECK_INTERVAL_SEC,
                 fetch_timeout=FETCH_TIMEOUT_SEC, from_env=False):
        self.code_root = Path(code_root).resolve() if code_root else default_code_root()
        self.install_root = Path(install_root).resolve() if install_root else install_root_for(self.code_root)
        self.running_version = running_version or UF.read_tree_version(self.code_root) or "0.0.0"
        self.problem = ""
        if from_env:
            base_url = (os.environ.get(UPDATE_URL_ENV) or "").strip() or None
            channel = (os.environ.get(CHANNEL_ENV) or "").strip().lower() or None
        self.channel = channel or DEFAULT_CHANNEL
        self.base_url = None
        if base_url:
            try:
                self.base_url = validate_base_url(base_url)
                if not UF.CHANNEL_RE.match(self.channel):
                    raise ValueError("GR_UPDATE_CHANNEL is not a valid channel name")
            except ValueError as e:      # misconfigured -> OFF (fail closed), said once in the log
                self.base_url, self.problem = None, str(e)
        if accepted_keys is None:
            try:
                from app import update_pubkey
            except ImportError:  # pragma: no cover
                import update_pubkey  # type: ignore[no-redef]
            accepted_keys = list(update_pubkey.ACCEPTED_KEYS)
        self.accepted_keys = list(accepted_keys)
        self.fetch_timeout = fetch_timeout
        self._fetch = fetch or (lambda url, max_bytes, dest=None: http_fetch(
            url, max_bytes, dest=dest, timeout=self.fetch_timeout))
        self.python_exe = python_exe or self._default_python()
        self.now = now
        self._log = log
        self._serializer_contract = serializer_contract or (lambda: None)
        self.instance_name = instance_name
        self._launch = installer_launcher or launch_installer
        self._exit = exit_fn or _default_exit
        self.check_interval = check_interval
        self.started_at = now()
        self._lock = threading.Lock()          # one check at a time
        self._state_lock = threading.Lock()    # current.json read-modify-write
        self._thread = None
        self.status_state = "off" if not self.base_url else "idle"
        self.status_detail = ""
        self.blocked_by: str | None = None     # the manifest version that blocks us
        self.installer: dict | None = None     # Part 4 offer
        self.event: dict | None = None         # what bootstrap did at this start
        self._queued_logs: list = []
        if self.base_url:
            cached = self._load_cached_manifest()
            if cached:
                self._apply_blocked(cached)

    # -------------------------------------------------- basics
    @property
    def enabled(self) -> bool:
        return bool(self.base_url)

    @property
    def versions_dir(self) -> Path:
        return self.install_root / "versions"

    @property
    def running_from_versions(self) -> bool:
        return self.code_root != self.install_root

    def _default_python(self) -> str:
        for name in ("python.exe", "python"):
            p = self.install_root / "python" / name
            if p.is_file():
                return str(p)
        return sys.executable

    def manifest_url(self) -> str:
        return urllib.parse.urljoin(self.base_url, f"{self.channel}/manifest.json")

    def log(self, level: int, summary: str, detail: str = "", result: str = "") -> None:
        """app.log always (stdout is redirected there); the sheet's LOG tab via log_client."""
        print(f"[update] {summary}" + (f" | {detail}" if detail else ""), flush=True)
        if self._log is not None:
            try:
                self._log(level, summary, detail, result)
            except Exception:  # noqa: BLE001
                pass
            return
        try:
            import log_client
            log_client.log_event(logging.getLogger("grv2"), level, summary, op="update",
                                 result=result, detail=detail)
        except Exception:  # noqa: BLE001 — logging must never break the app
            pass

    # -------------------------------------------------- current.json
    def read_state(self) -> dict:
        return normalize_state(_read_json(self.versions_dir / "current.json"))

    def _update_state(self, fn) -> dict:
        with self._state_lock:
            s = self.read_state()          # re-read: bootstrap of a second launch may have written
            fn(s)
            _write_json_atomic(self.versions_dir / "current.json", normalize_state(s))
            return s

    def _version_dir_ok(self, v: str) -> bool:
        d = self.versions_dir / v
        return d.is_dir() and UF.read_tree_version(d) == v and (d / "app" / "main.py").is_file()

    def _mark_failed(self, v: str, reason: str) -> None:
        def f(s):
            if v not in s["failed"]:
                s["failed"].append(v)
            if s["pending"] == v:
                s["pending"] = None
        self._update_state(f)
        self.log(logging.WARNING, f"update {v} rejected and will not be tried again", reason[:400],
                 "rejected")

    # -------------------------------------------------- the check
    def check(self, *, force: bool = False) -> dict:
        """One check (see the module docstring). Never raises; returns {"state", ...}."""
        if not self.enabled:
            return {"state": "off", "detail": self.problem}
        if not self._lock.acquire(blocking=False):
            return {"state": "checking"}
        try:
            return self._check(force)
        except Exception as e:  # noqa: BLE001 — the app always keeps running
            self.log(logging.WARNING, "update check failed unexpectedly", f"{type(e).__name__}: {e}")
            return self._set("error", f"{type(e).__name__}")
        finally:
            self._lock.release()

    def _set(self, state: str, detail: str = "", **extra) -> dict:
        self.status_state, self.status_detail = state, detail
        return {"state": state, "detail": detail, **extra}

    def _check(self, force: bool) -> dict:
        info = _read_json(self.versions_dir / "check.json") or {}
        last = info.get("at") if isinstance(info.get("at"), (int, float)) else 0
        if not force and 0 <= self.now() - last < self.check_interval:
            return {"state": "recent", "detail": ""}
        try:
            _write_json_atomic(self.versions_dir / "check.json", {"at": self.now()})
        except OSError as e:
            return self._set("error", f"cannot write the versions folder ({e.strerror})")
        url = self.manifest_url()
        try:
            mbytes = self._fetch(url, UF.MAX_MANIFEST_BYTES)
            sbytes = self._fetch(url + ".sig", UF.MAX_SIGNATURE_BYTES)
        except FetchError as e:
            self.log(logging.INFO, "update check: no answer from the update host",
                     f"host={_host_of(url)} {e}", "offline")
            return self._set("offline", str(e))
        try:
            UF.verify_signature(mbytes, sbytes, self.accepted_keys)
        except UF.SignatureUnavailable as e:
            self.log(logging.ERROR, "UPDATES DISABLED: the 'cryptography' package is missing from this "
                     "install, so no update can be verified (every update is refused). Reinstall the app.",
                     str(e), "crypto_missing")
            return self._set("crypto_missing", str(e))
        except UF.UpdateFormatError as e:
            self.log(logging.WARNING, "update manifest REJECTED: signature check failed",
                     f"host={_host_of(url)} channel={self.channel} {e}", "bad_signature")
            return self._set("bad_signature", str(e))
        try:
            m = UF.parse_manifest(mbytes)
        except UF.UpdateFormatError as e:
            self.log(logging.WARNING, "update manifest rejected", str(e), "bad_manifest")
            return self._set("bad_manifest", str(e))
        if m["channel"] != self.channel:
            self.log(logging.WARNING, "update manifest rejected: wrong channel",
                     f"manifest={m['channel']} install={self.channel}", "wrong_channel")
            return self._set("wrong_channel", m["channel"])
        cached = self._load_cached_manifest()
        if cached and UF.version_gt(cached["version"], m["version"]):
            # A stale copy (e.g. a CDN cache still serving an older release): ignored entirely, so
            # it can neither re-impose an old block list nor change anything; the next check retries.
            self.log(logging.INFO, "update check: the host answered with an older manifest than the one "
                     "already seen; ignored", f"got={m['version']} seen={cached['version']}", "stale_manifest")
            return self._set("stale_manifest", m["version"])
        self._remember_manifest(mbytes, sbytes, m)
        self._apply_blocked(m)
        return self._consider(m)

    def _consider(self, m: dict) -> dict:
        v = m["version"]
        if not UF.version_gt(v, self.running_version):
            return self._set("up_to_date", v)
        st = self.read_state()
        if v in st["failed"]:
            return self._set("skipped_failed", v)
        if st["pending"] == v and self._version_dir_ok(v):
            return self._set("ready", v)
        bundle = read_bundle_version(self.install_root)
        if m["requires_bundle"] > bundle:
            return self._consider_installer(m, bundle)
        need = m.get("min_serializer_contract")
        if need is not None:
            try:
                have = self._serializer_contract()
            except Exception:  # noqa: BLE001
                have = None
            if have is None:
                # The serializer does not report a contract number yet: unknown = do not block.
                self.log(logging.INFO, "update: serializer contract unknown, not blocking",
                         f"needs={need}", "contract_unknown")
            elif have < need:
                return self._set("waiting_serializer", f"needs {need}, has {have}")
        return self.stage(m)

    def _artifact_url(self, rel: str) -> str:
        full = urllib.parse.urljoin(self.manifest_url(), rel)
        if not full.startswith(self.base_url):
            raise UF.UpdateFormatError("the manifest points outside the update address")
        return full

    def _download_verified(self, rel_url: str, dest: Path, size: int, sha: str, cap: int) -> None:
        """Download to `dest`; exact signed size and SHA-256 or UpdateFormatError (file removed)."""
        url = self._artifact_url(rel_url)
        try:
            try:
                self._fetch(url, min(size, cap), dest=dest)
            except TooLargeError:
                raise UF.UpdateFormatError(f"download is larger than its signed size ({size})") from None
            got = dest.stat().st_size
            if got != size:
                raise UF.UpdateFormatError(f"download has the wrong size ({got}, signed {size})")
            if UF.sha256_file(dest) != sha:
                raise UF.UpdateFormatError("download does not match the signed SHA-256")
        except BaseException:
            _rmtree(dest)
            raise

    def stage(self, m: dict) -> dict:
        """Download, verify, unpack, self-check; on success versions/<v> + pending=v."""
        v = m["version"]
        vd = self.versions_dir
        staging, dl = vd / f"{v}.staging", vd / f"{v}.download"
        _rmtree(staging)
        _rmtree(dl)
        try:
            vd.mkdir(parents=True, exist_ok=True)
            pkg = m["package"]
            self._download_verified(pkg["url"], dl, pkg["size"], pkg["sha256"], UF.MAX_PACKAGE_BYTES)
        except FetchError as e:
            self.log(logging.INFO, f"update {v}: download failed (will retry later)", str(e), "offline")
            return self._set("download_failed", str(e))
        except UF.UpdateFormatError as e:
            # Not the signed file (corrupted / tampered / stale cache): refused, NOT marked failed —
            # the signed package itself may be fine on a later try.
            self.log(logging.WARNING, f"update {v}: package rejected", str(e), "bad_package")
            return self._set("bad_package", str(e))
        try:
            UF.safe_extract(dl, staging)
            tree_v = UF.read_tree_version(staging)
            if tree_v != v:
                raise UF.UpdateFormatError(f"package declares version {tree_v!r}, manifest says {v}")
        except (UF.UpdateFormatError, OSError) as e:
            _rmtree(staging)
            _rmtree(dl)
            self._mark_failed(v, f"package refused: {e}")     # the SIGNED package is unusable
            return self._set("rejected_package", str(e))
        finally:
            _rmtree(dl)
        ok, out = self._run_selfcheck(staging, v)
        if not ok:
            _rmtree(staging)
            self._mark_failed(v, f"self-check failed: {out}")
            return self._set("rejected_selfcheck", out)
        target = vd / v
        try:
            _rmtree(target)
            os.replace(staging, target)
            _write_json_atomic(target / ".update_manifest.json",
                               {"version": v, "notes": m.get("notes", ""), "released": m.get("released", ""),
                                "extension_version": m.get("extension_version")})
        except OSError as e:
            _rmtree(staging)
            return self._set("error", f"could not finish staging ({e.strerror})")

        def f(s):
            s["pending"] = v
        self._update_state(f)
        self.log(logging.INFO, f"update {v} downloaded and checked; it applies at the next start",
                 f"from {self.running_version}", "staged")
        return self._set("staged", v)

    def _selfcheck_env(self) -> dict:
        env = {k: v for k, v in os.environ.items()
               if k not in ("PYTHONPATH", "PYTHONHOME", "GRV2_TOKEN", "GRV2_EXEC",
                            "GRV2_TELEMETRY_SECRET", "GRV2_TELEMETRY_URL", UPDATE_URL_ENV)}
        env["PYTHONNOUSERSITE"] = "1"
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        return env

    def _run_selfcheck(self, tree: Path, v: str) -> tuple[bool, str]:
        scripts = [self.code_root / "app" / "selfcheck.py"]     # the TRUSTED (running) one first
        own = tree / "app" / "selfcheck.py"
        if own.is_file():
            scripts.append(own)
        if not scripts[0].is_file():
            return False, "the running version has no self-check"
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform == "win32" else 0
        for script in scripts:
            cmd = [self.python_exe, str(script), "--root", str(tree), "--expect-version", v,
                   "--install-root", str(self.install_root)]
            try:
                r = subprocess.run(cmd, cwd=str(tree), env=self._selfcheck_env(), capture_output=True,
                                   text=True, encoding="utf-8", errors="replace",
                                   timeout=SELFCHECK_TIMEOUT_SEC, creationflags=flags)
            except subprocess.TimeoutExpired:
                return False, "self-check timed out"
            except OSError as e:
                return False, f"self-check could not run ({e.strerror})"
            out = (r.stdout + r.stderr).strip()
            if r.returncode != 0 or "SELFCHECK OK" not in r.stdout:
                return False, " | ".join(out.splitlines()[-8:])[:800]
        return True, ""

    # -------------------------------------------------- Part 4
    def _consider_installer(self, m: dict, bundle: int) -> dict:
        v = m["version"]
        key = self.instance_name if self.instance_name is not None else self._instance_name()
        entry = m["installers"].get(key or "default")
        if entry is None:
            self.installer = {"version": v, "manual": True}
            return self._set("installer_manual", v)
        path = self.versions_dir / "installers" / f"GreenReceiptsSetup-{v}-{key or 'default'}.exe"
        try:
            if not (path.is_file() and path.stat().st_size == entry["size"]
                    and UF.sha256_file(path) == entry["sha256"]):
                path.parent.mkdir(parents=True, exist_ok=True)
                self._download_verified(entry["url"], path, entry["size"], entry["sha256"],
                                        UF.MAX_INSTALLER_BYTES)
        except FetchError as e:
            return self._set("download_failed", str(e))
        except UF.UpdateFormatError as e:
            self.log(logging.WARNING, f"update {v}: installer rejected", str(e), "bad_installer")
            return self._set("bad_installer", str(e))
        self.installer = {"version": v, "manual": False, "path": str(path), "size": entry["size"],
                          "sha256": entry["sha256"], "requires_bundle": m["requires_bundle"],
                          "notes": m.get("notes", "")}
        self.log(logging.INFO, f"update {v} needs a short install; waiting for the operator",
                 f"bundle {bundle} -> {m['requires_bundle']}", "installer_ready")
        return self._set("installer_ready", v)

    @staticmethod
    def _instance_name() -> str:
        try:
            import instance
            return instance.name()
        except Exception:  # noqa: BLE001
            return ""

    def install_now(self, *, confirmed: bool, acquire_idle) -> dict:
        """The operator clicked Install. `acquire_idle()` must return a release function when no
        capture or issue is running (it holds their locks so none can start), or None when busy.
        Re-verifies the installer file just before running it."""
        if not confirmed:
            return {"ok": False, "error": "not_confirmed"}
        inst = self.installer
        if not self.enabled or not inst or inst.get("manual") or not inst.get("path"):
            return {"ok": False, "error": "no_installer"}
        if inst["requires_bundle"] <= read_bundle_version(self.install_root):
            return {"ok": False, "error": "not_needed"}
        release = acquire_idle()
        if release is None:
            return {"ok": False, "error": "busy",
                    "detail": "A capture or an issue is running. Wait until it finishes, then click Install."}
        # Run a COPY outside the install folder (the installer replaces {app}\versions, where the
        # download lives), verified again right before it is started.
        path = Path(inst["path"])
        run_dir = Path(tempfile.mkdtemp(prefix="gr_installer_"))
        copy = run_dir / path.name
        try:
            shutil.copyfile(path, copy)
            good = copy.stat().st_size == inst["size"] and UF.sha256_file(copy) == inst["sha256"]
        except OSError:
            good = False
        if not good:
            release()
            self.installer = None
            _rmtree(path)
            _rmtree(run_dir)
            return {"ok": False, "error": "installer_changed",
                    "detail": "The downloaded install file changed on disk, so it was deleted. Nothing was installed."}
        try:
            self._launch(copy, self.install_root, os.getpid())
        except Exception as e:  # noqa: BLE001
            _rmtree(run_dir)
            release()
            self.log(logging.WARNING, "the installer could not be started", f"{type(e).__name__}: {e}")
            return {"ok": False, "error": "launch_failed", "detail": "The install could not start. Nothing was changed."}
        self.log(logging.INFO, f"installing update {inst['version']}; the app closes and reopens",
                 "", "installing")
        threading.Timer(EXIT_DELAY_SEC, self._exit).start()
        return {"ok": True, "version": inst["version"]}

    # -------------------------------------------------- kill switch
    def _cache_paths(self):
        return self.versions_dir / "manifest.json", self.versions_dir / "manifest.json.sig"

    def _remember_manifest(self, mbytes: bytes, sbytes: bytes, m: dict) -> None:
        old = self._load_cached_manifest()
        if old and UF.version_gt(old["version"], m["version"]):
            return     # never let a replayed older manifest overwrite a newer one
        mp, sp = self._cache_paths()
        try:
            mp.parent.mkdir(parents=True, exist_ok=True)
            sp.write_bytes(sbytes)
            mp.write_bytes(mbytes)
        except OSError:
            pass

    def _load_cached_manifest(self) -> dict | None:
        mp, sp = self._cache_paths()
        try:
            mbytes, sbytes = mp.read_bytes(), sp.read_bytes()
            UF.verify_signature(mbytes, sbytes, self.accepted_keys)   # re-verified at every start
            m = UF.parse_manifest(mbytes)
        except (OSError, UF.UpdateFormatError):
            return None
        return m if m["channel"] == self.channel else None

    def _apply_blocked(self, m: dict) -> None:
        if self.running_version in m.get("blocked_versions", []):
            if self.blocked_by is None:
                self.log(logging.ERROR, f"this version ({self.running_version}) has been withdrawn; "
                         "capture and issue are switched off until the app updates", "", "blocked")
            self.blocked_by = m["version"]
        elif self.blocked_by is not None and not UF.version_gt(self.blocked_by, m["version"]):
            self.blocked_by = None

    def blocked_message(self) -> str | None:
        if not self.enabled or self.blocked_by is None:
            return None
        ready = self.read_state().get("pending")
        tail = (" An update is ready: close and reopen the app to apply it." if ready else
                " Close and reopen the app to pick up the fix. If this message stays, contact Laurent.")
        return (f"Laurent has withdrawn this version of Green Receipts ({self.running_version}). "
                "Capture and Issue are switched off until the app has updated." + tail)

    # -------------------------------------------------- start-up / housekeeping
    def on_startup(self) -> None:
        """Local housekeeping before the app serves anything (no network). Does nothing at all on
        an install that has never staged an update and is not running one."""
        if not self.versions_dir.is_dir() and not self.running_from_versions:
            return
        ev_path = self.versions_dir / "last_event.json"
        ev = _read_json(ev_path)
        if isinstance(ev, dict) and ev.get("kind") in ("activated", "rolled_back"):
            self.event = ev
            try:
                os.replace(ev_path, ev_path.with_name("last_event.seen.json"))
            except OSError:
                pass
            if ev["kind"] == "rolled_back":
                back = ev.get("to") or "the installed version"
                if ev.get("permanent", True):
                    self._queued_logs.append((logging.WARNING,
                        f"update {ev.get('failed')} failed to start a second time; went back to {back} "
                        "and will not try it again", "bootstrap found the start marker of a run that never "
                        "came up", "rolled_back_final"))
                else:
                    self._queued_logs.append((logging.WARNING,
                        f"update {ev.get('failed')} failed to start; went back to {back} for now and will "
                        "try it once more at the next start", "bootstrap found the start marker of a run "
                        "that never came up", "rolled_back_retry"))
            else:
                notes = (_read_json(self.versions_dir / str(ev.get("version")) / ".update_manifest.json") or {})
                self.event["notes"] = str(notes.get("notes") or "")[:UF.MAX_NOTES_CHARS]
                self._queued_logs.append((logging.INFO, f"updated to {ev.get('version')}",
                                          f"from {ev.get('from') or 'the installed version'}", "activated"))
        ext_dest = self.install_root / "airbnb_bridge" / "extensao"
        backup = self.versions_dir / "root_extensao"
        try:
            if self.running_from_versions:
                if not backup.exists() and ext_dest.is_dir() and \
                        UF.read_extension_version(ext_dest) != UF.read_extension_version(
                            self.code_root / "airbnb_bridge" / "extensao"):
                    # Keep the installed version's own extension so a rollback to it can put it back.
                    shutil.copytree(ext_dest, backup, ignore=shutil.ignore_patterns("__pycache__"))
                    (backup / ".root_version").write_text(
                        UF.read_tree_version(self.install_root) or "", encoding="ascii")
                res = sync_extension(self.code_root / "airbnb_bridge" / "extensao", ext_dest)
            elif backup.is_dir():
                marker = (backup / ".root_version").read_text(encoding="ascii").strip() \
                    if (backup / ".root_version").is_file() else ""
                if marker and marker == self.running_version:
                    res = sync_extension(backup, ext_dest)
                else:
                    res = "stale_backup"
                    _rmtree(backup)            # an installer replaced the installed version
            else:
                res = "same"
            if res == "failed":
                self._queued_logs.append((logging.WARNING, "could not update the Chrome extension folder",
                                          str(ext_dest), "extension_copy_failed"))
            elif res == "copied":
                self._queued_logs.append((logging.INFO, "Chrome extension folder updated",
                                          UF.read_extension_version(ext_dest) or "", "extension_copied"))
        except OSError as e:
            self._queued_logs.append((logging.WARNING, "could not update the Chrome extension folder",
                                      f"{e}", "extension_copy_failed"))
        if not self.running_from_versions:
            st = self.read_state()
            if st["active"] and not UF.version_gt(st["active"], self.running_version):
                # A normal installer put a same-or-newer version in the install folder itself.
                def f(s):
                    s["active"], s["previous"] = None, None
                    if s["pending"] and not UF.version_gt(s["pending"], self.running_version):
                        s["pending"] = None
                try:
                    self._update_state(f)
                except OSError:
                    pass

    def mark_started(self) -> None:
        """Called once the local service answered /health: this version started fine. Removes
        bootstrap's start marker (so no rollback) and prunes old versions."""
        sp = self.versions_dir / "starting.json"
        s = _read_json(sp)
        if isinstance(s, dict) and s.get("version") == self.running_version:
            try:
                sp.unlink()
            except OSError:
                pass
        if self.running_from_versions and self.read_state()["attempts"].get(self.running_version):
            def clear(st):              # a clean start: an earlier failed attempt no longer counts
                st["attempts"].pop(self.running_version, None)
            try:
                self._update_state(clear)
            except OSError:
                pass
        if self.versions_dir.is_dir():
            self.prune()

    def prune(self) -> None:
        """Keep the active, previous and pending versions (and the running one); delete the rest,
        plus leftover staging / download folders and unused installers."""
        st = self.read_state()
        keep = {st["active"], st["previous"], st["pending"],
                self.running_version if self.running_from_versions else None} - {None}
        try:
            entries = list(self.versions_dir.iterdir())
        except OSError:
            return
        for p in entries:
            name = p.name
            if p.is_dir() and UF.is_version(name) and name not in keep:
                _rmtree(p)
            elif name.endswith((".staging", ".download")) and not self._lock.locked():
                _rmtree(p)
        inst_dir = self.versions_dir / "installers"
        if inst_dir.is_dir():
            current = (self.installer or {}).get("path")
            for p in inst_dir.iterdir():
                if str(p) != current:
                    _rmtree(p)

    def flush_logs(self) -> None:
        q, self._queued_logs = self._queued_logs, []
        for level, summary, detail, result in q:
            self.log(level, summary, detail, result)

    def start_background(self, *, delay: float = BACKGROUND_DELAY_SEC) -> None:
        """Start-up check in a daemon thread, then re-check every few hours while the app stays
        open (each check is rate-limited to once per CHECK_INTERVAL_SEC). Inert when off."""
        if self._thread is not None or (not self.enabled and not self._queued_logs):
            return

        def loop():
            time.sleep(max(0.0, delay))
            self.flush_logs()
            while self.enabled:
                self.check()
                time.sleep(min(self.check_interval, 3600.0))
        self._thread = threading.Thread(target=loop, name="gr-updater", daemon=True)
        self._thread.start()

    # -------------------------------------------------- what the UI shows
    def status(self) -> dict:
        if not self.enabled and not self.event:
            return {"enabled": False, "version": self.running_version, "lines": []}
        lines = []
        blocked = self.blocked_message()
        if blocked:
            lines.append({"kind": "red", "text": blocked})
        ev = self.event or {}
        if ev.get("kind") == "activated":
            notes = ev.get("notes") or ""
            lines.append({"kind": "info", "text": f"Updated to {ev.get('version')}." + (f" {notes}" if notes else "")})
        elif ev.get("kind") == "rolled_back" and ev.get("permanent", True):
            lines.append({"kind": "warn", "text": f"The update to {ev.get('failed')} didn't start properly, so the app "
                          "went back to the version you had before and won't try it again. Nothing else "
                          "was changed."})
        elif ev.get("kind") == "rolled_back":
            lines.append({"kind": "warn", "text": f"The update to {ev.get('failed')} didn't start properly, so the app "
                          "went back to the version you had before. It will try the update once more the "
                          "next time you open the app. Nothing else was changed."})
        st = self.read_state() if self.enabled else {"pending": None}
        if st["pending"] and not blocked and self.now() - self.started_at > READY_NOTICE_AFTER_SEC:
            lines.append({"kind": "info", "text": "An update is ready. Close and reopen the app to apply it."})
        inst = self.installer if self.enabled else None
        can_install = False
        if inst and inst.get("manual"):
            lines.append({"kind": "info", "text": f"Version {inst['version']} needs a new installer from Laurent. "
                          "Keep using this version until he sends it."})
        elif inst:
            can_install = True
            lines.append({"kind": "info", "text": f"Version {inst['version']} needs a short install. Click Install; "
                          "the app will close and reopen by itself."})
        return {"enabled": self.enabled, "version": self.running_version, "channel": self.channel,
                "state": self.status_state, "pending": st["pending"], "blocked": bool(blocked),
                "can_install": can_install, "install_version": (inst or {}).get("version"),
                "lines": lines}


# ---------------------------------------------------------------- the app's one instance
_SINGLETON: Updater | None = None
_SINGLETON_LOCK = threading.Lock()


def get() -> Updater:
    global _SINGLETON
    with _SINGLETON_LOCK:
        if _SINGLETON is None:
            _SINGLETON = Updater(from_env=True)
        return _SINGLETON


def set_instance(u: Updater | None) -> None:
    """Tests: inject (or clear) the app's updater."""
    global _SINGLETON
    with _SINGLETON_LOCK:
        _SINGLETON = u


def blocked_message() -> str | None:
    """For capture / issue: the red banner text when this version is withdrawn, else None.
    With GR_UPDATE_URL unset (and nothing injected) this is always None and builds nothing."""
    if _SINGLETON is None and not (os.environ.get(UPDATE_URL_ENV) or "").strip():
        return None
    try:
        return get().blocked_message()
    except Exception:  # noqa: BLE001
        return None


def status() -> dict:
    if _SINGLETON is None and not (os.environ.get(UPDATE_URL_ENV) or "").strip():
        return {"enabled": False, "lines": []}
    try:
        return get().status()
    except Exception:  # noqa: BLE001
        return {"enabled": False, "lines": []}
