/* Green Receipts desktop UI logic. Renders the screens and wires them to app/service.py.
   NO demo/sample data: the Google Sheet (via the serializer) is the single source of truth.
   If the backend is unreachable the app says so plainly — it NEVER shows fabricated rows. */
"use strict";
const $ = (s) => document.querySelector(s);
const el = (id) => document.getElementById(id);

const S = { screen: "setup", taxpayers: [], capture: null, pending: null,
            filter: "all", fixRow: null, issue: null, preview: null, registry: null,
            // "filed by hand" ticks live in STATE, not just the checkbox DOM: a filter chip or a
            // Refresh re-renders the table, which silently wiped the operator's selection and
            // funnelled them into the "Continue to issue · N ready" trap (2026-07-17).
            boundaryTicks: [],
            setupNotice: "" };   // persistent Settings status — survives re-renders (see setSetupNotice)

/* EN-only (2026-07-07). t() kept as identity so call sites stay stable. */
const t = (k) => k;

/* The Alojamento Local CAE codes (seeded in the sheet's CAE Reference tab). 55201 is the
   standard AL activity and the DEFAULT for new properties; 55204 is the short-stay variant. */
const CAE_OPTIONS = [
  { code: "55201", descr: "Alojamento mobilado para turistas" },
  { code: "55204", descr: "Outros locais de alojamento de curta duração" },
];
const CAE_DEFAULT = "55201";
function caeSelect(id, selected) {
  const sel = selected || CAE_DEFAULT;
  return `<select class="field mono" id="${id}">${CAE_OPTIONS.map((o) =>
    `<option value="${o.code}" ${o.code === sel ? "selected" : ""}>${o.code} — ${o.descr}</option>`).join("")}</select>`;
}
function caeDescr(code) { const o = CAE_OPTIONS.find((x) => x.code === code); return o ? o.descr : ""; }
function taxpayerSelect(id) {
  const txs = S.taxpayers || [];
  return `<select class="field" id="${id}">${txs.length
    ? txs.map((x) => `<option value="${x.taxpayer_id}">${displayName(x.name)} · NIF ${x.nif_masked}</option>`).join("")
    : `<option value="">— add a taxpayer first —</option>`}</select>`;
}

/* ---------- API (no fallback data — a failure is surfaced, never faked) ---------- */
async function api(path, opts) {
  const r = await fetch(path, opts);
  // A non-JSON reply (e.g. FastAPI's plain-text 500) must NOT throw into callers' catch
  // blocks — that showed "Couldn't reach the app" for what was really a server bug.
  try { return await r.json(); }
  catch { return { error: "http_" + r.status, detail: "The app hit an internal error (HTTP " + r.status + "). Tell Laurent — the details are in the app log." }; }
}
async function health() {
  try { const r = await fetch("/health"); if (!r.ok) return null; return await r.json(); }
  catch (e) { return null; }   // backend not reachable
}
/* Re-pull the client list so every screen reflects the current registry (source of truth). */
async function syncTaxpayers() {
  try { const d = await api("/taxpayers"); if (d && !d.error && Array.isArray(d.taxpayers)) S.taxpayers = d.taxpayers; }
  catch (e) { /* keep the last-known list; the screen shows its own error if it can't load data */ }
}
/* Refresh button: drop cached sheet data + re-pull the client list, then re-render (which re-fetches). */
async function refresh() {
  S.pending = null; S.preview = null; S.registry = null;
  await syncTaxpayers();
  render();
}
function refreshBtn() {
  return `<button class="ghost btn" onclick="refresh()" title="Re-read everything from the Google Sheet">↻ Refresh</button>`;
}
function notConnected(detail) {
  noRail();
  el("content").innerHTML = `<div class="center"><div class="card" style="max-width:520px;text-align:center;padding:28px">
    <span class="pill st-in_doubt" style="margin:0 auto">● NOT CONNECTED</span>
    <h1 style="margin-top:12px">The app can't reach your firm's sheet</h1>
    <p class="sub">${detail
      ? String(detail).replace(/</g, "&lt;")
      : "Its connection to your firm's Google Sheet is missing, or the app isn't fully started yet, so it can't read the sheet."}
      <br>Nothing was filed. This shouldn't happen with the installer Laurent sends you.</p>
    <div class="rowbtns" style="justify-content:center">${refreshBtn()}</div>
    <p class="sub" style="margin-top:12px">If it persists, send Laurent the <b>app.log</b> file from your <b>Green Receipts</b> app-data folder.</p></div></div>`;
}

/* ---------- rail ---------- */
const STEPS = [["Capture", "read stays from Airbnb"], ["Review", "check the rows"], ["Fix flagged", "optional"], ["Issue", "file receipts"]];
function rail(active) {
  const SCREENS = ["capture", "review", "fix", "issue"];
  let h = `<div class="rail"><h4>${t("THE PROCESS")}</h4>`;
  STEPS.forEach(([name, sub], i) => {
    const n = i + 1, cls = n < active ? "done" : n === active ? "active" : "todo";
    const inner = cls === "done" ? "✓" : n;
    h += `<div class="step ${cls}" style="cursor:pointer" onclick="nav('${SCREENS[i]}')" title="Go to ${name}"><span class="num">${inner}</span><div><div class="t">${t(name)}</div><div class="s">${sub}</div></div></div>`;
    if (i < STEPS.length - 1) h += `<div class="conn"></div>`;
  });
  // Multi-tenant: no single "active taxpayer" — each stay shows its own client. The footer just
  // reports how many clients are configured, with a shortcut to manage them in Settings.
  const nClients = (S.taxpayers || []).length;
  h += `<div class="railfoot"><div class="lbl">CLIENTS</div><div class="nm">${nClients || "—"} client${nClients === 1 ? "" : "s"}</div>
        <div class="nif" style="cursor:pointer;color:var(--accent-ink)" onclick="nav('setup')">Manage in Settings ↗</div>
        ${S.health && S.health.version ? `<div class="nif" style="margin-top:6px;color:var(--muted3)">v${esc(S.health.version)}</div>` : ""}</div></div>`;
  el("rail").outerHTML = h;
  el("rail") || (document.querySelector(".rail").id = "rail");
}
function noRail() { const r = document.querySelector(".rail, #rail"); if (r) r.outerHTML = `<div id="rail" style="display:none"></div>`; }

/* ---------- screens ---------- */
function nav(screen) {
  if (screen === "setup" && S.screen !== "setup") S.setupNotice = "";   // fresh visit, no stale status
  // NEVER navigate past ticked-but-unapplied "filed by hand" boxes. Ticking is only a
  // selection; it records nothing until applied. Leaving Review silently discarded the
  // operator's decision and the Issue screen then offered to file the very stays they had
  // just declared already-filed — 10 ticked, "Continue to issue · 11 ready" (real trap,
  // 2026-07-17). The Portal duplicate check would catch it, but only by parking 10 rows
  // IN_DOUBT for manual reconciliation. Ask instead; Cancel leaves the ticks intact.
  if (S.screen === "review" && screen !== "review") {
    const ids = pendingBoundaryTicks();
    if (ids.length) {
      const n = ids.length;
      showConfirm(
        n > 1 ? n + " stays are ticked but not marked yet" : "1 stay is ticked but not marked yet",
        "Ticking alone records nothing — it has to be applied.\n\nIf you continue now the ticks are thrown away and the app will file "
        + (n > 1 ? "those stays" : "that stay") + " again, exactly as if you had never ticked "
        + (n > 1 ? "them" : "it") + ".\n\nApply now? (Or Cancel, and untick anything you have NOT already issued yourself.)",
        // Apply, then CONTINUE to where they were going. Applying and stranding them back on
        // Review reads as "Apply did nothing" — the whole point of the click was to move on.
        "Apply " + n + " now", async () => { if (await applyFiledByHand(ids)) nav(screen); });
      return;
    }
  }
  S.screen = screen; render();
}

/* Persistent Settings status line. Written into #setupNotice AND kept in S so a re-render
   (refresh() after a registry mutation) re-paints it instead of silently destroying it —
   the old pattern wrote messages to the DOM right before a re-render wiped them, so
   "Test login" / "Change password" looked like they did nothing. */
function setSetupNotice(html) {
  S.setupNotice = html || "";
  const n = el("setupNotice"); if (n) n.innerHTML = S.setupNotice;
}

/* AT returns legal names ALL-CAPS ("FIRSTNAME MIDDLE SURNAME"); title-case them for DISPLAY
   only — the registry (and the receipt) keeps AT's exact form. Mixed-case input is left
   untouched (someone's intentional capitalisation is not ours to "fix"). */
function displayName(name) {
  const s = String(name || "");
  if (s !== s.toUpperCase()) return s;
  return s.toLowerCase().replace(/(^|[\s\-'])(\p{L})/gu, (m, sep, ch) => sep + ch.toUpperCase());
}

/* Operator-facing labels for registry field names — raw keys like "iva_cod_enq" must never
   reach the screen (review feedback: the refresh notice listed 9 raw field names). */
const FIELD_LABEL = {
  nome_prestador: "name", morada_fiscal_prestador: "fiscal address (domicílio)",
  morada_fiscal: "receipt address", estabelecimento_comercial: "establishment",
  data_inicio_atividade: "activity start date", iva_cod_enq: "IVA regime",
  iva_desc_enq: "IVA regime description", iva_cod_tipo_operacoes: "IVA operation type",
  iva_tipo_sujeito_passivo: "IVA taxpayer type", at_login_username: "Portal login",
};
function fieldLabels(keys) {
  // Collapse the IVA quartet into one "IVA regime" mention; dedupe; keep operator words.
  const seen = new Set();
  return (keys || []).map((k) => FIELD_LABEL[k] || k.replace(/_/g, " "))
    .filter((l) => (seen.has(l) ? false : (seen.add(l), true)))
    .filter((l, i, a) => !(l === "IVA regime description" && a.includes("IVA regime")))
    .join(", ");
}

/* In-app confirm/alert on the existing #modal — native popups clash with the app's look,
   can't be styled, and hang automated/webview contexts. showConfirm takes a callback. */
function showAlert(title, message) {
  el("modalBox").innerHTML = `<h1 style="margin-top:0;font-size:19px">${esc(title)}</h1>
    <p class="sub" style="white-space:pre-wrap">${esc(message)}</p>
    <div class="rowbtns" style="justify-content:flex-end"><button class="btn" onclick="closeModal()">OK</button></div>`;
  el("modal").style.display = "flex";
}
/* A blocking "this is working" view — no buttons, so a slow write can't be read as a dead one.
   The caller MUST closeModal() when it finishes (applyFiledByHand does, on every path). */
function showBusy(title, message) {
  // A MOVING spinner, not static text: this view stays up for ~10s PER ROW (the two-step audited
  // park+resolve), and a grey "Working…" label with no motion reads as frozen (audit, 2026-07-17).
  // .spinner is white (for dark buttons) so it's invisible here; inline a dark one on the named
  // `rot` keyframe instead so it visibly turns on the white modal.
  el("modalBox").innerHTML = `<h1 style="margin-top:0;font-size:19px">${esc(title)}</h1>
    <p class="sub" style="white-space:pre-wrap">${esc(message)}</p>
    <div style="display:flex;align-items:center;gap:9px;margin-top:4px;color:var(--muted);font-size:13px">
      <span class="busySpin" style="display:inline-block;width:14px;height:14px;border:2px solid rgba(20,28,45,.18);border-top-color:var(--muted);border-radius:999px;animation:rot .8s linear infinite"></span>
      Working…</div>`;
  el("modal").style.display = "flex";
}
let _confirmYes = null;
function showConfirm(title, message, yesLabel, onYes) {
  _confirmYes = onYes;
  el("modalBox").innerHTML = `<h1 style="margin-top:0;font-size:19px">${esc(title)}</h1>
    <p class="sub" style="white-space:pre-wrap">${esc(message)}</p>
    <div class="rowbtns" style="justify-content:flex-end">
      <button class="ghost btn" onclick="closeModal()">Cancel</button>
      <button class="btn" onclick="closeModal(); if (_confirmYes) { const f = _confirmYes; _confirmYes = null; f(); }">${esc(yesLabel || "Continue")}</button></div>`;
  el("modal").style.display = "flex";
}

function renderTopbar() {
  const tb = el("topbar"); if (!tb) return;
  const configured = (S.taxpayers && S.taxpayers.length);
  let acts = "";
  if (S.screen === "setup") {
    if (configured) acts = `<button class="mini" onclick="nav('capture')">Close Settings</button>`;
  } else if (S.screen !== "otp" && S.screen !== "busy" && S.screen !== "abchallenge") {
    acts = `<button class="mini" onclick="nav('selfcheck')">✓ Test setup</button>
            <button class="mini" onclick="nav('reconcile')">Check unconfirmed</button>
            <button class="mini" onclick="nav('setup')">⚙ Settings</button>`;
  }
  // A named instance (several deployments on one laptop) shows its label on every screen, so the
  // operator can never mistake whose data they are working on.
  const inst = S.health && S.health.instance_label;
  const badge = inst ? ` <span class="nif" style="margin-left:8px;padding:2px 8px;border-radius:6px;background:var(--hair3);color:var(--body)">${esc(inst)}</span>` : "";
  tb.innerHTML = `<div class="brand"><span class="sq"></span>Green Receipts${badge}</div><div class="acts">${acts}</div>`;
}

async function render() {
  const c = el("content");
  await syncTaxpayers();   // keep the client list in sync with the registry on every navigation
  renderTopbar();
  if (["capture", "review", "fix", "issue"].includes(S.screen))
    rail({ capture: 1, review: 2, fix: 3, issue: 4 }[S.screen]);
  else noRail();
  c.innerHTML = `<div class="spin">Loading…</div>`;
  try { await RENDER[S.screen](c); } catch (e) { c.innerHTML = `<div class="banner warn">Couldn't load this screen: ${e}. ${refreshBtn()}</div>`; }
  paintUpdateLines();
}

/* ---------- self-update lines (docs/PLAN_AUTO_UPDATE.md) ----------
   Quiet lines at the top of every screen: "Updated to X", "An update is ready…", a red banner when
   the admin has withdrawn this version (Capture and Issue then refuse, server-side), and the Install
   button for an update that needs a short install. Nothing shows when the updater is off. */
async function loadUpdateStatus() {
  let u; try { u = await api("/update/status"); } catch { u = null; }
  S.update = (u && !u.error && Array.isArray(u.lines)) ? u : null;
  paintUpdateLines();
}
function paintUpdateLines() {
  const c = el("content"); if (!c) return;
  const old = el("updateLines"); if (old) old.remove();
  const u = S.update; if (!u || !u.lines || !u.lines.length) return;
  const style = { red: "background:#fde8e8;border:1px solid #f3c1c1;color:#8f1d22",
                  warn: "background:#fef3cd;color:#92400e", info: "background:var(--hair3);color:var(--body)" };
  const lines = u.lines.map((l) => `<div class="banner" style="${style[l.kind] || style.info};margin:0 0 10px;font-size:13px">${l.kind === "red" ? "⚠ " : ""}${esc(l.text)}</div>`).join("");
  const wait = u.busy ? `<span class="sub" style="margin-left:8px">Wait until the ${u.busy === "issue" ? "issue" : "capture"} finishes.</span>` : "";
  const btn = u.can_install
    ? `<div style="margin:-4px 0 12px"><button class="btn" style="padding:5px 12px;font-size:12.5px" onclick="doInstallUpdate()" ${u.busy ? "disabled" : ""}>Install</button>${wait}</div>` : "";
  c.insertAdjacentHTML("afterbegin", `<div id="updateLines">${lines}${btn}</div>`);
}
function doInstallUpdate() {
  const v = (S.update && S.update.install_version) || "";
  showConfirm("Install the update?",
    `The app will close, install version ${v}, and open again by itself. This takes about a minute.\n\nYour clients, passwords and receipts are not touched.`,
    "Install", async () => {
      let r; try { r = await api("/update/install", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ confirmed: true }) }); }
      catch { r = { error: "unreachable" }; }
      if (r && r.ok) { showBusy("Installing the update", "The app is closing now and will open again by itself in about a minute."); return; }
      showAlert("The update was not installed", (r && r.detail) || "It couldn't start just now. Nothing was changed — try again later.");
      loadUpdateStatus();
    });
}

const RENDER = {
  async setup(c) {
    let st; try { st = await api("/setup/status"); } catch { st = { taxpayers: [], needs_password: [], configured: false }; }
    if (!S.paths) { try { S.paths = await api("/setup/paths"); } catch { S.paths = {}; } }
    // What's already configured (read-only) — re-fetched each time so a just-added entry shows.
    try { S.registry = await api("/setup/registry"); } catch { S.registry = { taxpayers: [], properties: [] }; }
    const txs = (S.registry && S.registry.taxpayers) || [];
    const props = (S.registry && S.registry.properties) || [];
    c.innerHTML = `<div class="center"><div class="card" style="max-width:720px;width:720px;border-radius:16px;box-shadow:0 20px 50px rgba(20,28,45,.16);padding:26px">
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <div><h1>${st.configured ? "Settings" : "Welcome to Green Receipts"}</h1>
          <p class="sub">${st.configured
            ? "Add or check a client, or map a listing below."
            : "Add your clients and their Airbnb listings below. The one-time computer setup is at the bottom — about 10 minutes, just once."}</p></div>
        <div style="display:flex;gap:10px;align-items:flex-start">${sheetBtn("Google Sheet")}${st.configured ? refreshBtn() : ""}</div>
      </div>
      <div id="setupNotice" style="margin-top:8px">${S.setupNotice || ""}</div>
      ${clientsCard(txs)}
      ${listingsCard(props, txs)}
      <div style="border-top:1px solid var(--hair2);margin-top:18px;padding-top:14px">
        <div class="lbl2" style="margin-bottom:10px">One-time setup for this computer</div>
        <div style="display:flex;gap:11px;align-items:flex-start;padding:2px 0">
          <span class="step todo" style="padding:0"><span class="num">1</span></span>
          <div style="flex:1"><div class="t" style="font-weight:700">Install the Chrome extension</div>
            <div class="s">Green Receipts Bridge reads airbnb.com only — it never logs in.</div>
            ${extInstallHelp({ detailsStyle: "margin-top:6px", summaryClass: "s", summaryStyle: "cursor:pointer", summaryText: "Show me how", bannerExtra: ";font-size:12.5px", tail: "next to the address bar. Done — once per computer." })}
          </div></div>
        ${checkRow("done", "Connected to your firm's sheet", "Set up by your administrator", "Connected")}
      </div>
      <div style="border-top:1px solid var(--hair2);margin-top:14px;padding-top:14px">
        <div class="lbl2" style="margin-bottom:4px">Where your receipts are saved</div>
        <div class="s">Every receipt the app files is downloaded from Portal das Finanças and kept
          here as a PDF${(S.paths || {}).drive_on ? ", and copied to Google Drive" : ""}.</div>
        ${receiptsPathRow()}
      </div>
      <div style="border-top:1px solid var(--hair2);margin-top:14px;padding-top:14px;display:flex;justify-content:flex-end;align-items:center">
        <button class="dark btn" onclick="nav('selfcheck')">Finish setup →</button></div>
    </div></div>`;
  },

  async capture(c) {
    if (!S.paths) { try { S.paths = await api("/setup/paths"); } catch { S.paths = {}; } }
    const cap = S.capture;
    // Persistent "last capture" memory (survives app restarts — the in-session S.captureAt
    // doesn't): tells the operator whether anything could be outstanding, and nudges gently
    // when it's been a while. Best-effort — a fetch failure just hides the line.
    let last = null; try { last = await api("/capture/last"); } catch { last = null; }
    const lastLine = last && last.ts
      ? (last.days_ago >= 7
        ? `<div class="banner" style="background:#fef3cd;color:#92400e;margin:14px 0 6px">Your last capture was <b>${last.days_ago} days ago</b> — new stays may be waiting. Run one now.</div>`
        : `<div style="margin:14px 0 6px" class="sub">Last capture: <b>${esc(String(last.ts).replace("T", " ").slice(0, 16))}</b>${last.days_ago ? ` (${last.days_ago} day${last.days_ago > 1 ? "s" : ""} ago)` : " (today)"} · ${last.reservations_seen} reservations read.</div>`)
      : `<div style="margin:14px 0 6px" class="sub">No capture has run on this computer yet.</div>`;
    c.innerHTML = `<h1>Capture completed stays</h1>
      <p class="sub">The app reads your finished reservations and each one's Airbnb fee. It never logs in or sees your password.</p>
      <div id="urgentBanner"></div>
      <div id="autoCapNote"></div>
      <div class="card" style="text-align:center">
        <div style="display:flex;justify-content:space-between;align-items:center;text-align:left">
          <div><b>Uses the Green Receipts Bridge extension</b>
            <div class="sub" style="margin:0">Reads airbnb.com only · never logs in.</div>
            <div id="extStatus" style="margin-top:6px;font-size:12.5px;min-height:18px"></div></div>
          <label class="sub" style="margin:0;white-space:nowrap"><input type="checkbox" id="dry"> Preview first</label></div>
        ${extInstallHelp({ detailsStyle: "text-align:left;margin:10px 0 4px", summaryClass: "sub", summaryStyle: "cursor:pointer;margin:0", summaryText: "Extension not installed yet? Click here", bannerExtra: "", tail: "— you only do this once." })}
        ${lastLine}
        <div style="margin:0 0 6px" class="sub">Reads stays finished since the previous capture (safe to run anytime — never captures the same stay twice).</div>
        <button class="btn" id="capBtn" onclick="doCapture()">Capture now</button>
        <div id="capNote" class="sub" style="display:none;margin:10px 0 0">Reading your reservations — this can take a few
          minutes the first time. Keep this window and Chrome open; the summary appears here when it finishes.</div></div>
      ${cap ? captureResult(cap) : ""}`;
    // pre-flight: tell the operator if the extension is ready BEFORE they click Capture (the automatic
    // capture on app start waits for this same check — see maybeAutoCapture)
    S.extCheckPromise = checkExtension();
    loadUrgentBanner();  // red banner: stays not issued with < 2 working days left
    if (S.autoCapture && S.autoCapture.running) autoCaptureNote("running");
    else if (S.autoCapture && S.autoCapture.done && cap) autoCaptureNote("done");
  },

  async review(c) {
    // ALL clients in one list (multi-tenant), straight from the sheet — each row shows its client.
    let p; try { p = await api("/pending"); } catch { p = { error: "unreachable" }; }
    if (p && p.error) {
      c.innerHTML = `<div style="display:flex;justify-content:space-between"><h1>${t("Review captured stays")}</h1>${refreshBtn()}</div>
        <div class="banner warn">Couldn't load stays from the sheet right now (${p.detail || p.error}). Nothing was changed — wait a moment and Refresh.</div>
        <div class="rowbtns"><button class="ghost btn" onclick="nav('capture')">← Back to capture</button></div>`;
      return;
    }
    S.pending = p;
    // The flagged review LANE (needs_review + quarantine) is a SEPARATE endpoint — /pending only returns
    // claimable rows, so without this the flagged chips are always 0. NON-BLOCKING: if it fails we still
    // show the ready rows and never block issuing them.
    let nr; try { nr = await api("/needs-review"); } catch { nr = { error: "unreachable" }; }
    S.needsReview = nr;
    const ready = enrich(p.rows || []);
    const flagged = (nr && !nr.error ? (nr.rows || []) : []).map(nrToRow);
    const rows = ready.concat(flagged);
    S.reviewRows = rows;   // openFix() looks a flagged row up here
    const counts = { all: rows.length, ready: ready.length,
                     needs_review: flagged.filter((r) => r.status === "needs_review").length,
                     quarantine: flagged.filter((r) => r.status === "quarantine").length };
    const show = rows.filter((r) => S.filter === "all" || r.status === (S.filter === "ready" ? "pending" : S.filter))
      // most-urgent first (overdue -> due-soon -> ok -> no-deadline), then by days-left — a sort, never a gate.
      .sort((a, b) => ((URG_RANK[a.urgency] ?? 3) - (URG_RANK[b.urgency] ?? 3))
        || ((a.days_left ?? 9999) - (b.days_left ?? 9999)));
    const nrWarn = (nr && nr.error)
      ? `<div class="banner warn">Couldn't load the review lane (${nr.detail || nr.error}) — the ready stays below are unaffected; Refresh to retry.</div>` : "";
    const overdueN = ready.filter((r) => r.urgency === "overdue").length;
    const dueSoonN = ready.filter((r) => r.urgency === "due_soon").length;
    const dueTotal = overdueN + dueSoonN;
    // Quiet status line — replaces the old stacked yellow banners. The flagged counts already show in
    // the chips and per-row deadlines in the Deadline column, so this is a subtle muted recap, not a
    // loud box. A small dot marks genuine deadline urgency (red = overdue, amber = due soon).
    const statusBits = [];
    if (flagged.length) statusBits.push(`${flagged.length} to look at <span style="color:var(--muted3)">— won't block the ready ones</span>`);
    if (dueTotal) statusBits.push(`<span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:${overdueN ? "#c05a50" : "#c8992e"};margin-right:6px;vertical-align:middle"></span>${dueTotal} near the 5-business-day deadline${overdueN ? ` (${overdueN} overdue)` : ""}`);
    const statusLine = statusBits.length
      ? `<div style="display:flex;gap:18px;flex-wrap:wrap;align-items:center;font-size:12.5px;color:var(--muted);margin:0 0 14px">${statusBits.map((b) => `<span>${b}</span>`).join("")}</div>` : "";
    c.innerHTML = `<div style="display:flex;justify-content:space-between"><div><h1>${t("Review captured stays")}</h1>
      <p class="sub">${rows.length} stay${rows.length === 1 ? "" : "s"} waiting across your clients.${flagged.length ? " Clear the flagged ones to include them." : ""}<br>The figures live in the GR tab — what files is exactly what the sheet says.</p></div>
      <div style="display:flex;gap:10px;align-items:flex-start">
        <input type="file" id="csvFile" accept=".csv" style="display:none" onchange="applyCsvFile(this)">
        ${refreshBtn()}${sheetLink("Open in Google Sheet · GR tab")}</div></div>
      <div id="csvMsg" style="display:none;margin:2px 0 12px"></div>
      ${rows.length ? `<details style="margin:0 0 12px"><summary class="s" style="cursor:pointer;color:var(--muted)">Optional: use the exact Airbnb payout dates (instead of the close estimate)</summary>
        <div class="banner" style="background:var(--hair3);color:var(--body);margin-top:8px;font-size:12.5px">
          The dates shown below are a close estimate of when Airbnb paid you. If you want the <b>exact</b>
          dates: in Airbnb open <b>Transactions → Transaction History → Export (CSV)</b>, save the file, then
          pick it here. Not required — receipts file fine with the estimate.
          <div style="margin-top:8px"><button class="ghost btn" style="padding:5px 12px;font-size:12.5px" onclick="pickCsv()">Pick the Airbnb CSV file…</button></div>
        </div></details>` : ""}
      ${rows.length === 0 ? emptyReviewBanner(nr) : ""}
      ${rows.length && S.health && S.health.v1_firewall ? `<div class="banner" style="background:var(--hair3);color:var(--body)">This list is every stay not yet filed <b>by this app</b> — it can include stays you already issued with your previous tool.
        Those are <b>skipped automatically</b> when you click Issue (each stay is checked against your previous records and the Portal first); the Done screen shows how many were skipped.</div>` : ""}
      ${(function () {
        const b = ready.filter((r) => r.boundary);
        if (!b.length) return "";
        return `<div class="banner" style="background:#fef3cd;color:#92400e;margin-bottom:14px"><b>${b.length} stay${b.length > 1 ? "s" : ""} from around when you started the app</b> — decide once:
          tick <b>“filed by hand”</b> on each receipt you already issued yourself at the Portal; leave the rest unticked — the app files those (it still checks the Portal first, so nothing can be filed twice).
          <div style="margin-top:8px;display:flex;gap:10px;flex-wrap:wrap">
            <button class="ghost btn" style="padding:5px 12px;font-size:12.5px" onclick="toggleAllBoundary()">Tick / untick all</button>
            <button class="btn" style="padding:5px 12px;font-size:12.5px" onclick="markTickedFiledByHand()">Mark ticked as filed by hand →</button>
          </div></div>`;
      })()}
      ${nrWarn}
      <div style="display:flex;gap:8px;margin:0 0 14px">
        ${chip("all", "All " + counts.all)} ${chip("ready", "Ready " + counts.ready)}
        ${chip("needs_review", "Needs review " + counts.needs_review)} ${chip("quarantine", "Needs setup " + counts.quarantine)}</div>
      ${statusLine}
      <div class="card" style="padding:0;overflow:hidden"><table><thead><tr><th>Status</th><th>Client</th><th>Guest / property</th><th>Dates</th><th>Deadline</th><th class="num">Total</th><th style="text-align:right">Action</th></tr></thead><tbody>
      ${show.map(reviewRow).join("")}</tbody></table></div>
      <div class="rowbtns" style="justify-content:space-between"><button class="ghost btn" onclick="nav('capture')">← Back to capture</button>
        <button class="btn" onclick="nav('issue')" ${counts.ready ? "" : "disabled"}>${t("Continue to issue")} · ${counts.ready} ready →</button></div>`;
  },

  async fix(c) {
    const r = S.fixRow;
    if (!r) {   // reached without a selected row (step rail, a refresh): LIST the flagged stays, never a blank page
      let nr; try { nr = await api("/needs-review"); } catch { nr = { error: "unreachable" }; }
      const back = `<div class="rowbtns"><button class="ghost btn" onclick="nav('review')">← Back to review</button></div>`;
      if (nr && nr.error) {
        c.innerHTML = `<div style="display:flex;justify-content:space-between"><h1>Flagged stays</h1>${refreshBtn()}</div>
          <div class="banner warn">Couldn't load the flagged stays right now (${esc(nr.detail || nr.error)}). Nothing was changed — wait a moment and Refresh.</div>${back}`;
        return;
      }
      const rows = (nr.rows || []).map(nrToRow)
        .sort((a, b) => ((URG_RANK[a.urgency] ?? 3) - (URG_RANK[b.urgency] ?? 3)) || ((a.days_left ?? 9999) - (b.days_left ?? 9999)));
      S.reviewRows = rows;   // openFix() looks a row up here
      c.innerHTML = `<div style="display:flex;justify-content:space-between"><div><h1>Flagged stays</h1>
          <p class="sub">These stays were <b>not issued</b>. Each line says why and what to do. Most urgent first.</p></div>${refreshBtn()}</div>
        ${rows.length
          ? `<div class="card" style="padding:0;overflow:hidden"><table><thead><tr><th>Status</th><th>Client</th><th>Guest / property</th><th>Dates</th><th>Deadline</th><th class="num">Total</th><th style="text-align:right">Action</th></tr></thead><tbody>
              ${rows.map(reviewRow).join("")}</tbody></table></div>`
          : `<div class="banner" style="background:var(--hair3);color:var(--body)">Nothing is flagged right now.</div>`}
        ${back}`;
      return;
    }
    const payout = (r.payout && r.payout !== "—") ? "€" + r.payout : "—";
    c.innerHTML = `<div class="sub" style="margin:0">Finish setting up this stay</div><h1>Map this listing to a property</h1>
      <div class="banner purple">This stay's Airbnb listing isn't in your Property Settings yet, so the app can't route its receipt to a taxpayer. Map it once here, and this stay will route correctly the next time you capture.</div>
      <div style="display:flex;gap:16px">
        <div class="card" style="width:300px;flex:0 0 300px;height:fit-content"><div class="lbl2" style="margin-bottom:10px">Captured from Airbnb</div>
          ${kv("Guest", esc(r.guest || "—"))}${kv("Airbnb code", esc(r.hm_code || "—"), true)}${kv("Listing id", esc(r.listing_id || "—"), true)}${kv("Dates", esc(stripTime(r.dates) || "—"))}${kv("Host payout", payout, true)}</div>
        <div class="card" style="flex:1"><div class="t" style="font-weight:700;margin-bottom:10px">Property this listing belongs to</div>
          <div class="grid2">
            <div style="grid-column:1/3"><span class="lbl2">Property name</span><input class="field" id="fx_name" placeholder="e.g. Apto. Centro"></div>
            <div><span class="lbl2">Taxpayer</span>${taxpayerSelect("fx_tp")}</div>
            <div><span class="lbl2">CAE · Alojamento Local</span>${caeSelect("fx_cae")}</div>
            <div><span class="lbl2">AL number</span><input class="field mono" id="fx_al" placeholder="12345/AL"></div>
            <div style="grid-column:1/3"><span class="lbl2">Listing id</span><input class="field mono" id="fx_id" value="${esc(r.listing_id || "")}"></div>
          </div>
          <div class="banner" style="background:var(--hair3);color:var(--muted);margin:14px 0 0">Saves a row to the <b>Property Settings ↗</b> tab. The CAE is checked against your <b>CAE Reference ↗</b> list before saving. Only stays not yet issued can be corrected; the change is logged.</div>
          <div class="rowbtns"><button class="ghost btn" onclick="nav('review')">Cancel</button><button class="purple btn" onclick="saveFix()">Save property mapping</button></div>
          <div id="fixMsg" style="margin-top:8px"></div>
        </div></div>`;
  },

  async issue(c) {
    // Multi-tenant: file for ALL clients (default) or one picked from the list. The backend
    // firewall pre-check then says what will ACTUALLY file (honest count, straight from the sheet).
    const scope = S.issueScope || "all";
    const clients = S.taxpayers || [];
    let pv; try { pv = await api("/emit/preview/" + encodeURIComponent(scope)); } catch { pv = { error: "unreachable" }; }
    if (pv && pv.error) {
      c.innerHTML = `<div style="display:flex;justify-content:space-between"><h1>Issue Fatura-Recibo</h1>${refreshBtn()}</div>
        <div class="banner warn">Google's service was briefly unavailable, so we couldn't check what will file. Nothing was filed. Please wait a minute, then Refresh to try again.</div>
        <div class="rowbtns"><button class="ghost btn" onclick="nav('review')">← Back to review</button></div>`;
      return;
    }
    S.preview = pv;
    const ready = pv.will_file || [];
    const total = ready.reduce((a, r) => { const t = amounts(r).total; return a + (isNaN(t) ? 0 : t); }, 0);
    const picker = `<select class="field" style="max-width:340px" onchange="S.issueScope=this.value;render()">
        <option value="all" ${scope === "all" ? "selected" : ""}>All clients (${clients.length})</option>
        ${clients.map((cl) => `<option value="${cl.taxpayer_id}" ${scope === cl.taxpayer_id ? "selected" : ""}>${displayName(cl.name)} · NIF ${cl.nif_masked}</option>`).join("")}
      </select>`;
    c.innerHTML = `<div style="display:flex;justify-content:space-between"><h1>Issue Fatura-Recibo</h1>${refreshBtn()}</div>
      <div style="display:flex;gap:10px;align-items:center;margin:0 0 14px"><span class="lbl2">Issue for</span>${picker}</div>
      ${pv.skipped_v1_count ? `<div class="banner green" style="margin:0 0 14px">✓ ${pv.skipped_v1_count} stay${pv.skipped_v1_count === 1 ? "" : "s"} already filed with your previous tool — those are skipped automatically and are NOT in the list below.</div>` : ""}
      <div style="display:flex;gap:14px;margin:0 0 16px">
        ${summary("Will file now", ready.length)} ${summary("Total to report", "€" + total.toFixed(2))} ${summary("Already filed before", pv.skipped_v1_count || 0, true)}</div>
      ${ready.length === 0 ? `<div class="banner ${pv.firewall ? "green" : "warn"}">${pv.firewall ? "Nothing new to file — every pending stay was already filed with your previous tool." : "Nothing to issue right now for this selection."}</div>` : `
      <div class="card" style="padding:0;overflow:hidden"><table><thead><tr><th>Client</th><th>Airbnb code</th><th>Guest</th><th>Dates</th><th class="num">Total to report</th></tr></thead><tbody>
        ${ready.map((r) => `<tr><td>${esc(displayName(r.client_name) || "—")}</td><td class="mono">${esc(r.hm_code)}</td><td>${esc(r.guest || "—")}</td><td>${esc(stripTime(r.dates || (r.service_date || "") + (r.end_date ? " → " + r.end_date : "")))}</td><td class="num">${eur(amounts(r).total)}</td></tr>`).join("")}</tbody></table></div>`}
      <div class="rowbtns" style="justify-content:space-between">
        <button class="ghost btn" onclick="nav('review')">← Back to review</button>
        <button class="btn" ${ready.length ? "" : "disabled"} onclick="openIssueModal()">Review &amp; issue ${ready.length} receipt${ready.length === 1 ? "" : "s"} →</button></div>`;
  },

  async otp(c) {
    c.innerHTML = `<div class="center"><div class="card" style="max-width:480px;width:480px;border-radius:16px;text-align:center;padding:26px">
      <span class="pill st-needs_review" style="margin:0 auto">● ONE-TIME CODE NEEDED</span>
      <h1 style="margin-top:12px">The Portal asked for a code</h1>
      <p class="sub">The app normally signs in with your saved password. This time the Portal wants a one-time code (OTP / Chave Móvel) it can't enter for you.</p>
      <div style="text-align:left;margin:6px 0 16px">
        <div class="banner" style="background:var(--hair3);color:var(--body)">1 · Open portaldasfinancas.gov.pt and enter the code.</div>
        <div class="banner" style="background:var(--hair3);color:var(--body)">2 · Come back — your receipts are still waiting, untouched.</div></div>
      <div class="rowbtns" style="justify-content:center"><a class="ghost btn" href="https://www.portaldasfinancas.gov.pt" target="_blank">Open Portal ↗</a>
        <button class="btn" onclick="doEmit()">I've signed in — issue now</button></div>
      <p class="sub" style="margin-top:12px">Nothing is ever issued on a failed or incomplete login.</p></div></div>`;
  },

  async abchallenge(c) {
    c.innerHTML = `<div class="center"><div class="card" style="max-width:480px;width:480px;border-radius:16px;text-align:center;padding:26px">
      <span class="pill st-needs_review" style="margin:0 auto">● SIGN-IN NEEDED</span>
      <h1 style="margin-top:12px">Airbnb wants to check it's you</h1>
      <p class="sub">The app reads your finished reservations through your Chrome. Airbnb signed you out, so the capture paused — nothing is broken.</p>
      <div style="text-align:left;margin:6px 0 16px">
        <div class="banner" style="background:var(--hair3);color:var(--body)">1 · Open airbnb.com in Chrome and sign in.</div>
        <div class="banner" style="background:var(--hair3);color:var(--body)">2 · Come back and retry the capture.</div></div>
      <div class="rowbtns" style="justify-content:center"><a class="ghost btn" href="https://www.airbnb.com" target="_blank">Open Airbnb ↗</a>
        <button class="btn" onclick="retryCaptureAfterAirbnbSignIn()">I've signed in — retry capture</button></div>
      <p class="sub" style="margin-top:12px">Nothing was written — the period is not marked complete until a capture finishes.</p></div></div>`;
  },

  async busy(c) {
    c.innerHTML = `<div class="center"><div class="card" style="max-width:480px;width:480px;border-radius:16px;text-align:center;padding:26px">
      <span class="pill st-needs_review" style="margin:0 auto">● PLEASE WAIT</span>
      <h1 style="margin-top:12px">A previous run is still finishing</h1>
      <p class="sub">Another filing run is still holding this taxpayer — usually because one is in
        progress, or one closed early. It clears itself within about <b>20 minutes</b>.
        Your receipts are untouched — nothing was filed.</p>
      <div class="rowbtns" style="justify-content:center"><button class="ghost btn" onclick="nav('issue')">Back</button>
        <button class="dark btn" onclick="doEmit()">Try again</button></div></div></div>`;
  },

  async done(c) {
    const r = S.issue || { filed: 0 };
    // Needed for the "where the PDFs went" line below — this screen can be the first one to want it.
    if (!S.paths) { try { S.paths = await api("/setup/paths"); } catch { S.paths = {}; } }
    // Shows ONLY what the backend actually returned (filed count, per-taxpayer counts, archived
    // PDFs, in-doubt). No fabricated per-receipt table — the real numbers live in the sheet + Portal.
    const per = r.per_taxpayer || [];
    const archived = per.reduce((a, t) => a + (t.archived || 0), 0);
    const archiveFailed = per.reduce((a, t) => a + (t.archive_failed || 0), 0);
    const errored = r.errored_total || 0;   // per-row pre-submit failures (re-claimable, nothing filed)
    const inDoubt = r.in_doubt_total || 0;
    const skips = r.skipped || [];           // taxpayer-level skips (no_cred / no_doc_number / emit_error)
    // ANY of these means the run is NOT a clean success. The hero glyph + heading must never read as a
    // green "✓ 0 filed" when nothing filed but something needs attention — that was the 2026-07-09 trap
    // (row-errored) AND its twin (a whole taxpayer SKIPPED with 0 filed still showed the green tick).
    const attention = errored > 0 || inDoubt > 0 || skips.length > 0;
    const liveRows = per.map((t) => `<tr><td class="gp"><div class="g">${esc(displayName(t.name || (S.taxpayers.find((x) => x.taxpayer_id === t.taxpayer_id) || {}).name || t.taxpayer_id || "Taxpayer"))}</div>
        <div class="p">NIF ${t.nif_masked || "—"}</div></td>
      <td class="num">${t.emitted || 0}</td><td class="num">${t.in_doubt || 0}</td><td class="num">${t.errored || 0}</td>
      <td>${t.skipped_reason ? skipText(t) : (t.errored ? "⚠ couldn't file — retry" : (t.in_doubt ? "⚠ not confirmed — check at Portal" : "✓"))}</td></tr>`).join("");
    const heroWarn = errored > 0 || inDoubt > 0 || (!r.filed && attention);
    const heading = r.filed
      ? `${r.filed} receipt${r.filed === 1 ? "" : "s"} filed`
      : errored ? `Nothing filed — ${errored} couldn't be issued`
      : skips.length ? `Nothing filed — ${skips.length} client${skips.length === 1 ? "" : "s"} skipped`
      : inDoubt ? `Nothing filed — ${inDoubt} not confirmed`
      : r.nothing_pending ? `Nothing to file right now`
      : `0 receipts filed`;
    c.innerHTML = `<div class="center"><div style="width:760px"><div class="big"><div class="ok">${heroWarn ? "⚠" : "✓"}</div>
      <h1 style="margin:0">${heading}</h1>
      <p class="sub">${r.filed ? "Filed at Portal das Finanças" : "Portal das Finanças"}${archived > 0 ? ` · ${archived} PDF${archived === 1 ? "" : "s"} saved${(S.paths || {}).drive_on ? " (also to Google Drive)" : ""}` : ""}.
        The exact receipts + document numbers are in the sheet's <b>GR</b> tab and at the Portal.</p></div>
      ${archiveFailed > 0 ? `<div class="banner warn">⚠ ${archiveFailed} receipt PDF${archiveFailed === 1 ? " couldn't be" : "s couldn't be"} downloaded from the Portal. The receipt${archiveFailed === 1 ? " itself is" : "s themselves are"} filed — only the PDF copy is missing, and it can be fetched later. Tell Laurent if it keeps happening.</div>` : ""}
      ${archived > 0 ? `<div class="card" style="text-align:left"><div class="lbl2" style="margin-bottom:4px">Your receipt PDF${archived === 1 ? "" : "s"}</div>${receiptsPathRow()}</div>` : ""}
      ${errored ? `<div class="banner warn">⚠ ${errored} stay${errored === 1 ? "" : "s"} could NOT be filed this run — nothing was filed for ${errored === 1 ? "it" : "them"}, so ${errored === 1 ? "it stays" : "they stay"} in the queue and will be retried next run. If it keeps happening, open the <b>GR</b> tab and read the <b>error</b> column, or send the log to Laurent.</div>` : ""}
      ${skips.length ? `<div class="banner warn">⚠ ${skips.length} client${skips.length === 1 ? " was" : "s were"} skipped and filed nothing — see the <b>Status</b> column below for why (e.g. missing Portal password). Fix and re-run.</div>` : ""}
      ${r.skipped_v1_total ? `<div class="banner green">✓ ${r.skipped_v1_total} stay${r.skipped_v1_total === 1 ? " was" : "s were"} skipped — already filed with your previous tool. That's the safeguard working; nothing was filed twice.</div>` : ""}
      ${inDoubt > 0 ? `<div class="banner warn">⚠ ${inDoubt} not confirmed — the app couldn't tell whether the Portal accepted ${inDoubt === 1 ? "it" : "them"}. Do NOT re-issue; check ${inDoubt === 1 ? "it" : "each"} at the Portal first. <a href="#" onclick="nav('reconcile');return false" style="font-weight:700;color:inherit">Check now →</a></div>` : ""}
      ${per.length ? `<div class="card" style="padding:0;overflow:hidden"><table><thead><tr><th>Client</th><th class="num">Filed</th><th class="num">Not confirmed</th><th class="num">Not filed</th><th>Status</th></tr></thead><tbody>${liveRows}</tbody></table></div>` : ""}
      <div class="rowbtns" style="justify-content:flex-end;align-items:center">
        <a class="link" href="https://www.portaldasfinancas.gov.pt" target="_blank">View at Portal ↗</a><button class="dark btn" onclick="nav('capture')">Done</button></div>
    </div></div>`;
  },

  async reconcile(c) {
    let d; try { d = await api("/indoubt"); } catch { d = { error: "unreachable" }; }
    const err = d && d.error ? (d.detail || d.error) : null;   // a REAL error is shown, never masked
    const rows = err ? [] : (d.rows || []);
    // v1-firewall matches ("already filed by v1 as doc N") are known-filed in the previous tool — offer a
    // one-click bulk verify for JUST those. Genuinely-ambiguous rows are excluded and still need per-row checks.
    const v1n = rows.filter((r) => (r.note || "").toLowerCase().includes("already filed by v1")).length;
    c.innerHTML = `<div style="display:flex;justify-content:space-between"><h1>Check unconfirmed receipts</h1>${refreshBtn()}</div>
      <p class="sub">These stays may or may not have been filed at the Portal — the app couldn't confirm.
        <b>Check each at the Portal first, then mark it verified.</b> Never just re-issue one.</p>
      ${err
        ? `<div class="banner warn">Couldn't load the list right now (${err}). Wait a minute and Refresh — nothing was changed.</div>`
        : rows.length === 0
          ? `<div class="banner green">✓ Nothing to check — no unconfirmed receipts right now.</div>`
          : `<div class="banner warn">⚠ ${rows.length} to verify. For each: open the Portal (Faturas e Recibos Verdes →
               Consultar), search the dates/amount (the description carries the AL number and the Airbnb code, e.g. HM…), then mark it
               verified once you've confirmed.</div>
            ${v1n > 0 ? `<div class="banner" style="background:var(--hair3);color:var(--body);display:flex;gap:12px;justify-content:space-between;align-items:center;flex-wrap:wrap">
               <span><b>${v1n}</b> of these were <b>already filed with your previous tool</b> (doc number known) — safe to clear together.
                 Anything the app genuinely couldn't confirm stays below for you to check one by one.</span>
               <button class="btn" style="padding:6px 12px;white-space:nowrap" onclick="resolveAllV1()">Mark all ${v1n} previous-tool receipts verified</button></div>` : ""}
            <div class="card" style="padding:0;overflow:hidden"><table><thead><tr><th>Guest / code</th><th>Dates</th>
              <th class="num">Total</th><th>Why it needs checking</th><th style="text-align:right">Action</th></tr></thead><tbody>
            ${rows.map(reconcileRow).join("")}</tbody></table></div>`}
      <div class="rowbtns"><button class="ghost btn" onclick="nav('capture')">← Back</button></div>`;
  },

  async selfcheck(c) {
    c.innerHTML = `<div style="display:flex;justify-content:space-between"><h1>Test setup</h1></div>
      <p class="sub">Checking your setup… this takes a few seconds (it does not log in to the Portal and files nothing).</p>
      <div class="center" style="min-height:120px"><div class="spin">Checking…</div></div>`;
    let d; try { d = await api("/selfcheck"); } catch { d = { error: "unreachable" }; }
    const err = d && d.error ? (d.detail || d.error) : null;
    const checks = err ? [] : (d.checks || []);
    const row = (ch) => `<div style="display:flex;gap:11px;align-items:center;border-top:1px solid var(--hair2);padding:13px 2px">
      <span style="font-size:17px;width:24px;text-align:center">${ch.ok ? "✅" : "⚠️"}</span>
      <div style="flex:1"><div style="font-weight:700">${esc(ch.label)}</div>
        <div style="color:var(--muted);font-size:12.5px">${esc(ch.detail || "")}</div></div></div>`;
    c.innerHTML = `<div style="display:flex;justify-content:space-between"><h1>Test setup</h1><button class="ghost btn" onclick="nav('selfcheck')">↻ Re-run</button></div>
      <p class="sub">A quick, safe check that everything is ready before you file — it does <b>not</b> log in to the Portal and files nothing. Run it after setup, and before handing the tool to a new person.</p>
      ${err
        ? `<div class="banner warn">Couldn't run the check (${esc(err)}). The app may still be starting — wait a moment and Re-run.</div>`
        : `${d.ready
              ? `<div class="banner green">✓ Everything looks ready — you can capture and file.</div>`
              : `<div class="banner warn">⚠ Not ready yet — fix the ⚠️ items below, then Re-run.</div>`}
           <div class="card" style="padding:2px 16px">${checks.map(row).join("")}</div>
           ${d.note ? `<p class="sub" style="margin-top:12px">${esc(d.note)}</p>` : ""}`}
      <div class="rowbtns" style="margin-top:14px;justify-content:space-between"><button class="ghost btn" onclick="nav('setup')">← Settings</button>
        <button class="dark btn" onclick="nav('capture')">Open Green Receipts →</button></div>`;
  },
};

/* ---------- small render helpers ---------- */
// Operator-facing text for a taxpayer that filed nothing. NEVER show the raw backend message for
// no_cred — it says "Run: python setup_taxpayer.py ..." (a developer command an operator can't use);
// point them at the in-app Setup/Settings screen instead. Falls back to the raw reason for anything
// unmapped (still prefixed with ⚠ so it never reads as success).
function skipText(t) {
  switch (t.result_code) {
    case "no_cred": return "⚠ No Portal password saved — open <b>Settings</b> and add this client's password";
    case "bad_credentials": return "⚠ Wrong Portal password — fix it in <b>Settings</b>";
    case "login_failed": return "⚠ Portal login failed — check the password in <b>Settings</b>";
    case "blocked": return "⚠ Portal login temporarily blocked — wait ~15 min, then retry";
    case "portal_error": return "⚠ Portal unreachable right now — retry next run";
    case "no_doc_number": return "⚠ Couldn't read the latest Portal document number — retry next run";
    case "emit_error": return "⚠ The app couldn't finish filing — retry next run";
    default: return "⚠ " + esc(t.skipped_reason || "skipped");
  }
}
function reconcileRow(r) {
  return `<tr id="rc_${r.row_id}"><td class="gp"><div class="g">${esc(r.guest || "—")}</div><div class="p mono">${esc(r.hm_code || "")}</div></td>
    <td>${stripTime(r.service_date || "")}${r.end_date ? "–" + stripTime(r.end_date) : ""}</td>
    <td class="num">${r.ttc && r.ttc !== "—" ? "€" + r.ttc : "–"}</td>
    <td style="font-size:11.5px;color:var(--muted);max-width:240px">${r.note || "unconfirmed at the Portal"}</td>
    <td style="text-align:right;white-space:nowrap"><a class="link" href="https://www.portaldasfinancas.gov.pt" target="_blank">Portal ↗</a>
      <button class="btn" style="padding:5px 10px;margin-left:8px" onclick="resolveRow('${r.row_id}')">Mark verified</button></td></tr>`;
}
function checkRow(state, title, sub, tag) {
  const circle = state === "done" ? `<span class="pill st-issued" style="width:28px;height:28px;justify-content:center;padding:0">✓</span>` :
    `<span class="step todo" style="padding:0"><span class="num">•</span></span>`;
  return `<div style="display:flex;gap:11px;align-items:flex-start;border-top:1px solid var(--hair2);padding:14px 0">
    ${circle}<div style="flex:1"><div class="t" style="font-weight:700">${title}</div><div class="s">${sub}</div></div>
    ${tag ? `<span class="pill st-issued">${tag}</span>` : ""}</div>`;
}
function captureResult(cap) {
  if (cap.error === "blocked_version") return `<div class="banner" style="margin-top:14px;background:#fde8e8;border:1px solid #f3c1c1;color:#8f1d22">⚠ ${esc(cap.detail || "")} Nothing was read or written.</div>`;
  if (cap.error) return `<div class="banner warn" style="margin-top:14px">Capture couldn't run (${cap.detail || cap.error}). Nothing was written — check the extension is installed and Chrome is open, then try again.</div>`;
  if (cap.status === "empty") return `<div class="banner warn" style="margin-top:14px">0 reservations returned — this is either an empty period or an expired session. Confirm manually before treating the period as done.</div>`;
  if (cap.status === "challenge") { nav("abchallenge"); return ""; }
  // Multi-tenant listing firewall refused the run (technical detail -> grv2.log + the sheet's LOG tab;
  // the operator only gets what to DO). wrong_account = the Chrome window that answered is signed in to
  // an Airbnb account with none of this app's rentals; no_listings = no rental is set up here yet.
  const h = S.health || {};
  const whose = h.instance_label ? `${esc(h.instance_label)}'s` : "your";
  if (cap.status === "wrong_account") {
    const num = h.instance_label && h.bridge_port
      ? ` If it happens again, click the <b>Green Receipts Bridge</b> icon in that Chrome window and check the connection number is <b>${esc(String(h.bridge_port))}</b>.` : "";
    return `<div class="banner warn" style="margin-top:14px"><b>Nothing was captured — Chrome is signed in to a different Airbnb account.</b>
      None of the stays Airbnb returned are for ${whose} rentals, so nothing was read further or saved.
      Open the Chrome window where you're signed in to ${whose} Airbnb account, then click <b>Capture now</b> again.${num}
      If a rental is missing from <b>Property Settings</b> in the Google Sheet, add it there, then click <b>Sync from Sheet</b> in Settings.</div>`;
  }
  if (cap.status === "no_listings") return `<div class="banner warn" style="margin-top:14px"><b>Nothing was captured — no rentals are set up yet.</b>
      Fill in ${whose} rentals in <b>Property Settings</b> in the Google Sheet, click <b>Sync from Sheet</b> in Settings, then capture again.</div>`;
  const wrote = cap.dry ? "Would write" : "Wrote";
  // Stays seen this run that were NOT sent on to be issued (Airbnb didn't give us the fee, a
  // suspect amount, a long stay, ...). Never a bare count and never "you can ignore this": each
  // one is named with its dates and deadline. They are in Review -> Needs review (unless saving
  // failed, which is said per stay) and are tried again on every capture.
  const flaggedN = cap.needs_review || 0;
  const flaggedBanner = flaggedN ? notIssuedBanner(cap) : "";
  // NON-BLOCKING completeness signals. Rehearsal feedback: the old amber banner + raw warning
  // text ("Airbnb didn't give us the payout total") read as "you MUST do something" to a
  // non-technical operator. It is an optional extra, so it renders as a quiet, COLLAPSED
  // note — the operator can ignore it entirely; the guide covers when it's worth opening.
  // It is NOT shown while any stay was left unissued: "everything was captured … ignore this"
  // next to a stay that got no receipt is exactly how a real stay went unnoticed (2026-11-10).
  const warnBanner = (!flaggedN && cap.warnings && cap.warnings.length)
    ? `<details style="margin-top:12px"><summary class="s" style="cursor:pointer;color:var(--muted)">ℹ Everything was captured. One optional extra exists — you can ignore this.</summary>
        <div class="banner" style="background:var(--hair3);color:var(--body);margin-top:8px;font-size:12.5px">
          If you ever want to double-check the capture against Airbnb's own statement (exact payout
          dates, nothing missed), the <b>Review</b> screen has an optional step for it:
          “<i>Optional: use the exact Airbnb payout dates</i>”. Your receipts file fine without it —
          the guide explains it if you're curious.
        </div></details>`
    : "";
  return `${flaggedBanner}${warnBanner}${cap.dry ? `<div class="banner purple" style="margin-top:14px"><b>Preview only — nothing was written.</b>
      Untick “Preview first” and capture again to write these stays for real; until then, Review will show 0.</div>` : ""}
    <div class="card" style="margin-top:14px"><div class="lbl2" style="margin-bottom:10px">${cap.dry ? "Preview result" : "Last run"}</div>
    <div>✓ Read <b>${cap.reservations_seen}</b> completed stays from Airbnb</div>
    ${(function () {
      const noFee = (Array.isArray(cap.flagged) ? cap.flagged : []).filter((f) => f.kind === "fee_unavailable").length;
      return noFee ? `<div>⚠ Airbnb did not give us the fee for <b>${noFee}</b> stay${noFee === 1 ? "" : "s"} — see above</div>`
                   : `<div>✓ Matched each stay's commission invoice</div>`;
    })()}
    <div>✓ ${wrote} <b>${cap.rows_ingested}</b> new rows · ${cap.skipped_seen || 0} already captured earlier${cap.needs_review ? ` · <b>${cap.needs_review}</b> flagged for review` : ""}</div>
    <div style="display:flex;justify-content:space-between;align-items:center;border-top:1px solid var(--hair2);margin-top:12px;padding-top:12px">
      <div class="sub" style="margin:0">These numbers are <b>this run</b> — Review shows everything currently waiting, including earlier captures.</div>
      ${cap.dry ? `<button class="dark btn" onclick="nav('capture')">Capture for real →</button>`
                : `<button class="dark btn" onclick="nav('review')">Continue to review →</button>`}</div></div>`;
}
/* Review with nothing listed. The green "All caught up" is shown ONLY when we know nothing is
   waiting: never while the review lane couldn't be loaded, and never after a capture that left
   stays unissued (the case where "all good" hid a real stay). */
function emptyReviewBanner(nr) {
  const cap = S.capture;
  const box = (cls, html) => `<div class="banner ${cls}" style="margin-bottom:14px">${html}</div>`;
  if (cap && cap.dry)
    return box("purple", `Nothing here yet because your last capture was a <b>preview</b> — it writes nothing. Go back and capture with “Preview first” unticked.`);
  if (nr && nr.error)
    return box("warn", `Nothing is ready to issue, but the list of stays that need a look couldn't be loaded. Click <b>↻ Refresh</b> before assuming everything is done.`);
  const flagged = cap && !cap.error ? (cap.needs_review || 0) : 0;
  if (flagged) {
    const fl = Array.isArray(cap.flagged) ? cap.flagged : [];
    const unsaved = fl.filter((f) => !f.saved).length + Math.max(0, flagged - fl.length);
    return unsaved
      ? box("warn", `⚠ Your last capture left <b>${unsaved}</b> stay${unsaved === 1 ? "" : "s"} <b>not issued</b> that couldn't be added to this list. Go back to <a class="link" href="#" onclick="nav('capture');return false">Capture</a> to see who, and capture again — they are tried again every time.`)
      : box("", `Nothing is waiting in this list right now. Your last capture flagged ${flagged} stay${flagged === 1 ? "" : "s"} — run <b>Capture</b> again to check on ${flagged === 1 ? "it" : "them"}.`);
  }
  return cap
    // A capture ran this session and nothing is waiting -> that's SUCCESS, not an error.
    ? box("green", `✓ <b>All caught up.</b> Your capture found no new stays to issue — everything already has its receipt. Nothing to do here.`)
    : box("warn", `Nothing is waiting to be issued right now. If stays finished recently, run a <b>Capture</b> to pick them up — stays already issued never reappear here.`);
}
/* The amber "not issued" banner on the capture screen: one line per stay (guest, dates, issue-by
   date, why) + a button to Review. Built from cap.flagged (backend.capture); falls back to the bare
   count when an older backend sent none. */
function notIssuedBanner(cap) {
  const n = cap.needs_review || 0;
  const fl = Array.isArray(cap.flagged) ? cap.flagged : [];
  const allFee = fl.length === n && fl.length > 0 && fl.every((f) => f.kind === "fee_unavailable");
  const s = n === 1 ? "" : "s";
  const head = allFee
    ? `${n} stay${s} could not be read from Airbnb and ${n === 1 ? "was" : "were"} <b>not issued</b>.`
    : `${n} stay${s} ${n === 1 ? "was" : "were"} <b>not issued</b> and need${n === 1 ? "s" : ""} a look.`;
  const lines = fl.map((f) => {
    const dates = stripTime(f.check_in ? f.check_in + (f.check_out ? " → " + f.check_out : "") : "");
    const by = f.issue_by ? ` · issue by <b>${esc(f.issue_by)}</b>` : "";
    const unsaved = (!cap.dry && !f.saved)
      ? `<div style="font-size:12px">⚠ This one couldn't be added to Review. It will be tried again on the next capture — note it down if the deadline is close.</div>` : "";
    return `<li style="margin:6px 0"><b>${esc(f.guest || f.hm_code || "A stay")}</b>${dates ? " · " + esc(dates) : ""}${by}
      <div style="font-size:12.5px">${esc(f.reason || "")}</div>${unsaved}</li>`;
  }).join("");
  const more = n > fl.length ? `<div style="font-size:12.5px;margin-top:4px">${n - fl.length} more — see Review.</div>` : "";
  return `<div class="banner" style="background:#fef3cd;color:#92400e;margin-top:14px">⚠ ${head}${cap.dry ? " (Preview — nothing was saved.)" : ""}
      ${lines ? `<ul style="margin:8px 0 0;padding-left:18px">${lines}</ul>` : ""}${more}
      ${cap.dry ? "" : `<div style="margin-top:10px"><button class="btn" style="padding:5px 12px;font-size:12.5px" onclick="nav('review')">Open Review →</button></div>`}</div>`;
}
// HTML-escape UNTRUSTED text (Airbnb guest / Details / listing, resolution reasons) before it goes into
// innerHTML — this is a local same-origin webview that can drive the backend to file real receipts, so a
// crafted guest name / Details must never inject markup. Applied at every render of attacker-influenced text.
function esc(s) {
  return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
// Sheet dates can carry a midnight timestamp (2026-04-30T00:00:00.000Z); the operator only needs the
// day. Strip any embedded ISO time from a date/range string (works on a pre-built "start → end" too).
const stripTime = (s) => String(s == null ? "" : s).replace(/T\d\d:\d\d(:\d\d)?(\.\d+)?Z?/g, "");
function enrich(rows) { return rows.map((r) => ({ status: "pending",
  guest: r.guest || "—", property: r.property || "—", ...r,
  dates: stripTime(r.dates || (r.service_date ? r.service_date + (r.end_date ? " → " + r.end_date : "") : "")) })); }
function nrToRow(r) {
  // A /needs-review row -> the reviewRow display shape. status = lane (needs_review|quarantine); the
  // review_reason shows as the note, the Airbnb `details` as a second muted line (classification context).
  return { row_id: r.row_id, status: r.lane, type: r.type || "", hm_code: r.hm_code, listing_id: r.listing_id_str,
    client_name: r.client_name, client_nif_masked: r.client_nif_masked, guest: r.guest || "—",
    property: r.property_label || r.listing_id_str || "—",
    dates: stripTime(r.check_in ? (r.check_in + (r.check_out ? " → " + r.check_out : "")) : ""),
    note: [(r.type && r.type !== "Reservation") ? r.type : "", r.review_reason].filter(Boolean).join(" · "),
    details: r.details || "", ttc: r.gross_earnings, payout: r.paid_out,
    issue_by: r.issue_by, days_left: r.days_left, urgency: r.urgency };
}
// The 5-business-day deadline badge (server-computed urgency). ADVISORY only — never gates a row; an
// overdue receipt shows red to PUSH toward issuing, it does not block it.
function deadlineBadge(r) {
  if (!r.issue_by) return `<span style="color:var(--muted)">—</span>`;
  const c = r.urgency === "overdue" ? "#a3282d" : r.urgency === "due_soon" ? "#7a5410" : "#0f6e4f";
  const bg = r.urgency === "overdue" ? "#fbecec" : r.urgency === "due_soon" ? "#fff7e6" : "#eaf6ef";
  const n = r.days_left;
  const label = r.urgency === "overdue" ? `overdue ${Math.abs(n)}d`
    : (n === 0 ? "due today" : `${n}d left`);
  return `<span title="Issue by ${esc(r.issue_by)} (5 business days after payout)" style="color:${c};background:${bg};padding:2px 8px;border-radius:10px;font-size:11px;white-space:nowrap">${label}</span>`;
}
const URG_RANK = { overdue: 0, due_soon: 1, ok: 2 };
/* The FILED figures, identical to the engine (emit_receipt.calculate_vat): base = round(ttc/1.06,2),
   total = round(base*1.06,2) [= importanciaRecebida, may differ from raw ttc by 1c], vat = total-base.
   Prefers the backend's already-computed values; derives only if the backend didn't send them. */
function amounts(r) {
  const rnd = (x) => Math.round(x * 100) / 100;
  const ttc = parseFloat(r.ttc), fee = parseFloat(r.fee);
  let base = (r.base !== undefined && r.base !== "") ? parseFloat(r.base) : (isNaN(ttc) ? NaN : rnd(ttc / 1.06));
  let total = (r.total !== undefined && r.total !== "") ? parseFloat(r.total) : (isNaN(base) ? NaN : rnd(base * 1.06));
  let vat = (r.vat !== undefined && r.vat !== "") ? parseFloat(r.vat) : ((isNaN(total) || isNaN(base)) ? NaN : rnd(total - base));
  let payout = (r.payout !== undefined && r.payout !== "") ? parseFloat(r.payout) : ((isNaN(ttc) || isNaN(fee)) ? NaN : rnd(ttc - fee));
  return { base, total, vat, fee, payout };
}
const eur = (v) => (v === null || v === undefined || v === "" || isNaN(parseFloat(v))) ? "—" : "€" + parseFloat(v).toFixed(2);
function sheetLink(label) {
  const u = S.health && S.health.sheet_url;
  return u ? `<a class="link" href="${u}" target="_blank"><span class="sq" style="background:#0f9d58"></span>${label} ↗</a>` : "";
}
function sheetBtn(label) {
  // Button-styled Google Sheet link for headers (the sheet is the source of truth for everything).
  const u = S.health && S.health.sheet_url;
  return u ? `<a class="ghost btn" href="${u}" target="_blank" style="text-decoration:none;white-space:nowrap"><span class="sq" style="background:#0f9d58;width:12px;height:12px;border-radius:3px;display:inline-block;margin-right:6px;vertical-align:-1px"></span>${label || "Open Google Sheet"} ↗</a>` : "";
}
// Plain-language lane labels. The internal status stays "quarantine" (CSS/filter/logic), but the operator
// sees "NEEDS SETUP" — a quarantine row means "your Property Settings aren't complete for this stay (map the
// listing / set the NIF / set the AL number)", which is a setup task, distinct from classifying a stay.
const LANE_LABEL = { pending: "READY", needs_review: "NEEDS REVIEW", quarantine: "NEEDS SETUP" };
function reviewRow(r) {
  const u = S.health && S.health.sheet_url;
  const action = r.status === "pending"
    ? (r.boundary ? `<label style="color:#8a6a10;font-weight:700;white-space:nowrap;cursor:pointer" title="Tick if you already issued this receipt by hand at the Portal, then use the banner button above"><input type="checkbox" class="bnd" data-rid="${esc(r.row_id)}" ${(S.boundaryTicks || []).indexOf(r.row_id) >= 0 ? "checked" : ""} onchange="toggleBoundaryTick('${esc(r.row_id)}', this.checked)" style="vertical-align:-2px"> filed by hand</label> · ` : "")
      + `<a class="link" href="#" onclick="openCorrect('${esc(r.row_id)}');return false" title="Fix a wrong guest name, date or amount BEFORE it is issued (checked + logged)">Correct</a>`
      + (u ? ` · <a class="link" href="${u}" target="_blank" title="Opens the GR tab — find the row by its Airbnb code">Sheet ↗</a>` : "")
    : r.status === "quarantine"
      ? `<a class="link" href="#" style="color:#553a97" onclick="openFix('${r.row_id}');return false" title="Finish this stay's Property Settings (map the listing / set the NIF / set the AL number)">Set up</a>`
      : (r.status === "needs_review" && /^reservation$/i.test(r.type || ""))
        // A parked BOOKING (fee not given by Airbnb, suspect amount, long stay, ...). If the operator
        // issued it by hand at the Portal, this records it so the app never issues it too.
        ? `<a class="link" href="#" style="color:#7a5410;font-weight:700" onclick="markParkedFiledByHand('${esc(r.row_id)}');return false" title="Only if you already issued this receipt yourself at the Portal">Filed by hand</a>`
          + (u ? ` · <a class="link" href="${u}" target="_blank" title="Opens the Google Sheet">Sheet ↗</a>` : "")
      : (u ? `<a class="link" href="${u}" target="_blank" style="color:#7a5410" title="An extra Airbnb payout (resolution/adjustment), not a normal booking. It is NOT filed automatically. Decide whether it's taxable income — if unsure, check with Laurent before including it.">Review ↗</a>` : "");
  const tint = r.status === "needs_review" ? "background:#fffdf7" : r.status === "quarantine" ? "background:#fdfbff" : "";
  const client = esc(displayName(r.client_name) || "Unassigned");
  const detail = r.details ? `<div class="p" style="color:var(--muted);font-style:italic">${esc(r.details)}</div>` : "";
  // Ready rows show the FILED total (VAT-computed); flagged rows show the RAW amount — the filing figure
  // isn't decided until the operator classifies them.
  const total = r.status === "pending"
    ? ((r.ttc && r.ttc !== "—") ? eur(amounts(r).total) : "–")
    : (r.ttc ? eur(r.ttc) : "–");
  return `<tr style="${tint}"><td><span class="pill st-${r.status}"><span class="dot"></span>${LANE_LABEL[r.status] || r.status.replace("_", " ").toUpperCase()}</span></td>
    <td class="gp"><div class="g">${client}</div><div class="p mono">${r.client_nif_masked ? "NIF " + esc(r.client_nif_masked) : ""}</div></td>
    <td class="gp"><div class="g">${esc(r.guest)}</div><div class="p">${esc(r.property)}${r.note ? " · " + esc(r.note) : ""}</div>${detail}</td>
    <td>${esc(r.dates)}</td><td>${deadlineBadge(r)}</td><td class="num">${total}</td><td style="text-align:right">${action}</td></tr>`;
}
function extPathRow() {
  const p = (S.paths && S.paths.extension_dir) || "";
  return p
    ? `<div style="display:flex;gap:8px;align-items:center;margin:6px 0"><code class="mono" id="extPath" style="background:#fff;border:1px solid var(--field);border-radius:6px;padding:5px 8px;font-size:12px;white-space:normal;word-break:break-all;flex:1;min-width:0">${p}</code>
       <button class="ghost btn" style="padding:5px 10px;font-size:12px;flex:0 0 auto" onclick="copyPath(this)">Copy</button></div>`
    : `<div style="margin:6px 0">the <b class="mono">airbnb_bridge\\extensao</b> folder inside the install folder
       <span class="sub">(Start menu → right-click Green Receipts → Open file location)</span></div>`;
}
function extInstallHelp({ detailsStyle, summaryClass, summaryStyle, summaryText, bannerExtra, tail }) {
  // The 3-step "Load unpacked" walkthrough shown on BOTH the Settings and Capture screens. The
  // instruction steps + extPathRow() are the shared, drift-prone core; each screen passes its own
  // chrome (details/summary styling & copy, banner font-size, closing line) so the rendered output
  // stays what each screen showed before this was extracted.
  return `<details style="${detailsStyle}"><summary class="${summaryClass}" style="${summaryStyle}">${summaryText}</summary>
    <div class="banner" style="background:var(--hair3);color:var(--body);margin:8px 0 0${bannerExtra}">
      1 · In Chrome, open <b class="mono">chrome://extensions</b> and switch on <b>Developer mode</b> (top right).<br>
      2 · Click <b>Load unpacked</b> and paste this folder path into the dialog:<br>
      ${extPathRow()}
      3 · The <b>Green Receipts Bridge</b> icon appears ${tail}${instancePortStep()}</div></details>`;
}
function instancePortStep() {
  // A named instance (a second deployment on this computer) pairs with ONE Chrome profile — the one
  // logged into ITS Airbnb account — by typing its port into that profile's extension popup.
  const h = S.health || {};
  if (!h.instance_label || !h.bridge_port) return "";
  const who = esc(h.instance_label);
  return `<br>4 · This computer has more than one Green Receipts. For <b>${who}</b>, do steps 1–3 in the Chrome window where
    you're signed in to <b>${who}'s Airbnb account</b> — its own Chrome profile (the round picture top-right in Chrome), not a
    private/incognito window. Then click the <b>Green Receipts Bridge</b> icon, type <b class="mono">${esc(String(h.bridge_port))}</b>
    in <b>Connection number</b> and click <b>Save</b>.`;
}
// Where the issued Fatura-Recibo PDFs land. Shown on the Settings screen and after a filing run,
// because a saved receipt the operator can't find is, to them, a receipt that wasn't saved.
function receiptsPathRow() {
  const p = (S.paths && S.paths.receipts_dir) || "";
  if (!p) return "";
  return `<div style="display:flex;gap:8px;align-items:center;margin:6px 0;flex-wrap:wrap">
    <code class="mono" id="receiptsPath" style="background:#fff;border:1px solid var(--field);border-radius:6px;padding:5px 8px;font-size:12px;white-space:normal;word-break:break-all;flex:1;min-width:220px">${p}</code>
    <button class="ghost btn" style="padding:5px 10px;font-size:12px;flex:0 0 auto" onclick="openFolder('receipts_dir', this)">Open folder</button>
    <button class="ghost btn" style="padding:5px 10px;font-size:12px;flex:0 0 auto" onclick="copyPath(this, 'receiptsPath')">Copy</button></div>`;
}
async function openFolder(which, btn) {
  // Best-effort: a refusal (folder not created yet / OS error) is SHOWN on the button, never silent.
  let r;
  try { r = await api("/setup/open/" + encodeURIComponent(which), { method: "POST" }); }
  catch (e) { r = { ok: false, detail: String(e) }; }
  if (r && r.ok) return;
  if (btn) {
    const was = btn.textContent;
    btn.textContent = (r && r.error === "not_yet") ? "Nothing filed yet" : "Couldn't open";
    btn.title = (r && (r.detail || r.error)) || "";
    setTimeout(() => { btn.textContent = was; }, 4000);
  }
}
async function copyPath(btn, id) {
  const node = el(id || "extPath");
  const txt = node ? node.textContent : "";
  try { await navigator.clipboard.writeText(txt); }
  catch { const ta = document.createElement("textarea"); ta.value = txt; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); }
  if (btn) btn.textContent = "Copied ✓";
}
// Clients section: existing taxpayers (per-row actions) + an inline "+ Add a client" form, one card.
function clientsCard(txs) {
  const rows = (txs || []).map((x) => `<tr>
    <td>${esc(displayName(x.name))}${x.cadastro_ok === false
      ? `<div style="font-size:11px;color:#b45309;white-space:nowrap">⚠ tax details missing</div>` : ""}</td><td class="mono">${esc(x.nif_masked || "")}</td><td class="mono">${esc(x.at_login || "—")}</td>
    <td style="text-align:right;white-space:nowrap">
      <button class="ghost btn" style="padding:4px 8px;font-size:12px" onclick="testLoginFor('${esc(x.taxpayer_id)}', this)">Test login</button>
      <button class="ghost btn" style="padding:4px 8px;font-size:12px" onclick="changePasswordFor('${esc(x.taxpayer_id)}')">Change password</button>
      <button class="ghost btn" style="padding:4px 8px;font-size:12px" onclick="refreshOneCadastro('${esc(x.taxpayer_id)}', this)">Refresh from Finanças</button></td></tr>`).join("");
  const list = (txs && txs.length)
    ? `<div class="card" style="padding:0;overflow-x:auto;margin:8px 0"><table><thead><tr><th>Name</th><th>NIF</th><th>Portal login</th><th style="text-align:right">Actions</th></tr></thead><tbody>${rows}</tbody></table></div>`
    : `<div class="banner" style="background:var(--hair3);color:var(--body);margin:8px 0">No clients yet — add the first one your firm files for.</div>`;
  const n = (txs && txs.length) || 0;
  // A client with blank tax details CANNOT file — say so here, with the fix path, instead of
  // letting the operator discover it as an "IVA regime not set" error at issue time.
  const broken = (txs || []).filter((x) => x.cadastro_ok === false);
  const brokenBanner = broken.length
    ? `<div class="banner" style="background:#fef3cd;color:#92400e;margin:8px 0">⚠ <b>${broken.map((x) => esc(displayName(x.name))).join(", ")}</b>:
        the address / IVA regime couldn't be read from Finanças when this client was added — usually the password was
        mistyped. Filing is <b>blocked</b> for them until fixed. <b>Fix:</b> click <b>Change password</b> and re-type it
        carefully — the app then signs in and fills the tax details automatically.</div>`
    : "";
  return `<div style="border-top:1px solid var(--hair2);margin-top:16px;padding-top:14px">
    <div style="font-weight:700;font-size:15px">Clients${n ? " (" + n + ")" : ""}</div>
    <div class="s" style="margin:2px 0 4px">The taxpayers your firm files for. Their address + IVA regime are read from Finanças automatically.</div>
    ${brokenBanner}
    ${list}
    <details ${n ? "" : "open"} style="margin-top:4px"><summary class="ghost btn" style="display:inline-block;cursor:pointer">${n ? "+ Add a client" : "Add your first client"}</summary>
      <div style="margin-top:12px"><div class="grid2">
        <div><span class="lbl2">NIF</span><input class="field mono" id="f_nif" placeholder="123456789"></div>
        <div><span class="lbl2">Portal username <span class="s">(usually just the NIF; add /n only if the client uses one)</span></span><input class="field mono" id="f_login" placeholder="123456789"></div>
        <div style="grid-column:1/3"><span class="lbl2">Portal password</span><input class="field" id="f_pw" type="password" placeholder="••••••••"></div></div>
      <div class="banner green" style="margin:12px 0 0">🔒 The password goes to Windows' encrypted password store, for your user only — never in a file.
        The client's <b>legal name, address and IVA regime are read straight from Finanças</b> — nothing to type, nothing to mistype.</div>
      <div class="rowbtns"><button class="btn" onclick="saveTaxpayer()">Save client</button></div></div></details>
    <div id="setupMsg" style="margin-top:8px"></div></div>`;
}

// Listings section: existing listing→client mappings (Sheet link) + an inline "+ Add a listing" form.
function listingsCard(props, txs) {
  const u = S.health && S.health.sheet_url;
  const rows = (props || []).map((p) => `<tr>
    <td>${esc(p.listing_name || "—")}<div class="mono" style="font-size:11px;color:var(--muted)">${esc(p.listing_id || "")}</div></td>
    <td>${esc(displayName(p.taxpayer_name))}</td><td class="mono">${esc(p.cae_code || "")}</td><td class="mono">${esc(p.al_number || "—")}</td>
    <td style="text-align:right">${u ? `<a class="link" href="${u}" target="_blank">Sheet ↗</a>` : ""}</td></tr>`).join("");
  const list = (props && props.length)
    ? `<div class="card" style="padding:0;overflow-x:auto;margin:8px 0"><table><thead><tr><th>Listing</th><th>Client</th><th>CAE</th><th>AL number</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`
    : `<div class="banner" style="background:var(--hair3);color:var(--body);margin:8px 0">No listings yet — they live in the Google Sheet. Click <b>Sync from Sheet</b> to bring them in.</div>`;
  const n = (props && props.length) || 0;
  const hasClients = (txs && txs.length) > 0;
  // Listings are added/edited in the SHEET only (single source of truth — the app copy is a
  // synced read-only cache). One button, no forms, no way for the two to diverge silently.
  return `<div style="border-top:1px solid var(--hair2);margin-top:16px;padding-top:14px">
    <div style="display:flex;justify-content:space-between;align-items:flex-start">
      <div><div style="font-weight:700;font-size:15px">Listings${n ? " (" + n + ")" : ""}</div>
        <div class="s" style="margin:2px 0 4px">Which client + activity each Airbnb listing files under.
          Add or edit listings in the Google Sheet's <b>Property Settings</b> tab, then sync.</div></div>
      <button class="ghost btn" style="white-space:nowrap" onclick="syncProperties(this)" ${hasClients ? "" : "disabled title='Add a client first — listings are matched to clients by NIF'"}>⟳ Sync from Sheet</button>
    </div>
    ${list}
    ${hasClients ? "" : `<div class="s" style="margin-top:4px">Add a client above first, then sync their listings from the Sheet.</div>`}</div>`;
}

// Friendly short label for a failed Portal sign-in kind (the full guidance is in r.message).
function loginKindLabel(kind) {
  return { blocked: "✗ locked — wait ~15–30 min", bad_credentials: "✗ wrong password",
           otp_required: "✗ needs a one-time code", portal_error: "✗ Portal unreachable",
           no_cred: "✗ no password saved" }[kind] || "✗ " + ((kind || "failed").replace(/_/g, " "));
}
async function testLoginFor(taxpayerId, btn) {
  const orig = btn.textContent; btn.disabled = true; btn.textContent = "Testing…";
  setSetupNotice(`<span class="spin">Checking the Portal sign-in for ${esc(txName(taxpayerId))}…</span>`);
  try {
    const r = await api("/setup/test-login/" + encodeURIComponent(taxpayerId));
    btn.textContent = r && r.ok ? "✓ Works" : loginKindLabel(r && r.kind);
    btn.style.color = r && r.ok ? "#1c6b3f" : "#9b2c2c";
    // Persistent verdict — stays on screen until the next action (the button text alone
    // reverted after 6s, which read as "Test login does nothing").
    if (r && r.ok) {
      setSetupNotice(`<span class="pill st-issued">✓ Portal sign-in works for ${esc(txName(taxpayerId))}</span>`);
    } else {
      setSetupNotice(`<span class="pill st-in_doubt">${esc(loginKindLabel(r && r.kind))} — ${esc(txName(taxpayerId))}</span>`
        + (r && r.message ? `<div class="s" style="margin-top:4px;color:#9b2c2c">${esc(r.message)}</div>` : ""));
    }
  } catch {
    btn.textContent = "✗ can't reach app"; btn.style.color = "#9b2c2c";
    setSetupNotice(`<span class="pill st-in_doubt">✗ Couldn't reach the app — nothing was checked</span>`);
  }
  setTimeout(() => { btn.disabled = false; btn.textContent = orig; btn.style.color = ""; btn.title = ""; }, 6000);
}
function txName(taxpayerId) {
  const tx = ((S.registry && S.registry.taxpayers) || []).find((t) => t.taxpayer_id === taxpayerId);
  return displayName((tx && tx.name) || taxpayerId);
}
/* Correct ONE field of a captured stay BEFORE it is issued — the window-app door to the
   audited override op (version-checked, logged in HISTORY, refused once filed). Only the
   fields an operator can sensibly judge are offered; the rest stay CLI-only. */
const CORRECT_FIELDS = [
  ["guest", "Guest name (as it should appear on the receipt)"],
  ["service_date", "Check-in date (YYYY-MM-DD)"],
  ["end_date", "Check-out date (YYYY-MM-DD)"],
  ["payment_date", "Airbnb payout date (YYYY-MM-DD)"],
  ["ttc", "Total amount, gross (e.g. 736.47)"],
];
/* The boundary stays currently offered for a decision. NOTE: /pending returns ONLY claimable
   rows (the flagged needs_review/quarantine lane is a separate endpoint), so every row here is
   already decidable — `boundary` is what makes it a switch-over decision. Do NOT filter on
   r.status here: that field does not exist on /pending rows, it is stamped later by enrich()
   when building S.reviewRows, so filtering on it silently matched nothing and disabled the
   guard entirely (caught by tests/test_ui_boundary.py). */
function boundaryRows() {
  return ((S.pending && S.pending.rows) || []).filter((r) => r.boundary);
}
function toggleBoundaryTick(rowId, on) {
  const t = new Set(S.boundaryTicks || []);
  if (on) t.add(rowId); else t.delete(rowId);
  S.boundaryTicks = [...t];
}
function toggleAllBoundary() {
  const ids = boundaryRows().map((r) => r.row_id);
  const allOn = ids.length > 0 && ids.every((id) => (S.boundaryTicks || []).indexOf(id) >= 0);
  S.boundaryTicks = allOn ? [] : ids;   // state-backed, so the re-render below repaints the ticks
  render();
}
/* A ticked "filed by hand" box is only a SELECTION until it is APPLIED (-> terminal VERIFIED,
   which is why applying needs a confirm). Read from STATE — not the checkbox DOM — so a filter
   chip or a Refresh can't silently drop the operator's decision. Ticks whose row is no longer
   claimable (handled elsewhere meanwhile) are dropped rather than applied to a stale row. */
function pendingBoundaryTicks() {
  const live = boundaryRows().map((r) => r.row_id);
  return (S.boundaryTicks || []).filter((id) => live.indexOf(id) >= 0);
}
/* The actual write. Callers own the confirm, so the nav guard doesn't double-prompt.
   Returns TRUE only if every row asked for was marked — the nav guard resumes on that. */
async function applyFiledByHand(rowIds) {
  // Marking is an audited two-step per row (park IN_DOUBT -> resolve VERIFIED, so each row is in
  // HISTORY twice) and EVERY serializer call takes the sheet's document lock, so this runs at
  // roughly 10 SECONDS PER ROW and cannot stream progress. Say so: 9 rows = ~90s of silence,
  // which reads as "Apply did nothing" — the operator then clicks again (seen live 2026-07-17,
  // row_version 4 = applied twice).
  const n = rowIds.length;
  showBusy(n > 1 ? "Marking " + n + " stays as filed by hand…" : "Marking 1 stay as filed by hand…",
    "Each one is recorded twice so it can be checked later, and the sheet takes them one at a time.\n\n"
    + "This takes about " + Math.max(10, Math.round(n * 10 / 5) * 5) + " seconds. Please leave the app open.");
  // The WRITE gets its own try: "Nothing was changed" may only ever be said when the write
  // itself failed. With refresh() inside the same try, a display-refresh hiccup AFTER the rows
  // were recorded fell into this catch and told the operator nothing changed — a lie the sheet
  // contradicts (review finding #24, 2026-07-17).
  let r;
  try {
    r = await api("/boundary/filed-manually", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ row_ids: rowIds, actor: (S.taxpayers[0] || {}).taxpayer_id || "operator" }) });
  } catch {
    closeModal();
    showAlert("Couldn't reach the app", "Nothing was changed — try again.");
    return false;
  }
  const marked = (r && r.marked) || [];
  if (marked.length) {
    const done = new Set(marked);   // applied -> no longer a pending tick (keeps any that failed)
    S.boundaryTicks = (S.boundaryTicks || []).filter((id) => !done.has(id));
    try { await refresh(); } catch {
      // The marks ARE recorded — say so honestly and still let the caller continue.
      closeModal();
      showAlert("Marked " + marked.length + " — the screen couldn't update",
        "The receipts were recorded. If the list looks unchanged, click ↻ Refresh.");
      return marked.length === n;
    }
  }
  closeModal();   // always drop the busy view before any verdict below
  if (r && r.failed && r.failed.length) {
    showAlert("Partly done", r.failed.length + " couldn't be marked — try again in a minute.");
    return false;
  }
  if (r && r.error && !marked.length) {
    showAlert("Nothing was changed", String(r.detail || r.error));
    return false;
  }
  return marked.length === n;
}
function markTickedFiledByHand() {
  const ids = pendingBoundaryTicks();
  if (!ids.length) { showAlert("Nothing ticked yet", "Tick “filed by hand” on each receipt you already issued yourself, then click again. Receipts you leave unticked will be filed by the app."); return; }
  markAllFiledByHand(ids);
}
function markAllFiledByHand(rowIds) {
  showConfirm(rowIds.length > 1 ? "Mark " + rowIds.length + " stays as filed by hand?" : "Mark this stay as filed by hand?",
    "Only for receipts you ALREADY issued yourself at the Portal, before switching to the app. They are settled for good — the app will never file them. (If unsure, Cancel and check the Portal first.)",
    "Yes — filed by hand", () => applyFiledByHand(rowIds));
}
/* A PARKED stay the operator issued by hand at the Portal -> recorded for good (the app never
   issues it, even if Airbnb gives us the fee on a later capture). Confirm first; the write is
   audited on the sheet. */
function markParkedFiledByHand(rowId) {
  showConfirm("Mark this stay as filed by hand?",
    "Only if you have ALREADY issued this receipt yourself at the Portal.\n\nThe app will then never issue it — even if Airbnb gives us the fee later. (If unsure, Cancel and check the Portal first.)",
    "Yes — filed by hand", async () => {
      showBusy("Marking 1 stay as filed by hand…", "This takes about 10 seconds. Please leave the app open.");
      let r;
      try {
        r = await api("/review/filed-by-hand", { method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ row_ids: [rowId], actor: (S.taxpayers[0] || {}).taxpayer_id || "operator" }) });
      } catch { closeModal(); showAlert("Couldn't reach the app", "Nothing was changed — try again."); return; }
      closeModal();
      if (r && r.marked && r.marked.indexOf(rowId) >= 0) {
        try { await refresh(); } catch { showAlert("Marked — the screen couldn't update", "The stay was recorded as filed by hand. Click ↻ Refresh."); }
        return;
      }
      const why = (r && r.failed && r.failed[0] && r.failed[0].detail) || (r && (r.detail || r.error)) || "unknown reason";
      showAlert("Nothing was changed", String(why));
    });
}
function openCorrect(rowId) {
  const r = ((S.pending && S.pending.rows) || []).find((x) => x.row_id === rowId);
  el("modalBox").innerHTML = `<h1 style="margin-top:0;font-size:19px">Correct this stay</h1>
    <p class="sub">${r ? esc(r.guest) + " · " + esc(r.service_date) + " · €" + esc(String(r.ttc)) : esc(rowId)}<br>
      Only stays <b>not yet issued</b> can be corrected. The change is checked and logged.</p>
    <span class="lbl2">What is wrong?</span>
    <select class="field" id="cor_field" style="width:100%">${CORRECT_FIELDS.map(([f, l]) =>
      `<option value="${f}">${l}</option>`).join("")}</select>
    <span class="lbl2" style="margin-top:8px;display:block">Correct value</span>
    <input class="field" id="cor_value" style="width:100%" placeholder="the right value">
    <div id="corMsg" class="s" style="margin:6px 0"></div>
    <div class="rowbtns" style="justify-content:flex-end">
      <button class="ghost btn" onclick="closeModal()">Cancel</button>
      <button class="btn" onclick="doCorrect('${esc(rowId)}')">Save correction</button></div>`;
  el("modal").style.display = "flex";
}
async function doCorrect(rowId) {
  const field = el("cor_field").value, value = (el("cor_value").value || "").trim();
  const msg = el("corMsg");
  if (!value) { msg.innerHTML = `<span style="color:#9b2c2c">Enter the correct value first.</span>`; return; }
  msg.innerHTML = `<span class="spin">Saving…</span>`;
  try {
    const r = await api("/fix/override", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ row_id: rowId, field, new_value: value, actor: (S.taxpayers[0] || {}).taxpayer_id || "operator" }) });
    if (r && r.ok) {
      closeModal();
      await refresh();   // Review re-renders with the corrected figure (live from the sheet)
    } else {
      msg.innerHTML = `<span style="color:#9b2c2c">${esc((r && (r.detail || r.error)) || "rejected")} — nothing was changed.</span>`;
    }
  } catch { msg.innerHTML = `<span style="color:#9b2c2c">Couldn't reach the app — nothing was changed.</span>`; }
}
function changePasswordFor(taxpayerId) {
  // Change an EXISTING client's Portal password from Settings. Masked input; saved to the
  // encrypted store, never a file. Files nothing at the Portal.
  el("modalBox").innerHTML = `<h1 style="margin-top:0;font-size:19px">Change Portal password</h1>
    <p class="sub">For <b>${esc(txName(taxpayerId))}</b>. Saved to Windows' encrypted password store — never to a file.</p>
    <input class="field" id="cpw" type="password" placeholder="New Portal password" style="width:100%;margin:6px 0">
    <div id="cpwMsg" class="s" style="margin:4px 0"></div>
    <div class="rowbtns" style="justify-content:flex-end">
      <button class="ghost btn" onclick="closeModal()">Cancel</button>
      <button class="btn" onclick="doChangePassword('${esc(taxpayerId)}')">Save password</button></div>`;
  el("modal").style.display = "flex";
  setTimeout(() => { const i = el("cpw"); if (i) i.focus(); }, 50);
}
async function doChangePassword(taxpayerId) {
  const pw = el("cpw") ? el("cpw").value : ""; const msg = el("cpwMsg");
  if (!pw) { if (msg) msg.innerHTML = `<span style="color:#9b2c2c">Enter the new password.</span>`; return; }
  if (msg) msg.innerHTML = `<span class="spin">Saving…</span>`;
  try {
    const r = await api("/setup/password/" + encodeURIComponent(taxpayerId), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ password: pw }) });
    if (r && r.ok) {
      closeModal();
      // Chain the Finanças refresh automatically: it signs in with the NEW password (so it IS
      // the login test — one AT attempt total) and fills/updates the tax details in the same
      // step. No separate "Test login" + "Refresh from Finanças" clicks needed after a change.
      setSetupNotice(`<span class="pill st-issued">✓ Password updated for ${esc(txName(taxpayerId))}</span>`
        + `<div class="s" style="margin-top:4px"><span class="spin">Checking it at Finanças and refreshing the tax details…</span></div>`);
      try {
        const rr = await api("/setup/refresh-cadastro/" + encodeURIComponent(taxpayerId), { method: "POST" });
        if (rr && rr.ok) {
          const ch = Object.keys(rr.changed || {});
          setSetupNotice(`<span class="pill st-issued">✓ Password works — signed in at Finanças${ch.length ? ` and updated ${ch.length} tax detail${ch.length > 1 ? "s" : ""}` : "; tax details already up to date"}</span>`);
          await refresh();
        } else {
          setSetupNotice(`<span class="pill st-issued">✓ Password saved</span> <span class="pill st-in_doubt">${esc(loginKindLabel(rr && rr.kind))}</span>`
            + (rr && rr.message ? `<div class="s" style="margin-top:4px;color:#9b2c2c">${esc(rr.message)}</div>` : ""));
        }
      } catch {
        setSetupNotice(`<span class="pill st-issued">✓ Password saved</span>`
          + `<div class="s" style="margin-top:4px">Couldn't check it at Finanças just now — use <b>Test login</b> on the row.</div>`);
      }
    }
    else if (msg) msg.innerHTML = `<span style="color:#9b2c2c">${esc((r && (r.detail || r.error)) || "rejected")}</span>`;
  } catch { if (msg) msg.innerHTML = `<span style="color:#9b2c2c">Couldn't reach the app — not saved.</span>`; }
}
async function refreshOneCadastro(taxpayerId, btn) {
  // Re-read ONE client's address + IVA regime from Finanças and update the app (read-only at the Portal).
  const orig = btn.textContent; btn.disabled = true; btn.textContent = "Reading…";
  try {
    const r = await api("/setup/refresh-cadastro/" + encodeURIComponent(taxpayerId), { method: "POST" });
    if (r && r.ok) {
      const ch = Object.keys(r.changed || {});
      // Set the persistent notice BEFORE refresh(): the re-render repaints it from S (the
      // button this function was called from no longer exists after the re-render).
      setSetupNotice(ch.length
        ? `<span class="pill st-issued">✓ ${esc(txName(taxpayerId))} updated from Finanças</span>`
          + `<div class="s" style="margin-top:4px">Updated: ${esc(fieldLabels(ch))}</div>`
        : `<span class="pill st-issued">✓ ${esc(txName(taxpayerId))} — already up to date with Finanças</span>`);
      await refresh();
    }
    else {
      btn.textContent = loginKindLabel(r && r.kind); btn.style.color = "#9b2c2c"; if (r && r.message) btn.title = r.message;
      setSetupNotice(`<span class="pill st-in_doubt">${esc(loginKindLabel(r && r.kind))} — couldn't read ${esc(txName(taxpayerId))}'s details from Finanças</span>`
        + (r && r.message ? `<div class="s" style="margin-top:4px;color:#9b2c2c">${esc(r.message)}</div>` : ""));
    }
  } catch {
    btn.textContent = "✗ can't reach app"; btn.style.color = "#9b2c2c";
    setSetupNotice(`<span class="pill st-in_doubt">✗ Couldn't reach the app — nothing was changed</span>`);
  }
  setTimeout(() => { btn.disabled = false; btn.textContent = orig; btn.style.color = ""; btn.title = ""; }, 6000);
}
function chip(k, label) { return `<span class="chip ${S.filter === k ? "on" : ""}" onclick="S.filter='${k}';render()">${label}</span>`; }
function summary(label, val, green) { return `<div class="card" style="flex:1;text-align:center"><div class="lbl2">${label}</div><div class="mono" style="font-size:26px;font-weight:700;color:${green ? "#1c6b3f" : "var(--ink)"}">${val}</div></div>`; }
function kv(k, v, mono) { return `<div style="margin-bottom:9px"><div class="lbl2">${k}</div><div class="${mono ? "mono" : ""}">${v}</div></div>`; }

/* ---------- actions (a backend failure is surfaced honestly, NEVER a fake success) ---------- */
async function saveTaxpayer() {
  const msg = el("setupMsg");
  if (!el("f_nif").value.trim() || !el("f_pw").value) {
    msg.innerHTML = `<span class="pill st-in_doubt">Fill in the NIF and password first</span>`;
    return;
  }
  // No name field: the legal name (and slug) come from Finanças server-side — the tax
  // authority's registration is what goes on receipts, so typing it here only added a
  // way to get it wrong. The username defaults to the NIF when left blank.
  const nifDigits = (el("f_nif").value || "0").replace(/\D/g, "");
  const body = { nif: parseInt(nifDigits) || 0,
    at_login_username: (el("f_login").value || "").trim() || nifDigits,
    password: el("f_pw").value };
  msg.innerHTML = `<span class="spin">Saving… (reading the client's registration from Portal das Finanças)</span>`;
  try {
    const r = await api("/setup/taxpayer", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    if (r && r.ok) {
      const c = r.cadastro || {};
      const detail = (c.morada_fiscal_prestador || c.estabelecimento_comercial)
        ? `<div class="s" style="margin-top:6px">Filled from AT — fiscal address (domicílio): `
          + `<b>${esc(c.morada_fiscal_prestador || "—")}</b>; establishment: <b>${esc(c.estabelecimento_comercial || "—")}</b>; `
          + `activity since: <b>${esc(c.data_inicio_atividade || "?")}</b>; IVA regime: <b>${esc(c.iva_regime || "?")}</b></div>`
        : "";
      // The AT-fetch warning is the MOST important part (a wrong password here means blank
      // tax details + blocked filings) — make it loud and tell the operator the fix path.
      const warn = r.warning
        ? `<div class="banner" style="background:#fef3cd;color:#92400e;margin-top:8px">⚠ ${esc(r.warning)}<br>`
          + `<b>What to do:</b> click <b>Change password</b> on the client's row (re-type it carefully), `
          + `then <b>Refresh from Finanças</b>. Filing stays blocked for this client until their tax details are filled.</div>`
        : "";
      const who = (r.cadastro && r.cadastro.nome_prestador) ? displayName(r.cadastro.nome_prestador) : r.taxpayer_id;
      setSetupNotice(`<span class="pill st-issued">✓ Saved · ${esc(who)}</span>${detail}${warn}`
        + (r.warning ? "" : `<div class="s" style="margin-top:4px">Now click <b>⟳ Sync from Sheet</b> below to bring in their listings.</div>`));
      await refresh();
    }
    else msg.innerHTML = `<span class="pill st-in_doubt">${esc((r && (r.detail || r.error)) || "rejected")}</span>`;
  } catch { msg.innerHTML = `<span class="pill st-in_doubt">Couldn't reach the app — not saved. Try again.</span>`; }
}
async function syncProperties(btn) {
  // One-way Sheet -> app listing sync. The Sheet's Property Settings tab is the only place
  // listings are added/edited; this refreshes the app's local copy and reports the delta.
  const orig = btn.textContent; btn.disabled = true; btn.textContent = "Syncing…";
  setSetupNotice(`<span class="spin">Reading Property Settings from the Google Sheet…</span>`);
  try {
    const r = await api("/setup/sync-properties", { method: "POST" });
    if (r && r.ok) {
      const bits = [];
      if ((r.added || []).length) bits.push(`<b>${r.added.length} added</b> (${r.added.map(esc).join("; ")})`);
      if ((r.updated || []).length) bits.push(`<b>${r.updated.length} updated</b> (${r.updated.map(esc).join("; ")})`);
      if ((r.deactivated || []).length) bits.push(`${r.deactivated.length} deactivated`);
      if (!bits.length) bits.push("already in sync — nothing changed");
      const warn = []
        .concat((r.skipped || []).map((s) => `⚠ skipped: ${esc(s)}`))
        .concat((r.local_only || []).map((s) => `⚠ ${esc(s)} exists in the app but not in the sheet — remove or re-add it in the sheet`));
      setSetupNotice(`<span class="pill st-issued">✓ Listings synced from the Sheet</span>`
        + `<div class="s" style="margin-top:4px">${bits.join(" · ")}</div>`
        + (warn.length ? `<div class="s" style="margin-top:4px;color:#92400e">${warn.join("<br>")}</div>` : ""));
      await refresh();
    } else {
      setSetupNotice(`<span class="pill st-in_doubt">✗ Sync failed — ${esc((r && (r.detail || r.error)) || "unknown")}</span>`
        + `<div class="s" style="margin-top:4px">Nothing was changed. Try again in a minute.</div>`);
    }
  } catch {
    setSetupNotice(`<span class="pill st-in_doubt">✗ Couldn't reach the app — nothing was changed</span>`);
  }
  btn.disabled = false; btn.textContent = orig;
}

// Retry entry point for the "abchallenge" (Airbnb signed-out) screen: navigate back to the
// Capture screen (so its DOM — capBtn/dry/capNote — and the result banner are in place), THEN
// call the SAME doCapture() the "Capture now" button uses. Nothing new is invented here.
async function retryCaptureAfterAirbnbSignIn() {
  S.screen = "capture";
  await render();
  doCapture();
}
/* 8c — capture without being asked. Once per app start: if the last capture is more than 24 hours
   old (and the admin has not switched this off), and the extension answered the check on the Capture
   screen, run the SAME capture as the "Capture now" button. It only reads stays from Airbnb and adds
   them to Review — it never issues a receipt. The backend re-checks every condition. */
async function maybeAutoCapture() {
  if (S.autoCaptureTried) return;
  S.autoCaptureTried = true;
  let st; try { st = await api("/capture/auto/status"); } catch { return; }
  if (!st || !st.due) return;
  if (S.extCheckPromise) { try { await S.extCheckPromise; } catch { /* treated as not connected */ } }
  if (!(S.extCheck && S.extCheck.connected)) return;
  if (S.screen !== "capture") return;   // the operator moved on: leave it to the button
  await doCapture({ auto: true });
}
function autoCaptureNote(state) {
  const box = el("autoCapNote"); if (!box) return;
  if (state === "running") {
    box.innerHTML = `<div class="banner purple">Your last capture was more than a day ago, so the app is capturing now by itself. It only reads stays from Airbnb — nothing is issued. The summary appears below when it finishes.</div>`;
    const b = el("capBtn"); if (b) { b.disabled = true; b.innerHTML = `<span class="spinner"></span>Reading from Airbnb…`; }
  } else if (state === "done") {
    box.innerHTML = `<div class="sub" style="margin:0 0 10px">The app ran this capture by itself because the last one was more than a day ago. Nothing was issued.</div>`;
  } else box.innerHTML = "";
}
/* Red banner on the first screen: every stay that was NOT issued and has fewer than 2 working days left
   before its issue-by date (or is already late). From Review's list (backend.urgent_parked) plus any
   stay this session's capture could not add to Review. */
async function loadUrgentBanner() {
  if (!el("urgentBanner")) return;
  let u; try { u = await api("/needs-review/urgent"); } catch { u = null; }
  const limit = (u && u.threshold) || 2;
  const rows = (u && !u.error && Array.isArray(u.rows)) ? u.rows.slice() : [];
  const fl = (S.capture && !S.capture.dry && Array.isArray(S.capture.flagged)) ? S.capture.flagged : [];
  for (const f of fl) {
    if (f.saved || f.days_left === null || f.days_left === undefined || f.days_left >= limit) continue;
    if (rows.some((r) => r.hm_code && r.hm_code === f.hm_code)) continue;
    rows.push({ hm_code: f.hm_code, guest: f.guest, check_in: f.check_in, check_out: f.check_out,
                issue_by: f.issue_by, days_left: f.days_left, review_reason: f.reason, unsaved: true });
  }
  const box = el("urgentBanner"); if (!box) return;
  if (!rows.length) { box.innerHTML = ""; return; }
  const n = rows.length, s = n === 1 ? "" : "s";
  const left = (d) => d < 0 ? `<b>late</b> — the deadline has passed` : d === 0 ? `<b>due today</b>` : `<b>${d} working day${d === 1 ? "" : "s"} left</b>`;
  const lines = rows.map((r) => {
    const dates = stripTime(r.check_in ? r.check_in + (r.check_out ? " → " + r.check_out : "") : "");
    return `<li style="margin:6px 0"><b>${esc(r.guest || r.hm_code || "A stay")}</b>${dates ? " · " + esc(dates) : ""} · issue by <b>${esc(r.issue_by || "")}</b> · ${left(Number(r.days_left))}
      ${r.review_reason ? `<div style="font-size:12.5px">${esc(r.review_reason)}</div>` : ""}${r.unsaved ? `<div style="font-size:12px">This one is not in Review — note it down.</div>` : ""}</li>`;
  }).join("");
  box.innerHTML = `<div class="banner" style="background:#fde8e8;border:1px solid #f3c1c1;color:#8f1d22">⚠ <b>${n} stay${s} ${n === 1 ? "has" : "have"} no receipt yet and ${n === 1 ? "is" : "are"} due very soon.</b>
    <ul style="margin:8px 0 0;padding-left:18px">${lines}</ul>
    <div style="font-size:12.5px;margin-top:8px">Run <b>Capture</b> to try again. If the deadline is close, issue the receipt by hand on the Portal and mark it “filed by hand” in Review.</div>
    <div style="margin-top:10px"><button class="btn" style="padding:5px 12px;font-size:12.5px" onclick="nav('review')">Open Review →</button></div></div>`;
}
async function doCapture(opts) {
  const auto = !!(opts && opts.auto);
  const b = el("capBtn"); if (b) { b.disabled = true; b.innerHTML = `<span class="spinner"></span>Reading from Airbnb…`; }
  const note = el("capNote"); if (note) note.style.display = "block";
  if (auto) { S.autoCapture = { running: true }; autoCaptureNote("running"); }
  // Show it's WORKING (elapsed seconds), not frozen, during the paced Airbnb read. Display-only;
  // polls a sibling endpoint while /capture blocks, and stops the moment it returns.
  const poll = setInterval(async () => {
    try { const p = await api("/capture/progress");
      if (p && p.running && el("capBtn")) el("capBtn").innerHTML = `<span class="spinner"></span>Reading from Airbnb… (${p.elapsed}s)`;
    } catch {}
  }, 1000);
  // The automatic capture is never a preview (a preview writes nothing, so it would heal nothing).
  const dryEl = el("dry"); const dry = auto ? false : (dryEl ? dryEl.checked : false); const acct = (S.taxpayers[0] || {}).taxpayer_id || "my-airbnb";
  let res;
  try { res = await api(auto ? "/capture/auto" : "/capture", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ account: acct, dry_run: dry }) }); }
  catch { res = { error: "unreachable" }; }
  finally { clearInterval(poll); }
  if (auto) {
    S.autoCapture = { running: false, done: !!(res && res.started) };
    if (!(res && res.started)) { render(); return; }   // not due after all (the backend re-checked): no change
  }
  S.capture = res;
  if (S.capture && !S.capture.error) S.capture.dry = dry;
  S.captureAt = new Date().toLocaleString("en-GB", { day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" });
  render();
}
// Pre-flight: briefly ask the backend to start the bridge and see if the Chrome extension connects, so
// the operator knows the extension is ready BEFORE clicking Capture. Disables Capture while checking (the
// probe holds the bridge port), then shows ✓ / ✗-with-Re-check. Reads nothing from Airbnb.
async function checkExtension() {
  const s = el("extStatus"), btn = el("capBtn");
  if (!s) return;
  // Reuse a recent SUCCESS (< 60s) so navigating back to Capture doesn't re-run the up-to-12s
  // bridge probe. A prior failure/unknown is ALWAYS re-checked (the operator may have just
  // installed/reloaded the extension). The real Capture re-establishes the bridge regardless.
  const c = S.extCheck;
  if (c && c.connected && (Date.now() - c.at) < 60000) {
    s.innerHTML = `<span style="color:#0f6e4f;font-weight:700">✓ Extension connected</span>`;
    if (btn) btn.disabled = false;
    return;
  }
  s.innerHTML = `<span style="color:var(--muted)"><span class="spinner"></span> Checking the extension…</span>`;
  if (btn) btn.disabled = true;
  let r; try { r = await api("/bridge/check"); } catch (e) { r = { connected: null, detail: String(e) }; }
  if (btn) btn.disabled = false;
  if (!el("extStatus")) return;  // operator navigated away while checking
  if (r && r.connected) {
    S.extCheck = { at: Date.now(), connected: true };
    el("extStatus").innerHTML = `<span style="color:#0f6e4f;font-weight:700">✓ Extension connected${r.stale ? " — an update is available" : ""}</span>`;
  } else if (r && r.connected === null) {
    el("extStatus").innerHTML = `<span class="sub" style="margin:0">${esc(r.detail || "couldn't check right now")}</span>`;
  } else {
    const stale = r && r.reason === "stale";
    const head = stale ? "✗ Extension out of date." : "✗ Extension not detected.";
    const act = stale ? "Reload it in chrome://extensions (Update), then" : "Open Chrome and load it (see below), then";
    el("extStatus").innerHTML = `<span style="color:#a3282d;font-weight:700">${head}</span> <span class="sub" style="margin:0">${act}</span> <a class="link" href="#" onclick="checkExtension();return false" style="color:#a3282d;font-weight:600">Re-check</a>`;
  }
}
function openFix(rowId) {
  // The Fix screen MAPS an unmapped listing -> it's quarantine-only. Guard so a needs_review row (which
  // needs classification, not listing-mapping) can never be routed into it.
  const r = (S.reviewRows || []).find((x) => x.row_id === rowId) || null;
  if (!r || r.status !== "quarantine") { nav("review"); return; }
  S.fixRow = r; nav("fix");
}
// Stage F: drop the Airbnb Transaction-History CSV to set each receipt's EXACT payout date (the extension's
// check-in+1 is only ~52% accurate) and surface any unmatched income. Reads the file locally; only pending
// dates are corrected; NON-BLOCKING.
function pickCsv() { const i = el("csvFile"); if (i) i.click(); }
async function applyCsvFile(input) {
  const f = input.files && input.files[0];
  if (!f) return;
  const msg = el("csvMsg");
  const set = (h) => { if (msg) { msg.style.display = "block"; msg.innerHTML = h; } };
  set(`<span class="sub">Reading ${esc(f.name)}…</span>`);
  let text;
  try { text = await f.text(); } catch { set(`<span class="banner warn" style="display:block">Couldn't read that file.</span>`); return; }
  input.value = "";
  try {
    const r = await api("/apply-csv", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ csv_text: text }) });
    if (r.error) { set(`<span class="banner warn" style="display:block">Couldn't apply the CSV (${esc(r.detail || r.error)}). Nothing was changed.</span>`); return; }
    const failed = (r.correct_failed && r.correct_failed.length) ? ` · <b>⚠ ${r.correct_failed.length} couldn't be corrected — Refresh and retry</b>` : "";
    const gap = r.signal ? ` · <b>⚠ ${esc(r.signal)}</b>` : "";
    const touched = (r.dates_corrected || 0) + (r.dates_unchanged || 0) + ((r.correct_failed && r.correct_failed.length) || 0);
    // "0 corrected, 0 already exact" with nothing waiting looked like the import silently failed —
    // say plainly that there was nothing to correct (the CSV itself was read fine).
    set(touched === 0
      ? `<span class="banner" style="display:block;background:var(--hair3);color:var(--body)">The file was read fine — but <b>no receipts are waiting for a date</b> right now, so there was nothing to correct${gap}. Use this after a capture, before you issue.</span>`
      : `<span class="banner" style="display:block;background:var(--hair3);color:var(--body)">✓ Set <b>${r.dates_corrected}</b> receipt${r.dates_corrected === 1 ? "" : "s"} to the exact payout date (${r.dates_unchanged} already exact)${failed}${gap}. Refreshing…</span>`);
    if (touched > 0) setTimeout(refresh, 1000);
  } catch { set(`<span class="banner warn" style="display:block">Couldn't reach the app.</span>`); }
}
async function saveFix() {
  const msg = el("fixMsg");
  if (!el("fx_tp").value || !el("fx_id").value.trim()) {
    if (msg) msg.innerHTML = `<span class="pill st-in_doubt">Pick the taxpayer and confirm the listing id first</span>`;
    return;
  }
  if (msg) msg.innerHTML = `<span class="spin">Mapping the listing…</span>`;
  const cae = el("fx_cae").value;
  try {
    // Map the listing (adds the property), then re-route the quarantined row so it can file.
    const r = await api("/setup/listing", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ listing_id: el("fx_id").value.trim(), taxpayer_id: el("fx_tp").value,
        cae_code: cae, cae_descr: caeDescr(cae), al_number: el("fx_al").value.trim(), listing_name: el("fx_name").value.trim() }) });
    if (!(r && r.ok)) { if (msg) msg.innerHTML = `<span class="pill st-in_doubt">${(r && (r.detail || r.error)) || "rejected"}</span>`; return; }
    try { await api("/fix/reroute", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ row_id: (S.fixRow || {}).row_id }) }); } catch {}
    await refresh(); nav("review");
  } catch { if (msg) msg.innerHTML = `<span class="pill st-in_doubt">Couldn't reach the app — not saved. Try again.</span>`; }
}
function openIssueModal() {
  // Only the rows that will ACTUALLY file (firewall pre-check from RENDER.issue) — the headline
  // count is the truth, straight from the sheet, not the whole pending pool.
  const ready = (S.preview && S.preview.will_file) || [];
  const skipped = (S.preview && S.preview.skipped_v1_count) || 0;
  const total = ready.reduce((a, r) => { const t = amounts(r).total; return a + (isNaN(t) ? 0 : t); }, 0);
  el("modalBox").innerHTML = `<span class="pill st-in_doubt">● IRREVERSIBLE ACTION</span>
    <h1 style="margin-top:10px">You're about to file ${ready.length} real Fatura-Recibo at Portal das Finanças.</h1>
    <p class="sub">Check the amounts below before continuing. VAT 6% (reduced) · Alojamento Local.${skipped ? ` <b>${skipped}</b> already-filed stay${skipped === 1 ? " is" : "s are"} not listed.` : ""}</p>
    ${ready.map((r) => {
      const a = amounts(r);
      const dates = stripTime(r.dates || ((r.service_date || "") + (r.end_date ? " → " + r.end_date : "")));
      return `<div class="rc"><div style="display:flex;justify-content:space-between"><div><b>${esc(r.guest || "—")}</b>${r.client_name && r.client_name !== "—" ? ` <span class="sub" style="margin:0">→ ${esc(displayName(r.client_name))}</span>` : ""}</div><b class="mono">${eur(a.total)}</b></div>
      <div class="mono" style="font-size:11px;color:var(--muted)">Alojamento Local · ${esc(dates)} · ${esc(r.hm_code)}</div>
      <div class="met"><div>Base value<b>${eur(a.base)}</b></div>
        <div>VAT (6%)<b>${eur(a.vat)}</b></div>
        <div>Host payout<b>${eur(a.payout)}</b></div>
        <div>Airbnb fee<b>${eur(a.fee)}</b></div></div></div>`; }).join("")}
    <div style="display:flex;justify-content:space-between;align-items:center;border-top:1px solid var(--hair2);margin-top:10px;padding-top:12px">
      <div class="sub" style="margin:0">Total to report <b class="mono" style="color:var(--ink)">€${total.toFixed(2)}</b></div>
      <div><button class="ghost btn" onclick="closeModal()">Cancel</button> <button class="danger btn" id="issueGo" ${ready.length ? "" : "disabled"} onclick="doEmit()">Issue ${ready.length} receipt${ready.length === 1 ? "" : "s"} now</button></div></div>
    <p class="sub" style="text-align:right;margin:10px 0 0">Each receipt is checked at the Portal before filing, never issued twice.</p>`;
  el("modal").style.display = "flex";
}
function closeModal() { el("modal").style.display = "none"; }
async function doEmit() {
  const b = el("issueGo"); if (b) { b.disabled = true; b.textContent = "Filing…"; }
  showEmitProgress();                              // swap the modal to a live progress view
  const poll = setInterval(pollEmitProgress, 1000); // /emit blocks; /emit/progress runs on a sibling thread
  const tp = S.issueScope || "all";   // "all" clients or the one picked on the Issue screen
  try { S.issue = await api("/emit", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ taxpayer: tp, confirmed: true }) }); }
  catch {
    clearInterval(poll);
    // A network failure must NEVER be reported as a successful filing (no fabricated count).
    closeModal();
    showAlert("Nothing was filed", "Couldn't reach the app to file — check the app is running and try again.");
    return;
  }
  clearInterval(poll);
  closeModal();
  if (S.issue.login_challenge) { nav("otp"); return; }   // GENUINE 2FA / Chave Movel -> sign in, then retry
  if (S.issue.login_problem) {   // a login problem that is NOT 2FA — show the honest reason
    const p = S.issue.login_problem;
    const msg = {
      blocked: "Your Portal sign-in is temporarily blocked after too many attempts. Wait ~15–30 minutes, then try again.",
      bad_credentials: "Portal das Finanças rejected your sign-in. Open Settings and re-enter your Portal password, then try again.",
      portal_error: "Couldn't complete sign-in at Portal das Finanças (it may be busy or temporarily unavailable). Try again shortly.",
    }[p.kind] || ("Sign-in problem: " + (p.detail || p.kind));
    showAlert("Stopped safely — nothing was filed", msg + (p.detail ? "\n\nPortal said: " + p.detail : ""));
    return;
  }
  if (S.issue.busy) { nav("busy"); return; }
  if (S.issue.error === "blocked_version") { showAlert("Issue is switched off — nothing was filed", S.issue.detail || ""); return; }
  if (S.issue.error) {
    // Transient Google/Apps Script blip (serializer_unavailable) -> plain language for the operator;
    // the technical detail stays in the app logs. Any OTHER error still shows its detail (never hide a cause).
    const friendly = (S.issue.error === "serializer_unavailable")
      ? "Google's service was briefly unavailable, so nothing was filed. Please wait a minute and try again."
      : ((S.issue.detail || S.issue.error) + ". Nothing was lost.");
    showAlert("Stopped safely — nothing was filed", friendly);
    return;
  }
  nav("done");
}

function showEmitProgress() {
  const box = el("modalBox"); if (!box) return;
  S.emitStopping = false;
  box.innerHTML = `<span class="pill st-in_doubt">● FILING AT PORTAL DAS FINANÇAS</span>
    <h1 style="margin-top:10px">Filing your receipts…</h1>
    <p class="sub">Each one is submitted to Portal das Finanças — this can take a moment per receipt. Keep this window open.</p>
    <div style="margin:18px 0 8px;height:10px;background:var(--hair2);border-radius:99px;overflow:hidden">
      <div id="emitBar" style="height:100%;width:4%;background:#0f6e4f;transition:width .4s"></div></div>
    <div id="emitProgTxt" class="sub" style="margin:0">Starting…</div>
    <div class="rowbtns" style="justify-content:flex-end;margin-top:14px">
      <button class="ghost btn" id="emitStopBtn" onclick="doStopEmit()">Stop</button></div>`;
}
async function doStopEmit() {
  // Stop AFTER the current receipt — never interrupt one mid-submit (the backend checks the flag
  // between rows). The receipts already filed stay filed; nothing new starts.
  S.emitStopping = true;
  const b = el("emitStopBtn"); if (b) { b.disabled = true; b.textContent = "Stopping…"; }
  try { await api("/emit/cancel", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" }); } catch { /* the run finishes on its own */ }
}
async function pollEmitProgress() {
  let p; try { p = await api("/emit/progress"); } catch { return; }
  const bar = el("emitBar"), txt = el("emitProgTxt");
  if (!bar || !p) return;
  // Denominator = the receipts that WILL file (from the Issue preview), not the claimable pool the
  // firewall skips — so "Filing 3 of 4" matches the button, never "of 25".
  const total = (S.preview && S.preview.will_file && S.preview.will_file.length) || p.total || 0;
  const done = total ? Math.min(p.done || 0, total) : (p.done || 0);
  bar.style.width = (total ? Math.max(4, Math.round(done / total * 100)) : (p.running ? 8 : 100)) + "%";
  const stop = S.emitStopping ? ` <b>· stopping after this one…</b>` : "";
  if (txt) txt.innerHTML = (total
    ? `Filing <b>${done}</b> of <b>${total}</b>${p.current ? ` · ${esc(p.current)}` : ""}${p.taxpayer ? ` <span style="color:var(--muted3)">(${esc(p.taxpayer)})</span>` : ""}`
    : (p.running ? "Filing…" : "Finishing…")) + stop;
}
function resolveRow(rowId) {
  showConfirm("Mark this receipt verified?",
    "Only do this AFTER you've checked the Portal for this receipt.", "Mark verified", async () => {
      try {
        const r = await api("/indoubt/resolve", { method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ row_id: rowId, actor: (S.taxpayers[0] || {}).taxpayer_id || "operator" }) });
        if (r && (r.ok || r.verified)) { const tr = el("rc_" + rowId); if (tr) tr.remove(); }
        else showAlert("Couldn't mark it verified", ((r && (r.detail || r.error)) || "unknown") + ". Nothing was changed.");
      } catch { showAlert("Couldn't reach the app", "Nothing was changed — try again."); }
    });
}

function resolveAllV1() {
  showConfirm("Clear the previous-tool receipts?",
    "These were already filed with your previous tool (their document number is known), so this only clears them from the list — it never re-issues anything.",
    "Mark all verified", async () => {
      try {
        const r = await api("/indoubt/resolve-v1", { method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ actor: (S.taxpayers[0] || {}).taxpayer_id || "operator" }) });
        if (r && r.error) { showAlert("Couldn't clear them", (r.detail || r.error) + ". Nothing was changed."); return; }
        if (r && r.failed && r.failed.length) showAlert("Partly cleared", r.resolved + " cleared; " + r.failed.length + " couldn't be cleared and stay in the list.");
        nav("reconcile");   // reload — cleared rows drop off; genuine-ambiguity rows remain for per-row checks
      } catch { showAlert("Couldn't reach the app", "Nothing was changed — try again."); }
    });
}

/* ---------- boot ---------- */
(async function boot() {
  const h = await health();
  S.health = h || {};
  if (h && h.instance_label) document.title = `Green Receipts — ${h.instance_label}`;
  if (!h) return notConnected("The app service isn't reachable. Close and reopen Green Receipts.");
  if (h.configured === false) return notConnected();   // up but no creds -> clear screen, not fake data
  try {
    const d = await api("/taxpayers");
    if (d && d.error) return notConnected(d.detail || d.error);
    S.taxpayers = (d && d.taxpayers) || [];
  } catch { return notConnected("Couldn't read your taxpayers. Try Refresh, or reopen the app."); }
  // Open to the MAIN flow when already set up; a fresh machine (no taxpayer) starts on Setup.
  S.screen = (S.taxpayers && S.taxpayers.length) ? "capture" : "setup";
  await render();
  // Self-update lines (quiet; nothing when the updater is off). Re-read every 10 minutes so
  // "update ready" / a withdrawn version shows up without reopening the window.
  loadUpdateStatus();
  setInterval(loadUpdateStatus, 10 * 60 * 1000);
  // 8c: capture by itself when the last capture is more than a day old (never issues anything).
  if (S.screen === "capture") maybeAutoCapture();
})();
