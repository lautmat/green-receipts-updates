"""app/main.py — launcher: start the local API (127.0.0.1) in a thread, then open a native
window pointing at it (pywebview if available, else the default browser). This is the .exe
entry point once packaged; it reads config.bat's GRV2_EXEC/GRV2_TOKEN from the environment,
exactly like the .bat flow.

SAFETY: the app launches via pythonw (no console), so anything printed during a run would
otherwise be discarded — including emitter.recordInDoubt's CRITICAL "park this row by hand"
recovery instructions, whose loss is the one path to a silent duplicate real receipt. So we
redirect stdout+stderr to a persistent app.log FIRST, and surface fatal errors in a MessageBox
instead of failing invisibly."""
from __future__ import annotations

import os
import sys
import threading
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import instance  # noqa: E402 — per-instance port / app-data dir / window title (GR_INSTANCE)

HOST = "127.0.0.1"


def app_log_path() -> Path:
    """%APPDATA%\\Green Receipts[\\<instance>]\\app.log (falls back to the home dir)."""
    try:
        d = instance.appdata_dir()
    except instance.InstanceConfigError:
        d = Path(os.environ.get("APPDATA") or str(Path.home())) / "Green Receipts"
    d.mkdir(parents=True, exist_ok=True)
    return d / "app.log"


def _title() -> str:
    try:
        return instance.display_name()
    except instance.InstanceConfigError:
        return "Green Receipts"


def _init_file_logging() -> Path | None:
    """Redirect stdout+stderr to app.log so NOTHING printed during a run is lost under the
    console-less pythonw launcher — most importantly emitter.recordInDoubt's by-hand recovery
    steps. Best-effort: never blocks or fails startup."""
    try:
        logf = app_log_path()
        try:  # crude size cap so it can't grow unbounded
            if logf.exists() and logf.stat().st_size > 5_000_000:
                logf.write_text("", encoding="utf-8")
        except Exception:
            pass
        f = open(logf, "a", encoding="utf-8", buffering=1)  # line-buffered text
        sys.stdout = f
        sys.stderr = f
        from datetime import datetime
        print(f"\n===== {_title()} started {datetime.now():%Y-%m-%d %H:%M:%S} "
              f"(pid {os.getpid()}) =====", flush=True)
        return logf
    except Exception:
        return None


def _msgbox(text: str, title: str = "Green Receipts", icon: int = 0x40) -> None:
    """A native message box (ctypes) so a console-less failure is still visible to the operator.
    icon 0x40 = info, 0x10 = error. Best-effort."""
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, text, title, icon)
    except Exception:
        pass


def _serve():
    import uvicorn
    uvicorn.run("app.service:app", host=HOST, port=instance.app_port(), log_level="warning")


def _health(url: str, timeout: float = 1.0) -> dict | None:
    """The /health body of whatever serves this port, or None if nothing answers. Single-instance
    guard: a second launch must not try to bind an in-use port (that would error) — instead it
    reopens the UI against the running instance. Matters most in browser-fallback mode, where
    closing the tab leaves uvicorn up."""
    import json
    import urllib.request
    try:
        with urllib.request.urlopen(url + "health", timeout=timeout) as r:
            if r.status != 200:
                return None
            try:
                return json.loads(r.read().decode("utf-8")) or {}
            except ValueError:
                return {}
    except Exception:
        return None


def _health_ok(url: str, timeout: float = 1.0) -> bool:
    return _health(url, timeout) is not None


def _report_refusal(summary: str, detail: str) -> None:
    """A startup refusal happens BEFORE the backend (and its logging) exists, so record it here:
    app.log (stdout is redirected there), grv2.log, and the sheet's LOG tab when the serializer is
    configured. The operator only ever sees the plain message box. Best-effort, never raises."""
    print(f"{summary} | {detail}", flush=True)
    try:
        import logging

        import log_client
        try:
            log_dir = instance.config_dir() / "logs"
        except instance.InstanceConfigError:     # the instance name itself is the problem
            log_dir = app_log_path().parent
        log = log_client.setup_logging(
            "app", operator_id=os.environ.get("GR_ACCOUNT") or "app", log_dir=log_dir,
            serializer_url=os.environ.get("GRV2_EXEC"), api_token=os.environ.get("GRV2_TOKEN"))
        log_client.log_event(log, logging.ERROR, summary, op="app", result="refused_start",
                             detail=detail)
    except Exception:  # noqa: BLE001 — logging must never mask the refusal itself
        pass


def _updater():
    """The self-updater (app/updater.py) — inert unless GR_UPDATE_URL is set. Any problem in it
    is logged and ignored: the updater can never stop the app from starting."""
    try:
        from app import updater
        return updater.get()
    except Exception as e:  # noqa: BLE001
        print(f"updater unavailable: {type(e).__name__}: {e}", flush=True)
        return None


def _upd(method: str) -> None:
    u = _updater()
    if u is None:
        return
    try:
        getattr(u, method)()
    except Exception as e:  # noqa: BLE001
        print(f"updater {method} failed: {type(e).__name__}: {e}", flush=True)


def main() -> int:
    import time
    log_hint = f"The details are in this file — please send it to Laurent:\n{app_log_path()}"
    try:
        instance.validate()
    except instance.InstanceConfigError as e:
        # The start marker (versions\starting.json) is left in place: if this version was just
        # installed by the updater, the next start goes back to the previous one.
        _report_refusal("startup refused: invalid instance config", str(e))
        _msgbox("Green Receipts can't open because its setup needs fixing. Nothing was changed.\n\n"
                + log_hint, "Green Receipts — could not start", icon=0x10)
        return 1
    # Local housekeeping for an installed update (the Chrome extension folder, bootstrap's note
    # about what it did at this start). Does nothing on an install that never had an update.
    _upd("on_startup")
    url = f"http://{HOST}:{instance.app_port()}/"
    t = None
    running = _health(url)
    if running is not None:
        # This launch's code ran fine (the window of a running app is reopened, or another
        # instance holds the port): not a failed start, so no rollback next time.
        _upd("mark_started")
        # It must be THIS instance: reopening another instance's window would put the operator in
        # the wrong taxpayer's data. A pre-instance build reports no "instance" (= the default one).
        theirs = str(running.get("instance") or "")
        if theirs != instance.name():
            _report_refusal(
                "startup refused: app port held by another instance",
                f"port={instance.app_port()} serving={theirs or 'default'!r} "
                f"serving_version={running.get('version')!r} me={instance.name() or 'default'!r}")
            other = f"Green Receipts — {running.get('instance_label')}" if running.get("instance_label") \
                else "the main Green Receipts"
            _msgbox(f"{_title()} can't open while {other} is open on this computer.\n\n"
                    f"Close {other}, then open {_title()} again. Nothing was changed.\n\n"
                    "If this keeps happening: " + log_hint, f"{_title()} — could not start", icon=0x10)
            return 1
        print(f"already running at {url} — reopening it.", flush=True)
    else:
        t = threading.Thread(target=_serve, daemon=True)
        t.start()
        up = False
        for _ in range(50):          # wait up to ~5s for uvicorn to bind before opening the window
            if _health_ok(url, timeout=0.3):
                up = True
                break
            time.sleep(0.1)
        if not up:
            # uvicorn never came up (port stolen by another process, import failure in the worker
            # thread, etc.) — don't open a blank window pointing at a dead server.
            print("the local service did not start within 5s — aborting launch.", flush=True)
            _msgbox(f"{_title()} could not start its local service.\n\nDetails were written to "
                    "app.log in your \"Green Receipts\" app-data folder. Please send it to Laurent.",
                    f"{_title()} — could not start", icon=0x10)
            return 1
        # The first /health was served: this version started. Clear the start marker, then check
        # for updates in the background (only when GR_UPDATE_URL is set).
        _upd("mark_started")
        _upd("start_background")
    try:
        import webview  # pywebview -> a real native window
        # min_size keeps the window above the width where the Settings action buttons would clip
        # (the tables also fall back to horizontal scroll below it, so nothing is ever hidden).
        webview.create_window(_title(), url, width=1080, height=720, min_size=(1000, 640))
        webview.start()
    except Exception as e:
        # No WebView2/.NET, or pywebview missing: open in the default browser (still 127.0.0.1-only,
        # still private) and TELL the operator so a missing window isn't read as "the app is broken".
        print(f"native window unavailable ({e!r}); opening in the default browser instead.", flush=True)
        import webbrowser
        webbrowser.open(url)
        _msgbox(f"{_title()} opened in your web browser.\n\nIf no tab opened, go to:\n{url}\n\n"
                "Keep this notice open while you work; closing it quits the app.", _title())
        if t is not None:
            try:
                t.join()
            except KeyboardInterrupt:
                return 0
    return 0


if __name__ == "__main__":
    os.environ.setdefault("PYTHONUNBUFFERED", "1")
    _init_file_logging()
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except BaseException as e:  # noqa: BLE001 — last-resort: log + show, never die invisibly
        import traceback
        try:
            traceback.print_exc()
        except Exception:
            pass
        _msgbox(f"Green Receipts stopped unexpectedly:\n\n{e}\n\nDetails were written to app.log in "
                "your \"Green Receipts\" app-data folder. Please send it to Laurent.",
                "Green Receipts — error", icon=0x10)
        sys.exit(1)
