#!/usr/bin/env python3
"""Provision / inspect / remove green-receipts v2 TAXPAYER identities (Phase 3).

  add <taxpayer_id>        interactive: append a [[taxpayer]] + store the AT password
  show <taxpayer_id>       display the registry entry + keyring presence (masked)
  delete <taxpayer_id>     remove the [[taxpayer]] entry + keyring password
  migrate [--purge-env]    v1 .env -> a v2 [[taxpayer]]; --purge-env SHREDS .env afterwards
  audit                    scan the working tree + registry for secrets (tools/secret_scan.py)

DECISION E: the AT password is the ONLY secret; it lives in the OS secret store keyed
by nif_prestador (NOT the human slug, so a copied registry can't bind a wrong password).
Everything else is non-secret registry TOML in ~/.config/green_receipts/registry/.
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tomllib
from pathlib import Path

import keyring

from registry import CRED_KEY_PASSWORD, CRED_MODES, REGISTRY_DIR

PROJECT_ROOT = Path(__file__).parent
ENV_PATH = PROJECT_ROOT / ".env"
TAXPAYERS_TOML = "taxpayers.toml"


def _atomic_write(path: Path, text: str) -> None:
    """Write `text` to a registry TOML SAFELY: back up the current file to <name>.bak, then write
    through a temp file + os.replace. A crash / power loss / AV lock can never leave a half-written
    file that fails to parse and bricks startup — the original stays intact until the atomic
    replace, and the last good copy is in <name>.bak."""
    path = Path(path)
    if path.exists():
        shutil.copy2(path, path.with_name(path.name + ".bak"))
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)   # atomic on Windows + POSIX


def _atomic_append(path: Path, text: str) -> None:
    """Append `text` to a registry TOML atomically (see _atomic_write)."""
    path = Path(path)
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    _atomic_write(path, existing + text)


def update_taxpayer(registry_dir: Path, taxpayer_id: str, new_fields: dict) -> Path:
    """Atomically merge `new_fields` into ONE existing [[taxpayer]] row, preserving every other
    row verbatim. Used by 'refresh from AT' to update a taxpayer's auto-derived cadastro in place
    (addresses / IVA regime / início de atividade) without disturbing the rest of the registry."""
    registry_dir = Path(registry_dir)
    path = registry_dir / TAXPAYERS_TOML
    raw = tomllib.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    rows = raw.get("taxpayer", [])
    if not any(str(r.get("taxpayer_id")) == str(taxpayer_id) for r in rows):
        raise ValueError(f"taxpayer_id {taxpayer_id!r} not found — cannot refresh a taxpayer that isn't registered")
    out = ["# taxpayers.toml"]
    for r in rows:
        merged = {**r, **new_fields} if str(r.get("taxpayer_id")) == str(taxpayer_id) else r
        out.append(render_taxpayer_block(merged).rstrip("\n"))
    _atomic_write(path, "\n".join(out) + "\n")
    return path


# --------------------------------------------------------------------------
# Testable core (no I/O prompts) — exercised by tests/test_registry.py
# --------------------------------------------------------------------------
def _toml_escape(v) -> str:
    return str(v).replace("\\", "\\\\").replace('"', '\\"')


def render_taxpayer_block(f: dict) -> str:
    fields = [
        ("taxpayer_id", f["taxpayer_id"]),
        ("nif_prestador", str(int(f["nif_prestador"]))),  # quoted string (registry int()s it)
        ("nome_prestador", f.get("nome_prestador", "")),
        ("morada_fiscal_prestador", f.get("morada_fiscal_prestador", "")),
        ("morada_fiscal", f.get("morada_fiscal", "")),
        ("estabelecimento_comercial", f.get("estabelecimento_comercial", "")),
        ("at_login_username", f["at_login_username"]),
        ("cred_mode", f["cred_mode"]),
    ]
    # Auto-derived cadastro (emit_receipt.fetch_cadastro) — written only when present, so
    # hand-written / legacy rows stay clean and the registry defaults apply.
    for k in ("data_inicio_atividade", "iva_cod_enq", "iva_desc_enq",
              "iva_cod_tipo_operacoes", "iva_tipo_sujeito_passivo"):
        if f.get(k):
            fields.append((k, f[k]))
    lines = ["", "[[taxpayer]]"] + [f'{k} = "{_toml_escape(v)}"' for k, v in fields]
    return "\n".join(lines) + "\n"


def existing_taxpayer_ids(registry_dir: Path) -> set[str]:
    p = Path(registry_dir) / TAXPAYERS_TOML
    if not p.exists():
        return set()
    data = tomllib.loads(p.read_text(encoding="utf-8"))
    return {str(t["taxpayer_id"]) for t in data.get("taxpayer", [])}


PROPERTIES_TOML = "properties.toml"

# Descriptions for the Alojamento Local CAE codes (seeded in the CAE Reference tab).
# An unknown code is prompted for and validated later by verify.bat.
CAE_DESCR = {
    "55201": "Alojamento mobilado para turistas",
    "55204": "Outros locais de alojamento de curta duracao",
}


def render_property_block(f: dict) -> str:
    fields = [
        ("property_id", f.get("property_id") or f["listing_id_str"]),
        ("listing_id_str", str(f["listing_id_str"])),
        ("listing_name", f.get("listing_name", "")),
        ("taxpayer_id", f["taxpayer_id"]),
        ("cae_code", str(f["cae_code"])),
        ("cae_descr", f.get("cae_descr", "")),
        ("al_number", f.get("al_number", "")),
        ("airbnb_account_id", f.get("airbnb_account_id", "")),
    ]
    lines = ["", "[[property]]"] + [f'{k} = "{_toml_escape(v)}"' for k, v in fields]
    lines.append(f'active = {"true" if f.get("active", True) else "false"}')
    return "\n".join(lines) + "\n"


def existing_listing_ids(registry_dir: Path) -> set[str]:
    p = Path(registry_dir) / PROPERTIES_TOML
    if not p.exists():
        return set()
    data = tomllib.loads(p.read_text(encoding="utf-8"))
    return {str(pr["listing_id_str"]).strip() for pr in data.get("property", [])}


def append_property(registry_dir: Path, fields: dict) -> Path:
    """Validate + append one [[property]] routing row to properties.toml.

    Guards (mirror registry.load_registry): the taxpayer_id must already exist,
    the listing_id_str must be a non-empty string not already mapped (A2 — the
    same listing under two properties files a receipt under the wrong taxpayer),
    and cae_code must be a 5-digit code."""
    registry_dir = Path(registry_dir)
    listing = str(fields["listing_id_str"]).strip()
    tid = str(fields["taxpayer_id"])
    cae = str(fields["cae_code"]).strip()
    if not listing:
        raise ValueError("listing_id_str cannot be empty (it is the ONLY routing key).")
    if tid not in existing_taxpayer_ids(registry_dir):
        raise ValueError(f"taxpayer_id {tid!r} is not in taxpayers.toml — add the taxpayer first.")
    if not (cae.isdigit() and len(cae) == 5):
        raise ValueError(f"cae_code {cae!r} must be a 5-digit code (e.g. 55201).")
    if listing in existing_listing_ids(registry_dir):
        raise ValueError(
            f"listing_id_str {listing!r} is already mapped (A2 collision) — delete it first "
            f"or use a different listing.")
    registry_dir.mkdir(parents=True, exist_ok=True)
    path = registry_dir / PROPERTIES_TOML
    _atomic_append(path, render_property_block(fields))
    return path


def sync_properties_from_sheet(registry_dir: Path, sheet_rows: list[dict],
                               nif_to_slug: dict) -> dict:
    """One-way Sheet -> local sync of the listing->taxpayer routing. The Google Sheet's
    "Property Settings" tab is the ONLY place listings are added or edited; this refreshes
    the app's local read-only copy (properties.toml, the emit-time G2 guard's source).

    Upserts one [[property]] per listing id (a sheet row's listing_ids_csv may carry
    several). Fail-closed rules, in order of danger:
      - the same listing id in TWO sheet rows (routing conflict — could file under the wrong
        taxpayer) -> the listing is PAUSED locally (active=false) until the sheet is fixed;
      - 'active' means active-unless-explicitly-FALSE, matching the serializer's
        resolveAgainst — a blank cell must not silently deactivate a filing listing;
      - a local row the sheet NO LONGER HAS (row deleted) is DEACTIVATED, not kept filing —
        the Sheet is authoritative; its stays park visibly as "needs setup" instead of
        routing via a zombie mapping. Local rows belonging to taxpayers outside this sync's
        NIF set are left untouched (reported in local_only).
    Returns {added, updated, unchanged, deactivated, skipped, local_only}."""
    import re as _re
    registry_dir = Path(registry_dir)
    path = registry_dir / PROPERTIES_TOML
    existing = {}
    order = []
    if path.exists():
        for pr in tomllib.loads(path.read_text(encoding="utf-8")).get("property", []):
            lid = str(pr.get("listing_id_str", "")).strip()
            if lid:
                existing[lid] = dict(pr)
                order.append(lid)

    def _is_active(v) -> bool:
        # Mirror resolveAgainst (Logic.gs): a row is active unless EXPLICITLY switched off.
        return str(v).strip().upper() not in ("FALSE", "0", "NO", "NAO", "NÃO")

    out = {"added": [], "updated": [], "unchanged": [], "deactivated": [],
           "skipped": [], "local_only": []}
    seen_sheet_lids = set()
    claimed_by = {}   # lid -> (label, slug) — cross-row collision detection
    conflicted = set()
    for row in sheet_rows:
        label = str(row.get("property_label") or row.get("property_id") or "?")
        nif = str(row.get("taxpayer_nif") or "").strip()
        slug = nif_to_slug.get(nif)
        cae = str(row.get("cae_code") or "").strip()
        active = _is_active(row.get("active", ""))
        lids = [s for s in _re.split(r"[,\s]+", str(row.get("listing_ids_csv") or "")) if s]
        if not lids:
            out["skipped"].append(f"{label}: no listing id in the sheet row")
            continue
        if slug is None:
            out["skipped"].append(f"{label}: no client with NIF …{nif[-3:]} in the app — add the client first")
            continue
        if not (cae.isdigit() and len(cae) == 5):
            out["skipped"].append(f"{label}: CAE {cae!r} is not a 5-digit code — fix it in the sheet")
            continue
        desired = {"property_id": str(row.get("property_id") or ""), "listing_name": label,
                   "taxpayer_id": slug, "cae_code": cae,
                   "cae_descr": str(row.get("cae_descricao") or CAE_DESCR.get(cae, "")),
                   "al_number": str(row.get("al_number") or "").strip(), "active": active}
        for lid in lids:
            seen_sheet_lids.add(lid)
            # The same listing id under TWO sheet rows is a routing conflict — the mirror of
            # append_property's A2 guard. Never let "last row wins" quietly reroute receipts:
            # pause the listing locally and tell the operator to fix the sheet.
            if lid in claimed_by and claimed_by[lid][0] != label:
                conflicted.add(lid)
                out["skipped"].append(
                    f"listing {lid} appears in TWO sheet rows ({claimed_by[lid][0]} and {label}) — "
                    f"filing for it is paused until the sheet is fixed")
                if lid in existing:
                    existing[lid]["active"] = False
                continue
            claimed_by[lid] = (label, slug)
            desired_lid = dict(desired, listing_id_str=lid,
                               property_id=desired["property_id"] or lid)
            cur = existing.get(lid)
            if cur is None:
                if active:
                    existing[lid] = desired_lid
                    order.append(lid)
                    out["added"].append(f"{label} ({lid})")
                else:
                    out["skipped"].append(f"{label} ({lid}): switched off in the sheet — not imported")
                continue
            merged = dict(cur)
            merged.update({k: v for k, v in desired_lid.items()})
            merged.setdefault("airbnb_account_id", cur.get("airbnb_account_id", ""))
            if not active and str(cur.get("active", True)).lower() not in ("false",):
                out["deactivated"].append(f"{label} ({lid})")
            elif any(str(merged.get(k, "")) != str(cur.get(k, "")) for k in
                     ("listing_name", "taxpayer_id", "cae_code", "cae_descr", "al_number", "active")):
                out["updated"].append(f"{label} ({lid})")
            else:
                out["unchanged"].append(lid)
                continue
            existing[lid] = merged

    # Rows DELETED from the sheet: the Sheet is authoritative, so their local copies stop
    # filing (deactivated, kept on file for the audit trail). Only for taxpayers this sync
    # covered — a listing of an unsynced taxpayer is merely reported.
    synced_slugs = set(nif_to_slug.values())
    for lid in order:
        if lid in seen_sheet_lids or lid in conflicted:
            continue
        row = existing[lid]
        name = row.get("listing_name") or lid
        if str(row.get("taxpayer_id", "")) in synced_slugs:
            if str(row.get("active", True)).lower() not in ("false",):
                row["active"] = False
                out["deactivated"].append(f"{name} ({lid}) — removed from the sheet")
        else:
            out["local_only"].append(f"{name} ({lid})")
    blocks = ["# properties.toml"] + [render_property_block(existing[lid]).rstrip("\n")
                                      for lid in order]
    _atomic_write(path, "\n".join(blocks) + "\n")
    return out


def append_taxpayer(registry_dir: Path, fields: dict) -> Path:
    """Validate + append one [[taxpayer]] to taxpayers.toml. Raises on collision/mismatch.

    Guards (the same load-bearing invariants registry.load_registry enforces):
      - cred_mode in CRED_MODES
      - int(at_login_username.split('/')[0]) == nif_prestador  (copy-paste guard)
      - taxpayer_id not already present                         (slug collision)
    """
    registry_dir = Path(registry_dir)
    tid = str(fields["taxpayer_id"])
    nif = int(fields["nif_prestador"])
    cred_mode = str(fields["cred_mode"])
    at_login = str(fields["at_login_username"])

    if cred_mode not in CRED_MODES:
        raise ValueError(f"cred_mode {cred_mode!r} not in {CRED_MODES}")
    base = at_login.split("/")[0]
    if not base.isdigit() or int(base) != nif:
        raise ValueError(
            f"at_login_username base {base!r} != nif_prestador {nif} (copy-paste guard)")
    if tid in existing_taxpayer_ids(registry_dir):
        raise ValueError(
            f"taxpayer_id {tid!r} already exists (slug collision) - choose another or delete first")
    # NIF-uniqueness guard: two taxpayer rows sharing ONE NIF = the "dup-NIF mess" — divergent
    # addresses/IVA under one NIF, so the wrong address could print on a receipt. The app's
    # add_taxpayer already rejects this; enforce it in the CLI path too. Same NIF = same taxpayer.
    _p = Path(registry_dir) / TAXPAYERS_TOML
    if _p.exists():
        _existing = tomllib.loads(_p.read_text(encoding="utf-8")).get("taxpayer", [])
        if any(int(str(x.get("nif_prestador")).strip()) == nif for x in _existing):
            raise ValueError(
                f"a taxpayer with NIF {nif} already exists — same NIF = same taxpayer; edit (or "
                f"delete) that entry instead of adding a second row for one NIF")

    registry_dir.mkdir(parents=True, exist_ok=True)
    path = registry_dir / TAXPAYERS_TOML
    _atomic_append(path, render_taxpayer_block(fields))
    return path


def keyring_service_for(nif: int) -> str:
    return f"green_receipts_v2/{int(nif)}"


def store_password(nif: int, password: str) -> str:
    service = keyring_service_for(nif)
    keyring.set_password(service, CRED_KEY_PASSWORD, password)
    return service


def import_seed(registry_dir: Path, seed_dir: Path) -> list[str]:
    """Copy an administrator-provided registry (shipped in the bundle at registry_seed/)
    into the operator's registry — but ONLY on a fresh machine (no taxpayers.toml yet),
    so it never clobbers a machine the operator has already configured. Returns the
    filenames imported (empty if nothing to do). Secrets are NOT seeded — only the
    non-secret identity + routing TOMLs; the Portal password is entered separately."""
    seed_dir, registry_dir = Path(seed_dir), Path(registry_dir)
    if not seed_dir.is_dir() or (registry_dir / TAXPAYERS_TOML).exists():
        return []
    tomls = sorted(seed_dir.glob("*.toml"))
    if not tomls:
        return []
    registry_dir.mkdir(parents=True, exist_ok=True)
    copied = []
    for t in tomls:
        shutil.copy2(t, registry_dir / t.name)
        copied.append(t.name)
    return copied


def taxpayers_missing_password(registry_dir: Path) -> list[tuple[str, int]]:
    """Taxpayers whose cred_mode is 'stored' but have no Portal password in the keyring
    yet — i.e. a seeded-but-not-yet-usable taxpayer that only needs its password."""
    p = Path(registry_dir) / TAXPAYERS_TOML
    if not p.exists():
        return []
    out = []
    for t in tomllib.loads(p.read_text(encoding="utf-8")).get("taxpayer", []):
        # Default MUST match registry.load_registry (which defaults an absent cred_mode to
        # "prompt") — otherwise a seed TOML omitting cred_mode would get a stored password
        # here that emit then ignores as prompt-mode (and --yes would hard-error).
        if str(t.get("cred_mode", "prompt")) != "stored":
            continue
        try:  # a malformed seeded NIF must not traceback the operator's setup — skip it
            nif = int(str(t.get("nif_prestador", "")).strip())
        except (ValueError, TypeError):
            continue
        try:
            has = keyring.get_password(keyring_service_for(nif), CRED_KEY_PASSWORD)
        except Exception:  # noqa: BLE001 — treat a keyring read error as "missing"
            has = None
        if not has:
            out.append((str(t["taxpayer_id"]), nif))
    return out


def prompt_missing_passwords(registry_dir: Path) -> int:
    """Prompt for + store the Portal password of every seeded passwordless taxpayer.
    Returns how many were set."""
    n = 0
    for tid, nif in taxpayers_missing_password(registry_dir):
        print(f"\nTaxpayer '{tid}' (NIF {nif}) is set up but needs your Portal (AT) password.")
        pw = _ask(f"Portal password for {tid} (saved to the Windows keyring, never a file)",
                  secret=True)
        store_password(nif, pw)
        print("  Saved to the Windows keyring.")
        n += 1
    return n


def shred_file(path: Path) -> None:
    """Best-effort secure delete: overwrite with random bytes + fsync, then unlink.

    NOTE: on SSD / copy-on-write filesystems an in-place overwrite is NOT guaranteed
    to hit the original blocks; this raises the bar but is not a cryptographic erase.
    """
    path = Path(path)
    if not path.exists():
        return
    n = path.stat().st_size
    with path.open("r+b", buffering=0) as fh:
        fh.write(os.urandom(max(n, 1)))
        fh.flush()
        os.fsync(fh.fileno())
    path.unlink()


def parse_env_file(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        out[k.strip()] = v.strip().strip('"').strip("'")
    return out


# --------------------------------------------------------------------------
# CLI subcommands
# --------------------------------------------------------------------------
def _ask(label: str, *, secret: bool = False) -> str:
    import getpass
    while True:
        v = (getpass.getpass(f"  {label}: ") if secret else input(f"  {label}: ")).strip()
        if v:
            return v
        print("    (cannot be empty)")


def _ask_default(label: str, default: str = "") -> str:
    """Prompt allowing an empty answer to accept `default` (used to edit auto-fetched values)."""
    suffix = f" [{default}]" if default else ""
    v = input(f"  {label}{suffix}: ").strip()
    return v or default


def _ask_yes_no(label: str, default: bool = True) -> bool:
    hint = "[Y/n]" if default else "[y/N]"
    while True:
        v = input(f"  {label} {hint}: ").strip().lower()
        if not v:
            return default
        if v in ("y", "yes", "s", "sim"):
            return True
        if v in ("n", "no", "nao", "não"):
            return False
        print("    (please answer y or n)")


def add_taxpayer_interactive(registry_dir, tid: str, *, advanced: bool = False) -> int:
    """Prompt for one taxpayer's identity + (by default) store the AT password now.

    Returns the nif. The credential mode is 'stored' by default — the operator's
    password goes to the Windows keyring so the monthly emitir.bat runs without
    asking. 'prompt' mode is offered ONLY under --advanced (it is incompatible with
    the bundle's non-interactive emitir.bat and would silently skip the taxpayer)."""
    if tid in existing_taxpayer_ids(registry_dir):
        raise SystemExit(f"taxpayer_id {tid!r} already exists. Use a different id or `delete` it first.")
    print(f"\nAdding taxpayer {tid!r}.\n")
    nif = int(_ask("NIF (9 digits, numbers only)"))
    at_login = _ask("Portal (AT) login username, the NIF/seq form (e.g. 000000000/3)")
    cred_mode = "stored"
    if advanced:
        cred_mode = ""
        while cred_mode not in CRED_MODES:
            cred_mode = _ask(f"cred_mode {CRED_MODES} (stored=keyring, prompt=ask each run)").lower()
    # Password is needed now to log in to AT and auto-fill the registration from your cadastro.
    pw = _ask("Portal (AT) password", secret=True)

    fields = {"taxpayer_id": tid, "nif_prestador": nif,
              "at_login_username": at_login, "cred_mode": cred_mode}
    fields.update(_collect_cadastro(nif, at_login, pw))

    append_taxpayer(registry_dir, fields)  # re-validates (slug + NIF guard)
    if cred_mode == "stored":
        svc = store_password(nif, pw)
        print(f"  Password saved to the Windows keyring ({svc}); no file holds it.")
    else:
        print("  cred_mode=prompt: password not stored; you'll be asked each run.")
    print(f"  Added taxpayer to {Path(registry_dir) / TAXPAYERS_TOML}")
    return nif


# Auto-derived IVA-regime + início fields (kept as-is from AT; addresses are prompted separately).
_CADASTRO_IVA_FIELDS = ("data_inicio_atividade", "iva_cod_enq", "iva_desc_enq",
                        "iva_cod_tipo_operacoes", "iva_tipo_sujeito_passivo")


def _collect_cadastro(nif: int, at_login: str, password: str) -> dict:
    """Auto-derive the prestador's identity from AT (name, addresses, IVA regime, início de
    atividade). Falls back to manual entry if the AT fetch can't be done. Never invents values."""
    cad = None
    try:
        import emit_receipt
        print("\n  Signing in to AT to read your registration (nothing is filed)...")
        lr, cad = emit_receipt.login_and_fetch_cadastro(at_login, nif, password)
        if cad is None:
            print(f"  Could not read from AT (login: {lr.kind} — {lr.message or 'no cadastro'}).")
    except Exception as e:  # network / layout change / import issue -> manual fallback
        print(f"  Could not auto-fill from AT ({type(e).__name__}: {e}).")

    if cad is not None:
        if cad.nif and int(cad.nif) != int(nif):
            print(f"  WARNING: AT returned NIF {cad.nif}, but you entered {nif}. Using what you enter below.")
        print("\n  Read from AT (please confirm):")
        print(f"    Name                     : {cad.nome}")
        print(f"    Fiscal address (domicílio): {cad.morada_fiscal_prestador}")
        print(f"    Establishment            : {cad.estabelecimento_comercial}")
        print(f"    Receipt address          : {cad.morada_fiscal}")
        print(f"    Activity start           : {cad.data_inicio_atividade or '(unknown)'}")
        print(f"    IVA regime               : {cad.iva_desc_enq or cad.iva_cod_enq} "
              f"({cad.iva_cod_enq}/{cad.iva_cod_tipo_operacoes}/{cad.iva_tipo_sujeito_passivo})")
        acts = ", ".join(f"{a['code']} {a['descr']}" for a in cad.actividades) or "(none)"
        print(f"    Activities               : {acts}")
        if _ask_yes_no("  Use these values from AT?", default=True):
            # THE single Cadastro->registry mapping — shared with 'refresh' and the app's
            # add flow so the three paths can never drift apart.
            from emit_receipt import cadastro_to_registry_fields
            return cadastro_to_registry_fields(cad)
        # operator wants to adjust — prompt with the AT values pre-filled
        print("  Edit each value (press Enter to keep the AT value):")
        out = {
            "nome_prestador": _ask_default("Name", cad.nome),
            "morada_fiscal_prestador": _ask_default("Fiscal address (domicílio)", cad.morada_fiscal_prestador),
            "morada_fiscal": _ask_default("Receipt address (morada fiscal)", cad.morada_fiscal),
            "estabelecimento_comercial": _ask_default("Establishment", cad.estabelecimento_comercial),
        }
        # keep the auto-derived IVA regime + activity-start unless clearly wrong (advanced edit not exposed)
        for k in _CADASTRO_IVA_FIELDS:
            out[k] = getattr(cad, k, "")
        return out

    # Manual fallback (no AT data): addresses typed by hand; IVA/início left blank (defaults apply).
    print("\n  Enter the taxpayer's details by hand:")
    return {
        "nome_prestador": _ask("Name (nome do prestador)"),
        "morada_fiscal_prestador": _ask("Fiscal address / domicílio (morada fiscal do prestador)"),
        "morada_fiscal": _ask("Receipt address (morada fiscal)"),
        "estabelecimento_comercial": _ask("Establishment (estabelecimento comercial)"),
    }


def cmd_add(args: argparse.Namespace) -> None:
    add_taxpayer_interactive(args.registry_dir, args.taxpayer_id, advanced=args.advanced)


def _pick_taxpayer(registry_dir) -> str:
    ids = sorted(existing_taxpayer_ids(registry_dir))
    if not ids:
        raise SystemExit("No taxpayers yet — add one first (setup.bat, then choose 'add a taxpayer').")
    if len(ids) == 1:
        return ids[0]
    print("  Which taxpayer is this listing for?")
    for i, t in enumerate(ids, 1):
        print(f"    {i}) {t}")
    while True:
        v = input("  number: ").strip()
        if v.isdigit() and 1 <= int(v) <= len(ids):
            return ids[int(v) - 1]
        print("    (enter one of the numbers above)")


def map_property_interactive(registry_dir) -> None:
    """Prompt for one listing -> taxpayer + CAE + AL routing row (properties.toml)."""
    tid = _pick_taxpayer(registry_dir)
    listing = _ask("Airbnb listing id (the NUMBER, e.g. 1234567890123456789)")
    name = input("  listing name (optional, display only): ").strip()
    cae = ""
    while not (cae.isdigit() and len(cae) == 5):
        cae = _ask("CAE code (5 digits — 55201 = Alojamento Local)")
    descr = CAE_DESCR.get(cae) or _ask("CAE description")
    al = _ask("AL registration number (alojamento local)")
    append_property(registry_dir, {
        "listing_id_str": listing, "listing_name": name, "taxpayer_id": tid,
        "cae_code": cae, "cae_descr": descr, "al_number": al,
    })
    print(f"  Mapped listing {listing} -> {tid} (CAE {cae}, AL {al}).")


def cmd_map(args: argparse.Namespace) -> None:
    map_property_interactive(args.registry_dir)


def cmd_list(args: argparse.Namespace) -> None:
    rdir = Path(args.registry_dir)
    txs = sorted(existing_taxpayer_ids(rdir))
    print(f"Registry: {rdir}")
    print(f"  taxpayers ({len(txs)}): {', '.join(txs) or '(none)'}")
    pp = rdir / PROPERTIES_TOML
    props = tomllib.loads(pp.read_text(encoding="utf-8")).get("property", []) if pp.exists() else []
    print(f"  listings mapped ({len(props)}):")
    for pr in props:
        print(f"    {pr.get('listing_id_str')} -> {pr.get('taxpayer_id')} "
              f"(CAE {pr.get('cae_code')}, AL {pr.get('al_number', '')})")
    if not props:
        print("    (none — add one with 'map a listing')")


def cmd_seed(args: argparse.Namespace) -> None:
    """Import the administrator's bundled registry (registry_seed/) + set any missing
    Portal password. Safe to re-run: import is a no-op once the machine is configured."""
    rdir = Path(args.registry_dir)
    imported = import_seed(rdir, Path(__file__).resolve().parent / "registry_seed")
    if imported:
        print(f"Imported your administrator's setup ({', '.join(imported)}).")
    elif not (rdir / TAXPAYERS_TOML).exists():
        print("Nothing to import (no registry_seed/ in this bundle).")
    if prompt_missing_passwords(rdir) == 0 and (rdir / TAXPAYERS_TOML).exists():
        print("All taxpayers already have a stored password — you're set.")


def cmd_wizard(args: argparse.Namespace) -> None:
    """The friendly default (a bare `setup.bat` double-click lands here)."""
    rdir = Path(args.registry_dir)
    print("Green Receipts — setup\n======================")
    # On a fresh machine, pull in the administrator's bundled registry so the operator
    # only has to enter their Portal password (stage: fully-scripted handover).
    imported = import_seed(rdir, Path(__file__).resolve().parent / "registry_seed")
    if imported:
        print(f"\nImported your administrator's setup ({len(imported)} file(s)) — you only need "
              f"your Portal password.")
    prompt_missing_passwords(rdir)
    cmd_list(args)
    while True:
        print("\nWhat would you like to do?")
        have_tx = bool(existing_taxpayer_ids(rdir))
        print("  1) Add a taxpayer (identity + Portal password)")
        print("  2) Map an Airbnb listing to a taxpayer (needed before emitting)" if have_tx
              else "  2) Map a listing  (add a taxpayer first)")
        print("  3) Show what's configured")
        print("  4) Done")
        choice = input("  number: ").strip()
        try:
            if choice == "1":
                tid = _ask("A short name for this taxpayer (e.g. client-a)")
                add_taxpayer_interactive(rdir, tid, advanced=args.advanced)
            elif choice == "2" and have_tx:
                map_property_interactive(rdir)
            elif choice == "3":
                cmd_list(args)
            elif choice == "4":
                break
            else:
                print("  (choose 1, 2, 3 or 4)")
        except (ValueError, SystemExit) as e:
            print(f"  Could not do that: {e}")
    print("\nNext: open config.bat and paste your serializer URL + token, then run verify.bat.")


def cmd_show(args: argparse.Namespace) -> None:
    tid = args.taxpayer_id
    p = Path(args.registry_dir) / TAXPAYERS_TOML
    if not p.exists():
        raise SystemExit(f"{p} not found.")
    data = tomllib.loads(p.read_text(encoding="utf-8"))
    match = next((t for t in data.get("taxpayer", []) if str(t["taxpayer_id"]) == tid), None)
    if not match:
        raise SystemExit(f"taxpayer_id {tid!r} not found in {p}.")
    print(f"Taxpayer {tid!r}:")
    for k, v in match.items():
        print(f"  {k} = {v}")
    nif = int(str(match["nif_prestador"]))
    svc = keyring_service_for(nif)
    pw = keyring.get_password(svc, CRED_KEY_PASSWORD)
    print(f"  keyring {svc}/{CRED_KEY_PASSWORD} = {'*' * 8 if pw else '(none)'}")


def cmd_delete(args: argparse.Namespace) -> None:
    tid = args.taxpayer_id
    p = Path(args.registry_dir) / TAXPAYERS_TOML
    if not p.exists():
        raise SystemExit(f"{p} not found.")
    data = tomllib.loads(p.read_text(encoding="utf-8"))
    rows = data.get("taxpayer", [])
    match = next((t for t in rows if str(t["taxpayer_id"]) == tid), None)
    if not match:
        raise SystemExit(f"taxpayer_id {tid!r} not found.")
    if not args.yes:
        resp = input(f"Delete taxpayer {tid!r} (entry + keyring password)? type 'yes': ").strip().lower()
        if resp != "yes":
            print("Aborted.")
            return
    kept = [t for t in rows if str(t["taxpayer_id"]) != tid]
    _atomic_write(p, "".join(render_taxpayer_block(t) for t in kept).lstrip("\n") or "")
    nif = int(str(match["nif_prestador"]))
    try:
        keyring.delete_password(keyring_service_for(nif), CRED_KEY_PASSWORD)
    except keyring.errors.PasswordDeleteError:
        pass
    print(f"  Removed taxpayer {tid!r} (entry + keyring).")


def cmd_migrate(args: argparse.Namespace) -> None:
    if not ENV_PATH.exists():
        raise SystemExit(f"{ENV_PATH} not found - nothing to migrate.")
    env = parse_env_file(ENV_PATH)
    nif_prestador = int(env["NIF_PRESTADOR"])
    fields = {
        "taxpayer_id": args.taxpayer_id, "nif_prestador": nif_prestador,
        "at_login_username": env["NIF"],  # v1 login form "NIF/seq"
        "cred_mode": "stored",
        "nome_prestador": env.get("NOME_PRESTADOR", ""),
        "morada_fiscal_prestador": env.get("MORADA_FISCAL_PRESTADOR", ""),
        "morada_fiscal": env.get("MORADA_FISCAL", ""),
        "estabelecimento_comercial": env.get("ESTABELECIMENTO_COMERCIAL", ""),
    }
    append_taxpayer(args.registry_dir, fields)
    store_password(nif_prestador, env["PASSWORD"])
    print(f"  Migrated .env -> taxpayer {args.taxpayer_id!r} (cred_mode=stored, password in keyring).")
    if args.purge_env:
        shred_file(ENV_PATH)
        print(f"  SHREDDED {ENV_PATH} (overwritten + unlinked).")
    else:
        print(f"  NOTE: {ENV_PATH} still on disk in plaintext. Re-run with --purge-env to shred it.")


def cmd_refresh(args: argparse.Namespace) -> None:
    """Re-read a taxpayer's cadastro from AT and update the registry in place (addresses / IVA
    regime / início de atividade). Run this when a client's tax registration changes at Finanças —
    the tool also detects such a change at issue time and asks you to refresh."""
    import requests
    import registry as REG
    import emit_receipt as ER
    from emit import _login_profile
    reg = REG.load_registry(Path(args.registry_dir))
    tp = reg.taxpayers.get(args.taxpayer_id)
    if tp is None:
        raise SystemExit(f"taxpayer_id {args.taxpayer_id!r} not found.")
    cred = REG.resolve_credential(tp, assume_yes=True)
    # Cooldown gate (same rule as the app): a known blocked / wrong-password credential is
    # NOT re-attempted — each retry against AT extends the lockout.
    import login_cache
    hit = login_cache.check(int(tp.nif_prestador))
    if hit:
        raise SystemExit("  Not attempting the sign-in: " + login_cache.guidance(hit))
    print(f"  Signing in to AT to re-read {tp.taxpayer_id!r}'s registration (nothing is filed) ...")
    session = requests.Session()
    lr = ER.login_result(session, _login_profile(tp, cred))
    login_cache.record(int(tp.nif_prestador), lr.kind, lr.message)
    if not lr.ok:
        raise SystemExit(f"  Sign-in failed ({lr.kind}: {lr.message or ''}). Nothing changed.")
    new_fields = ER.cadastro_to_registry_fields(ER.fetch_cadastro(session))
    changed = [f"    {k}: {getattr(tp, k, '')!r} -> {v!r}"
               for k, v in new_fields.items() if str(getattr(tp, k, "")) != str(v)]
    if not changed:
        print("  No changes — the registry already matches AT.")
        return
    print("  Updating from AT:\n" + "\n".join(changed))
    update_taxpayer(args.registry_dir, args.taxpayer_id, new_fields)
    print(f"  Refreshed taxpayer {args.taxpayer_id!r} from AT.")


def cmd_audit(args: argparse.Namespace) -> None:
    scan = PROJECT_ROOT / "tools" / "secret_scan.py"
    targets = [str(PROJECT_ROOT), str(Path(args.registry_dir))]
    print(f"Running secret scan over: {targets}")
    rc = subprocess.call([sys.executable, str(scan), *targets])
    raise SystemExit(rc)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--registry-dir", default=str(REGISTRY_DIR),
                    help="registry directory (default: ~/.config/green_receipts/registry)")
    ap.add_argument("--advanced", action="store_true",
                    help="expose the cred_mode prompt (default is the safe 'stored').")
    # No subcommand -> the friendly interactive wizard (a bare setup.bat double-click).
    ap.set_defaults(func=cmd_wizard)
    sub = ap.add_subparsers(dest="cmd")

    a = sub.add_parser("add", help="add one taxpayer (identity + Portal password)")
    a.add_argument("taxpayer_id"); a.set_defaults(func=cmd_add)
    mp = sub.add_parser("map", help="map an Airbnb listing to a taxpayer (properties.toml)")
    mp.set_defaults(func=cmd_map)
    ls = sub.add_parser("list", help="show configured taxpayers + listing mappings")
    ls.set_defaults(func=cmd_list)
    sd = sub.add_parser("seed", help="import the bundled registry + set the Portal password")
    sd.set_defaults(func=cmd_seed)
    s = sub.add_parser("show"); s.add_argument("taxpayer_id"); s.set_defaults(func=cmd_show)
    d = sub.add_parser("delete"); d.add_argument("taxpayer_id")
    d.add_argument("--yes", action="store_true"); d.set_defaults(func=cmd_delete)
    m = sub.add_parser("migrate"); m.add_argument("taxpayer_id", nargs="?", default="laurent")
    m.add_argument("--purge-env", action="store_true", help="shred .env after a successful migrate")
    m.set_defaults(func=cmd_migrate)
    rf = sub.add_parser("refresh", help="re-read a taxpayer's registration from AT + update the registry")
    rf.add_argument("taxpayer_id"); rf.set_defaults(func=cmd_refresh)
    au = sub.add_parser("audit"); au.set_defaults(func=cmd_audit)

    args = ap.parse_args()
    try:
        args.func(args)
    except (EOFError, KeyboardInterrupt):
        # A closed console / Ctrl-C must never end in a raw traceback for the
        # non-technical operator this tool exists for (review finding).
        print("\nSetup closed — nothing else was changed. Run setup.bat again any time.")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
