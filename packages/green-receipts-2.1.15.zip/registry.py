"""green-receipts v2 — three-table identity registry + credential resolution.

SCAFFOLD STUB (Phase 0). Importable and type-coherent; the load/resolve bodies
are intentionally left as `TODO(Phase 3)` per V2_PLAN.md sections 6.1 / 6.2 and
the Phase 3 row of the roadmap (section 7).

This REPLACES the flat v1 `Profile` (profiles.py) with the separated identity
model from the design pass. v1 `profiles.py` stays untouched as a deprecated
single-taxpayer shim for the owner's email path during migration — do NOT delete
it here.

The registry is the NON-SECRET, git-safe mirror of the Sheet `SETTINGS` tab,
read from ~/.config/green_receipts/registry/*.toml:
    taxpayers.toml · properties.toml · deployments.toml · airbnb_accounts.toml

DECISIONS encoded here (do not relitigate):
  B  one ingestion source per deployment (Deployment.sheet_adapter)
  C  Airbnb auth is in-browser; AirbnbAccount carries identifiers only
  D  Sheet canonical + single serializer (Deployment.serializer_url)
  E  per-taxpayer AT creds in a secret store keyed by nif_prestador;
     cred_mode prompt|stored; per-laptop emitters

Load-bearing invariants (enforced in load_registry, Phase 3):
  - int(at_login_username.split("/")[0]) == nif_prestador
  - every Property.taxpayer_id resolves to a Taxpayer
  - every Property.airbnb_account_id resolves to an AirbnbAccount
  - routing is listing_id_str only; listing_name never routes
"""
from __future__ import annotations

import getpass
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

import keyring

# Default location of the deployed (filled, NEVER committed) registry — per instance
# (instance.py): the default instance keeps ~/.config/green_receipts/registry.
import instance as _instance

REGISTRY_DIR = _instance.config_dir() / "registry"

# Secret-store keys for an AT credential, keyed by nif_prestador (DECISION E).
# The keyring SERVICE is derived from the nif so a copied registry under a
# colliding human slug cannot bind the wrong password (V2_PLAN section 6.2).
CRED_KEY_PASSWORD = "at_password"

# Allowed values for the two enumerated fields (validated at load, Phase 3).
CRED_MODES = ("prompt", "stored")
# "email" was retired 2026-10-23 (it could only estimate the Airbnb fee): a deployment
# still configured for it fails at load instead of feeding guessed-fee rows.
SHEET_ADAPTERS = ("extension",)


# ---------------------------------------------------------------------------
# Dataclasses — one per registry table, plus the aggregate + a resolved cred.
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Taxpayer:
    """A prestador identity. Maps to one [[taxpayer]] in taxpayers.toml.

    nif_prestador is the canonical credential key (immutable, globally unique).
    The password is NEVER stored here — see resolve_credential().
    """
    taxpayer_id: str
    nif_prestador: int
    nome_prestador: str
    morada_fiscal_prestador: str
    morada_fiscal: str
    estabelecimento_comercial: str
    at_login_username: str            # "NIF/seq" — non-secret delegation form
    cred_mode: str                    # one of CRED_MODES
    # Auto-derived from AT at registration (emit_receipt.fetch_cadastro). Defaults preserve
    # behaviour for rows written before this feature: "" IVA codes fall back in the emit
    # payload to the historical hard-coded regime; "" data_inicio_atividade disables the guard.
    data_inicio_atividade: str = ""   # ISO "YYYY-MM-DD" — início de atividade per AT
    iva_cod_enq: str = ""             # consultaIva.codEnqIva  (e.g. "I")
    iva_desc_enq: str = ""            # consultaIva.descEnqIVA
    iva_cod_tipo_operacoes: str = ""  # consultaIva.codTipoOperacoes  (e.g. "B")
    iva_tipo_sujeito_passivo: str = ""  # consultaIva.tipoSujeitoPassivo  (e.g. "1")

    def keyring_service(self) -> str:
        """Secret-store service name, keyed by nif (not the human slug)."""
        return f"green_receipts_v2/{self.nif_prestador}"


@dataclass(frozen=True)
class Property:
    """A listing -> taxpayer + CAE routing rule. One [[property]] row.

    Routing key is listing_id_str ONLY (string form — the numeric id overflows
    2^53). listing_name is display-only and never routes.
    """
    listing_id_str: str
    listing_name: str
    taxpayer_id: str
    cae_code: str
    cae_descr: str
    airbnb_account_id: str
    active: bool
    property_id: str = ""
    # Alojamento Local registration number (Nr. de Registo do AL) — goes in the receipt
    # description in place of the reservation code. Cache of the Property Settings tab's
    # al_number; the serializer's decidePromote refuses to promote a row whose property
    # has no al_number set.
    al_number: str = ""


@dataclass(frozen=True)
class Deployment:
    """One canonical Sheet + its serializer. One [[deployment]] row.

    sheet_adapter encodes DECISION B (one ingestion source). serializer_url is
    SECRET-EQUIVALENT (V2_PLAN section 6.3) — in production it comes from the OS
    Credential Manager, not the committed TOML.
    """
    deployment_id: str
    spreadsheet_id: str
    sheet_adapter: str                # one of SHEET_ADAPTERS
    airbnb_accounts: list[str]
    serializer_url: str


@dataclass(frozen=True)
class AirbnbAccount:
    """A capture session identifier. NO credentials (DECISION C)."""
    account_id: str
    label: str
    airbnb_user_id: str = ""


@dataclass(frozen=True)
class ResolvedCredential:
    """The outcome of resolve_credential — an AT login ready to authenticate.

    `password` is held only in memory for the lifetime of the run; it is never
    written back to disk by this module.
    """
    nif_prestador: int
    at_login_username: str
    password: str
    source: str                       # "prompt" | "keyring" | "cli_override"


@dataclass
class Registry:
    """The whole loaded, cross-validated registry for a deployment."""
    taxpayers: dict[str, Taxpayer] = field(default_factory=dict)
    properties: list[Property] = field(default_factory=list)
    deployments: dict[str, Deployment] = field(default_factory=dict)
    airbnb_accounts: dict[str, AirbnbAccount] = field(default_factory=dict)

    def taxpayer_by_nif(self, nif: int) -> Taxpayer | None:
        """Reverse lookup used by the per-row emitter identity check (G3/G4)."""
        for t in self.taxpayers.values():
            if t.nif_prestador == nif:
                return t
        return None

    def resolve_listing(self, listing_id_str: str) -> Property | None:
        """Fail-closed routing (V2_PLAN section 5).

        Returns the single ACTIVE Property whose listing_id_str matches, or None
        (caller quarantines). TODO(Phase 3): enforce exactly-one-active; two+
        matches must raise/quarantine as AMBIGUOUS, never pick the first.
        """
        key = str(listing_id_str).strip()
        if not key:
            return None
        matches = [p for p in self.properties if p.active and str(p.listing_id_str).strip() == key]
        if len(matches) > 1:
            labels = [p.property_id or p.listing_name for p in matches]
            raise ValueError(
                f"AMBIGUOUS routing: listing_id_str {key!r} matches {len(matches)} active "
                f"properties {labels} - never pick the first (V2_PLAN section 5)."
            )
        return matches[0] if matches else None


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------
def _read_toml(path: Path) -> dict:
    """Parse one REQUIRED registry TOML file; missing file is a hard error."""
    if not path.exists():
        raise FileNotFoundError(
            f"Registry file not found: {path}\n"
            f"  Run setup.bat (or `python setup_taxpayer.py`) to create it."
        )
    with path.open("rb") as f:
        return tomllib.load(f)


def _read_toml_optional(path: Path) -> dict:
    """Parse an OPTIONAL registry TOML file; a missing file reads as empty.

    Only taxpayers.toml is strictly required to run (login + preview). The routing
    files (properties / deployments / airbnb_accounts) may not exist yet on a
    freshly set-up operator machine — treat them as empty rather than crashing the
    whole tool with a traceback (review finding B2). An empty properties registry
    simply means every emit row fails the G2 re-resolve as 'settings drift' (a loud,
    per-row ERROR the operator can see and fix), never a wrong or silent filing."""
    if not path.exists():
        return {}
    with path.open("rb") as f:
        return tomllib.load(f)


def load_registry(registry_dir: Path | str = REGISTRY_DIR) -> Registry:
    """Load + cross-validate the four registry TOMLs into a Registry.

    TODO(Phase 3): parse each [[table]] array into its dataclass, then enforce
    the load-bearing invariants (module docstring):
      - at_login_username base NIF == nif_prestador  (copy-paste guard)
      - cred_mode in CRED_MODES; sheet_adapter in SHEET_ADAPTERS
      - every Property.taxpayer_id / airbnb_account_id resolves
      - listing_id_str uniqueness (A2 collision audit, V2_PLAN section 5)
    Raises ValueError on any violated invariant (fail-fast — never a partial
    Registry), FileNotFoundError if a file is missing.
    """
    registry_dir = Path(registry_dir)
    tx_raw = _read_toml(registry_dir / "taxpayers.toml")            # REQUIRED
    pr_raw = _read_toml_optional(registry_dir / "properties.toml")  # routing (may be empty)
    dp_raw = _read_toml_optional(registry_dir / "deployments.toml")
    ac_raw = _read_toml_optional(registry_dir / "airbnb_accounts.toml")

    reg = Registry()

    # --- airbnb accounts (referenced by deployments + properties) ---
    for d in ac_raw.get("account", []):
        acc = AirbnbAccount(
            account_id=str(d["account_id"]),
            label=str(d.get("label", "")),
            airbnb_user_id=str(d.get("airbnb_user_id", "")),
        )
        if acc.account_id in reg.airbnb_accounts:
            raise ValueError(f"duplicate airbnb account_id {acc.account_id!r}")
        reg.airbnb_accounts[acc.account_id] = acc

    # --- taxpayers ---
    for d in tx_raw.get("taxpayer", []):
        nif = int(str(d["nif_prestador"]).strip())
        t = Taxpayer(
            taxpayer_id=str(d["taxpayer_id"]),
            nif_prestador=nif,
            nome_prestador=str(d.get("nome_prestador", "")),
            morada_fiscal_prestador=str(d.get("morada_fiscal_prestador", "")),
            morada_fiscal=str(d.get("morada_fiscal", "")),
            estabelecimento_comercial=str(d.get("estabelecimento_comercial", "")),
            at_login_username=str(d["at_login_username"]),
            cred_mode=str(d.get("cred_mode", "prompt")),
            data_inicio_atividade=str(d.get("data_inicio_atividade", "")),
            iva_cod_enq=str(d.get("iva_cod_enq", "")),
            iva_desc_enq=str(d.get("iva_desc_enq", "")),
            iva_cod_tipo_operacoes=str(d.get("iva_cod_tipo_operacoes", "")),
            iva_tipo_sujeito_passivo=str(d.get("iva_tipo_sujeito_passivo", "")),
        )
        if t.taxpayer_id in reg.taxpayers:
            raise ValueError(f"duplicate taxpayer_id {t.taxpayer_id!r} (slug collision)")
        if t.cred_mode not in CRED_MODES:
            raise ValueError(
                f"taxpayer {t.taxpayer_id!r}: cred_mode {t.cred_mode!r} not in {CRED_MODES}")
        base = t.at_login_username.split("/")[0]
        if not base.isdigit() or int(base) != t.nif_prestador:
            raise ValueError(
                f"taxpayer {t.taxpayer_id!r}: at_login_username base {base!r} != nif_prestador "
                f"{t.nif_prestador} (copy-paste guard, V2_PLAN section 6.2)")
        reg.taxpayers[t.taxpayer_id] = t

    # --- deployments ---
    for d in dp_raw.get("deployment", []):
        dep = Deployment(
            deployment_id=str(d["deployment_id"]),
            spreadsheet_id=str(d.get("spreadsheet_id", "")),
            sheet_adapter=str(d["sheet_adapter"]),
            airbnb_accounts=[str(a) for a in d.get("airbnb_accounts", [])],
            serializer_url=str(d.get("serializer_url", "")),
        )
        if dep.deployment_id in reg.deployments:
            raise ValueError(f"duplicate deployment_id {dep.deployment_id!r}")
        if dep.sheet_adapter not in SHEET_ADAPTERS:
            raise ValueError(
                f"deployment {dep.deployment_id!r}: sheet_adapter {dep.sheet_adapter!r} "
                f"not in {SHEET_ADAPTERS}")
        for a in dep.airbnb_accounts:
            if a not in reg.airbnb_accounts:
                raise ValueError(
                    f"deployment {dep.deployment_id!r}: airbnb_account {a!r} "
                    f"not in airbnb_accounts.toml")
        reg.deployments[dep.deployment_id] = dep

    # --- properties (routing rules) ---
    for d in pr_raw.get("property", []):
        p = Property(
            listing_id_str=str(d["listing_id_str"]),
            listing_name=str(d.get("listing_name", "")),
            taxpayer_id=str(d["taxpayer_id"]),
            cae_code=str(d["cae_code"]),
            cae_descr=str(d.get("cae_descr", "")),
            airbnb_account_id=str(d.get("airbnb_account_id", "")),
            active=bool(d.get("active", True)),
            property_id=str(d.get("property_id", "")),
            al_number=str(d.get("al_number", "")),
        )
        if p.taxpayer_id not in reg.taxpayers:
            raise ValueError(
                f"property {p.listing_id_str!r}: taxpayer_id {p.taxpayer_id!r} "
                f"not in taxpayers.toml")
        if p.airbnb_account_id and p.airbnb_account_id not in reg.airbnb_accounts:
            raise ValueError(
                f"property {p.listing_id_str!r}: airbnb_account_id {p.airbnb_account_id!r} "
                f"not in airbnb_accounts.toml")
        reg.properties.append(p)

    # --- A2: a listing_id_str must be active under at most one property ---
    seen: dict[str, str] = {}
    for p in reg.properties:
        if not p.active:
            continue
        key = str(p.listing_id_str).strip()
        owner = p.property_id or p.taxpayer_id
        if key in seen:
            raise ValueError(
                f"listing_id_str {key!r} is active under two properties ({seen[key]} and "
                f"{owner}) - A2 cross-taxpayer collision (V2_PLAN section 5).")
        seen[key] = owner

    return reg


# ---------------------------------------------------------------------------
# Credential resolution (DECISION E)
# ---------------------------------------------------------------------------
def resolve_credential(
    taxpayer: Taxpayer,
    *,
    assume_yes: bool = False,
    cli_override: str | None = None,
) -> ResolvedCredential:
    """Resolve the AT password for `taxpayer` per its cred_mode (DECISION E).

    Modes (V2_PLAN section 6.2):
      - "prompt": getpass at run time, never persisted. Under assume_yes
        (a scheduled --yes run) this is a HARD ERROR — prompt mode must never
        block a headless run.
      - "stored": OS secret store keyed by nif_prestador (keyring preferred,
        DPAPI-wrapped .cred fallback).

    cli_override, if given, takes precedence (source="cli_override") — used by
    the BAT launcher to pass a freshly prompted password without re-prompting.

    The keyring is keyed by nif_prestador (taxpayer.keyring_service()) so a
    registry copied onto a laptop that already holds a different person under a
    colliding human slug cannot bind the wrong password.

    TODO(Phase 3): implement prompt (getpass) + stored (keyring/DPAPI) branches;
    raise on cred_mode not in CRED_MODES; enforce the assume_yes+prompt hard
    error. Reuse the keyring/DPAPI patterns from v1 setup_profile.py.
    """
    if cli_override is not None:
        return ResolvedCredential(
            nif_prestador=taxpayer.nif_prestador,
            at_login_username=taxpayer.at_login_username,
            password=cli_override,
            source="cli_override",
        )
    if taxpayer.cred_mode not in CRED_MODES:
        raise ValueError(
            f"taxpayer {taxpayer.taxpayer_id!r}: unknown cred_mode "
            f"{taxpayer.cred_mode!r} (expected one of {CRED_MODES})"
        )
    if taxpayer.cred_mode == "prompt" and assume_yes:
        raise RuntimeError(
            f"taxpayer {taxpayer.taxpayer_id!r}: cred_mode='prompt' cannot run "
            f"under --yes (a scheduled run must use cred_mode='stored')."
        )
    if taxpayer.cred_mode == "prompt":
        pw = getpass.getpass(
            f"AT password for {taxpayer.taxpayer_id} (NIF {taxpayer.nif_prestador}): ")
        if not pw:
            raise RuntimeError(f"taxpayer {taxpayer.taxpayer_id!r}: empty password entered")
        return ResolvedCredential(
            nif_prestador=taxpayer.nif_prestador,
            at_login_username=taxpayer.at_login_username,
            password=pw,
            source="prompt",
        )

    # cred_mode == "stored": OS secret store keyed by nif_prestador (DECISION E).
    pw = keyring.get_password(taxpayer.keyring_service(), CRED_KEY_PASSWORD)
    if pw is None:
        raise RuntimeError(
            f"taxpayer {taxpayer.taxpayer_id!r}: no stored AT password under "
            f"{taxpayer.keyring_service()!r}. Run: python setup_taxpayer.py add {taxpayer.taxpayer_id}")
    return ResolvedCredential(
        nif_prestador=taxpayer.nif_prestador,
        at_login_username=taxpayer.at_login_username,
        password=pw,
        source="keyring",
    )
