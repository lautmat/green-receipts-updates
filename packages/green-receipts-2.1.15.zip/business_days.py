"""Business-day date math — PURE stdlib, no holiday calendar (explicit decision).

Backs the Portuguese "issue the Fatura-Recibo within 5 business days of payment"
deadline. Business days = weekdays only (Mon-Fri); Saturday + Sunday are skipped.
There is DELIBERATELY no holiday calendar — Portal deadlines are counted in plain
weekdays and a holiday table would drift stale + is a per-region concern. No
network, no I/O.

  add_business_days(d, n)          -> date : advance n weekdays FORWARD (n>=0)
  issue_by(payment_date, n=5)      -> "YYYY-MM-DD" : the emit deadline
  business_days_left(deadline, today) -> int : signed weekdays today -> deadline
"""
from __future__ import annotations

from datetime import date, timedelta


def _as_date(d: date | str) -> date:
    """Accept a date or an ISO 'YYYY-MM-DD' string; return a date (no time part)."""
    if isinstance(d, date):
        return d
    return date.fromisoformat(str(d).strip())


def _is_weekday(d: date) -> bool:
    return d.weekday() < 5   # Mon..Fri == 0..4; Sat/Sun == 5/6


def add_business_days(d: date | str, n: int) -> date:
    """The date ``n`` business days FORWARD from ``d`` (n>=0).

    ``d`` is a date OR an ISO string. n=0 returns the same day unchanged (no
    snap onto a weekday). Each forward step lands on a weekday; Sat/Sun don't
    count — add_business_days(Fri, 1) == the following Monday.
    """
    if n < 0:
        raise ValueError(f"add_business_days needs n>=0, got {n}")
    cur = _as_date(d)
    left = n
    while left > 0:
        cur += timedelta(days=1)
        if _is_weekday(cur):
            left -= 1
    return cur


def issue_by(payment_date: date | str, n: int = 5) -> str:
    """The 'issue within n business days' deadline = payment_date + n business days.

    Returns an ISO 'YYYY-MM-DD' string (the form the pipeline carries dates in).
    """
    return add_business_days(payment_date, n).isoformat()


def _business_days_between(a: date, b: date) -> int:
    """Count business days stepping from ``a`` up to ``b`` (a<=b): each weekday
    landed on AFTER ``a``, through ``b`` inclusive. Same semantics as the forward
    step in add_business_days, so it's the inverse count."""
    count = 0
    cur = a
    while cur < b:
        cur += timedelta(days=1)
        if _is_weekday(cur):
            count += 1
    return count


def business_days_left(deadline: date | str, today: date | str) -> int:
    """Signed business days from ``today`` to ``deadline`` (0 when equal).

    Positive = days remaining; NEGATIVE = overdue (today past the deadline).
    Both args accept a date or an ISO string. The magnitude is the number of
    add_business_days steps between the two dates (weekends don't count).
    """
    dl = _as_date(deadline)
    td = _as_date(today)
    if dl >= td:
        return _business_days_between(td, dl)
    return -_business_days_between(dl, td)
