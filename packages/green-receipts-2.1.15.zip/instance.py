"""Instance identity — lets several Green Receipts deployments run side by side on ONE Windows
login without sharing any local state (e.g. an operator's own AL next to their clients' firm deployment, or
the owner's own account next to a friend's).

An instance is named by ``GR_INSTANCE`` (set by config.bat). Unset/empty = the DEFAULT instance,
which keeps every legacy location byte-for-byte (``~/.config/green_receipts``, app port 8756,
bridge port 18482, ``%APPDATA%\\Green Receipts``) so existing installs are untouched.

A NAMED instance gets:
  - its own config dir   ``~/.config/green_receipts/instances/<name>/`` (registry, receipts,
    logs, dedupe seen-files, last_capture.json, bridge_token, Drive token);
  - its own app-data dir ``%APPDATA%\\Green Receipts\\<name>\\`` (app.log);
  - its own ports, which MUST be set explicitly (GR_APP_PORT / GR_BRIDGE_PORT) and must differ
    from the default instance's. Fail-closed: a named instance that would fall back to the default
    ports could reopen the OTHER instance's window or pair with the OTHER instance's extension.

Everything here is read from the environment at call time, so tests can monkeypatch os.environ.
Module name is ``instance`` (repo root) so emit.py, the app and the bridge can all import it.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

DEFAULT_APP_PORT = 8756
DEFAULT_BRIDGE_PORT = 18482
APP_NAME = "Green Receipts"

_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,31}$")


class InstanceConfigError(RuntimeError):
    """The instance settings in config.bat are missing or unsafe (refuse to start)."""


def name() -> str:
    """The instance slug ('' = the default instance). Lower-case letters, digits, dashes."""
    raw = (os.environ.get("GR_INSTANCE") or "").strip().lower()
    if raw in ("", "default"):
        return ""
    if not _NAME_RE.match(raw):
        raise InstanceConfigError(
            f"GR_INSTANCE={raw!r} is not a valid instance name — use 1-32 lower-case letters, "
            "digits or dashes (e.g. 'operator-b', 'firm-clients').")
    return raw


def is_default() -> bool:
    return name() == ""


def label() -> str:
    """Human label shown in the window title + UI header ('' for the default instance)."""
    n = name()
    if not n:
        return ""
    return (os.environ.get("GR_INSTANCE_LABEL") or "").strip() or n.replace("-", " ").title()


def display_name() -> str:
    lb = label()
    return f"{APP_NAME} — {lb}" if lb else APP_NAME


def config_dir() -> Path:
    """Root of this instance's local state. Default instance = the legacy location."""
    base = Path.home() / ".config" / "green_receipts"
    n = name()
    return base / "instances" / n if n else base


def appdata_dir() -> Path:
    """Where app.log lives (%APPDATA%\\Green Receipts[\\<name>])."""
    base = Path(os.environ.get("APPDATA") or str(Path.home())) / APP_NAME
    n = name()
    return base / n if n else base


def _port(var: str, default: int) -> int:
    raw = (os.environ.get(var) or "").strip()
    if not raw:
        if is_default():
            return default
        raise InstanceConfigError(
            f"Instance {name()!r} has no {var} in config.bat. A named instance needs its own "
            f"ports so it can never reach another instance's app or extension.")
    try:
        port = int(raw)
    except ValueError:
        raise InstanceConfigError(f"{var}={raw!r} is not a port number.") from None
    if not 1024 <= port <= 65535:
        raise InstanceConfigError(f"{var}={port} is outside 1024-65535.")
    if not is_default() and port in (DEFAULT_APP_PORT, DEFAULT_BRIDGE_PORT):
        raise InstanceConfigError(
            f"Instance {name()!r} uses {var}={port}, which belongs to the default instance. "
            "Pick a different port.")
    return port


def app_port() -> int:
    return _port("GR_APP_PORT", DEFAULT_APP_PORT)


def bridge_port() -> int:
    return _port("GR_BRIDGE_PORT", DEFAULT_BRIDGE_PORT)


def validate() -> None:
    """Resolve everything once at startup so a bad config.bat fails loudly and early."""
    name()
    a, b = app_port(), bridge_port()
    if a == b:
        raise InstanceConfigError(f"GR_APP_PORT and GR_BRIDGE_PORT are both {a}; they must differ.")


def describe() -> dict:
    """What /health reports — lets the UI (and a second launch) see WHICH instance is running."""
    return {"instance": name(), "instance_label": label(), "bridge_port": bridge_port()}
