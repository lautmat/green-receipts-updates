#!/usr/bin/env python3
"""Process-global memory of the last AT (Portal) login OUTCOME per taxpayer, so the long-lived app
does NOT keep re-attempting a credential that is temporarily BLOCKED or known-WRONG — each failed
attempt is exactly what EXTENDS an AT lockout. Keyed by nif_prestador (the id both the app backend
and the free-function emit path always have). Advisory + fail-open: a miss just means "go ahead and
try", so a restart or race costs at most one extra real attempt.

Lives at the repo root (not under app/) so emit.py can import it without depending on the app
package (app/backend.py already imports from emit; this avoids a cycle)."""
from __future__ import annotations

import threading
import time

_CACHE: dict[int, dict] = {}     # nif -> {"kind", "message", "ts"}
_LOCK = threading.Lock()

# How long to suppress re-attempts, per failure kind:
#   blocked         -> the AT lockout; wait before touching it again (retrying extends it)
#   bad_credentials -> never auto-expire; only a password change clears it (retrying can LOCK it)
# Any other kind (portal_error / otp_required / no_cred) is NOT cached — transient / legitimate /
# local-only, and must never be suppressed.
_COOLDOWN: dict[str, int | None] = {"blocked": 20 * 60, "bad_credentials": None}


def record(nif, kind: str, message: str = "") -> None:
    """Remember the outcome. A success (or any non-suppressed kind) CLEARS the entry."""
    with _LOCK:
        if kind == "ok" or kind not in _COOLDOWN:
            _CACHE.pop(int(nif), None)
        else:
            _CACHE[int(nif)] = {"kind": kind, "message": message, "ts": time.time()}


def check(nif):
    """Return the active block entry (with seconds_left) if this taxpayer should NOT be logged in
    right now, else None (clear to try). A time-based cooldown that has elapsed is auto-cleared."""
    with _LOCK:
        e = _CACHE.get(int(nif))
        if not e:
            return None
        cd = _COOLDOWN.get(e["kind"])
        if cd is None:                                   # bad_credentials: until password change
            return {**e, "seconds_left": None}
        left = cd - (time.time() - e["ts"])
        if left <= 0:
            _CACHE.pop(int(nif), None)
            return None
        return {**e, "seconds_left": int(left)}


def clear(nif) -> None:
    """Forget this taxpayer's cached failure (called on a password change so the next login retries)."""
    with _LOCK:
        _CACHE.pop(int(nif), None)


def guidance(e: dict) -> str:
    """Operator-facing, actionable text for a cached block/bad-credential."""
    if e.get("kind") == "blocked":
        mins = max(1, (e.get("seconds_left") or 0) // 60)
        return (f"Your Portal sign-in is temporarily locked from too many attempts — wait ~{mins} "
                f"more min; do not keep retrying (each try extends the lock).")
    if e.get("kind") == "bad_credentials":
        return ("The saved Portal password was rejected last time. Change it in Settings before "
                "trying again — repeated wrong sign-ins will lock the credential.")
    return e.get("message") or "the previous sign-in failed"
