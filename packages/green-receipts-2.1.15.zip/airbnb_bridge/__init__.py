"""green-receipts v2 — Airbnb capture bridge (Phase 6 scaffold).

This package is the **extension** ingestion adapter (decision B: one ingestion
source per deployment; this is the `extension` source, default for the operators).
It captures completed reservations + their VAT (commission) invoices directly
from the user's warm Chrome session via an MV3 extension over a local
WebSocket, then POSTs canonical rows to the Apps Script serializer (decision D).

Architecture (adapted from AL-analytics `tools/host_bridge`):

    extensao/  (MV3 Chrome extension = WS CLIENT)
        |  ws://127.0.0.1:18472   GET/HEAD only, *.airbnb.com only
        v
    host_bridge.HostBridge  (Python = WS SERVER, async context manager)
        |
        v
    reservations_adapter.ingest_extension(...)
        - page  GET /api/v2/reservations  (completed query)
        - fetch GET /<invoice_url>         (host_vat_invoices)
        - map -> canonical row, POST /ingest to the serializer

Settled decisions encoded here:
  B  one ingestion source per deployment (this = `extension`)
  C  reservations-API + invoice capture on the user's own Chrome session
     (extension never logs in, never sees credentials, OTP = human)

NOTE: This is a Phase-0 SCAFFOLD. Business logic is stubbed with
`TODO(Phase 6)` markers that reference docs/V2_PLAN.md. Nothing here emits a
receipt or writes to a live sheet.
"""
from __future__ import annotations

from .host_bridge import (
    BridgeError,
    BridgeJobResult,
    HostBridge,
    host_bridge,
    ALLOWED_METHODS,
    ALLOWLIST_RE,
    DEFAULT_HOST,
    DEFAULT_PORT,
)

__all__ = [
    "BridgeError",
    "BridgeJobResult",
    "HostBridge",
    "host_bridge",
    "ALLOWED_METHODS",
    "ALLOWLIST_RE",
    "DEFAULT_HOST",
    "DEFAULT_PORT",
    "ingest_extension",
]

# Lazy alias so `from airbnb_bridge import ingest_extension` works without
# importing the (heavier) adapter module at package import time.
def __getattr__(name: str):  # pragma: no cover - thin lazy shim
    if name == "ingest_extension":
        from .reservations_adapter import ingest_extension
        return ingest_extension
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
