"""Extension ingestion adapter — Reservations API + VAT invoices (Phase 6 scaffold).

This is the ``extension`` ingestion source (decision B). It pages the confirmed
Reservations REST endpoint, fetches each reservation's VAT (commission)
invoices, derives the green-receipt figures, and POSTs ONE canonical row per
emittable completed reservation to the Apps Script serializer (decision D, op
``ingest``). It NEVER writes to the sheet directly and NEVER emits a receipt.

Capture mechanism (CONFIRMED live 2026-06-21 — docs/V2_PLAN.md "CAPTURE
MECHANISM", which supersedes the old earnings-CSV/S3 path):

  1) GET /api/v2/reservations  (completed query, pageable)        -> per stay
  2) GET /<invoice_url>        (each host_vat_invoices[] entry)    -> service fee

Derived figures (docs/V2_PLAN.md "Deriving the green-receipt figures"):
  service_fee     = the id:0 VAT invoice's "Service Fee" (AUTHORITATIVE; replaces
                    v1's =N*0.03/0.97 guess)
  total_payout    = parsed `earnings` (a formatted NET string, e.g. "€694.79")
  total_to_report = total_payout + service_fee   (== v1 M = N + P, the gross/TTC)

This module is a Phase-0 SCAFFOLD: signatures, the field-mapping, and the
load-bearing decisions are encoded; all fetching/parsing/POSTing is
``TODO(Phase 6)``.
"""
from __future__ import annotations

import asyncio
import calendar
import json
import logging
import random
import re
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Any

from . import extractors
from .extractors import AIRBNB_WEB_API_KEY, RESERVATIONS_PAGE_SIZE
from .host_bridge import BridgeError, HostBridge, host_bridge

log = logging.getLogger("airbnb_bridge.adapter")

# Airbnb Ireland VAT id on every commission invoice (reverse charge). Used to
# sanity-check the parsed invoice + as the Modelo 30 counterparty. Not a secret.
AIRBNB_IRELAND_VAT_ID = "IE9827384L"


class ChallengeError(Exception):
    """A login/OTP wall was hit mid-capture (a /login redirect or login-page body).

    The adapter catches this, sets ``IngestReport.challenge``, and PAUSES — it
    never writes a partial period (which the completeness gate would misread as
    "month fully captured"). The human completes the SMS-OTP in their own tab and
    re-runs. See docs/V2_PLAN.md §3.3.
    """


class IngestError(Exception):
    """The serializer rejected a row, or replied with something un-parseable."""


class AccountMismatchError(Exception):
    """None of the newest stays the logged-in Airbnb session returns is on a listing this
    deployment owns — almost always the WRONG Airbnb account in this Chrome profile (e.g. a
    second instance's extension riding the first instance's session). Raised BEFORE any fee
    lookup or ingest, so nothing from the foreign account is read further or written.

    Carries the diagnostics for the logs (never shown to the operator verbatim):
    ``seen_listings`` = the listing ids on the refused page, ``owned_count``."""

    def __init__(self, message, *, seen_listings=(), owned_count=0):
        super().__init__(message)
        self.seen_listings = sorted({str(x) for x in seen_listings})
        self.owned_count = owned_count


class NoOwnedListingsError(AccountMismatchError):
    """No active listing is configured for this deployment yet (nothing could be attributed)."""


# Markers that a fetch silently followed a redirect to the auth wall and returned
# the login page (HTTP 200, HTML) instead of the data — the cold-session case.
# "/login", "auth/login" and the page_name JSON are LOCALE-INDEPENDENT (they always fire); the human-text
# markers are a fallback and carry both EN and PT ("iniciar/inicie sessão") so a Portuguese login wall on a
# 200-status HTML page is still recognised rather than mistaken for data (silent under-capture).
_LOGIN_MARKERS = ("/login", "auth/login", '"page_name":"login"',
                  "log in to airbnb", "iniciar sessão", "inicie sessão", "iniciar sessao", "inicie sessao")


def _looks_like_login(body: str) -> bool:
    low = (body or "")[:4000].lower()
    return any(m in low for m in _LOGIN_MARKERS)


def _json_is_login(data: object) -> bool:
    """Defence-in-depth for the reservations/stay_details paths (which return a PARSED dict and never
    re-scan the raw body): a 200-status login body that happens to parse as JSON would otherwise be
    captured as an empty period. Re-serialise with no-space separators and match ONLY the unambiguous
    page_name marker — NOT the loose "/login" substring, which could legitimately appear in a data URL."""
    try:
        blob = json.dumps(data, separators=(",", ":"), default=str).lower()
    except (TypeError, ValueError):
        return False
    return '"page_name":"login"' in blob or '"page_name":"signup_login"' in blob


def months_before(d: date, n: int) -> date:
    """The date ``n`` calendar months before ``d`` (day clamped to month length).

    Used for the history-backfill floor: green receipts are not issued for stays
    whose check-in is more than N months old (default 6). Pure stdlib (no dateutil).
    """
    total = d.year * 12 + (d.month - 1) - n
    y, m = divmod(total, 12)
    m += 1
    return date(y, m, min(d.day, calendar.monthrange(y, m)[1]))


def _brief_bridge_error(msg: str) -> str:
    """A BridgeError message without its URL: ``HTTP 400 deprecated_web_operation``.

    host_bridge reports ``HTTP <status> from <url>: <body>`` and the URL of a persisted
    query is ~500 characters of url-encoded JSON — unreadable in the capture report and
    the LOG tab. Keep the status and Airbnb's ``error_type`` (or a short tail)."""
    m = re.search(r"HTTP (\d{3})", msg or "")
    status = f"HTTP {m.group(1)}" if m else ""
    t = re.search(r'"error_type"\s*:\s*"([^"]{1,80})"', msg or "")
    if t:
        return f"{status} {t.group(1)}".strip()
    tail = re.sub(r"https?://\S+", "<url>", msg or "").strip()
    return (tail[:160] or "unknown bridge error")


def _brief_graphql_errors(data: dict) -> str:
    """First GraphQL error message of a payload, short (for the capture report)."""
    errs = data.get("errors") if isinstance(data, dict) else None
    first = errs[0] if isinstance(errs, list) and errs else errs
    text = first.get("message") if isinstance(first, dict) else first
    return str(text or "")[:120]


def _is_challenge_error(msg: str) -> bool:
    """Recognise a login-wall signal in a BridgeError message.

    The extension reports a login wall as a job error string that STARTS with
    "CHALLENGE:" (see extensao/background.js handleJob) — which carries none of
    the _LOGIN_MARKERS — so we must match that prefix explicitly, in addition to
    a raw login-page body that surfaced through a non-JSON parse error, AND an
    HTTP 401/403 status (host_bridge.fetch_json raises "HTTP 401 from <url>: ...")
    — a mid-run session expiry that returns auth-error JSON instead of a login
    page previously degraded ONE row and wrote a partial month with exit 0
    (review finding); it must PAUSE the run like every other login wall.
    """
    low = (msg or "").strip().lower()
    return (low.startswith("challenge") or "login page" in low
            or bool(re.match(r"^http 40[13] ", low)) or _looks_like_login(msg))


# ---------------------------------------------------------------------------
# Canonical row field-mapping (Reservations API -> STAGING tuple).
#
# Both adapters (email + extension) POST this self-consistent per-booking tuple
# to the serializer's `ingest` op — never a row reassembled from parallel
# columns. The serializer validates `gross ~= paid_out + service_fee` and that
# `listing_id` resolves before accepting. See docs/V2_PLAN.md §3 + §2.2.
#
#   reservations API field        -> canonical STAGING field   (notes)
#   -------------------------------------------------------------------------
#   confirmation_code             -> hm_code                   HM dedup/identity
#   listing_id_str                -> listing_id                ROUTING KEY — use
#                                                              the _str; numeric
#                                                              listing_id overflows
#                                                              2^53 (returns ...3200)
#   (constant)                    -> type = "Reservation"      feeds GR
#   start_date                    -> check_in                  service date + period
#   end_date                      -> check_out
#   guest (primary guest name)    -> guest
#   earnings (parsed)             -> paid_out / total_payout   NET, formatted str
#   id:0 invoice "Service Fee"    -> service_fee               obj 7, authoritative
#   payout + service_fee          -> gross_earnings / ttc      == v1 M = N + P
#   (parsed from earnings)        -> currency                  non-EUR => needs_review
#   (constant)                    -> fee_provenance = "csv"    (extension == real fee)
#   <account identifier>          -> airbnb_account_id         obj 4 cross-check
#   confirmation_code + batch     -> source_ref
#   (constant)                    -> source = "extension"
# ---------------------------------------------------------------------------
CANONICAL_FIELDS = (
    "hm_code", "listing_id", "type", "check_in", "check_out", "guest",
    "paid_out", "service_fee", "gross_earnings", "ttc", "currency",
    "source", "airbnb_account_id", "source_ref",
)


@dataclass
class IngestReport:
    """Summary returned by ``ingest_extension`` (also printed in --dry-run)."""
    account: str
    since: date
    until: date
    dry_run: bool
    pages_fetched: int = 0
    reservations_seen: int = 0
    rows_ingested: int = 0          # POSTed to /ingest (or would-be, if dry_run)
    rows_skipped_not_complete: int = 0
    rows_skipped_too_old: int = 0   # check-in older than the backfill floor (>N months)
    rows_needs_review: int = 0      # adjustments / non-EUR / unresolved listing_id
    fee_lookups: int = 0            # StayHostingDetailsQuery fetches (the fee source)
    fee_retries: int = 0            # repeated fee reads after a refused/unreadable one
    fees_from_vat_invoice: int = 0  # stays whose fee came from the VAT-invoice fallback (8b)
    invoice_renders: int = 0        # VAT-invoice renders made by that fallback (incl. "not ready" repeats)
    invoices_fetched: int = 0       # only the deferred Phase-6b invoice verify/archive
    rows_skipped_seen: int = 0      # already-captured stays skipped (no fetch) — dedupe
    rows_skipped_foreign: int = 0   # stays on listings NOT in this deployment's Property Settings
    foreign_listings: list[str] = field(default_factory=list)  # their listing_id_str (sorted)
    foreign_counts: dict = field(default_factory=dict)          # listing_id_str -> stays skipped (logs)
    challenge: bool = False         # True if a /login wall paused the run
    reconcile: dict | None = None   # completeness gate result (if a total was given)
    errors: list[str] = field(default_factory=list)
    # NON-BLOCKING signals (completeness / reconcile). Kept STRICTLY separate from `errors` (row-level
    # failures) so a completeness gap can never be misread as a failure or gate issuance (audit finding).
    warnings: list[str] = field(default_factory=list)
    rows: list[dict] = field(default_factory=list)  # populated in dry_run
    captured_hms: list[str] = field(default_factory=list)  # HMs captured THIS run (seen-file)
    # One entry per stay that was seen, is eligible, and was NOT sent on to be issued this run (the
    # capture screen lists them; docs/PLAN_FEE_LOOKUP_400.md step 4). Keys: hm_code, guest, check_in,
    # check_out, payment_date, kind, reason (plain words for the operator), saved (True when the stay
    # is now visible in Review -> Needs review / Needs setup).
    flagged: list[dict] = field(default_factory=list)
    rows_filed_by_hand: int = 0     # parked stays the operator already marked "filed by hand" (settled)


def parse_earnings_amount(earnings: str) -> tuple[float | None, str]:
    """Parse a formatted Airbnb earnings string into (amount, currency).

    Examples: ``"€694.79"`` -> ``(694.79, "EUR")``; ``"€1,234"`` -> ``(1234.0, "EUR")``;
    ``"€1.234,56"`` -> ``(1234.56, "EUR")``; ``"€1,234,567"`` -> ``(1234567.0, "EUR")``.

    Money-grouping rules (B5 — a misparse here becomes the DECLARED income; the old
    last-separator-is-decimal heuristic turned "€1,234" into 1.23, a 1000x error):
      * both separators present -> the LAST one is the decimal separator;
      * one separator repeated  -> thousands grouping (all groups of 3);
      * ONE separator with exactly 3 digits after and 1-3 before -> thousands
        ("€1,234" and "€1.234" both mean 1234 — money never has 3 decimals);
      * otherwise a single separator is the decimal separator ("€12,34" -> 12.34).

    Returns ``(None, currency)`` for a malformed/ambiguous numeric part — the caller
    flags needs_review; NEVER a silent 0.0 or a wrong-magnitude guess. An empty/
    symbol-only input keeps the legacy ``(0.0, currency)``. A non-EUR currency flags
    the row ``needs_review`` (open question 5).
    """
    if earnings is None:
        return 0.0, ""
    s = str(earnings).strip()
    up = s.upper()
    currency = "EUR" if ("€" in s or "EUR" in up) else ("USD" if ("$" in s or "USD" in up) else "")
    digits = re.sub(r"[^0-9.,\-]", "", s)
    neg = digits.startswith("-")
    d = digits.lstrip("-")
    if "-" in d:                      # a stray interior '-' is malformed, refuse to guess
        return None, currency
    if not d.strip(".,"):             # empty / separators only -> legacy empty result
        return 0.0, currency

    dots, commas = d.count("."), d.count(",")
    num = None
    _head = re.compile(r"[1-9]\d{0,2}$")  # a thousands head: 1-3 digits, no leading zero
    if dots and commas:
        # Both present: the LAST separator is the decimal one, the other is thousands —
        # and the whole shape must be VALID money grouping: 1-2 decimal digits, integer
        # part grouped as 1-3 then 3s ("12.34,56" or "1,234.567" are malformed -> None).
        dec = "," if d.rfind(",") > d.rfind(".") else "."
        thou = "." if dec == "," else ","
        intpart, _, tail = d.rpartition(dec)
        groups = intpart.split(thou)
        if (1 <= len(tail) <= 2 and tail.isdigit() and _head.match(groups[0] or "")
                and all(len(g) == 3 and g.isdigit() for g in groups[1:])):
            num = "".join(groups) + "." + tail
    elif dots or commas:
        sep = "." if dots else ","
        head, *groups = d.split(sep)
        if len(groups) > 1:
            # Repeated separator -> thousands grouping; anything else is malformed.
            if all(len(g) == 3 and g.isdigit() for g in groups) and _head.match(head):
                num = d.replace(sep, "")
        elif len(groups[0]) == 3 and _head.match(head):
            num = head + groups[0]    # "1,234" / "1.234" -> 1234 (thousands)
        elif len(groups[0]) <= 2:
            num = head + "." + groups[0] if groups[0] else head
        # else: stays None — >3 digits after one separator is money in NEITHER convention,
        # and a zero/leading-zero head ("0,500") is not a thousands read -> needs_review.
    else:
        num = d
    if not num:
        return None, currency
    try:
        val = round(float(num), 2)
    except ValueError:
        return None, currency
    return (-val if neg else val), currency


def implausible_fee(paid_out, service_fee) -> bool:
    """Plausibility cross-check (B5): the Airbnb host service fee is a small cut of
    gross (3-16%), so a POSITIVE fee larger than the payout itself is the signature
    of a wrong-magnitude amount (e.g. a payout misparsed 1000x low) — flag for
    review, never declare. Credit notes (negative fee) and missing values are the
    caller's separate concerns."""
    if paid_out is None or service_fee is None:
        return False
    return service_fee > 0 and service_fee > paid_out


def parse_host_service_fee(details: Any) -> float | None:
    """Extract the host service fee (a positive commission) from a
    ``StayHostingDetailsQuery`` payload — the GET-only fee source that replaces
    rendering the client-only invoice page (decision 2026-06-22, the owner).

    The payout breakdown carries a line item ``{"label": "Host service fee (3.0%)",
    "formattedValue": "-€21.49"}`` (the rate varies per host/period). We match the
    EXACT fee line — "host service fee" optionally followed by a "(rate)" — so a
    sibling like "Host service fee VAT" is NOT picked up. The fee is shown NEGATIVE
    in the payout, so we return its absolute value. Verified equal to the invoice fee.

    Fail-closed for tax safety: returns ``None`` (caller -> needs_review, never a
    silent wrong number) on a GraphQL error at ANY depth (e.g. a stale persistedQuery
    hash), an absent line item, OR when two host-service-fee line items disagree.
    """
    found, had_error = _scan_host_service_fees(details)
    if had_error:
        return None
    if not found:
        return None
    if len(set(found)) > 1:  # conflicting line items -> refuse to guess
        return None
    return found[0]


def details_fee_conflict(details: Any) -> bool:
    """True when a StayHostingDetailsQuery payload answered cleanly (no GraphQL error) but carries
    TWO DIFFERENT host-service-fee line items. That is not "the fee is unavailable": Airbnb told us
    two things, so a person must look — the VAT-invoice fallback is NOT used for it."""
    found, had_error = _scan_host_service_fees(details)
    return (not had_error) and len(set(found)) > 1


def _scan_host_service_fees(details: Any) -> tuple[list[float], bool]:
    """Every host-service-fee amount found in a details payload, and whether it had a GraphQL error."""
    if not isinstance(details, dict):
        return [], False
    found: list[float] = []
    had_error = False
    # The label must END after "fee" or continue into a RATE parenthesis "(3.0%)" — a digit must follow
    # the "(", so a "Host service fee (VAT)" sibling can never be mistaken for the fee itself.
    fee_label = re.compile(r"^host service fee\s*(\(\d|$)", re.I)
    # Third safety layer if Airbnb ignores locale=en + Accept-Language and returns Portuguese: the host
    # service fee is "Comissão/Taxa de serviço ... anfitrião". Same rule — require the label to END after
    # "anfitrião" or open a rate "(3,0%)" so neither "... IVA" nor "... (IVA)" VAT siblings are matched.
    fee_label_pt = re.compile(r"^(comiss[ãa]o|taxa) de servi[çc]o.*anfitri[ãa]o\s*(\(\d|$)", re.I)

    def walk(node):
        nonlocal had_error
        if isinstance(node, dict):
            if node.get("errors"):  # GraphQL errors at ANY depth -> bail
                had_error = True
            label, fv = node.get("label"), node.get("formattedValue")
            if isinstance(label, str) and (fee_label.match(label.strip()) or fee_label_pt.match(label.strip())) and fv:
                amt, _ = parse_earnings_amount(fv)
                if amt is not None:
                    found.append(abs(round(amt, 2)))
            for v in node.values():
                walk(v)
        elif isinstance(node, list):
            for v in node:
                walk(v)

    walk(details)
    return found, had_error


def parse_service_fee(invoice_html: str) -> dict[str, Any]:
    """Parse one VAT invoice's HTML into structured fee fields.

    NOTE: as of 2026-06-22 the invoice is fetched only for the deferred Phase-6b
    verification/archival step — the EMITTABLE fee comes from
    ``parse_host_service_fee`` (StayHostingDetailsQuery), because the invoice page
    is client-rendered and a GET returns only a shell. This parser still serves the
    rendered-DOM verification path.

    Returns (Phase 6): ``{service_fee, vat, reverse_charge, invoice_number,
    issue_date, parties_vat_ids}`` — the id:0 invoice's ``service_fee`` is the
    authoritative commission (obj 7). Asserts the Airbnb-Ireland VAT id +
    reverse-charge marker are present as a sanity check.
    """
    t = invoice_html or ""

    def find(pat):
        m = re.search(pat, t, re.I)
        return m.group(1).strip() if m else None

    fee_raw = find(r"Service Fee\s*(-?\s*€?\s*[\d.,]+)")
    number = find(r"Invoice number:?\s*([A-Za-z0-9\-]+)")
    return {
        "service_fee": parse_earnings_amount(fee_raw)[0] if fee_raw else None,  # signed (CN is negative)
        "vat": None,
        "reverse_charge": bool(re.search(r"reverse charge applies", t, re.I)),
        "invoice_number": number,
        "issue_date": find(r"issue date:?\s*(\d{4}-\d{2}-\d{2})"),
        "hm_code": find(r"\bfor\s+(HM[0-9A-Za-z]+)"),
        "is_credit_note": bool(re.search(r"\bcredit note\b", t, re.I)) or bool(number and "-CN-" in number.upper()),
        "parties_vat_ids": re.findall(r"VAT ID:?\s*([A-Z]{2}[0-9A-Za-z]+)", t, re.I),
        "airbnb_ireland_ok": AIRBNB_IRELAND_VAT_ID in t,
    }


# A money amount in RENDERED invoice text (after NBSP -> space): "€40.08 EUR", "-€11.49 EUR",
# "€ 40.08", "40.08 EUR". A currency marker (symbol or ISO code) is REQUIRED, so "0.0%" (the VAT
# rate column) and dates are never read as money.
_INV_MONEY = re.compile(
    r"(?P<neg>[-−])?\s*(?P<sym>[€$£])\s*(?P<neg2>[-−])?\s*(?P<num>\d(?:[\d.,]*\d)?)(?:\s*(?P<code>[A-Z]{3})\b)?"
    r"|(?P<neg3>[-−])?(?P<num3>\d(?:[\d.,]*\d)?)\s*(?P<code3>[A-Z]{3})\b")


def _invoice_amounts(text: str) -> list[tuple[float | None, str, int, int]]:
    """(amount, currency, start, end) for every money token in ``text``; amount None = unparseable."""
    out = []
    for m in _INV_MONEY.finditer(text):
        if m.group("num") is not None:
            num, sym, code = m.group("num"), m.group("sym"), m.group("code") or ""
            neg = bool(m.group("neg") or m.group("neg2"))
            cur_sym = {"€": "EUR", "$": "USD", "£": "GBP"}[sym]
            currency = cur_sym if (not code or code == cur_sym) else f"{cur_sym}/{code}"
        else:
            num, code, neg = m.group("num3"), m.group("code3"), bool(m.group("neg3"))
            currency = code
        val, _ = parse_earnings_amount(num)
        out.append(((-val if (neg and val is not None) else val), currency, m.start(), m.end()))
    return out


# The gap between an EUR amount and its currency EQUIVALENT on the very next line: spaces and at
# most ONE line break, no tab. A table cell boundary is a line holding a tab ("\n\t\n"), so a
# foreign amount that starts a NEW cell is never mistaken for an equivalent.
_EQUIV_GAP = re.compile(r"[ \r]*\n?[ \r]*")


def _invoice_eur_cells(text: str) -> tuple[list[float | None] | None, str]:
    """The EUR amount of each cell in ``text``, in order. Airbnb prints every amount twice — the
    EUR figure, then a USD (or other) equivalent on the next line; that equivalent is dropped. A
    foreign amount that does NOT directly follow an EUR amount means the cell has no EUR figure:
    returns (None, its currency) -> non_eur."""
    cells: list[float | None] = []
    prev_eur_end = None
    for val, cur, start, end in _invoice_amounts(text):
        if cur == "EUR":
            cells.append(val)
            prev_eur_end = end
            continue
        if prev_eur_end is not None and _EQUIV_GAP.fullmatch(text[prev_eur_end:start]):
            prev_eur_end = None          # the equivalent of the EUR amount just read: ignored
            continue
        return None, cur
    return cells, ""


def parse_invoice_service_fee(text: str) -> dict[str, Any]:
    """Read the host service fee from the RENDERED text of ONE Airbnb VAT invoice (the 8b fallback,
    docs/PLAN_FEE_LOOKUP_400.md). Real layout (rendered 2026-11-11, tests/fixtures/invoice_*.txt):

        PT<tab>0.0%<tab>Service Fee<tab>
        €13.34<nbsp>EUR          <- Base Fee Amount
        $15.30<nbsp>USD          <- its USD equivalent (ignored)
        <tab>
        €0.00<nbsp>EUR           <- VAT Amount (0.00: reverse charge)
        $0.00<nbsp>USD
        <tab>
        €13.34<nbsp>EUR          <- Total Fee Including VAT
        $15.30<nbsp>USD
        <tab><tab><tab><tab>Subtotal<tab>
        €13.34<nbsp>EUR
        $15.30<nbsp>USD

    Returns ``{"fee": float|None, "status": str, "detail": str}``. ``status``:
      * ``ok``        — exactly one "Service Fee" line; its cells are EITHER the three cells above
                        with Base Fee == Total including VAT and VAT == 0.00, OR a single cell; the
                        fee is positive EUR; and the Subtotal's EUR amount equals it;
      * ``not_ready`` — no "Service Fee" line, or no amount after it yet. The FIRST render of an
                        invoice can be an empty shell (~34 characters); the caller renders again.
                        NEVER read as zero;
      * anything else — do not use it (park the stay): ``ambiguous``, ``non_eur`` (a cell with no
        EUR figure), ``credit_note`` (the document's own title says so), ``bad_amount`` (zero,
        negative, unparseable).
    Only the EUR figures are read; a USD/other EQUIVALENT line right after an EUR figure is ignored.
    Fail-closed: any doubt -> no fee. This never estimates anything."""
    t = str(text or "").replace(" ", " ").replace(" ", " ")
    labels = list(re.finditer(r"\bservice fee\b", t, re.I))
    if not labels:
        return {"fee": None, "status": "not_ready", "detail": f"no Service Fee line ({len(t)} chars)"}
    if len(labels) > 1:
        return {"fee": None, "status": "ambiguous", "detail": f"{len(labels)} Service Fee lines"}
    # The document TITLE (before "Invoice from:") says "Credit Note" on a credit note. Only the title
    # counts: a current invoice legitimately names its related credit note ("...-CN-1") in its
    # "Invoice history" footer. (A credit note's amounts are negative too, so it fails twice.)
    m_from = re.search(r"\binvoice from\b", t, re.I)
    head = t[:m_from.start()] if m_from else t[:labels[0].start()]
    if re.search(r"\bcredit note\b", head, re.I):
        return {"fee": None, "status": "credit_note", "detail": "the document is a credit note"}
    after = t[labels[0].end():]
    sub = re.search(r"\bsubtotal\b", after, re.I)
    window = after[:sub.start()] if sub else after[:300]
    if not _invoice_amounts(window):
        return {"fee": None, "status": "not_ready", "detail": "no amount after the Service Fee line yet"}
    cells, foreign = _invoice_eur_cells(window)
    if cells is None:
        return {"fee": None, "status": "non_eur", "detail": f"an amount in {foreign} with no EUR figure"}
    if not cells:
        return {"fee": None, "status": "non_eur", "detail": "no EUR amount on the Service Fee line"}
    if any(v is None for v in cells):
        return {"fee": None, "status": "bad_amount", "detail": "unparseable amount"}
    cells = [round(v, 2) for v in cells]
    if len(cells) == 3:
        base, vat, total = cells
        if vat != 0:
            return {"fee": None, "status": "ambiguous", "detail": f"VAT amount {vat:.2f} is not 0.00"}
        if base != total:
            return {"fee": None, "status": "ambiguous",
                    "detail": f"base fee {base:.2f} and total {total:.2f} disagree"}
        fee = base
    elif len(cells) == 1:
        fee = cells[0]
    else:
        return {"fee": None, "status": "ambiguous",
                "detail": f"{len(cells)} EUR amounts on the Service Fee line: "
                          + ", ".join(f"{v:.2f}" for v in cells)}
    if fee <= 0:
        return {"fee": None, "status": "bad_amount", "detail": f"fee {fee:.2f} is not positive"}
    if not sub:
        return {"fee": None, "status": "ambiguous", "detail": "no Subtotal after the Service Fee line"}
    sub_cells, _f = _invoice_eur_cells(after[sub.end():sub.end() + 120])
    if not sub_cells or sub_cells[0] is None or round(sub_cells[0], 2) != fee:
        return {"fee": None, "status": "ambiguous", "detail": "the Subtotal does not match the Service Fee"}
    return {"fee": fee, "status": "ok", "detail": ""}


def current_invoice_strict(host_vat_invoices: Any) -> tuple[dict | None, str]:
    """The ONE current (``id: 0``) VAT invoice of a stay, for the 8b fee fallback — or (None, why).
    A stay can have several invoices (seen: 11.49, -11.49, 13.34); only ``id: 0`` is current. Zero
    or several ``id: 0`` entries, or one without an invoice_url, -> None (park, never guess). The id
    must be the INTEGER 0 (``False`` / ``"0"`` do not count)."""
    invs = host_vat_invoices if isinstance(host_vat_invoices, list) else []
    cur = [i for i in invs if isinstance(i, dict) and type(i.get("id")) is int and i.get("id") == 0]
    if len(cur) != 1:
        return None, f"{len(cur)} current (id 0) invoices"
    if not str(cur[0].get("invoice_url") or "").strip():
        return None, "the current invoice has no link"
    return cur[0], ""


def classify_invoice_role(inv: dict) -> str:
    """host_vat_invoices[] entry -> role. id 0 = current (the authoritative fee);
    '-CN-' in the number = credit_note; otherwise (negative id) superseded."""
    if inv.get("id") == 0:
        return "current"
    if "-CN-" in str(inv.get("invoice_number", "")).upper():
        return "credit_note"
    return "superseded"


def current_invoice(host_vat_invoices: list[dict] | None) -> dict | None:
    """The id:0 invoice — the authoritative current commission (obj 7)."""
    for inv in (host_vat_invoices or []):
        if inv.get("id") == 0:
            return inv
    return None


def approx_payout_date(start_date: Any) -> str:
    """Approximate the Airbnb PAYOUT date for the extension lane = check-in + 1 CALENDAR day.

    The Reservations API carries stay dates but NOT when the payout was sent; Airbnb releases the
    host payout ~24h after CHECK-IN, so check_in+1 is the real payout Date on roughly half of stays
    (validated on 4 years of history — the rest land check_in+2). It is only a STARTING estimate,
    always superseded by the exact CSV date. CALENDAR +1 (not a business-day add — the payout lands
    ~24h later on any weekday).

    This is an ESTIMATE: it becomes the receipt's dataPrestacao and the 5-business-day deadline, and
    it is OVERRIDABLE (backend.OVERRIDABLE / Logic.OVERRIDABLE_FIELDS) so a later EXACT payout date
    (a CSV drop, or an operator correction) supersedes it. Returns "" for a missing/unparseable
    start_date -> the emitter then falls back to check-in (a real date), never a fabricated one.
    """
    try:
        return (date.fromisoformat(str(start_date)) + timedelta(days=1)).isoformat()
    except (ValueError, TypeError):
        return ""


# Airbnb switches a stay to MONTHLY installment payouts at ~28 nights; below this a stay is a single
# payout. Mirrors the threshold in airbnb_bridge/transactions.py Stage B (the CSV-lane cross-row pass).
LONG_STAY_NIGHTS = 28


def long_stay_reason(check_in: Any, check_out: Any) -> str:
    """Extension-lane long-stay safety (mirrors transactions.py Stage B). A stay of >=28 nights is
    where Airbnb bills in MONTHLY installments: the single check-in+1 estimate here can't represent
    payouts spanning several months, and the stay completes AFTER its own 5-business-day deadline. So
    a long stay must be parked for review — the operator verifies each installment is issued on its own
    payout date — rather than silently filing one mis-dated receipt for the whole amount.

    Returns the review reason for a >=28-night stay, else "" (no flag). The extension lane sees ONE
    reservation per HM, so unlike the CSV pass it can't COUNT installments across rows; >=28 nights is
    the detectable proxy for the same stays. Fail-safe: unparseable dates -> "" (never a false
    long-stay flag), matching Stage B's nights=0 default."""
    try:
        nights = (date.fromisoformat(str(check_out)) - date.fromisoformat(str(check_in))).days
    except (ValueError, TypeError):
        return ""
    if nights >= LONG_STAY_NIGHTS:
        return f"long stay ({nights} nights) — verify the payout(s) and dates"
    return ""


def map_reservation_to_row(
    reservation: dict,
    *,
    service_fee: float,
    account: str,
    batch_id: str,
    payment_date: str = "",
) -> dict:
    """Map one reservations-API entry + its derived fee to a canonical row.

    Encodes the load-bearing rules:
      * routing key is ``listing_id_str`` (NOT the numeric ``listing_id``, which
        overflows 2^53); a missing ``listing_id_str`` is a HARD failure for the
        capture, never a silent blank (no name-based routing).
      * ``total_payout`` = parsed ``earnings``; ``ttc`` = payout + service_fee.
      * ``type`` = "Reservation"; ``fee_provenance`` = "csv" (extension has the
        real fee); ``source`` = "extension".

    ``payment_date`` is passed IN by the caller (not derived here) so the caller owns lane
    semantics: the EXTENSION lane passes ``approx_payout_date(start_date)`` (the check-in+1 payout
    estimate); any other caller leaves it "" so its dataPrestacao stays at check-in — the estimate
    must never leak into a lane silently. (The email lane was retired 2026-10-23.)
    Becomes the receipt's dataPrestacao + the 5-business-day deadline; blank -> emitter falls back
    to check-in (a real date, never a fabricated one); overridable by a later EXACT date.
    """
    listing_id_str = reservation.get("listing_id_str")
    if not listing_id_str:
        raise ValueError(
            f"reservation {reservation.get('confirmation_code')!r}: missing listing_id_str "
            f"- HARD failure (no name-based routing).")
    payout, currency = parse_earnings_amount(reservation.get("earnings"))
    fee = round(float(service_fee), 2) if service_fee is not None else None
    gross = round(payout + fee, 2) if (payout is not None and fee is not None) else None
    # Guest name -> nomeAdquirente on the Fatura-Recibo (REQUIRED). The live API field
    # is `guest_user` (full_name; first_name fallback); `guest` kept for old fixtures.
    gu = reservation.get("guest_user") or reservation.get("guest") or {}
    guest = gu.get("full_name") or gu.get("first_name") or ""
    cur = current_invoice(reservation.get("host_vat_invoices")) or {}
    # Keys match the serializer's ingest contract (validateIngestRow / writeIngest_):
    # listing_id_str (the routing key) + gross_earnings.
    return {
        "source": "extension", "type": "Reservation",
        "hm_code": reservation.get("confirmation_code"),
        "listing_id_str": str(listing_id_str),     # the _str — numeric overflows 2^53
        "listing_name": reservation.get("listing_name", ""),
        "check_in": reservation.get("start_date"), "check_out": reservation.get("end_date"),
        "guest": guest,
        "paid_out": payout, "service_fee": fee, "gross_earnings": gross,
        "currency": currency or "EUR", "fee_provenance": "invoice",
        "airbnb_account_id": account,
        # payment_date is supplied by the caller per lane (see docstring): extension -> check-in+1
        # estimate, email -> "" (unchanged check-in fallback). Never fabricated inside this shared mapper.
        "payment_date": str(payment_date or ""),
        "source_ref": cur.get("invoice_number", "") + (f"|{batch_id}" if batch_id else ""),
    }


def reconcile_period(rows: list[dict], account_payout_total, tol: float = 0.01) -> dict:
    """Completeness gate (anti-silent-under-declaration): the summed reservation
    payouts must reconcile against the account's total payout for the period. A
    shortfall flags a standalone Resolution payout not tied to a completed
    reservation (the deferred POST-MVP gap) for a manual check."""
    s = round(sum(r["paid_out"] for r in rows if r.get("paid_out") is not None), 2)
    total = round(float(account_payout_total), 2)
    return {"sum_payouts": s, "account_total": total,
            "ok": abs(s - total) <= tol, "shortfall": round(total - s, 2)}


# How far PAST `until` the reservations query reaches, so a checked-in-not-out stay (end in the future)
# whose payout has landed is still fetched. The payout-based is_emittable filters the rest; long stays
# (>=28 nights) route to the review lane regardless. 45 days covers normal in-progress stays.
CAPTURE_FORWARD_DAYS = 45
# A refused or unreadable fee read is repeated this many MORE times (pause = backoff x attempt)
# before the stay is flagged needs_review — see the retry loop in ingest_extension.
STAY_DETAILS_RETRIES = 2
STAY_DETAILS_RETRY_BACKOFF_SEC = 3.0

# ---- 8b: second fee source (docs/PLAN_FEE_LOOKUP_400.md step 8b) -------------------------------
# OWNER SWITCH. When the details lookup (StayHostingDetailsQuery) has failed on EVERY query version
# and EVERY retry, read the fee from the stay's own Airbnb VAT invoice (the current, id-0 one,
# rendered through the extension) instead of parking the stay. Set to False to turn the fallback off
# (the stay is then parked, exactly as before).
VAT_INVOICE_FEE_FALLBACK = True
# The first render of an invoice can be an empty shell; it is rendered up to this many times in all
# (pause = backoff x attempt between renders) before the stay is parked.
VAT_INVOICE_RENDER_ATTEMPTS = 3
VAT_INVOICE_RETRY_BACKOFF_SEC = 3.0
# fee_provenance on a row whose fee came from the VAT invoice. A details-lookup fee keeps the value
# it has always had ("invoice"), so every existing row and reader is unchanged. Any serializer
# (2.1.12 and 2.1.13) accepts any provenance except the retired email estimates.
FEE_PROVENANCE_VAT_INVOICE = "vat_invoice"

# Why a stay was parked, in the operator's words (shown in Review and on the capture screen). The
# technical detail (query version, HTTP status, serializer reply) goes to report.errors -> the logs.
FEE_UNAVAILABLE_REASON = (
    "Airbnb did not give us this stay's fee, so it was not issued. Try Capture again later. If the "
    "deadline is close, issue the receipt by hand on the Portal and mark it 'filed by hand'.")
NO_LISTING_REASON = (
    "Airbnb did not say which of your rentals this stay belongs to, so it was not issued. Try Capture "
    "again later. If the deadline is close, issue the receipt by hand on the Portal.")
SHEET_REFUSED_REASON = (
    "The Google Sheet did not accept this stay, so it was not issued. Try Capture again later. If it "
    "keeps happening, tell Laurent. If the deadline is close, issue the receipt by hand on the Portal "
    "and mark it 'filed by hand'.")
NEEDS_SETUP_REASON = (
    "This stay's rental isn't fully set up in Property Settings, so it was not issued. Finish the "
    "setup from Review, then capture again.")


def non_eur_reason(currency) -> str:
    return (f"This stay was paid in {currency or 'an unknown currency'}, not euros, so it was not issued. "
            f"Check the amount and issue the receipt by hand on the Portal, then mark it 'filed by hand'.")


def _minimal_park_row(res: dict, *, account: str, batch_id: str) -> dict:
    """A review-lane row built from the reservation ALONE — for a stay whose fee Airbnb did not give
    us (or that the sheet refused, or that has no listing id). The fee and the gross are EMPTY: never
    guessed, never estimated (tests/test_no_fee_estimate.py). The serializer accepts it only as a
    needs_review row (client_review_reason), and a needs_review row is never promoted, so it can never
    be issued. When a later capture reads the fee, the serializer replaces it in place with the normal
    row (Logic.decideStagingIngest)."""
    payout, currency = parse_earnings_amount(res.get("earnings"))
    gu = res.get("guest_user") or res.get("guest") or {}
    cur = current_invoice(res.get("host_vat_invoices")) or {}
    return {
        "source": "extension", "type": "Reservation",
        "hm_code": res.get("confirmation_code"),
        "listing_id_str": str(res.get("listing_id_str") or ""),
        "listing_name": res.get("listing_name", ""),
        "check_in": res.get("start_date"), "check_out": res.get("end_date"),
        "guest": gu.get("full_name") or gu.get("first_name") or "",
        "paid_out": payout, "service_fee": None, "gross_earnings": None,
        "currency": currency or "EUR", "fee_provenance": "",
        "airbnb_account_id": account,
        "payment_date": approx_payout_date(res.get("start_date")),
        "source_ref": cur.get("invoice_number", "") + (f"|{batch_id}" if batch_id else ""),
    }


async def _fee_from_vat_invoice(fetcher, res: dict, report: "IngestReport", *, sleep,
                                pacing: bool) -> tuple[float | None, str]:
    """The 8b fallback for ONE stay: render its current (id 0) VAT invoice and read the fee.
    Returns (fee, "") or (None, why-not for the log). Bounded: at most VAT_INVOICE_RENDER_ATTEMPTS
    renders; a text that is "not ready" (no Service Fee line yet) or a failed render is tried again,
    anything ambiguous is NOT (it would not become less ambiguous). A ChallengeError (login wall)
    propagates at once. Sanity: fee > 0 and fee < the stay's payout, else no fee."""
    inv, why = current_invoice_strict(res.get("host_vat_invoices"))
    if inv is None:
        return None, why
    last = "not tried"
    for attempt in range(VAT_INVOICE_RENDER_ATTEMPTS):
        if attempt and pacing:  # pacing disabled (tests) -> no real wait
            await sleep(VAT_INVOICE_RETRY_BACKOFF_SEC * attempt)
        report.invoice_renders += 1
        try:
            text = await fetcher.vat_invoice_text(str(inv.get("invoice_url")))
        except ChallengeError:
            raise
        except BridgeError as e:
            last = f"render failed ({_brief_bridge_error(str(e))})"
            continue
        parsed = parse_invoice_service_fee(text)
        if parsed["status"] == "not_ready":
            last = f"not ready ({parsed['detail']})"
            continue
        if parsed["status"] != "ok":
            return None, f"{parsed['status']}: {parsed['detail']}"
        fee = parsed["fee"]
        payout, _cur = parse_earnings_amount(res.get("earnings"))
        if payout is None or not (0 < fee < payout):
            return None, f"fee {fee:.2f} fails the sanity check against payout {payout}"
        return fee, ""
    return None, f"{last} after {VAT_INVOICE_RENDER_ATTEMPTS} renders"


def _brief_reply(reply) -> str:
    """A serializer reply, short, for the capture log (never the whole body)."""
    if isinstance(reply, dict):
        bits = [str(reply.get(k)) for k in ("_status", "error", "reason") if reply.get(k)]
        errs = reply.get("errors")
        if isinstance(errs, list) and errs:
            bits.append("; ".join(str(e) for e in errs[:3]))
        return (" ".join(bits) or "no detail")[:200]
    return str(reply)[:200]


def _park_stay(report: IngestReport, res: dict, row: dict, *, reason: str, kind: str, detail: str,
               dry_run: bool, post, serializer_url, api_token, operator_id) -> None:
    """Make a stay that will NOT be issued this run VISIBLE: POST it to the serializer as a
    needs_review row (``client_review_reason``) so it shows in Review -> Needs review with its reason
    and issue-by date, count it, and list it for the capture screen. It is never added to
    ``captured_hms``, so the next capture asks Airbnb again (and heals it when the fee arrives).

    Two serializer answers change that (2.1.13+ serializer; an older one sends neither field):
      * ``ingest_result == "filed_by_hand"`` — the operator already issued it by hand: settled, so it
        goes to the seen-file and is NOT flagged again;
      * ``ingest_result == "idempotent"`` with ``staging_status`` new/promoted — the stay is already on
        its way to a receipt (e.g. another laptop captured it cleanly): not flagged, seen.
    Saving is best-effort (a failure is logged and the stay is still listed on the capture screen),
    and dry_run writes nothing."""
    hm = str(row.get("hm_code") or res.get("confirmation_code") or "")
    report.errors.append(f"{hm}: {detail}")
    saved = False
    if not dry_run and hm:
        reply = None
        try:
            reply = post(serializer_url, {**row, "client_review_reason": reason},
                         api_token=api_token, operator_id=operator_id)
        except Exception as e:  # noqa: BLE001 — visibility is best-effort; the capture screen still lists it
            report.errors.append(f"{hm}: could not save the flagged stay to Review ({type(e).__name__}: "
                                 f"{str(e)[:120]})")
        if isinstance(reply, dict):
            result = reply.get("ingest_result")
            if result == "filed_by_hand":
                report.rows_filed_by_hand += 1
                report.captured_hms.append(hm)
                return
            if result == "idempotent" and reply.get("staging_status") in ("new", "promoted"):
                report.captured_hms.append(hm)
                return
            saved = bool(reply.get("stored"))
            if not saved:
                report.errors.append(f"{hm}: the sheet did not save the flagged stay: {_brief_reply(reply)}")
    report.rows_needs_review += 1
    report.flagged.append({
        "hm_code": hm, "guest": str(row.get("guest") or ""),
        "check_in": str(row.get("check_in") or ""), "check_out": str(row.get("check_out") or ""),
        "payment_date": str(row.get("payment_date") or ""),
        "kind": kind, "reason": reason, "saved": saved})


# Airbnb ``user_facing_status_key`` values where the host HAS the income (checked-in or done). A stay
# fires a green receipt once its PAYOUT has landed (~check-in + 1 day) — Airbnb pays the host ~24h after
# CHECK-IN — NOT only after checkout, so a multi-night stay's 5-business-day deadline (keyed to the
# payout) is not missed. The live vocabulary (verified 2026-07-09 against the host reservations API) is
# exactly three keys: "upcoming" (not started — excluded), "current" (checked-in-not-out), "complete"
# (checked-out). NB: it is "current", NOT "currently_hosting" — the earlier guess never matched, so a
# checked-in stay whose payout had landed (e.g. Kelly Ash) was silently NOT captured until checkout.
# The check_in+1 date gate in is_emittable still excludes a guest who checked in TODAY (payout lands
# tomorrow). An unlisted state is simply not emitted (fail-safe).
EMITTABLE_STATUSES = frozenset({"complete", "current"})


def is_emittable(reservation: dict, today: "date | None" = None) -> bool:
    """PAYOUT-based eligibility (docs/V2_PLAN.md CAPTURE MECHANISM, revised): a stay fires a green receipt
    once its Airbnb payout has landed — ``check_in + 1 calendar day <= today`` — AND it is an
    income-bearing state (``EMITTABLE_STATUSES``: checked-in or checked-out). This replaces the old
    checkout-only gate so a stay whose payout is in but which has not yet checked out (its receipt already
    due) is captured. Upcoming stays (payout not landed), canceled/declined, and unknown states are
    excluded. Fail-safe: an unparseable/missing check-in -> NOT emittable (the payout date is unknowable)."""
    if str(reservation.get("user_facing_status_key") or "") not in EMITTABLE_STATUSES:
        return False
    try:
        check_in = date.fromisoformat(str(reservation.get("start_date")))
    except (ValueError, TypeError):
        return False
    return (check_in + timedelta(days=1)) <= (today or date.today())


class _BridgeFetcher:
    """Live fetcher: drives the MV3 extension (via HostBridge) to GET on-domain.

    Wraps the named extractors so ``ingest_extension`` is decoupled from the
    transport — tests inject a fake with the same two async methods. A login wall
    (a /login redirect, or a login-page body returned with HTTP 200) is raised as
    ``ChallengeError`` so the run PAUSES instead of ingesting a login page.
    """

    def __init__(self, bridge: HostBridge):
        self.bridge = bridge

    async def reservations(self, *, offset: int, ends_before: str | None) -> dict:
        try:
            page = await extractors.reservations_list(self.bridge, offset=offset, ends_before=ends_before)
        except BridgeError as e:
            # The extension reports a login wall as a "CHALLENGE:" job error, and a
            # login HTML body surfaces as a non-JSON parse error — both -> pause.
            if _is_challenge_error(str(e)):
                raise ChallengeError(str(e)) from e
            raise
        if _json_is_login(page):  # 200-status login body that parsed as JSON -> pause, don't capture empty
            raise ChallengeError(f"login page returned for reservations (offset={offset})")
        return page if isinstance(page, dict) else {"reservations": page or []}

    async def stay_details(self, confirmation_code: str) -> dict:
        """One reservation's payout breakdown, trying each known query version in turn.

        Airbnb retires persisted-query versions, and a version being retired fails
        INTERMITTENTLY (HTTP 400 ``deprecated_web_operation``) before it fails always. So a
        version that is refused — by an HTTP error, or by a GraphQL error body — is not the
        end: the next hash in ``extractors.STAY_DETAILS_HASHES`` is tried. A login wall still
        raises ``ChallengeError`` at once (no fallback past a login page). When every version
        fails, ONE compact ``BridgeError`` naming each attempt is raised (the caller retries,
        then flags the stay)."""
        failures: list[str] = []
        refused: dict | None = None
        for sha in extractors.STAY_DETAILS_HASHES:
            try:
                data = await extractors.stay_hosting_details(
                    self.bridge, confirmation_code=confirmation_code, sha256_hash=sha)
            except BridgeError as e:
                if _is_challenge_error(str(e)):
                    raise ChallengeError(str(e)) from e
                failures.append(f"query {sha[:8]}: {_brief_bridge_error(str(e))}")
                continue
            if _json_is_login(data):  # 200-status login body that parsed as JSON -> pause, don't capture empty
                raise ChallengeError(f"login page returned for stay {confirmation_code}")
            if not isinstance(data, dict):
                data = {}
            if data.get("errors"):  # GraphQL refusal (e.g. PersistedQueryNotFound) -> try the next version
                failures.append(f"query {sha[:8]}: GraphQL error {_brief_graphql_errors(data)}")
                refused = data
                continue
            return data
        if refused is not None and len(failures) == 1:
            return refused  # a single known version and it answered with an error body: let the parser fail closed
        raise BridgeError("; ".join(failures) or "no StayHostingDetailsQuery version configured")

    async def vat_invoice_text(self, invoice_url: str) -> str:
        """RENDER one VAT invoice through the extension and return its text (the 8b fee fallback).
        A login wall — reported by the extension as a CHALLENGE job error, or a login page in the
        rendered text — raises ChallengeError so the run pauses."""
        try:
            text = await extractors.render_vat_invoice(self.bridge, invoice_url=invoice_url)
        except BridgeError as e:
            if _is_challenge_error(str(e)):
                raise ChallengeError(str(e)) from e
            raise
        if _looks_like_login(text):
            raise ChallengeError("login page returned when opening a VAT invoice")
        return text or ""

    async def invoice(self, invoice_url: str) -> str:
        # Deferred Phase-6b verification/archival path only (not the emit fee source).
        try:
            html = await extractors.vat_invoice(self.bridge, invoice_url=invoice_url)
        except BridgeError as e:
            if _is_challenge_error(str(e)):
                raise ChallengeError(str(e)) from e
            raise
        if _looks_like_login(html):
            raise ChallengeError(f"login page returned for invoice {invoice_url}")
        return html


async def ingest_extension(
    account: str,
    *,
    since: date,
    until: date,
    dry_run: bool,
    bridge: HostBridge | None = None,
    fetcher: Any | None = None,
    serializer_url: str | None = None,
    api_token: str | None = None,
    operator_id: str = "extension",
    listing_ids: list[str] | None = None,
    account_payout_total: float | None = None,
    post_fn: Any | None = None,
    min_checkin: date | None = None,
    seen_hm: set[str] | None = None,
    pace_min: float = 0.5,
    pace_max: float = 2.0,
    sleeper: Any | None = None,
    owned_listing_ids: set[str] | None = None,
) -> IngestReport:
    """Capture completed reservations for ``account`` and POST canonical rows.

    Args:
        account: Airbnb account identifier (NOT credentials — the extension rides
            the user's warm session; decision C). Tags each row's
            ``airbnb_account_id`` for the obj-4 cross-check.
        since / until: period window. Completed stays are queried with
            ``status=accepted&ends_before=<until>`` (the reservations API's
            completed filter); ``since`` bounds the lower edge client-side.
        dry_run: when True, parse + map + reconcile but DO NOT POST /ingest — just
            populate ``IngestReport.rows``. This is the owner's path: run against their
            own account to validate the extension and harvest real fees WITHOUT
            writing to his email-sourced store.
        bridge: an already-started HostBridge; if None, one is created via the
            ``host_bridge`` context manager (which HARD-ABORTS on a stale extension).
        serializer_url: the Apps Script web-app /exec endpoint (treated as a
            secret-equivalent; resolved by the caller, never hard-coded). Required
            unless ``dry_run``.
        api_token / operator_id: carried in every /ingest POST body (the URL alone
            is insufficient — the serializer binds the token, section 6.3).
        fetcher: dependency-injected transport (``.reservations`` / ``.invoice``
            async methods). Defaults to a ``_BridgeFetcher`` over ``bridge``; tests
            pass a fake so the orchestration is provable without a live session.
        listing_ids: optional capture-scope filter (route only these listings).
        owned_listing_ids: the listings THIS deployment owns (its Property Settings). When
            given, it is the multi-tenant firewall: a stay on any other listing is never
            fee-fetched nor ingested — it is counted in ``rows_skipped_foreign`` and named in a
            non-blocking warning (so another tenant's guests never land in this workbook, even
            when one Airbnb login co-hosts several tenants' listings). And if NONE of the first
            page's stays is owned, ``AccountMismatchError`` aborts before anything is read further
            (the wrong Airbnb account is logged in). None = no firewall (legacy / tests).
        account_payout_total: if given, run the completeness reconcile (sum of
            captured payouts vs this independent account total) and flag a shortfall.
        post_fn: override for ``_post_ingest`` (tests inject a recorder).
        min_checkin: history-backfill FLOOR — a HARD guardrail (independent of, and
            stricter than, ``since``): any reservation whose check-in (start_date)
            is before this date is excluded as too old to issue a receipt for, and
            counted in ``rows_skipped_too_old`` (never silently dropped). The caller
            sets it to ``months_before(today, 6)``.
        seen_hm: confirmation codes already captured — their fee is NOT fetched
            (dedupe, cuts request volume so repeat runs are nearly silent; the
            anti-bot win). Skipped stays are counted in ``rows_skipped_seen``.
        pace_min/pace_max: a randomized gap (seconds) inserted before each fee
            lookup (and each page after the first), so the cadence looks like a
            human clicking through reservations rather than a tight burst
            (objective 9 — don't trip Airbnb's velocity rules). Set pace_max=0 to
            disable (tests do this); ``sleeper`` overrides asyncio.sleep.

    Flow (docs/V2_PLAN.md §3.2 + CAPTURE MECHANISM):
        ensure fresh extension (HARD ABORT if stale)
        page GET /api/v2/reservations  (completed query, _limit/_offset)
        for each reservation:
            if not is_emittable(...):           -> skip (count)
            GET StayHostingDetailsQuery(hm)                 # the "You earn" panel
            service_fee = parse_host_service_fee(details)   # GET-only, == invoice fee
            row = map_reservation_to_row(...)               # listing_id_str routing
            if dry_run: collect; else POST {op:"ingest", row} to serializer
        completeness/reconciliation gate (transactional per (account, period))
        (the VAT invoice is fetched ONLY for the deferred Phase-6b verify/archive)

    Returns:
        IngestReport with counts + (in dry_run) the mapped rows.

    The standalone-Resolution-payout reconciliation (sum reservation payouts vs an
    INDEPENDENT account payout total; a shortfall flags a manual check) is wired
    via ``account_payout_total`` but the source of that independent total is
    DEFERRED POST-MVP (docs/V2_PLAN.md Amendment Note #2): standalone Resolution
    payouts not tied to a completed reservation may not appear in /reservations.
    operator/extension-only (does not exist for the owner's email deployment).
    """
    report = IngestReport(account=account, since=since, until=until, dry_run=dry_run)

    if not dry_run and not serializer_url:
        raise ValueError("serializer_url is required unless dry_run=True")
    if pace_min < 0 or (pace_max and pace_max > 0 and pace_min > pace_max):
        raise ValueError(f"invalid pacing: pace_min={pace_min}, pace_max={pace_max}")
    # Checked BEFORE the bridge opens (nothing to clean up on refusal).
    owned = {str(x).strip() for x in owned_listing_ids} if owned_listing_ids is not None else None
    if owned is not None and not owned:
        raise NoOwnedListingsError(
            "this deployment has no active listing in Property Settings, so no stay can be "
            "attributed to it — fill Property Settings and Sync, then capture again.")

    # Resolve the transport. With no injected fetcher: open (or adopt) a HostBridge
    # — the `async with host_bridge()` form runs the stale-extractor HARD ABORT;
    # a passed-in bridge is re-checked here too (a stale extractor silently
    # under-declares — docs/V2_PLAN.md §3.2).
    own_bridge = None
    if fetcher is None:
        if bridge is None:
            own_bridge = host_bridge()
            bridge = await own_bridge.__aenter__()
        else:
            bridge.ensure_fresh_extension()
        fetcher = _BridgeFetcher(bridge)

    batch_id = f"{account}:{until.isoformat()}"
    since_str = since.isoformat() if since else None
    # Fetch horizon: reach PAST `until` (default today) so currently-hosting stays — checked in, payout
    # landed, but ending in the future — are returned by the reservations query (ends_before). The
    # payout-based is_emittable then keeps only stays whose payout has actually landed; upcoming stays
    # within the horizon are fetched but skipped. Long stays (>=28 nights) route to review regardless.
    fetch_until_str = (until + timedelta(days=CAPTURE_FORWARD_DAYS)).isoformat() if until else None
    floor_str = min_checkin.isoformat() if min_checkin else None  # backfill floor (check-in)
    listing_filter = {str(x) for x in listing_ids} if listing_ids else None
    foreign: dict[str, int] = {}
    seen = {str(x) for x in seen_hm} if seen_hm else set()
    sleep = sleeper if sleeper is not None else asyncio.sleep
    collected: list[dict] = []  # every mapped row (drives reconcile + dry_run.rows)

    async def pace():
        """Human-like jittered gap before a fetch (anti-velocity-detection)."""
        if pace_max and pace_max > 0:
            await sleep(random.uniform(pace_min, pace_max))

    try:
        offset = 0
        while True:
            if offset > 0:
                await pace()
            page = await fetcher.reservations(offset=offset, ends_before=fetch_until_str)
            report.pages_fetched += 1
            reservations = (page or {}).get("reservations") or []
            if not reservations:
                break
            if owned is not None and offset == 0:
                page_listings = {str(r.get("listing_id_str")) for r in reservations}
                if not page_listings & owned:
                    raise AccountMismatchError(
                        f"none of the {len(reservations)} most recent stays in this Chrome's Airbnb "
                        f"session is on one of this deployment's {len(owned)} listing(s) — the wrong "
                        "Airbnb account is probably logged in (or Property Settings is out of date). "
                        "Nothing was captured.",
                        seen_listings=page_listings, owned_count=len(owned))
            for res in reservations:
                report.reservations_seen += 1
                end = str(res.get("end_date") or "")
                if since_str and end and end < since_str:
                    continue  # below the lower window edge (the API filters the upper)
                start = str(res.get("start_date") or "")
                if floor_str and start and start < floor_str:
                    report.rows_skipped_too_old += 1  # check-in beyond the backfill floor
                    continue
                if not is_emittable(res):
                    report.rows_skipped_not_complete += 1
                    continue
                if listing_filter is not None and str(res.get("listing_id_str")) not in listing_filter:
                    continue
                if owned is not None and str(res.get("listing_id_str")) not in owned:
                    # Multi-tenant firewall: not this deployment's listing -> no fetch, no ingest.
                    lid = str(res.get("listing_id_str"))
                    foreign[lid] = foreign.get(lid, 0) + 1
                    report.rows_skipped_foreign += 1
                    continue
                hm = res.get("confirmation_code")
                if str(hm) in seen:
                    report.rows_skipped_seen += 1  # already captured -> no fetch (dedupe)
                    continue
                # Fee source = the host "You earn" breakdown (StayHostingDetailsQuery,
                # GET-only), NOT the client-rendered invoice page. Verified equal to
                # the VAT invoice; the invoice is now a deferred Phase-6b cross-check.
                await pace()  # jittered gap so 26 fee lookups aren't a tight burst
                # A transport/HTTP error on ONE reservation's fee fetch must degrade
                # THAT row to needs_review, never abort the whole period. Only a
                # ChallengeError (login wall) propagates to the pause handler.
                # Airbnb refuses a query version it is retiring INTERMITTENTLY (HTTP 400
                # deprecated_web_operation, 2026-11-10/11): the same read succeeds on repeat. So a
                # failed OR unreadable fee read is repeated up to STAY_DETAILS_RETRIES more times,
                # with a growing pause, before the stay is flagged. (The fetcher has already tried
                # every known query version on each attempt.) A login wall is never retried.
                fee = None
                details = None
                fee_from_invoice = False
                fetch_error: BridgeError | None = None
                for attempt in range(STAY_DETAILS_RETRIES + 1):
                    if attempt:
                        report.fee_retries += 1
                        if pace_max and pace_max > 0:  # pacing disabled (tests) -> no real wait
                            await sleep(STAY_DETAILS_RETRY_BACKOFF_SEC * attempt)
                    try:
                        details = await fetcher.stay_details(hm)
                    except ChallengeError:
                        raise
                    except BridgeError as e:
                        fetch_error = e
                        continue
                    fetch_error = None
                    fee = parse_host_service_fee(details)
                    if fee is not None:
                        break
                # EVERY stay that is seen, eligible and NOT sent on to be issued is PARKED VISIBLY (Review ->
                # Needs review, with its reason and issue-by date) instead of living only in a console
                # note — a silently-missing stay passes its 5-working-day deadline unnoticed (the
                # missed-stay incident, 2026-11-10). A parked stay stays OUT of captured_hms, so the next
                # capture asks Airbnb again; when the fee then arrives the serializer replaces the parked
                # row in place and the stay files normally (docs/V2_PLAN.md "Parked stays").
                def _park(row_, reason, kind, detail):
                    _park_stay(report, res, row_, reason=reason, kind=kind, detail=detail,
                               dry_run=dry_run, post=(post_fn or _post_ingest),
                               serializer_url=serializer_url, api_token=api_token,
                               operator_id=operator_id)

                if fetch_error is None:
                    report.fee_lookups += 1  # one per STAY that Airbnb answered (retries are in fee_retries)
                # 8b — SECOND FEE SOURCE, used ONLY when the details lookup failed on every query version
                # and every retry: the stay's own current (id 0) Airbnb VAT invoice, rendered through the
                # extension. Airbnb's own document, never an estimate. Not used when the details payload
                # answered with two DIFFERENT fees (a person must look), nor when the switch is off, nor
                # with a transport that cannot render. Anything doubtful -> no fee -> parked as before.
                # The invoice and details figures can differ by a cent for the same stay (40.08 vs 40.09
                # seen 2026-11-11); which is authoritative is the owner's call, so the invoice is only a
                # fallback and the row records where its fee came from (fee_provenance).
                invoice_note = ""
                if fee is None:
                    render = getattr(fetcher, "vat_invoice_text", None)
                    if not VAT_INVOICE_FEE_FALLBACK:
                        invoice_note = "VAT-invoice fallback switched off"
                    elif render is None:
                        invoice_note = ""
                    elif fetch_error is None and details_fee_conflict(details):
                        invoice_note = "VAT invoice not used: the details gave two different fees"
                    else:
                        await pace()
                        inv_fee, why = await _fee_from_vat_invoice(
                            fetcher, res, report, sleep=sleep, pacing=bool(pace_max and pace_max > 0))
                        if inv_fee is not None:
                            fee, fee_from_invoice = inv_fee, True
                            report.fees_from_vat_invoice += 1
                            log.info("%s: fee %.2f read from the VAT invoice (details lookup failed)", hm, fee)
                        else:
                            invoice_note = f"VAT invoice not usable ({why})"
                if fee is None and fetch_error is not None:
                    _park(_minimal_park_row(res, account=account, batch_id=batch_id),
                          FEE_UNAVAILABLE_REASON, "fee_unavailable",
                          f"stay-details fetch failed after {STAY_DETAILS_RETRIES + 1} attempts "
                          f"({fetch_error}) — fee unavailable" + (f"; {invoice_note}" if invoice_note else ""))
                    continue
                if fee is None:
                    _park(_minimal_park_row(res, account=account, batch_id=batch_id),
                          FEE_UNAVAILABLE_REASON, "fee_unavailable",
                          "could not read Host service fee from StayHostingDetailsQuery "
                          "(refused query version, or unexpected payload)"
                          + (f"; {invoice_note}" if invoice_note else ""))
                    continue
                try:
                    # EXTENSION lane: stamp the check-in+1 payout ESTIMATE as payment_date (email lane
                    # leaves it "" — the estimate is deliberately extension-only).
                    row = map_reservation_to_row(
                        res, service_fee=fee, account=account, batch_id=batch_id,
                        payment_date=approx_payout_date(res.get("start_date")))
                except ValueError as e:  # missing listing_id_str -> HARD fail this row (no name routing)
                    # Parked WITHOUT a listing (the serializer quarantines it: it can never route, so it
                    # can never be issued) and without the fee — nothing is guessed.
                    _park(_minimal_park_row(res, account=account, batch_id=batch_id),
                          NO_LISTING_REASON, "no_listing", str(e))
                    continue
                if fee_from_invoice:
                    row["fee_provenance"] = FEE_PROVENANCE_VAT_INVOICE  # where the fee came from (8b)
                # Non-EUR -> needs_review (a direct mis-declaration by the FX amount).
                if str(row.get("currency") or "").upper() != "EUR":
                    _park(row, non_eur_reason(row.get("currency")), "non_eur",
                          f"non-EUR currency {row.get('currency')!r} — needs manual review")
                    continue
                # B5 fail-safes: an unparseable payout, or a fee larger than the payout
                # itself (the signature of a wrong-magnitude parse), must never become
                # the declared income — flag for human review instead. It is excluded from
                # the reconcile sum and from the seen-file.
                if row.get("paid_out") is None:
                    _r = (f"payout amount unparseable ({res.get('earnings')!r}) "
                          f"— needs manual review")
                    _park(row, _r, "amounts", _r)
                    continue
                if implausible_fee(row.get("paid_out"), row.get("service_fee")):
                    _r = (f"implausible amounts (service_fee {row.get('service_fee')} "
                          f"> payout {row.get('paid_out')}) — possible wrong-magnitude "
                          f"parse, needs manual review")
                    _park(row, _r, "amounts", _r)
                    continue
                # Long-stay safety: a >=28-night stay bills in monthly installments, so one check-in+1
                # receipt for the whole amount would be mis-dated (and the stay completes past its own
                # 5-business-day deadline). Park it for review — surfacing it in the Stage-D review lane —
                # instead of auto-filing. Closes the extension-lane gap the holistic review found (the CSV
                # Stage-B pass caught these, but the live extension lane did not).
                _long = long_stay_reason(row.get("check_in"), row.get("check_out"))
                if _long:
                    _park(row, _long, "long_stay", _long)
                    continue
                collected.append(row)
                if dry_run:
                    report.rows.append(row)
                    report.captured_hms.append(str(hm))
                    report.rows_ingested += 1  # would-be
                else:
                    reply = (post_fn or _post_ingest)(
                        serializer_url, row, api_token=api_token, operator_id=operator_id)
                    if isinstance(reply, dict) and reply.get("ingest_result") == "filed_by_hand":
                        # The operator issued this stay by hand while it was parked: the serializer
                        # wrote NOTHING (it will never be issued by the app). Settled -> seen-file.
                        report.rows_filed_by_hand += 1
                        report.captured_hms.append(str(hm))
                    elif isinstance(reply, dict) and reply.get("stored"):
                        report.rows_ingested += 1
                        if reply.get("route_status") and reply.get("route_status") != "RESOLVED":
                            report.rows_needs_review += 1  # fail-closed -> QUARANTINE
                            report.flagged.append({
                                "hm_code": str(hm), "guest": str(row.get("guest") or ""),
                                "check_in": str(row.get("check_in") or ""),
                                "check_out": str(row.get("check_out") or ""),
                                "payment_date": str(row.get("payment_date") or ""),
                                "kind": "needs_setup", "reason": NEEDS_SETUP_REASON, "saved": True})
                        else:
                            # ONLY a durably-RESOLVED row is safe to dedupe next run; a
                            # quarantined stay must stay re-fetchable (else silent drop).
                            report.captured_hms.append(str(hm))
                    else:
                        # The serializer refused the normal row (validation, busy, ...). Park the stay
                        # VISIBLY with no fee and no gross (so the same arithmetic cannot refuse it
                        # again); it stays re-fetchable and heals on a later capture.
                        _park(_minimal_park_row(res, account=account, batch_id=batch_id),
                              SHEET_REFUSED_REASON, "rejected",
                              f"ingest rejected: {_brief_reply(reply)}")
            if len(reservations) < RESERVATIONS_PAGE_SIZE:
                break
            offset += len(reservations)
    except ChallengeError as e:
        # Login/OTP wall -> PAUSE. Never run the completeness reconcile or report
        # success on a partial period (anti-silent-under-declaration).
        report.challenge = True
        report.errors.append(f"CHALLENGE (login/OTP wall) — paused, period NOT complete: {e}")
        return report
    finally:
        if own_bridge is not None:
            await own_bridge.__aexit__(None, None, None)

    if foreign:
        report.foreign_listings = sorted(foreign)
        # Operator-facing (shown in the app): plain words + the Airbnb listing numbers, which ARE what
        # the operator types into Property Settings. The per-listing counts go to the logs (live_capture).
        report.warnings.append(
            f"{report.rows_skipped_foreign} stay(s) were left out because their rental isn't in "
            f"Property Settings (Airbnb listing number: {', '.join(report.foreign_listings)}). "
            f"If one of these rentals belongs here, add it to Property Settings, click Sync from "
            f"Sheet in Settings, and capture again.")
        report.foreign_counts = dict(sorted(foreign.items()))

    # Completeness SIGNAL — a NON-BLOCKING warning, NEVER a row-level error and never a gate on issuance.
    # Does the captured reservation income reconcile against the period's total payout? A gap = income not
    # matched to a reservation (a resolution/adjustment/cancellation, or a stay we missed). ALWAYS say when
    # we could NOT verify, so "no reconcile ran" is never mistaken for "all good" (audit finding). The gap
    # is signed: >0 = unmatched income to check; <0 = over-captured / a credit.
    if account_payout_total is None:
        report.warnings.append(
            "We couldn't double-check that every Airbnb payout matches a captured stay this run "
            "(Airbnb didn't give us the payout total). To double-check, use \"Correct dates from CSV\" "
            "with your Airbnb Transaction-History export.")
    elif report.rows_skipped_seen:
        report.warnings.append(
            f"We couldn't double-check the totals this run — {report.rows_skipped_seen} stay(s) were "
            f"skipped because they were already captured earlier.")
    else:
        report.reconcile = reconcile_period(collected, account_payout_total)
        if not report.reconcile["ok"]:
            gap = report.reconcile["shortfall"]
            report.warnings.append(
                f"€{abs(gap):.2f} of Airbnb payouts didn't match a captured stay — usually an extra payout "
                f"(a resolution, adjustment or cancellation) or a stay that wasn't captured. Check your "
                f"Airbnb transactions if the amount looks off.")
    return report


def _post_ingest(
    serializer_url: str,
    row: dict,
    *,
    api_token: str | None = None,
    operator_id: str = "extension",
    post: Any | None = None,
    timeout: float = 120.0,
) -> dict:
    """POST one canonical row to the serializer's ``ingest`` op (decision D).

    Every write goes through the single Apps Script LockService serializer — the
    adapter never touches the sheet directly. Carries the per-laptop/per-firm
    token + operator_id in the POST body (the URL alone is insufficient — the
    serializer binds the token to operator_id, section 6.3).

    Returns the serializer's JSON reply, e.g.
    ``{"op":"ingest","stored":true,"row_id":...,"dest":"STAGING"|"QUARANTINE",
       "route_status":...,"warnings":[...]}``. Raises ``IngestError`` on a
    non-JSON / HTTP-error reply (a 503 ``busy`` is returned as-is for the caller
    to back off). ``post`` is injectable for testing (defaults to requests.post).
    """
    body = {"op": "ingest", "operator_id": operator_id, "api_token": api_token, "row": row}
    return _post_op(serializer_url, body, post=post, timeout=timeout)


def post_promote(
    serializer_url: str,
    *,
    api_token: str | None = None,
    operator_id: str = "extension",
    post: Any | None = None,
    timeout: float = 120.0,
) -> dict:
    """POST the serializer's ``promote`` op: move STAGING 'new' rows to GR (unmapped ->
    QUARANTINE, duplicate row_id -> needs_review, Adjustment -> excluded).

    Promote is what makes captured rows CLAIMABLE by emit — a capture that never
    promotes leaves GR empty and `emitir` reporting "0 pending" forever (review
    finding B1: nothing else in the shipped operator flow calls this op).

    Returns the serializer's JSON reply
    ``{"op":"promote","counts":{"promote":N,"quarantine":N,"excluded":N,"needs_review":N}}``.
    Raises ``IngestError`` on a persistent non-JSON / transport failure (same retry
    envelope as ``_post_ingest``); a serializer JSON refusal (e.g. 503 ``busy``)
    is returned as-is for the caller to handle.
    """
    body = {"op": "promote", "operator_id": operator_id, "api_token": api_token}
    return _post_op(serializer_url, body, post=post, timeout=timeout)


def _post_op(serializer_url: str, body: dict, *, post: Any | None = None,
             timeout: float = 120.0) -> dict:
    """POST one op body to the serializer /exec with the shared retry envelope."""
    poster = post
    if poster is None:
        import requests  # lazy: capture extra, not needed for offline tests
        poster = requests.post
    # Apps Script /exec is occasionally flaky: a transient HTTP 404 / redirect-to-error / 5xx
    # arrives as a non-JSON Google page, or the connection drops. A single blip must NOT abort
    # the operator's whole capture, so retry a few times with backoff; only a persistent failure
    # raises. (A serializer JSON reply — incl. a 503 'busy' — parses fine and returns as-is.)
    import time
    last = "no attempt"
    for attempt in range(4):
        resp = None
        try:
            resp = poster(serializer_url, data=json.dumps(body),
                          headers={"Content-Type": "application/json"}, timeout=timeout)
            return resp.json()
        except Exception as e:  # noqa: BLE001 — non-JSON reply or a transport error -> retry
            status = getattr(resp, "status_code", "?")
            last = f"non-JSON reply (HTTP {status}): {str(getattr(resp, 'text', '') or e)[:200]}"
        if attempt < 3:
            time.sleep(0.5 * (2 ** attempt))  # 0.5s, 1s, 2s
    raise IngestError(last)
