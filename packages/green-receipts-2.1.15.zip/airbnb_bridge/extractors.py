"""Named GET-only extractors for the Airbnb capture bridge (Phase 6 scaffold).

These mirror the AL ``host_bridge`` "predefined named extractors only" pattern:
the Python side never ships arbitrary JS to the extension; it can only invoke a
fixed catalogue of extractors *by name*, each bound to a single allowlisted URL
template. A compromised bridge can therefore only ever issue the GETs enumerated
here, against ``*.airbnb.com``.

Each function below is a STUB: it raises ``NotImplementedError`` and carries the
exact URL template (and field-of-interest notes) in its docstring. The real
fetching is wired in Phase 6 through ``host_bridge.HostBridge.fetch_json`` /
``fetch_text``; the names here are the canonical keys the adapter and the
extension agree on.

All URLs are confirmed-live per docs/V2_PLAN.md "CAPTURE MECHANISM". The Airbnb
public web API key is a SHARED CONSTANT (``X-Airbnb-API-Key:
d306zoyjsyarp7ifhu67rjxn52tv0t20``) — it is NOT a secret (it ships in Airbnb's
public web bundle) but it is set by the adapter at call time, not hard-coded in
each extractor.
"""
from __future__ import annotations

import json
from typing import Any
from urllib.parse import urlencode

# The public Airbnb web API key (ships in Airbnb's own JS bundle; not a secret).
# Centralised here so the adapter and extractors agree on one value.
AIRBNB_WEB_API_KEY = "d306zoyjsyarp7ifhu67rjxn52tv0t20"

# Reservations list page size (matches the live ``_limit`` observed in DevTools).
RESERVATIONS_PAGE_SIZE = 40

# On-domain base. Every extractor URL is under https://www.airbnb.com/ so the
# two-layer allowlist (ALLOWLIST_RE in host_bridge) accepts it.
AIRBNB_BASE = "https://www.airbnb.com"

# StayHostingDetailsQuery is the GET GraphQL behind the hosting "You earn" panel.
# Its payout breakdown carries the per-reservation "Host service fee", so we read the
# fee here instead of rendering the client-only invoice page (which a GET can't extract).
# (Usually equal to the VAT invoice fee; a 1-cent difference was seen on 2026-11-11.)
#
# The persistedQuery sha256 is tied to the query VERSION and Airbnb retires old versions.
# A retired version does NOT fail cleanly: Airbnb answers HTTP 400
# {"error_type":"deprecated_web_operation"} INTERMITTENTLY while it phases the version out
# (seen 2026-11-10/11: the June hash failed 2 reads in 3 for one stay and none for another),
# and may answer a PersistedQueryNotFound GraphQL error once it is gone. So the adapter
# tries every hash in STAY_DETAILS_HASHES in order and retries; only when all of that fails
# is the stay flagged needs_review (never a silent wrong number).
STAY_DETAILS_OP = "StayHostingDetailsQuery"
# Public Airbnb GraphQL persistedQuery ids (NOT secrets), NEWEST FIRST. Each is split across
# two adjacent string literals so the hex carries no 9-consecutive-digit run (which the
# secret-scan NIF heuristic would otherwise false-flag); the values are unchanged.
# When Airbnb rotates again: put the new hash FIRST and keep the previous one behind it.
STAY_DETAILS_HASHES = (
    "835c438f2d2661bf41cacfd2062" "50be8eaf4d4b8ba1454abcce10b0c8ea9d5a4",  # seen live 2026-10-01
    "1e81282ae4de44e05bc8b7764" "56644efd4ebcd676451ce7f6c3c5757a1057e02",   # June 2026, being retired
)
STAY_DETAILS_HASH = STAY_DETAILS_HASHES[0]  # the preferred one (kept for existing callers)

__all__ = [
    "AIRBNB_WEB_API_KEY",
    "RESERVATIONS_PAGE_SIZE",
    "AIRBNB_BASE",
    "STAY_DETAILS_OP",
    "STAY_DETAILS_HASH",
    "STAY_DETAILS_HASHES",
    "reservations_list_url",
    "vat_invoice_url",
    "stay_hosting_details_url",
    "reservations_list",
    "vat_invoice",
    "render_vat_invoice",
    "stay_hosting_details",
    "listing_directory",
]


def reservations_list_url(
    *, offset: int = 0, ends_before: str | None = None, limit: int = RESERVATIONS_PAGE_SIZE,
) -> str:
    """Build the completed-stay reservations URL (the live query, urlencoded)."""
    params = [
        ("_format", "for_remy"),
        ("_limit", str(limit)),
        ("_offset", str(offset)),
        ("collection_strategy", "for_reservations_list"),
        ("locale", "en"),
        ("currency", "EUR"),
        ("status", "accepted"),       # completed stays = accepted with end in the past
        ("sort_field", "end_date"),
        ("sort_order", "desc"),
    ]
    if ends_before:
        params.append(("ends_before", ends_before))
    return f"{AIRBNB_BASE}/api/v2/reservations?{urlencode(params)}"


def vat_invoice_url(invoice_url: str) -> str:
    """Normalise a per-reservation ``host_vat_invoices[].invoice_url`` to absolute.

    Accepts ``"invoice/<token>"``, ``"/invoice/<token>"`` or an already-absolute
    ``https://www.airbnb.com/invoice/<token>`` and always returns the absolute
    on-domain form the allowlist accepts.
    """
    u = str(invoice_url or "").strip()
    if u.startswith("http://") or u.startswith("https://"):
        return u
    return f"{AIRBNB_BASE}/{u.lstrip('/')}"


def stay_hosting_details_url(confirmation_code: str, sha256_hash: str | None = None) -> str:
    """Build the StayHostingDetailsQuery GET URL for one reservation (the source
    of the host service fee). A persistedQuery GET — no POST, allowlist-clean.
    ``sha256_hash`` picks the query version (default: the preferred one)."""
    sha256_hash = sha256_hash or STAY_DETAILS_HASH
    variables = {
        "confirmationCode": str(confirmation_code),
        "requestSource": "RESERVATION_LIST",
        "viewerTimeZoneOffset": 0,
    }
    extensions = {"persistedQuery": {"version": 1, "sha256Hash": sha256_hash}}
    params = [
        ("operationName", STAY_DETAILS_OP),
        ("locale", "en"),
        ("currency", "EUR"),
        ("variables", json.dumps(variables, separators=(",", ":"))),
        ("extensions", json.dumps(extensions, separators=(",", ":"))),
    ]
    return f"{AIRBNB_BASE}/api/v3/{STAY_DETAILS_OP}/{sha256_hash}?{urlencode(params)}"


async def reservations_list(
    bridge: Any,
    *,
    offset: int = 0,
    ends_before: str | None = None,
    limit: int = RESERVATIONS_PAGE_SIZE,
) -> Any:
    """Fetch one page of the host's reservations (completed-stay query).

    URL template (CONFIRMED live 2026-06-21 — docs/V2_PLAN.md CAPTURE MECHANISM)::

        GET https://www.airbnb.com/api/v2/reservations
              ?_format=for_remy
              &_limit=<limit>
              &_offset=<offset>
              &collection_strategy=for_reservations_list
              &locale=en
              &currency=EUR
              # completed stays (what green receipts fire on):
              &status=accepted
              &ends_before=<YYYY-MM-DD>
              &sort_field=end_date
              &sort_order=desc
        Header: X-Airbnb-API-Key: d306zoyjsyarp7ifhu67rjxn52tv0t20

    Per-reservation fields the adapter consumes (see reservations_adapter):
      confirmation_code (HM), listing_id_str (USE the _str — numeric overflows
      2^53), start_date, end_date, earnings (formatted NET payout string),
      host_vat_invoices[], user_facing_status_key (emit on "complete").

    Pageable via ``_limit``/``_offset``. The "Upcoming"/"Canceled" tabs are the
    same endpoint with different ``status``/``date_min`` params (Canceled feeds
    cancellation-capture — out of MVP scope).
    """
    url = reservations_list_url(offset=offset, ends_before=ends_before, limit=limit)
    return await bridge.fetch_json(url, headers={"X-Airbnb-API-Key": AIRBNB_WEB_API_KEY,
                                             "Accept-Language": "en-US,en;q=0.9"})


async def vat_invoice(bridge: Any, *, invoice_url: str) -> Any:
    """Fetch one Airbnb-Ireland VAT (commission) invoice as HTML.

    URL template (CONFIRMED live — docs/V2_PLAN.md)::

        GET https://www.airbnb.com/<invoice_url>

    where ``<invoice_url>`` is the per-reservation ``host_vat_invoices[].invoice_url``
    (e.g. ``invoice/1woggbQjl7p``). Returns ``text/html`` (the page is
    print-clean). The HTML is the AUTHORITATIVE source archived to Drive.

    Parse targets (Phase 6 / Phase 6b):
      - "Service Fee EUR 16.71"   -> service_fee (obj 7; the id:0 invoice is current)
      - VAT reverse charge marker, invoice_number, both parties' VAT IDs
        (Airbnb Ireland IE9827384L — also the Modelo 30 source doc).

    Role tagging by the caller: id 0 = current; ``-CN-`` in number = credit note;
    other negative id = superseded. Archive ALL of them (the revision trail is
    the audit history) — see docs/V2_PLAN.md DOCUMENT ARCHIVAL Track 1.
    """
    return await bridge.fetch_text(vat_invoice_url(invoice_url))


async def render_vat_invoice(bridge: Any, *, invoice_url: str) -> str:
    """RENDER one VAT invoice (the SPA hydrates) and return its extracted text.

    The invoice page is client-rendered, so a plain GET (vat_invoice) returns only
    the shell; this opens it in a background tab on the user's session and reads the
    rendered DOM. For Phase-6b archival + the fee cross-check ONLY — the emit fee
    comes from StayHostingDetailsQuery, which never needs this.
    """
    return await bridge.render_text(vat_invoice_url(invoice_url))


async def stay_hosting_details(bridge: Any, *, confirmation_code: str, sha256_hash: str | None = None) -> Any:
    """Fetch one reservation's hosting details (the "You earn" payout breakdown).

    GET the StayHostingDetailsQuery persistedQuery (see ``stay_hosting_details_url``)
    and return the parsed JSON. The adapter's ``parse_host_service_fee`` pulls the
    "Host service fee" line item out of it — the AUTHORITATIVE per-reservation
    commission, verified equal to the VAT invoice, but reachable with a plain GET
    (unlike the client-rendered invoice page). Header carries the public web key.
    """
    url = stay_hosting_details_url(confirmation_code, sha256_hash)
    return await bridge.fetch_json(url, headers={"X-Airbnb-API-Key": AIRBNB_WEB_API_KEY,
                                             "Accept-Language": "en-US,en;q=0.9"})


async def listing_directory(bridge: Any) -> Any:
    """Catalog the host's listings to fill any ``listing_id`` gaps.

    URL template::

        GET https://www.airbnb.com/api/v2/reservations  (the list itself carries
            listing_id_str per reservation — the PRIMARY routing source)

        Fallback catalog scrape when an id is genuinely absent:
        GET https://www.airbnb.com/hosting/listings   (host listing directory)
        GET https://www.airbnb.com/rooms/<listing_id> (per-listing confirm)

    Purpose: the reservations API already returns ``listing_id_str`` per booking
    (so the v1 "scrape listing_id from the name" gap is CLOSED in the normal
    path). This extractor exists only as the fallback to resolve a numeric
    listing_id when one is missing, yielding ``{listing_name -> listing_id}`` /
    ``{hm -> listing_id}``. ``listing_id`` is a HARD-REQUIRED non-null field: the
    adapter FAILS the capture rather than silently blanking it (no name-based
    routing — see docs/V2_PLAN.md §3.2 "the listing_id gap").
    """
    # TODO(Phase 6): only invoked when reservations_list omits listing_id_str
    #   for some row. Prefer the _str field from the reservations payload; this
    #   catalog scrape is the last-resort fallback, re-checked at resolve time.
    raise NotImplementedError(
        "listing_directory is a Phase-0 scaffold stub; wire in Phase 6."
    )
