"""Transaction-History CSV parser — the payment-date pipeline source (PURE).

Airbnb's "Transaction History" export is the ONLY place the actual PAYMENT date
lives (the ``Date`` column) — the Reservations API carries stay dates but not when
the money moved. A green receipt is a REAL Portuguese tax document, so the parser
is deliberately conservative: anything it can't cleanly classify as a filable stay
is routed to ``review`` (never silently filed, never silently dropped).

Row lanes:
  file   — a completed Reservation with clean EUR positive money -> issue a receipt
  review — needs a human: an unrecognised Type, an Airbnb-remitted-tax stay, a
           non-EUR amount, a refund/reversal, or a missing amount
  skip   — a Payout bank-transfer SUMMARY row (reconciliation only, never a receipt)

Money flows through the pipeline as STRINGS ("790.76"); thousands commas are
stripped ("1,103.56" -> "1103.56"). Blank money -> "". PURE: no I/O, no network.
"""
from __future__ import annotations

import datetime
import re

# The Airbnb "Transaction History" CSV column names (header row), for reference. Read BY NAME,
# so a real export's extra columns (Booking date, Nights, Listing, Reference code, Paid out,
# Fast pay fee, Earnings year) are ignored, and column reorders never misalign anything.
#   Amount  = the NET paid to the host for a Reservation row (blank on a Payout summary row) -> paid_out
#   Gross earnings = Amount + Service fee (the guest-side gross/TTC) -> ttc
#   Listing = the human listing name (routing is by listing_id, resolved downstream) -> listing_name
CSV_COLUMNS = (
    "Date", "Arriving by date", "Type", "Confirmation code", "Start date",
    "End date", "Guest", "Listing", "Currency", "Amount", "Gross earnings",
    "Service fee", "Cleaning fee", "Airbnb remitted tax", "Details",
)


def _iso_date(s: str | None) -> str:
    """US ``MM/DD/YYYY`` -> ISO ``YYYY-MM-DD``, VALIDATED against the real calendar.

    Blank / non-US-format / impossible date (month 13, day 32, 02/30, a DD/MM export
    where the fields are swapped into an invalid combination) -> "" — NEVER a guessed or
    fabricated date. The caller routes a Reservation with an empty payment/stay date to
    ``review`` rather than filing a mis-periodised tax document."""
    m = re.match(r"\s*(\d{1,2})/(\d{1,2})/(\d{4})\s*$", str(s or ""))
    if not m:
        return ""
    mm, dd, yyyy = (int(g) for g in m.groups())
    try:
        return datetime.date(yyyy, mm, dd).isoformat()   # rejects 13/xx, xx/32, 02/30, ...
    except ValueError:
        return ""


# A clean US-format money literal: optional sign, optional 1,234-grouped thousands, optional
# decimals. Anything else (a European decimal comma "1.234,56", letters, two dots) is NOT
# trusted — it must not be silently coerced into a plausible-but-wrong number.
_US_MONEY = re.compile(r"^-?\d{1,3}(?:,\d{3})*(?:\.\d+)?$|^-?\d+(?:\.\d+)?$")


def _money(s: str | None) -> str:
    """CSV money cell -> display string. Clean US format ("1,103.56" -> "1103.56") has its
    thousands commas stripped; a blank cell -> "". Anything NOT clean US format is returned
    RAW (stripped) so a review row shows the operator the suspicious original — we never emit
    a silently-corrupted amount (e.g. a European "1.234,56" must not become "1.23456")."""
    t = str(s or "").strip()
    if not t:
        return ""
    return t.replace(",", "") if _US_MONEY.match(t) else t


def _parse_amount(s: str | None) -> float | None:
    """Float for FLAG checks only (>0 / <=0). ``None`` when blank OR not a clean US-format
    number (European format / garbage -> None -> the caller routes the row to review rather
    than filing a wrong amount)."""
    t = str(s or "").strip()
    if not t or not _US_MONEY.match(t):
        return None
    try:
        return float(t.replace(",", ""))
    except ValueError:
        return None


def parse_transactions(rows: list[dict]) -> list[dict]:
    """Map Transaction-History CSV rows -> canonical dicts, one per input row.

    See module docstring for the lane rules. ``rows`` is keyed by the CSV column
    names (``CSV_COLUMNS``). Order is preserved."""
    out: list[dict] = []
    for row in rows:
        txn_type = str(row.get("Type") or "").strip()
        currency = str(row.get("Currency") or "").strip()
        # Canonical shell — every row carries the same keys (blank money -> "").
        canon = {
            "hm_code": str(row.get("Confirmation code") or "").strip(),
            "listing_name": str(row.get("Listing") or "").strip(),
            "check_in": _iso_date(row.get("Start date")),
            "check_out": _iso_date(row.get("End date")),
            "guest": str(row.get("Guest") or "").strip(),
            # paid_out = the NET the host received (CSV "Amount"); ttc = the guest-side gross
            # ("Gross earnings"). The serializer REQUIRES a positive paid_out to accept a Reservation
            # and cross-checks gross == paid_out + service_fee, so we carry both verbatim.
            "paid_out": _money(row.get("Amount")),
            "ttc": _money(row.get("Gross earnings")),
            "service_fee": _money(row.get("Service fee")),
            "cleaning_fee": _money(row.get("Cleaning fee")),
            "remitted_tax": _money(row.get("Airbnb remitted tax")),
            "currency": currency,
            "payment_date": _iso_date(row.get("Date")),
            "txn_type": txn_type,
            "lane": "",
            "review_reason": "",
        }

        # Payout = a bank-transfer SUMMARY (blank code, blank stay dates): never a
        # receipt, reconciliation only.
        if txn_type == "Payout":
            canon["lane"] = "skip"
            out.append(canon)
            continue

        # Anything that isn't a plain Reservation (Resolution Payout, Adjustment, ...)
        # -> review with its Type + Details kept so a human can classify it.
        if txn_type != "Reservation":
            canon["lane"] = "review"
            canon["review_reason"] = (
                f"{txn_type}: classify (extra-service = file, damage/indemnity = exclude)")
            canon["details"] = str(row.get("Details") or "").strip()
            out.append(canon)
            continue

        # A Reservation: file ONLY when every tax-critical field is clean — FAIL CLOSED. Any
        # missing/invalid field (no booking ref, unreadable payment/stay date, unclear amount,
        # unclear/positive remitted tax, non-EUR) accumulates a reason and routes to review; a
        # green receipt is never issued with a blank date/reference or a coerced amount.
        reasons: list[str] = []
        if not canon["hm_code"]:
            reasons.append("no booking reference")
        if not canon["payment_date"]:
            reasons.append("unreadable payment date — verify")
        if not canon["check_in"] or not canon["check_out"]:
            reasons.append("unreadable stay dates — verify")

        gross = _parse_amount(row.get("Gross earnings"))
        if gross is None:
            reasons.append("missing/unclear amount")
        elif gross <= 0:
            reasons.append("negative/refund — verify")

        # paid_out (CSV "Amount") is a SEPARATE required field: the serializer rejects a Reservation
        # with a blank/non-positive paid_out (its anti-under-declaration gate) — and a rejected row is
        # DROPPED, not parked. So a Reservation missing a clean positive Amount must route to review
        # HERE, or the stay vanishes silently from the month (the exact fail-open we guard against).
        paid = _parse_amount(row.get("Amount"))
        if paid is None:
            reasons.append("missing/unclear payout amount")
        elif paid <= 0:
            reasons.append("non-positive payout — verify")

        remitted_raw = str(row.get("Airbnb remitted tax") or "").strip()
        remitted = _parse_amount(row.get("Airbnb remitted tax"))
        if remitted_raw and remitted is None:            # present but unparseable -> don't fail open
            reasons.append(f"unclear remitted tax '{remitted_raw}' — confirm")
        elif remitted is not None and remitted > 0:
            reasons.append(f"Airbnb remitted tax {canon['remitted_tax']} — confirm treatment")

        if currency != "EUR":
            reasons.append(f"non-EUR ({currency})")

        if reasons:
            canon["lane"] = "review"
            canon["review_reason"] = "; ".join(reasons)
            canon["details"] = str(row.get("Details") or "").strip()
        else:
            canon["lane"] = "file"
        out.append(canon)

    # --- Stage B (installment / long-stay safety): a cross-row pass over the FILE lane ---
    # A reservation paid in MULTIPLE payouts (Airbnb pays 28+ night stays monthly) appears as several
    # 'file' rows sharing one Confirmation code. The serializer keys row_id on the HM, so it would collide
    # them and silently park the 2nd..Nth as an opaque "duplicate row_id" — that income never files. Detect
    # it HERE and route ALL of a multi-payout HM's rows to review, so the operator sees the whole installment
    # picture (each installment is its own receipt, on its own payout date). Also flag any single very-long
    # stay (>=28 nights, where installment billing begins) for a quick verify. Validated on the owner's 4-year
    # history: this catches the 5 real multi-payout HMs, no false trigger on a resolution sharing an HM.
    # Count RESERVATION-TYPE rows per HM (ANY lane), not just 'file' rows: if one installment is independently
    # routed to review (its own remitted-tax / refund / non-EUR flag), counting only 'file' would leave the
    # OTHER clean installment at count 1 -> it files alone, then collides on row_id when the reviewed one is
    # later issued -> a silent drop (adversarial-review finding). Resolutions/Adjustments are NOT txn_type
    # 'Reservation', so a reservation sharing its HM with one still files (count stays 1).
    resv_counts: dict[str, int] = {}
    for r in out:
        if r["txn_type"] == "Reservation" and r["hm_code"]:
            resv_counts[r["hm_code"]] = resv_counts.get(r["hm_code"], 0) + 1
    for r in out:
        if r["lane"] != "file":
            continue
        hm = r["hm_code"]
        if hm and resv_counts.get(hm, 0) > 1:
            r["lane"] = "review"
            r["review_reason"] = (f"{resv_counts[hm]} payouts for reservation {hm} (paid in installments) "
                                  f"— verify each installment is issued, none dropped")
            continue
        if r["check_in"] and r["check_out"]:
            try:
                nights = (datetime.date.fromisoformat(r["check_out"])
                          - datetime.date.fromisoformat(r["check_in"])).days
            except ValueError:
                nights = 0
            if nights >= 28:
                r["lane"] = "review"
                r["review_reason"] = f"long stay ({nights} nights) — verify the payout(s) and dates"

    return out


# This parser reads ENGLISH Airbnb Transaction-History column names + US MM/DD/YYYY dates. A Portuguese
# (or any non-English) account exports LOCALIZED headers + DD/MM dates, which would be silently
# mis-parsed into WRONG tax dates. Detect that and FAIL CLEARLY (tell the operator to set the Airbnb
# account language to English and re-export) — never guess. The live EXTENSION lane is unaffected (it
# pins locale=en + Accept-Language:en on the API requests); this guard is only for the manual CSV drop.
_CSV_REQUIRED_HEADERS = ("Type", "Confirmation code", "Start date", "Amount", "Date")


def csv_locale_error(csv_rows: list[dict]) -> str:
    """Return a clear operator message if the CSV is NOT a recognisable English Airbnb export (localized
    headers, or DD/MM dates that would mis-parse), else "" (safe to parse as English/US-format)."""
    if not csv_rows:
        return ""
    # Union across ALL rows: a real export (csv.DictReader) gives every row the full header set, but a
    # Payout-only row carries fewer keys than a Reservation row, so row[0] alone under-counts the columns.
    headers = set().union(*(r.keys() for r in csv_rows))
    missing = [h for h in _CSV_REQUIRED_HEADERS if h not in headers]
    if missing:
        return ("This doesn't look like an English Airbnb Transaction-History export (missing column"
                + ("s" if len(missing) > 1 else "") + ": " + ", ".join(missing) + "). If your Airbnb "
                "account language is Portuguese, switch it to English (airbnb.com → Account → "
                "Preferred language → English), re-download the Transaction History, and drop it again.")
    # English headers but DD/MM-looking dates (a first field > 12 is impossible as a US month) would
    # mis-periodise a receipt silently — refuse rather than guess. We scan EVERY date field of EVERY row,
    # so any real multi-reservation month (payouts + check-ins spread across the calendar) is caught by a
    # single day > 12. KNOWN residual: a file where EVERY date happens to fall on days 1–12 is ambiguous
    # and passes as MM/DD. This only arises off-instruction (Airbnb's own export ties headers+date-format
    # to the account locale, so a direct PT export is already caught by the header check above; the all-≤12
    # case needs an operator to re-save the file through a PT-locale Excel) and is documented as acceptable.
    for r in csv_rows:
        for col in ("Date", "Start date", "End date"):
            m = re.match(r"\s*(\d{1,2})/(\d{1,2})/\d{4}\s*$", str(r.get(col) or ""))
            if m and int(m.group(1)) > 12:
                return ("The dates in this CSV look like DD/MM/YYYY, but the tool reads US MM/DD/YYYY. "
                        "Re-export with your Airbnb account language set to English so dates come as MM/DD.")
    return ""


def parse_csv_signals(csv_rows: list[dict]) -> dict:
    """Extract the actionable signals from a Transaction-History CSV drop (Stage F). This does NOT
    re-ingest (which would hit the listing-routing problem — the CSV has a Listing NAME, not the
    listing_id the serializer routes on); it ENRICHES + SIGNALS on top of the extension capture:

      exact_dates       {hm_code: ISO payout date} — the EXACT dataPrestacao for each single-payout
                        filable Reservation, to CORRECT the extension lane's check-in+1 estimate (only
                        ~52% accurate) via the (ISO-validated) override op. Multi-payout HMs are absent
                        here (Stage B routes them to review), so we never auto-correct an installment stay.
      extras            the review-lane rows (resolutions / adjustments / remitted-tax / long / installment)
                        — income or edge cases NOT a plain filable reservation, for the operator to classify.
      payout_total      sum of the bank-transfer 'Payout' rows (what actually hit the account).
      reservation_total sum of the 'Reservation' net Amounts.

    gap = payout_total - reservation_total = the unmatched income (resolutions/adjustments) — the same
    completeness signal proven exact on 4 years of real data. PURE: no I/O, no network."""
    err = csv_locale_error(csv_rows)   # PT / non-English / DD-MM export -> fail clearly, never mis-parse
    if err:
        return {"error": "unsupported_csv", "detail": err, "exact_dates": {}, "extras": [],
                "payout_total": 0.0, "reservation_total": 0.0, "gap": 0.0}
    parsed = parse_transactions(csv_rows)
    exact_dates = {r["hm_code"]: r["payment_date"] for r in parsed
                   if r["lane"] == "file" and r["hm_code"] and r["payment_date"]}
    extras = [r for r in parsed if r["lane"] == "review"]

    def _sum(type_name: str, col: str) -> float:
        return round(sum(_parse_amount(row.get(col)) or 0.0 for row in csv_rows
                         if str(row.get("Type") or "").strip() == type_name), 2)

    payout_total = _sum("Payout", "Paid out")
    reservation_total = _sum("Reservation", "Amount")
    return {"exact_dates": exact_dates, "extras": extras,
            "payout_total": payout_total, "reservation_total": reservation_total,
            "gap": round(payout_total - reservation_total, 2)}
