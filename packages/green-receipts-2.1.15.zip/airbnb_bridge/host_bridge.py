"""Local WebSocket bridge to the user's authenticated Airbnb Chrome session.

Adapted from AL-analytics ``src/host_auth.py`` (the proven MV3 + WebSocket
transport) for green-receipts v2 capture. Starts a WS server on
``127.0.0.1:18472``; the companion MV3 extension (``extensao/``) connects OUT to
this server, runs predefined named extractors / GET fetches from inside a real
``*.airbnb.com`` tab (so cookies + Origin are correct), and returns response
bodies as text.

Key properties (decision C — capture on the user's own session):
  * Local-only (127.0.0.1). Never exposed to the LAN.
  * URL allowlist enforced on BOTH sides (defence in depth): the extension
    guards it, and this Python side re-guards every job before sending it.
  * GET/HEAD only. No mutation of Airbnb state, ever.
  * Cookies never cross the bridge in either direction — they live in the
    browser; the browser attaches them. We only ever see response bodies.

WHAT CHANGED vs the AL bridge (read before editing):
  * Stale-extension handling is promoted from a WARNING to a **HARD ABORT**.
    See ``check_extension_version`` / ``ensure_fresh_extension``. In AL this was
    a soft warning; for tax documents a silently-stale extractor is
    catastrophic (it can under-declare income with no visible error), so v2
    refuses to capture against a mismatched extension.
  * Extractors are green-receipts-specific (reservations_list, vat_invoice,
    listing_directory) — see ``extractors.py``.

Usage:
    async with HostBridge() as bridge:           # start + wait + freshness gate
        data = await bridge.fetch_json(url)      # GET-only, allowlisted
        html = await bridge.fetch_text(inv_url)
"""
from __future__ import annotations

import asyncio
import hmac
import json
import logging
import os
import re
import secrets
import time
import uuid
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import websockets
    from websockets.asyncio.server import ServerConnection
    from websockets.protocol import State
except ImportError:  # pragma: no cover - websockets is an install-time dep
    # Keep the module importable for syntax/audit checks on a machine without
    # the capture extra installed. Any actual bridge use raises clearly.
    websockets = None  # type: ignore[assignment]
    ServerConnection = Any  # type: ignore[assignment,misc]

    class State:  # type: ignore[no-redef]
        OPEN = "OPEN"


log = logging.getLogger("airbnb_bridge")

# ---- SHARED CONSTANTS (must match extensao/background.js verbatim) ----------
DEFAULT_HOST = "127.0.0.1"
# Port 18482 is DELIBERATELY distinct from the AL Analytics Host Bridge (18472),
# which green-receipts was adapted from and which uses the same /bridge protocol.
# Sharing a port let AL's extension connect to our bridge and trip the freshness
# gate; worse, a cross-project bridge could drive the wrong extension against the
# user's Airbnb session. Keep this in sync with extensao/background.js DEFAULT_BRIDGE_PORT.
# This is the DEFAULT instance's port; a named instance (instance.py, GR_BRIDGE_PORT) uses its
# own, and its extension is pointed at it from the popup — so two instances on one laptop never
# drive each other's Chrome profile.
DEFAULT_PORT = 18482
# Hello handshake app-id — the bridge accepts ONLY its own extension, so a foreign
# bridge-protocol extension (e.g. AL's) that reaches this port is rejected, not
# mistaken for ours. Must match extensao/background.js BRIDGE_APP_ID.
BRIDGE_APP_ID = "green-receipts-bridge"

# Optional per-deployment shared token (objective: harden the unauthenticated
# localhost WS for an operator's multi-user laptops). When a token is configured, the
# bridge accepts a hello ONLY if it carries the matching token — so a hostile LOCAL
# process can't impersonate the extension and feed fake reservation/fee data. The
# operator pastes the token into the extension popup ONCE (chrome.storage). Default
# location; set GR_BRIDGE_TOKEN_FILE to override, or pass token="" to disable.
def _bridge_token_path() -> Path:
    override = os.environ.get("GR_BRIDGE_TOKEN_FILE")
    if override:
        return Path(override)
    import instance
    return instance.config_dir() / "bridge_token"   # per instance (instance.py)


def load_or_mint_bridge_token(path: Path | None = None, *, mint: bool = True) -> str | None:
    """Read the shared bridge token (a stable per-machine secret); mint + persist one
    if absent. Returns None if there is no token and mint=False (enforcement off)."""
    p = path or _bridge_token_path()
    try:
        tok = p.read_text(encoding="utf-8").strip()
        if tok:
            return tok
    except OSError:
        pass
    if not mint:
        return None
    tok = "grb-" + secrets.token_urlsafe(24)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        # Create with owner-only perms ATOMICALLY (mode at creation), so the token is
        # never briefly world-readable between write and chmod (POSIX). On Windows the
        # mode is advisory (NTFS ACLs of the user's own config dir apply).
        fd = os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        try:
            os.write(fd, tok.encode("utf-8"))
        finally:
            os.close(fd)
    except OSError:
        pass
    return tok
# Two-layer allowlist: this regex mirrors the extension's URL_ALLOWLIST.
ALLOWLIST_RE = re.compile(r"^https://([a-z0-9-]+\.)*airbnb\.com/", re.IGNORECASE)
ALLOWED_METHODS = {"GET", "HEAD"}

# Repo copy of the extension manifest — used ONLY for the freshness gate below,
# never read at request time.
_EXTENSION_MANIFEST_PATH = Path(__file__).resolve().parent / "extensao" / "manifest.json"


def read_disk_extension_version(manifest_path: Path | None = None) -> str | None:
    """Best-effort read of the repo extension's manifest version.

    Returns ``None`` when the manifest is missing/unparseable so a Python-only
    deployment can skip the freshness gate.
    """
    path = manifest_path or _EXTENSION_MANIFEST_PATH
    try:
        with path.open(encoding="utf-8") as f:
            version = json.load(f).get("version")
        return str(version) if version else None
    except (OSError, json.JSONDecodeError, AttributeError):
        return None


def check_extension_version(running: str | None, disk: str | None) -> str | None:
    """Compare the handshake-reported extension version against the repo manifest.

    Returns a human-readable message when Chrome is running a DIFFERENT version
    than the code on disk (unpacked extension edited but not reloaded, or loaded
    from a different folder). Returns ``None`` when versions match or either side
    is unknown.

    HARD ABORT (v2 change): in AL this fed a soft warning. The June-2026
    incident — Chrome silently running a stale reservations extractor for days,
    producing 0 rows with no hint why — is *worse* for green receipts: a stale
    extractor can silently capture the wrong/empty period and the completeness
    gate would read it as "all done", under-declaring income. So callers treat a
    non-None return here as a fatal ``BridgeError`` (see ``ensure_fresh_extension``),
    never a continue-anyway warning.
    """
    if not running or not disk or running == disk:
        return None
    return (
        f"Chrome is running Green Receipts Bridge v{running} but the repo "
        f"manifest is v{disk} — Chrome is executing STALE extension code. "
        "Capture is ABORTED (a stale extractor can silently under-declare). "
        "Fix: open chrome://extensions, find 'Green Receipts Bridge', toggle it "
        "off/on (or click reload). If the version still mismatches, check "
        "Details -> 'Loaded from' path."
    )


# 8d — the extension reloads itself (docs/PLAN_FEE_LOOKUP_400.md step 8d). An extension that
# understands the {kind: "reload"} job says so in its hello (``jobKinds``). When such an extension
# is stale, the bridge asks it to reload (Chrome re-reads the unpacked files from the folder it
# loaded) and waits this long for the fresh hello before falling back to today's hard abort.
RELOAD_JOB_KIND = "reload"
RELOAD_WAIT_SEC = 15.0


def supports_reload(hello: dict | None) -> bool:
    """Does the extension that sent this hello understand the ``reload`` job? 0.7.0 and older
    advertise only ``fetch`` (or nothing), so they are never sent one."""
    kinds = (hello or {}).get("jobKinds")
    return isinstance(kinds, (list, tuple)) and RELOAD_JOB_KIND in kinds


def _is_open(conn: Any | None) -> bool:
    return conn is not None and getattr(conn, "state", None) == State.OPEN


class BridgeError(RuntimeError):
    """Raised on any failure in the Airbnb host-bridge layer."""


class _ExtensionDisconnected(BridgeError):
    """The extension's connection closed while a job was in flight (a BridgeError like any other;
    reload_if_stale tells it apart because a reloading extension closes its socket on purpose)."""


@dataclass
class BridgeJobResult:
    status: int
    url: str
    content_type: str
    body: str


@dataclass
class _PendingJob:
    future: "asyncio.Future"
    started: float = field(default_factory=time.monotonic)


class HostBridge:
    """Local WebSocket bridge for the Green Receipts Airbnb capture extension.

    Lifecycle (or use the ``async with`` form, which does start + wait +
    freshness gate for you):

        bridge = HostBridge()
        await bridge.start()                 # opens local WS server
        await bridge.wait_for_extension()    # blocks until extension says hello
        bridge.ensure_fresh_extension()      # HARD ABORT on stale extractor
        ...                                  # fetch_json / fetch_text
        await bridge.stop()
    """

    def __init__(
        self,
        host: str = DEFAULT_HOST,
        port: int | None = None,
        connect_timeout: float = 60.0,
        job_timeout: float = 30.0,
        token: str | None = None,
    ):
        self.host = host
        if port is None:
            import instance
            port = instance.bridge_port()   # DEFAULT_PORT for the default instance
        self.port = port
        self.connect_timeout = connect_timeout
        self.job_timeout = job_timeout
        # token=None/"" -> enforcement OFF (app-id only; the owner's low-friction default).
        # token="auto" -> load/mint the shared token + enforce. token="<value>" -> enforce it.
        self.token = load_or_mint_bridge_token() if token == "auto" else (token or None)
        self._server = None
        self._extension: Any | None = None
        self._connected_event = asyncio.Event()
        self._pending: dict[str, _PendingJob] = {}
        self._hello: dict | None = None
        # Every VALID hello bumps this (and sets _hello_event), so reload_if_stale can wait for a
        # NEW hello — the one the extension sends after it has reloaded.
        self._hello_seq = 0
        self._hello_event = asyncio.Event()
        # True only while reload_if_stale waits for the reloaded extension: lets that extension's
        # new connection take the slot even if the old socket's close has not been seen yet.
        self._reload_pending = False
        self.reload_attempted = False   # at most ONE reload per bridge session (never a loop)
        # Non-None after wait_for_extension() when Chrome reports a version that
        # differs from extensao/manifest.json. ensure_fresh_extension() turns
        # this into a fatal error.
        self.stale_extension_warning: str | None = None

    async def __aenter__(self) -> "HostBridge":
        await self.start()
        await self.wait_for_extension()
        # A stale extension that can reload itself is asked to (8d); otherwise / if still stale,
        # v2: freshness is a gate, not a warning — refuse to hand back a bridge
        # that would run a stale extractor.
        await self.reload_if_stale()
        self.ensure_fresh_extension()
        return self

    async def __aexit__(self, *exc):
        await self.stop()

    async def start(self) -> None:
        if websockets is None:  # pragma: no cover
            raise BridgeError(
                "the 'websockets' package is required for capture; "
                "install the capture extra (pip install websockets)."
            )
        log.info("starting airbnb_bridge on ws://%s:%d", self.host, self.port)
        # SECURITY (bound to 127.0.0.1, so off-machine peers cannot reach it). The
        # WS itself is UNAUTHENTICATED: the first peer to connect is trusted as
        # "the extension". On a single-user laptop running capture interactively
        # this is the accepted posture (same as the AL bridge it is adapted from),
        # but a hostile LOCAL process/page could impersonate the extension and feed
        # FAKE reservation/invoice data -> wrong receipts. HARDENING for the shared-laptop
        # multi-user deployment (tracked, Phase 9/10): require the hello to carry a
        # per-launch shared token the bridge generates and the operator pastes into
        # the extension. Not a blocker for the owner's own-machine dry-run.
        # TODO(Phase 6): mirror AL's ping_interval/ping_timeout tuning; confirm
        #   the keepalive cadence matches extensao/background.js KEEPALIVE_ALARM.
        self._server = await websockets.serve(
            self._handler, self.host, self.port, ping_interval=20, ping_timeout=10,
        )

    async def stop(self) -> None:
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
            log.info("airbnb_bridge stopped")
        for _job_id, job in list(self._pending.items()):
            if not job.future.done():
                job.future.set_exception(BridgeError("bridge stopping"))
        self._pending.clear()

    async def wait_for_extension(self) -> None:
        try:
            await asyncio.wait_for(
                self._connected_event.wait(), timeout=self.connect_timeout
            )
        except asyncio.TimeoutError:
            raise BridgeError(
                f"Chrome extension did not connect within {self.connect_timeout}s. "
                "Is Chrome running with the 'Green Receipts Bridge' extension "
                "loaded? See airbnb_bridge/README.md for the one-time install."
            )
        self._check_hello_version()

    def _check_hello_version(self) -> None:
        """Set ``stale_extension_warning`` from the current hello vs the manifest on disk."""
        running = (self._hello or {}).get("extensionVersion")
        disk = read_disk_extension_version()
        self.stale_extension_warning = check_extension_version(running, disk)
        # Fail-closed: an extension DID connect (we have a hello) but reported no
        # version, while we have a disk manifest to compare against -> we cannot
        # prove it is fresh. check_extension_version() fail-OPENs on unknowns (by
        # design, so a Python-only deployment can skip the gate); on the extension
        # path that unknown is itself a silent-under-declaration risk, so abort.
        if disk and not running:
            self.stale_extension_warning = (
                "connected extension reported no version; cannot verify it is fresh "
                "(refusing to capture — an unknown/stale extractor can silently "
                "under-declare). Reload 'Green Receipts Bridge' in chrome://extensions."
            )

    def ensure_fresh_extension(self) -> None:
        """HARD ABORT if the connected extension is stale (v2 safety gate).

        Must be called after ``wait_for_extension``. Promotes AL's soft warning
        to a fatal error: a stale extractor is a silent-under-declaration risk
        for real tax documents (see ``check_extension_version`` docstring and
        docs/V2_PLAN.md §3.2 "stale-ext HARD ABORT").
        """
        if self.stale_extension_warning:
            log.error("STALE EXTENSION (aborting): %s", self.stale_extension_warning)
            raise BridgeError(self.stale_extension_warning)

    async def reload_if_stale(self, *, timeout: float | None = None) -> bool:
        """8d: before the stale-extension HARD ABORT, ask the extension to reload itself.

        Only when ALL hold: the connected extension is stale, it reported its version, it
        advertises the ``reload`` job in its hello (0.8.0+; an older one is never sent it), its
        authenticated connection is open, and no reload was tried yet in this bridge session (so a
        folder that still holds old files can never cause a reload loop). Then: send
        ``{"id", "kind": "reload"}`` on that connection, wait up to ``timeout`` (RELOAD_WAIT_SEC)
        for a NEW valid hello (same app-id + token gate as every hello), and re-check its version.

        Never raises and never relaxes the gate: if no fresh hello arrives, or the new one is still
        stale, ``stale_extension_warning`` stays set and ``ensure_fresh_extension`` aborts with
        today's message. Returns True when a reload was sent."""
        if not self.stale_extension_warning or self.reload_attempted:
            return False
        hello = self._hello or {}
        ext = self._extension
        if not hello.get("extensionVersion") or not supports_reload(hello) or not _is_open(ext):
            return False
        self.reload_attempted = True
        budget = RELOAD_WAIT_SEC if timeout is None else float(timeout)
        loop = asyncio.get_event_loop()
        deadline = loop.time() + budget
        seq = self._hello_seq
        old_version = hello.get("extensionVersion")
        job_id = str(uuid.uuid4())
        ack: "asyncio.Future" = loop.create_future()
        self._pending[job_id] = _PendingJob(future=ack)
        self._hello_event.clear()
        self._reload_pending = True
        log.warning("extension v%s is stale; asking it to reload itself", old_version)
        try:
            try:
                await ext.send(json.dumps({"id": job_id, "kind": RELOAD_JOB_KIND}))
            except Exception as e:  # noqa: BLE001 — could not ask: today's abort follows
                log.warning("could not send reload to the extension: %s", e)
                return True
            # The extension answers before it reloads. An ERROR answer means it refused (e.g. it
            # reloaded moments ago): stop here, today's abort follows. Its socket closing first, or
            # no answer at all, is normal for a reload — keep waiting for the new hello.
            hello_wait = asyncio.ensure_future(self._hello_event.wait())
            try:
                await asyncio.wait({ack, hello_wait}, return_when=asyncio.FIRST_COMPLETED,
                                   timeout=max(0.0, min(5.0, deadline - loop.time())))
            finally:
                hello_wait.cancel()
            if ack.done() and not ack.cancelled():
                err = ack.exception()
                if err is not None and not isinstance(err, _ExtensionDisconnected):
                    log.warning("extension refused to reload: %s", err)
                    return True
            while self._hello_seq == seq:
                remaining = deadline - loop.time()
                if remaining <= 0:
                    break
                self._hello_event.clear()
                if self._hello_seq != seq:
                    break
                try:
                    await asyncio.wait_for(self._hello_event.wait(), timeout=remaining)
                except asyncio.TimeoutError:
                    break
        finally:
            self._reload_pending = False
            self._pending.pop(job_id, None)
            if ack.done() and not ack.cancelled():
                ack.exception()   # retrieved, so asyncio never logs it as unhandled
            else:
                ack.cancel()
        if self._hello_seq == seq:
            log.warning("no fresh hello within %.0fs after the reload request", budget)
            return True
        self._check_hello_version()
        log.info("extension reloaded: v%s -> v%s (%s)", old_version,
                 (self._hello or {}).get("extensionVersion"),
                 "still stale" if self.stale_extension_warning else "fresh")
        return True

    @property
    def extension_info(self) -> dict | None:
        return self._hello

    async def _handler(self, ws: Any) -> None:
        # Do NOT claim the single extension slot until a VALID hello (correct app-id
        # AND, when enforced, the token) arrives — else a foreign local process could
        # seize the slot just by connecting and block the real extension (review finding).
        claimed = False
        log.info("connection from %s", ws.remote_address)
        try:
            async for raw in ws:
                try:
                    msg = json.loads(raw)
                except Exception as e:
                    log.warning("bad JSON from connection: %s", e)
                    continue
                kind = msg.get("kind")
                if kind == "hello":
                    # Reject a foreign bridge-protocol extension (e.g. the AL Analytics
                    # Host Bridge) WITHOUT having claimed the slot.
                    if msg.get("app") != BRIDGE_APP_ID:
                        log.warning("rejecting foreign hello: app=%r v%s (expected app=%r)",
                                    msg.get("app"), msg.get("extensionVersion"), BRIDGE_APP_ID)
                        await ws.close(code=4002, reason="not the green-receipts extension")
                        return
                    # Optional shared-token gate (constant-time): a hostile local process
                    # can speak the protocol + app-id but not know the token.
                    if self.token and not hmac.compare_digest(str(msg.get("token") or ""), self.token):
                        log.warning("rejecting hello: bad/missing bridge token")
                        await ws.close(code=4003, reason="bad bridge token")
                        return
                    # VALID hello — claim the slot now (reject a second valid extension).
                    if _is_open(self._extension) and self._extension is not ws:
                        if not self._reload_pending:
                            log.warning("rejecting duplicate extension (one already connected)")
                            await ws.close(code=4001, reason="already connected")
                            return
                        # 8d: we asked the extension to reload and its NEW connection said a valid
                        # hello (app-id + token checked above) before the old socket's close was seen.
                        # The new connection takes the slot; the old one is closed.
                        old = self._extension
                        self._extension = None
                        try:
                            await old.close(code=4004, reason="replaced after reload")
                        except Exception:  # noqa: BLE001
                            pass
                    self._extension = ws
                    claimed = True
                    self._hello = msg
                    self._hello_seq += 1
                    log.info("extension hello: app=%s v%s allowlist=%s methods=%s jobKinds=%s",
                             msg.get("app"), msg.get("extensionVersion"),
                             msg.get("allowlist"), msg.get("methods"), msg.get("jobKinds"))
                    self._connected_event.set()
                    self._hello_event.set()
                    continue
                # An unvalidated peer (no valid hello yet) cannot drive jobs or be
                # treated as the extension — ignore everything until it says a real hello.
                if not claimed:
                    continue
                if kind == "ping":
                    continue
                if kind == "challenge":
                    # /login redirect detected in the page — OTP/login wall.
                    # TODO(Phase 6): surface a CHALLENGE that PAUSES ingestion
                    #   (never write a partial period the completeness gate would
                    #   read as "all done"); the human completes SMS OTP in their
                    #   own tab and re-runs. See docs/V2_PLAN.md §3.3.
                    log.warning("CHALLENGE reported by extension: %s", msg.get("detail"))
                    continue
                job_id = msg.get("id")
                if not job_id:
                    log.warning("response without id: %s", str(msg)[:200])
                    continue
                job = self._pending.pop(job_id, None)
                if job is None:
                    log.warning("response for unknown job %s", job_id)
                    continue
                if job.future.done():
                    continue
                if msg.get("error"):
                    job.future.set_exception(BridgeError(msg["error"]))
                else:
                    job.future.set_result(BridgeJobResult(
                        status=msg.get("status", 0),
                        url=msg.get("url", ""),
                        content_type=msg.get("contentType", ""),
                        body=msg.get("body", ""),
                    ))
        finally:
            # Only tear down shared state if THIS connection actually held the slot —
            # an unvalidated peer disconnecting must not clear the real extension.
            if claimed and self._extension is ws:
                log.info("extension disconnected")
                self._extension = None
                self._connected_event.clear()
                # Fail any in-flight jobs immediately instead of letting each hang for
                # the full job_timeout: if the SW died / extension closed mid-job, the
                # adapter should get a prompt BridgeError (-> per-row needs_review).
                for jid, job in list(self._pending.items()):
                    if not job.future.done():
                        job.future.set_exception(_ExtensionDisconnected("extension disconnected mid-job"))
                self._pending.clear()

    async def _send_job(
        self, url: str, method: str = "GET", headers: dict | None = None,
        *, kind: str = "fetch", timeout: float | None = None,
    ) -> BridgeJobResult:
        """Send one job (kind "fetch" GET/HEAD, or "render") to the extension and
        await its response. Python-side half of the two-layer allowlist: URL (and,
        for fetch, the method) are re-checked here even though the extension guards too.
        """
        if not ALLOWLIST_RE.match(url):
            raise BridgeError(f"URL not allowed (must match https://*.airbnb.com/): {url}")
        if kind == "fetch" and method.upper() not in ALLOWED_METHODS:
            raise BridgeError(f"method {method} not allowed (GET/HEAD only)")
        ext = self._extension
        if not _is_open(ext):
            raise BridgeError("extension not connected")
        job_id = str(uuid.uuid4())
        fut: "asyncio.Future" = asyncio.get_event_loop().create_future()
        self._pending[job_id] = _PendingJob(future=fut)
        payload = {"id": job_id, "kind": kind, "url": url}
        if kind == "fetch":
            payload["method"] = method.upper()
            payload["headers"] = headers or {}
        try:
            await ext.send(json.dumps(payload))
        except Exception as e:
            self._pending.pop(job_id, None)
            raise BridgeError(f"failed to send job: {e}") from e
        budget = timeout if timeout is not None else self.job_timeout
        try:
            return await asyncio.wait_for(fut, timeout=budget)
        except asyncio.TimeoutError:
            self._pending.pop(job_id, None)
            raise BridgeError(f"job timed out after {budget}s")

    async def render_text(self, url: str, *, timeout: float = 45.0) -> str:
        """Render a client-rendered page in a background tab and return its extracted
        text (for archival/cross-check of the client-only invoice; see extractors)."""
        r = await self._send_job(url, kind="render", timeout=timeout)
        if r.status >= 400:
            raise BridgeError(f"render {r.status} from {url}")
        return r.body

    # ---------- High-level helpers (stubs) ----------

    async def fetch_text(self, url: str, headers: dict | None = None) -> str:
        """GET ``url`` via the extension and return the response body as text.

        Used for VAT invoice HTML (``GET /<invoice_url>``).
        """
        # TODO(Phase 6): finalise error semantics — e.g. a /login redirect body
        #   should raise a CHALLENGE-typed error so the adapter pauses the period
        #   rather than ingesting a login page. See docs/V2_PLAN.md §3.3.
        r = await self._send_job(url, "GET", headers)
        if r.status >= 400:
            raise BridgeError(f"HTTP {r.status} from {url}")
        return r.body

    async def fetch_json(self, url: str, headers: dict | None = None) -> Any:
        """GET ``url`` via the extension and parse the body as JSON.

        Used for the reservations list (``GET /api/v2/reservations?...``).
        """
        # TODO(Phase 6): attach X-Airbnb-API-Key header for the reservations API
        #   (the public web key is a SHARED CONSTANT, set by the adapter, not
        #   stored here). Detect a login-page HTML body returned with status 200
        #   and convert to a CHALLENGE. See docs/V2_PLAN.md CAPTURE MECHANISM.
        r = await self._send_job(url, "GET", headers)
        if r.status >= 400:
            raise BridgeError(f"HTTP {r.status} from {url}: {r.body[:200]}")
        try:
            return json.loads(r.body)
        except json.JSONDecodeError as e:
            raise BridgeError(
                f"non-JSON response from {url}: {e}; body[:200]={r.body[:200]!r}"
            )


@asynccontextmanager
async def host_bridge(**kwargs):
    """``async with host_bridge() as bridge:`` — convenience wrapper.

    Does start + wait_for_extension + reload_if_stale (8d: a stale extension that
    can reload itself is asked to, once) + ensure_fresh_extension (HARD ABORT on a
    stale extractor), then stops the server on exit.
    """
    bridge = HostBridge(**kwargs)
    try:
        await bridge.start()
        await bridge.wait_for_extension()
        await bridge.reload_if_stale()
        bridge.ensure_fresh_extension()
        yield bridge
    finally:
        await bridge.stop()
