// Minimal connection-status UI for the Green Receipts Bridge popup.

function fmtTime(ms) {
  if (!ms) return "—";
  const s = Math.round((Date.now() - ms) / 1000);
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  return `${h}h ago`;
}

function render(state, bridgeUrl) {
  const el = document.getElementById("state");
  el.textContent = ({
    connected: "Connected",
    connecting: "Connecting…",
    disconnected: "CLI not running",
    idle: "Idle",
    error: "Error",
  })[state.state] || state.state;
  el.className = "state " + state.state;
  document.getElementById("bridge").textContent = bridgeUrl || "—";
  document.getElementById("jobs").textContent = state.jobsHandled ?? 0;
  document.getElementById("since").textContent = fmtTime(state.since);
  document.getElementById("err").textContent = state.lastError || "—";
}

async function refresh() {
  try {
    const resp = await chrome.runtime.sendMessage({ kind: "get-status" });
    if (resp && resp.status) render(resp.status, resp.bridgeUrl);
  } catch (e) {
    // service worker may be cold-starting; show idle
    render({ state: "idle", since: Date.now(), lastError: null, jobsHandled: 0 }, "");
  }
}

document.getElementById("reconnect").addEventListener("click", async () => {
  try {
    await chrome.runtime.sendMessage({ kind: "reconnect" });
  } catch (e) {}
  setTimeout(refresh, 250);
});

// Bridge port: pairs THIS Chrome profile with ONE Green Receipts instance (empty = the default).
(async () => {
  try {
    const r = await chrome.storage.local.get("bridgePort");
    if (r.bridgePort) document.getElementById("port").value = r.bridgePort;
  } catch (e) {}
})();
document.getElementById("savePort").addEventListener("click", async () => {
  const raw = document.getElementById("port").value.trim();
  const n = Number(raw);
  const out = document.getElementById("portStatus");
  if (raw && !(Number.isInteger(n) && n >= 1024 && n <= 65535)) {
    out.textContent = "That number doesn't look right — copy it exactly from Green Receipts.";
    return;
  }
  try {
    if (raw) await chrome.storage.local.set({ bridgePort: n });
    else await chrome.storage.local.remove("bridgePort");
    out.textContent = raw ? `Saved (${n}). Connecting…` : "Cleared. Connecting…";
    await chrome.runtime.sendMessage({ kind: "reconnect" });
  } catch (e) {
    out.textContent = "Couldn't save — close this box and try again.";
    console.warn("bridgePort save failed", e);
  }
  setTimeout(refresh, 250);
});

// Shared bridge token: load the saved value, save on click, then reconnect so the
// new token is sent in the next hello.
(async () => {
  try {
    const r = await chrome.storage.local.get("bridgeToken");
    if (r.bridgeToken) document.getElementById("token").value = r.bridgeToken;
  } catch (e) {}
})();
document.getElementById("saveToken").addEventListener("click", async () => {
  const tok = document.getElementById("token").value.trim();
  try {
    await chrome.storage.local.set({ bridgeToken: tok });
    document.getElementById("tokenStatus").textContent = tok ? "Saved. Reconnecting…" : "Cleared.";
    await chrome.runtime.sendMessage({ kind: "reconnect" });
  } catch (e) {
    document.getElementById("tokenStatus").textContent = "Save failed: " + e;
  }
  setTimeout(refresh, 250);
});

// Listen for pushed status updates while the popup is open.
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.kind === "status") {
    render(msg.status, "");
  }
});

refresh();
setInterval(refresh, 1000);
