// Green Receipts Bridge — MV3 service worker.
//
// Connects OUT to the local Green Receipts CLI when it is running, accepts
// fetch jobs over a WebSocket, executes them against *.airbnb.com (cookies
// attached automatically by Chrome because of host_permissions), and returns
// the response body. Adapted from the AL Analytics Host Bridge.
//
// HARD RULES (the two-layer GET-only allowlist; mirrored on the Python side):
//   * Only URLs matching https://*.airbnb.com/* are accepted.
//   * Only GET and HEAD methods are accepted. No POST/PUT/DELETE — this bridge
//     can read your reservations + VAT invoices, never mutate Airbnb state.
//   * Cookie/authorization/origin headers from incoming jobs are STRIPPED —
//     Chrome attaches the real session cookies itself (credentials:'include').
//   * No arbitrary JS from the bridge — jobs are plain {url, method, headers}.
//   * The extension never logs in and never sees your password or OTP. If
//     Airbnb shows a /login wall, we report CHALLENGE and the human resolves it
//     in their own tab (OTP = human).
//
// The service worker stays alive while the WebSocket is open; when the CLI
// exits the WS closes and the SW idles until the next reconnect attempt.

// Port 18482 is DELIBERATELY distinct from the AL Analytics Host Bridge (18472),
// which this was adapted from and which speaks the same /bridge protocol — so the
// two projects' extensions never connect to each other's bridge. Keep in sync
// with airbnb_bridge/host_bridge.py DEFAULT_PORT.
// MULTI-INSTANCE: several Green Receipts deployments can run on one laptop (instance.py), each
// with its own bridge port. Each Chrome PROFILE (one per Airbnb account) is paired with ONE
// instance by setting its port in the popup (chrome.storage "bridgePort"); unset = the default.
const DEFAULT_BRIDGE_PORT = 18482;
let bridgePort = DEFAULT_BRIDGE_PORT;
function bridgeUrl() { return `ws://127.0.0.1:${bridgePort}/bridge`; }
function validPort(p) { const n = Number(p); return Number.isInteger(n) && n >= 1024 && n <= 65535 ? n : null; }
async function loadBridgePort() {
  try {
    const r = await chrome.storage.local.get("bridgePort");
    bridgePort = validPort(r.bridgePort) || DEFAULT_BRIDGE_PORT;
  } catch (e) { bridgePort = DEFAULT_BRIDGE_PORT; }
}
const RECONNECT_ALARM = "gr-bridge-reconnect";
const KEEPALIVE_ALARM = "gr-bridge-keepalive";

// SHARED CONSTANTS — keep verbatim in sync with airbnb_bridge/host_bridge.py.
// BRIDGE_APP_ID lets our bridge accept ONLY this extension (and reject AL's).
const BRIDGE_APP_ID = "green-receipts-bridge";
const URL_ALLOWLIST = /^https:\/\/([a-z0-9-]+\.)*airbnb\.com\//i;
const METHOD_ALLOWLIST = new Set(["GET", "HEAD"]);

let ws = null;
let status = { state: "idle", since: Date.now(), lastError: null, jobsHandled: 0 };

function setStatus(state, lastError = null) {
  status = { state, since: Date.now(), lastError, jobsHandled: status.jobsHandled };
  // Broadcast to the popup if it is open (ignored if not).
  chrome.runtime.sendMessage({ kind: "status", status }).catch(() => {});
}

// Detect an Airbnb /login redirect or login page in a response. When the warm
// session has expired, Airbnb 302s API/invoice GETs to a login page; we must
// NOT treat that HTML/JSON as data (it would silently capture an empty period).
function looksLikeLogin(finalUrl, body) {
  try {
    if (/\/login(\?|$)/i.test(finalUrl || "")) return true;
    const head = String(body || "").slice(0, 4000).toLowerCase();
    // The /login URL test above is locale-independent. So are the JSON markers below ('"page_name":"login"',
    // "auth/login") — these MUST be here because reservations()/stay_details() in the Python adapter only
    // pause on a raised error; they never re-scan a parsed body, so this is the SOLE scanner for a
    // 200-status JSON login body on the live reservations path. The text markers are a fallback and carry
    // both EN ("log in to airbnb") and PT ("iniciar/inicie sessão") so a Portuguese login wall served as
    // 200-status HTML is not mistaken for data (which would silently capture an empty period).
    return head.includes('"page_name":"login"') || head.includes("auth/login") ||
           head.includes("log in to airbnb") ||
           head.includes("iniciar sessão") || head.includes("inicie sessão") ||
           head.includes("iniciar sessao") || head.includes("inicie sessao") ||
           (head.includes("/login") && head.includes("redirect_url"));
  } catch (e) {
    return false;
  }
}

// Perform the actual GET/HEAD from the service worker. host_permissions over
// *.airbnb.com lets credentials:'include' attach the real session cookies.
async function doFetch(url, method, headers) {
  const r = await fetch(url, {
    method,
    credentials: "include",
    headers,
    redirect: "follow",
  });
  const body = method === "HEAD" ? "" : await r.text();
  return {
    status: r.status,
    url: r.url,
    contentType: r.headers.get("content-type") || "",
    body,
  };
}

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

// Wait until the tab finishes loading (or a timeout), so a client-rendered page has
// had a chance to hydrate before we read its DOM.
function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    const start = Date.now();
    const check = () => {
      chrome.tabs.get(tabId, (t) => {
        if (chrome.runtime.lastError || !t) return resolve();
        if (t.status === "complete" || Date.now() - start > timeoutMs) return resolve();
        setTimeout(check, 250);
      });
    };
    check();
  });
}

// Render-then-extract: open `url` in a hidden background tab on the user's session,
// let it hydrate, read document.body.innerText (read-only), then ALWAYS close the tab.
async function renderJob(id, url) {
  if (!URL_ALLOWLIST.test(url)) {
    return { id, error: "URL not in allowlist (render): must match https://*.airbnb.com/*" };
  }
  let tab = null;
  try {
    tab = await chrome.tabs.create({ url, active: false });
    await waitForTabComplete(tab.id, 20000);
    await sleep(1800); // settle client-side hydration
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => ((document.body && document.body.innerText) || ""),
    });
    const text = (results && results[0] && results[0].result) || "";
    let finalUrl = url;
    try { const t = await chrome.tabs.get(tab.id); finalUrl = t.url || url; } catch (e) {}
    if (!URL_ALLOWLIST.test(finalUrl)) {
      return { id, error: "render redirected off-allowlist to " + finalUrl };
    }
    if (looksLikeLogin(finalUrl, text)) {
      try { ws.send(JSON.stringify({ kind: "challenge", detail: "login wall on render " + url })); } catch (e) {}
      return { id, error: "CHALLENGE: Airbnb returned a login page during render." };
    }
    status.jobsHandled += 1;
    return { id, status: 200, url: finalUrl, contentType: "text/plain", body: text };
  } catch (e) {
    return { id, error: "render failed: " + String(e) };
  } finally {
    if (tab && tab.id != null) {
      try { await chrome.tabs.remove(tab.id); } catch (e) {}
    }
  }
}

// Self-reload (0.8.0+): the app asks for it when Chrome is running older extension files than the
// ones in the install folder, so nobody has to reload the extension by hand. Accepted ONLY on the
// bridge connection this extension opened and said its hello on (the bridge checked app-id + token
// before it sends any job), and at most once a minute, so nothing can keep the extension in a
// reload loop. chrome.runtime.reload() needs no extra permission. It fetches nothing.
const SELF_RELOAD_MIN_GAP_MS = 60000;
async function reloadJob(id, sock) {
  if (!sock || sock !== ws || !sock.grHelloSent || sock.readyState !== WebSocket.OPEN) {
    return { id, error: "reload refused: not the authenticated bridge connection" };
  }
  let last = 0;
  try { const r = await chrome.storage.local.get("lastSelfReloadAt"); last = Number(r.lastSelfReloadAt) || 0; } catch (e) {}
  if (Date.now() - last < SELF_RELOAD_MIN_GAP_MS) {
    return { id, error: "reload refused: this extension reloaded less than a minute ago" };
  }
  try { await chrome.storage.local.set({ lastSelfReloadAt: Date.now() }); } catch (e) {}
  // Answer first; onmessage calls chrome.runtime.reload() right after sending this.
  return { id, status: 200, url: "", contentType: "text/plain", body: "reloading", reloadAfterSend: true };
}

async function handleJob(rawJob, sock) {
  let job;
  try {
    job = JSON.parse(rawJob);
  } catch (e) {
    return { error: "invalid JSON job" };
  }
  if (!job || typeof job !== "object" || !job.id) {
    return { error: "job missing id" };
  }
  const kind = job.kind || "fetch";
  if (kind === "reload") {
    return reloadJob(job.id, sock);
  }
  if (kind === "render") {
    // Render a client-rendered page (e.g. a VAT invoice SPA) in a background tab and
    // extract its rendered text — for archival/cross-check only (the emit fee comes
    // from a plain GET). Same *.airbnb.com allowlist, read-only (innerText), tab closed.
    return renderJob(job.id, job.url || "");
  }
  if (kind !== "fetch") {
    return { id: job.id, error: `unknown job kind "${kind}"; only "fetch"/"render"/"reload" supported` };
  }

  const id = job.id;
  const url = job.url || "";
  const method = (job.method || "GET").toUpperCase();
  const headers = job.headers || {};

  // ---- Two-layer allowlist guard (layer 1 of 2; Python re-guards) ----
  if (!URL_ALLOWLIST.test(url)) {
    return { id, error: "URL not in allowlist: must match https://*.airbnb.com/*" };
  }
  if (!METHOD_ALLOWLIST.has(method)) {
    return { id, error: `method ${method} not allowed; only GET/HEAD` };
  }

  // Strip any cookie/auth/origin headers the caller tried to set — the browser
  // owns the session. (X-Airbnb-API-Key is allowed through; it is the public
  // web key, not a secret.)
  const safeHeaders = {};
  for (const k of Object.keys(headers)) {
    if (/^(cookie|set-cookie|authorization|origin|referer|host)$/i.test(k)) continue;
    safeHeaders[k] = headers[k];
  }

  // TODO(Phase 6): confirm a direct service-worker fetch carries the session
  //   cookies for the reservations REST API + invoice pages (it should — these
  //   are plain on-domain GETs, unlike the GraphQL gateway which needed a real
  //   tab Origin). If a tab Origin turns out to be required, re-introduce the
  //   `tabs` + `scripting` MAIN-world fetch from the AL bridge (kept minimal).
  try {
    const r = await doFetch(url, method, safeHeaders);
    // Post-redirect guard: redirect:'follow' means r.url is the FINAL url after
    // any 3xx hops. The request url was allowlisted, but the response we are
    // about to return must ALSO be on *.airbnb.com — never hand back a body
    // fetched from somewhere a redirect bounced us to. (Cookies are per-origin so
    // none leaked, but the invariant is "only ever read *.airbnb.com".)
    if (r.url && !URL_ALLOWLIST.test(r.url)) {
      return { id, error: "redirected off-allowlist to " + r.url + "; refusing to return body" };
    }
    if (looksLikeLogin(r.url, r.body)) {
      // Pause, do not return data: report a CHALLENGE the CLI surfaces to the
      // human (complete SMS OTP in your own tab, then re-run). OTP = human.
      try {
        ws.send(JSON.stringify({ kind: "challenge", detail: "login wall on " + url }));
      } catch (e) {}
      return { id, error: "CHALLENGE: Airbnb returned a login page; log in in your browser and re-run." };
    }
    status.jobsHandled += 1;
    return { id, status: r.status, url: r.url, contentType: r.contentType, body: r.body };
  } catch (e) {
    return { id, error: `fetch failed: ${String(e)}` };
  }
}

function scheduleReconnect(delaySec = 5) {
  chrome.alarms.create(RECONNECT_ALARM, { delayInMinutes: delaySec / 60 });
}

function clearReconnect() {
  chrome.alarms.clear(RECONNECT_ALARM);
}

let connectPending = false;
async function connect() {
  if (connectPending) return;
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }
  connectPending = true;
  try { await loadBridgePort(); } finally { connectPending = false; }
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }
  setStatus("connecting");
  try {
    ws = new WebSocket(bridgeUrl());
  } catch (e) {
    setStatus("error", String(e));
    scheduleReconnect(10);
    return;
  }
  const sock = ws;
  ws.onopen = async () => {
    setStatus("connected");
    clearReconnect();
    // The optional shared bridge token (set once via the popup) — the bridge rejects
    // a hello without it when token enforcement is on (multi-user hardening for an operator's shared laptops).
    let bridgeToken = "";
    try { const r = await chrome.storage.local.get("bridgeToken"); bridgeToken = r.bridgeToken || ""; } catch (e) {}
    // Hello handshake — carries the version so the CLI's freshness gate can
    // HARD-ABORT if Chrome is running a stale extractor (v2 safety property).
    try {
      ws.send(JSON.stringify({
        kind: "hello",
        app: BRIDGE_APP_ID,
        token: bridgeToken,
        extensionVersion: chrome.runtime.getManifest().version,
        bridgePort,
        allowlist: "https://*.airbnb.com/*",
        methods: ["GET", "HEAD"],
        // "reload" tells the app this extension can reload itself (0.8.0+); older ones never get asked.
        jobKinds: ["fetch", "render", "reload"],
      }));
      sock.grHelloSent = true;
    } catch (e) {}
    // 30s = Chrome's real minimum alarm period (sub-minute is clamped to 30s for
    // installed extensions). The bridge's WS ping_interval=20s also keeps the SW warm.
    chrome.alarms.create(KEEPALIVE_ALARM, { periodInMinutes: 0.5 });
  };
  ws.onmessage = async (evt) => {
    const result = await handleJob(evt.data, sock);
    const reloadAfterSend = !!(result && result.reloadAfterSend);
    if (result) delete result.reloadAfterSend;
    try {
      sock.send(JSON.stringify(result));
    } catch (e) {
      // socket may have closed mid-job; nothing to do
    }
    if (reloadAfterSend) setTimeout(() => { try { chrome.runtime.reload(); } catch (e) {} }, 250);
  };
  ws.onerror = () => {
    setStatus("error", "websocket error");
  };
  ws.onclose = () => {
    setStatus("disconnected");
    chrome.alarms.clear(KEEPALIVE_ALARM);
    scheduleReconnect(5);
  };
}

// Activate on install/update or browser startup.
chrome.runtime.onInstalled.addListener(() => {
  setStatus("idle");
  connect();
});
chrome.runtime.onStartup.addListener(() => {
  setStatus("idle");
  connect();
});

// Alarm-driven reconnect + keepalive (keeps the SW alive while connected).
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === RECONNECT_ALARM) {
    connect();
  } else if (alarm.name === KEEPALIVE_ALARM) {
    if (ws && ws.readyState === WebSocket.OPEN) {
      try {
        ws.send(JSON.stringify({ kind: "ping", t: Date.now() }));
      } catch (e) {}
    }
  }
});

// Popup status query / manual reconnect.
chrome.runtime.onMessage.addListener((req, _sender, sendResponse) => {
  if (req && req.kind === "get-status") {
    sendResponse({ status, bridgeUrl: bridgeUrl() });
    return true;
  }
  if (req && req.kind === "reconnect") {
    // Close whatever is open OR still connecting (a port change must drop the old socket).
    try {
      if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
        const old = ws; ws = null; old.onclose = null; old.close();
      }
    } catch (e) {}
    connect();
    sendResponse({ ok: true });
    return true;
  }
});

// Kick off immediately in case neither onInstalled nor onStartup fires (e.g.
// the SW was just woken by an event).
connect();
