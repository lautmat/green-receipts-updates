"""log_client.py — two-tier logging (Phase 11, objective 12).

Tier 1 (local, authoritative): a rotating file with ALL levels + full detail.
Tier 2 (online, remote-debug): a buffered, batched, BEST-EFFORT poster to the
serializer `log` op -> the `LOG` tab. Online logging is NON-BLOCKING — a POST
failure is swallowed and re-buffered, never raised into the app, so the tool keeps
working offline.

Redaction is SECRETS-ONLY (owner decision 2026-06-22): credentials/tokens/keys are
scrubbed; raw guest names + full NIFs are intentionally KEPT (the LOG is the
accountant's own client data, private to the firm account) — the opposite of the
source-commit secret-scan, which flags real NIFs in code.
"""
from __future__ import annotations

import atexit
import json
import logging
import logging.handlers
import re
import socket
import threading
import time
import uuid
from pathlib import Path

# Per-process correlation id (so one capture/emit run's events group together).
RUN_ID = uuid.uuid4().hex[:12]

# --- SECRETS-only redaction (keep NIFs + guest names) --------------------------
_CRED = r'api[_-]?token|token|password|passwd|pwd|pass|secret|api[_-]?key|authorization|auth|credential|bearer'
_REDACT = [
    (re.compile(r'(Bearer\s+)[A-Za-z0-9._\-+/=]+', re.I), r'\1***'),  # before key=value (has a space)
    # QUOTED credential value: key": "anything-including-spaces-and-commas"
    (re.compile(r'((?:' + _CRED + r')["\']?\s*[:=]\s*)(["\'])(.*?)\2', re.I), r'\1\2***\2'),
    # bare credential value: key=token  (stops at whitespace/quote/comma/brace)
    (re.compile(r'((?:' + _CRED + r')["\']?\s*[:=]\s*)([^"\'\s,}\]]+)', re.I), r'\1***'),
    (re.compile(r'\bgrv2-[A-Za-z0-9_-]+'), 'grv2-***'),                # serializer token shape
    (re.compile(r'(jsessionid=)[^\s;?&"\']+', re.I), r'\1***'),        # URL-embedded live session id
    (re.compile(r'(/macros/s/)[A-Za-z0-9_-]{20,}(/exec)'), r'\1***\2'),  # /exec deployment id (secret-equiv URL)
    (re.compile(r'\bAKfycb[A-Za-z0-9_-]{20,}'), 'AKfycb***'),
]


def scrub(text) -> str:
    """Redact credentials/tokens; leave NIFs, guest names, hm codes intact."""
    s = str(text)
    for pat, repl in _REDACT:
        s = pat.sub(repl, s)
    return s


class OnlineLogHandler(logging.Handler):
    """Buffers events and delivers batches to the serializer `log` op on a BACKGROUND
    daemon thread, so emit() (the app thread) only ever appends to an in-memory buffer
    and NEVER touches the network — logging cannot block or raise into the app. The
    worker POSTs on a nudge (>= batch_size) or every flush_interval; a failed/raising
    delivery re-buffers (re-capped to max_buffer)."""

    def __init__(self, post_fn, *, operator_id, component, level=logging.INFO,
                 batch_size=20, flush_interval=5.0, host=None, max_buffer=2000):
        super().__init__(level)
        self.post_fn = post_fn          # callable(events:list[dict]) -> bool (truthy = delivered)
        self.operator_id = operator_id
        self.component = component
        self.host = host or socket.gethostname()
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        self.max_buffer = max_buffer
        self._buf: list[dict] = []
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._worker = threading.Thread(target=self._run, name="grv2-log", daemon=True)
        self._worker.start()
        atexit.register(self.close)

    def _event(self, record: logging.LogRecord) -> dict:
        return {
            "run_id": RUN_ID,
            "operator_id": self.operator_id,
            "host": self.host,
            "level": record.levelname,
            "component": getattr(record, "component", self.component),
            "op": getattr(record, "op", ""),
            "entity_id": getattr(record, "entity_id", ""),
            "result": getattr(record, "result", ""),
            "message": scrub(record.getMessage()),
            "detail": scrub(getattr(record, "detail", "")),
        }

    def emit(self, record):
        # NON-BLOCKING: append to the buffer + nudge the worker. No network here.
        try:
            ev = self._event(record)
            with self._lock:
                self._buf.append(ev)
                if len(self._buf) > self.max_buffer:           # bound memory if offline for long
                    del self._buf[:-self.max_buffer]
                n = len(self._buf)
            if n >= self.batch_size:
                self._wake.set()
        except Exception:
            pass  # logging must NEVER raise into the app

    def _run(self):
        while not self._stop.is_set():
            self._wake.wait(self.flush_interval)
            self._wake.clear()
            self._drain()

    def _drain(self):
        with self._lock:
            batch, self._buf = self._buf, []
        if not batch:
            return
        try:
            delivered = bool(self.post_fn(batch))
        except Exception:
            delivered = False  # never raise
        if not delivered:
            with self._lock:                  # re-buffer + RE-CAP the whole buffer (bound stays max_buffer)
                self._buf[:0] = batch
                if len(self._buf) > self.max_buffer:
                    del self._buf[:-self.max_buffer]

    def flush(self):
        # Synchronous drain — used by tests + at shutdown; NOT on the emit() hot path.
        self._drain()

    def close(self):
        self._stop.set()
        self._wake.set()
        try:
            self._worker.join(timeout=3)
        except Exception:
            pass
        self._drain()  # final best-effort drain at shutdown
        super().close()


def make_serializer_poster(url, token, operator_id, requests_mod=None):
    """A post_fn that POSTs a batch to the serializer `log` op. Returns True on a
    successful append, False otherwise (the handler re-buffers)."""
    def post(events):
        r = requests_mod
        if r is None:
            import requests as r
        try:
            resp = r.post(url, data=json.dumps({
                "op": "log", "api_token": token, "operator_id": operator_id, "events": events}),
                headers={"Content-Type": "application/json"}, timeout=(3.05, 10))  # (connect, read)
            body = resp.json()
            return isinstance(body, dict) and body.get("error") is None and body.get("appended") is not None
        except Exception:
            return False
    return post


def make_http_poster(url, *, secret=None, source=None, requests_mod=None):
    """A post_fn that POSTs a batch of events as JSON to an arbitrary HTTPS collector — the
    CENTRAL troubleshooting endpoint (distinct from the per-firm LOG tab). Body:
    {"source", "operator_id", "host", "events"[]}; optional Bearer `secret`. Returns True on
    a 2xx (the handler drops the batch), False otherwise (the handler re-buffers + retries).
    Best-effort: any exception -> False, never raised into the app (same contract as the
    serializer poster). Redaction already happened in OnlineLogHandler._event before batching."""
    def post(events):
        r = requests_mod
        if r is None:
            import requests as r
        payload = {"source": source or "grv2", "events": events}
        headers = {"Content-Type": "application/json"}
        if secret:
            headers["Authorization"] = f"Bearer {secret}"
        try:
            resp = r.post(url, data=json.dumps(payload), headers=headers, timeout=(3.05, 10))
            return 200 <= resp.status_code < 300
        except Exception:
            return False
    return post


class _FileFormatter(logging.Formatter):
    """The local grv2.log line = the classic format PLUS the structured log_event fields, so the
    local file carries the same debugging detail as the sheet's LOG tab (it used to keep only the
    headline). Scrubbed the same way as the online sink; plain logger.info() lines are unchanged."""

    def format(self, record):
        line = super().format(record)
        extras = [f"{k}={getattr(record, k)}" for k in ("op", "entity_id", "result")
                  if getattr(record, k, "")]
        detail = getattr(record, "detail", "")
        if detail:
            extras.append(f"detail={detail}")
        return scrub(f"{line} | {' '.join(extras)}") if extras else line


def setup_logging(component, *, operator_id="local", serializer_url=None, api_token=None,
                  online_level=logging.INFO, log_dir=None, post_fn=None, online=True,
                  telemetry_url=None, telemetry_secret=None, telemetry_post_fn=None,
                  telemetry_level=None):
    """Configure the 'grv2' logger: a rotating local file (DEBUG+) plus, when an
    online sink is available, a best-effort batched poster (online_level+).

    Optional CENTRAL telemetry: pass telemetry_url (or telemetry_post_fn) to also fan out to
    a troubleshooting collector. It gets its OWN independent OnlineLogHandler — a separate
    buffer/retry loop — so a failure on one sink NEVER re-delivers to the other (no double
    post). Returns the logger. Idempotent-ish: clears prior handlers."""
    logger = logging.getLogger("grv2")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()
    logger.propagate = False

    if not log_dir:
        import instance
        log_dir = instance.config_dir() / "logs"
    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    fh = logging.handlers.RotatingFileHandler(log_dir / "grv2.log", maxBytes=2_000_000,
                                              backupCount=5, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(_FileFormatter("%(asctime)s %(levelname)-7s [%(name)s] %(message)s"))
    logger.addHandler(fh)

    if online:
        if post_fn is None and serializer_url and api_token:
            post_fn = make_serializer_poster(serializer_url, api_token, operator_id)
        if post_fn is not None:
            logger.addHandler(OnlineLogHandler(post_fn, operator_id=operator_id,
                                               component=component, level=online_level))
        # A SECOND, INDEPENDENT sink: the central telemetry collector. Its own handler =>
        # its own buffer + retry, so if the LOG-tab poster fails and this one succeeds (or
        # vice versa) neither re-delivers the other's batch.
        if telemetry_post_fn is None and telemetry_url:
            telemetry_post_fn = make_http_poster(telemetry_url, secret=telemetry_secret,
                                                 source=component)
        if telemetry_post_fn is not None:
            logger.addHandler(OnlineLogHandler(telemetry_post_fn, operator_id=operator_id,
                                               component=component,
                                               level=telemetry_level or online_level))
    return logger


def log_event(logger, level, message, *, op="", entity_id="", result="", detail="", component=None):
    """Emit a structured event (the extras land in the online LOG columns)."""
    extra = {"op": op, "entity_id": entity_id, "result": result, "detail": detail}
    if component:
        extra["component"] = component
    logger.log(level, message, extra=extra)
