"""Document archival (Phase 6b/8b) — Drive folder routing + invoice cross-check.

Two tracks (V2_PLAN "DOCUMENT ARCHIVAL"):
  Track 1 (6b): archive every reservation's VAT (commission) invoice(s) and record
                the metadata + Drive URL via the serializer `recordInvoice` op.
  Track 2 (8b): archive each issued Fatura-Recibo PDF via `recordReceiptPdf`.

This module holds the PURE, testable pieces: the contamination-safe Drive folder
routing (one folder per client, sub-folder per property — the SAME listing ->
property -> client mapping as emission, so a document can never be filed under the
wrong client) and the invoice cross-check that verifies the StayHostingDetailsQuery
fee we emitted against the authoritative VAT invoice.

The binary half — rendering the client-only invoice to a clean PDF and uploading to
Drive — is deployment wiring (needs Drive scope + the Phase-6b render-then-extract);
the serializer ops + this routing/verification are the backbone it plugs into.
"""
from __future__ import annotations

import os
import re
import time
from datetime import date
from pathlib import Path
from urllib.parse import quote

from airbnb_bridge.reservations_adapter import parse_service_fee

DRIVE_ROOT = "GreenReceipts"
PORTAL_BASE = "https://irs.portaldasfinancas.gov.pt"


def default_pdf_root() -> Path:
    """Local folder where issued Fatura-Recibo PDFs are ALWAYS saved (independent of Google
    Drive). Overridable with GRV2_PDF_DIR (config.bat can point it at a friendlier place);
    defaults under the app's config dir so a PDF is never lost even if Drive isn't set up."""
    env = os.environ.get("GRV2_PDF_DIR")
    if env:
        return Path(env)
    import instance
    return instance.config_dir() / "receipts"


def receipt_pdf_url(nif, user_id, numero_unico, *, variant: str = "normal", base: str = PORTAL_BASE) -> str:
    """Build the OFFICIAL Fatura-Recibo PDF URL (the route the consultar detail view's
    ``onPressImprimir`` actually fires). TWO non-obvious rules — both REQUIRED, or the
    Portal answers "Recibo inexistente":

      1. the ``/`` in ``numeroUnico`` becomes ``-``  ("FR ATSIRE01FR/117" -> "FR ATSIRE01FR-117")
      2. a trailing ``/{variant}`` segment ("normal" | "economico")

    (The list-view "Imprimir" builds it WITHOUT these and 404s/"inexistente"; the working
    form was found 2026-06-23 by a DevTools network capture and verified to return
    application/pdf.) ``user_id`` is the record's ``userId`` (0 for these receipts)."""
    seg = quote(str(numero_unico).replace("/", "-"), safe="-")
    return f"{base}/recibos/portal/imprimirV2/{nif}/{user_id}/{seg}/{variant}"


def fetch_receipt_pdf(session, *, nif, user_id, numero_unico, num_doc=None,
                      variant: str = "normal", retries: int = 4, sleeper=None,
                      base: str = PORTAL_BASE):
    """GET the official Fatura-Recibo PDF bytes (or None if it never yields a PDF).

    A just-issued receipt can briefly 503 (the PDF isn't generated yet) — retry on 503
    only; any other non-PDF response stops. The Referer mirrors the detail view, as the
    browser sends. ``session`` must be an authenticated Portal session (emit_receipt.login)."""
    if sleeper is None:
        sleeper = lambda: time.sleep(3)
    from emit_receipt import COMMON_HEADERS
    url = receipt_pdf_url(nif, user_id, numero_unico, variant=variant, base=base)
    referer = f"{base}/recibos/portal/consultar/detalheV2/{nif}/{user_id}/{num_doc if num_doc is not None else ''}"
    for attempt in range(max(1, retries)):
        r = session.get(url, headers={**COMMON_HEADERS, "Referer": referer})
        if r.content[:4] == b"%PDF":
            return r.content
        if r.status_code != 503:
            break
        sleeper()
    return None


def _safe(name: str) -> str:
    """Folder-name-safe: collapse separators/control chars, trim. Never empty."""
    s = re.sub(r"[\\/\x00-\x1f]+", " ", str(name or "")).strip()
    s = re.sub(r"\s+", " ", s)
    return s or "_unknown"


def drive_folder_path(client: str, property_label: str, *, root: str = DRIVE_ROOT) -> str:
    """The archival folder for one stay: ``<root>/<client>/<property>``.

    Routing mirrors emission (listing -> property -> client), so a document is
    always filed under the same client/property the receipt was issued for.
    """
    return "/".join([root, _safe(client), _safe(property_label)])


def portal_doc_record(session, nif_prestador, num_doc, *, base: str = PORTAL_BASE):
    """Look up one issued document (userId + numeroUnico + amounts) via obtemDocumentosV2
    over a 12-month window. Returns the record dict, or None if not found / query failed."""
    from datetime import date
    from emit_receipt import COMMON_HEADERS, CONSULTAR_REFERER
    today = date.today()
    month, year = today.month - 11, today.year
    if month <= 0:
        month += 12
        year -= 1
    start = date(year, month, 1)
    try:
        r = session.get(f"{base}/recibos/api/obtemDocumentosV2", params={
            "dataEmissaoInicio": start.isoformat(), "dataEmissaoFim": today.isoformat(),
            "nifPrestadorServicos": nif_prestador, "modoConsulta": "Prestador",
            "tipoPesquisa": "1", "tableSize": "500", "offset": "0", "isAutoSearchOn": "on"},
            headers={**COMMON_HEADERS, "Referer": CONSULTAR_REFERER})
        docs = r.json().get("listaDocumentos") or []
    except Exception:
        return None
    return next((d for d in docs if str(d.get("numDocumento")) == str(num_doc)), None)


def make_pdf_archiver(*, portal_session, nif_prestador, registry, drive_files=None,
                      serializer=None, local_root=None):
    """Build the ``emit_for_nif`` archiver hook: for the just-issued doc, fetch the official
    Fatura-Recibo PDF once and archive it to (1) a LOCAL folder — always, if ``local_root`` is
    set, so a PDF is never lost even without Google Drive — and (2) Google Drive, if ``drive_files``
    is configured (recording the Drive URL via recordReceiptPdf). Best-effort per destination;
    raises only if NEITHER destination stored the PDF (emit_for_nif counts it; the receipt stays
    filed and can be backfilled with tools/archive_receipt_pdf.py)."""
    def _archive(*, num_doc, row, session=None):
        prop = registry.resolve_listing(str(row.get("listing_id_str") or ""))
        client = prop.taxpayer_id if prop else str(row.get("taxpayer_nif") or "_unrouted")
        property_label = (prop.property_id if prop else "") or "_unrouted"
        rec = portal_doc_record(portal_session, nif_prestador, num_doc)
        if not rec:
            raise RuntimeError(f"doc {num_doc} not found at Portal for PDF archival")
        pdf = fetch_receipt_pdf(portal_session, nif=rec["nifPrestadorServicos"],
                                user_id=rec.get("userId", 0), numero_unico=rec["numeroUnico"], num_doc=num_doc)
        if not pdf or pdf[:4] != b"%PDF":
            raise RuntimeError(f"no official PDF for doc {num_doc}")
        name = f"FR-{num_doc}-{_safe(rec.get('nomeAdquirente') or '')}.pdf"
        results = []

        # (1) LOCAL save — always-on, independent of Drive. A local FS error is recorded but
        # doesn't by itself fail the archival (Drive may still succeed below).
        if local_root is not None:
            try:
                from pdf_store import receipt_local_path
                path = receipt_local_path(local_root, client, date.today().isoformat(), num_doc)
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "wb") as fh:
                    fh.write(pdf)
                results.append(path)
            except Exception:
                pass

        # (2) DRIVE — optional; records the URL. Swallowed here so a Drive hiccup can't discard a
        # successful local save; a total failure (no results) raises below.
        if drive_files is not None:
            try:
                from googleapiclient.http import MediaInMemoryUpload
                from drive_uploader import archive_document
                url = archive_document(drive_files, client=client, property_label=property_label,
                                       name=name, media=MediaInMemoryUpload(pdf, mimetype="application/pdf"))
                if serializer is not None:
                    serializer.record_receipt_pdf(row_id=row.get("row_id"), num_doc=num_doc, drive_url=url)
                results.append(url)
            except Exception:
                pass

        if not results:
            raise RuntimeError(f"could not archive PDF for doc {num_doc} (local + Drive both failed)")
        return results[0]

    return _archive


def cross_check_invoice_fee(captured_fee, invoice_fee, tol: float = 0.01) -> dict:
    """Verify the emitted fee (from StayHostingDetailsQuery) == the invoice fee.

    The invoice is the authoritative legal document; this confirms the GET-only fee
    source agreed with it. Returns ``{ok, captured, invoice, diff}``; a mismatch
    (|diff| > tol) is a flag for manual review, not an automatic correction.
    """
    cap = round(float(captured_fee), 2) if captured_fee is not None else None
    inv = round(float(invoice_fee), 2) if invoice_fee is not None else None
    if cap is None or inv is None:
        return {"ok": False, "captured": cap, "invoice": inv, "diff": None,
                "reason": "missing fee on one side"}
    diff = round(cap - inv, 2)
    return {"ok": abs(diff) <= tol, "captured": cap, "invoice": inv, "diff": diff}


def cross_check_invoice_html(captured_fee, invoice_html, tol: float = 0.01) -> dict:
    """As cross_check_invoice_fee but parses the rendered invoice HTML for its fee
    (reuses parse_service_fee). The id:0 invoice's Service Fee is the comparison."""
    parsed = parse_service_fee(invoice_html)
    res = cross_check_invoice_fee(captured_fee, parsed.get("service_fee"), tol=tol)
    res["invoice_number"] = parsed.get("invoice_number")
    res["reverse_charge"] = parsed.get("reverse_charge")
    return res
